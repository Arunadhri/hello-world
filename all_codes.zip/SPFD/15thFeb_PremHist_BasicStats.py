
# coding: utf-8

# In[1]:


import os
import pandas as pd
import numpy as np
from pandas import ExcelWriter

os.chdir(r'\\ns-sisci01hd\home_s01\Citrix_Folder_Redirect\Downloads\SPFD')


# In[2]:


df_clean= pd.read_pickle('clean_payment_hist_v2.pkl')


# In[3]:


other_data = pd.read_pickle('Data_For_Agent_Modelling_v2.pkl')


# In[4]:


#Getting the columns to be used from the master data
other_data = other_data[['KEY','AGENT1','LOB','ISSUE_DATE','PAYMENT_FREQUENCY','STATUS','MATURITY_DATE','ANNUAL_PREMIUM']]
other_data = other_data.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
other_data = other_data.drop_duplicates()
prem_hist_agent = df_clean.merge(other_data,how='inner',on='KEY')
prem_hist_agent = prem_hist_agent[prem_hist_agent['LOB']=='Life']


# In[5]:


#Ignoring rows which don't have annual premium
prem_hist_agent = prem_hist_agent[prem_hist_agent['ANNUAL_PREMIUM']>0]


# In[6]:


#Calculating delay parameters
prem_hist_agent['DelayInPayment(days)'] = (prem_hist_agent['PAYMENT_DATE'] - prem_hist_agent['PREMIUM_DUE_DATE']).dt.days
prem_hist_agent['IssuedToDueDate(days)'] = (prem_hist_agent['PREMIUM_DUE_DATE'] - prem_hist_agent['ISSUE_DATE']).dt.days
prem_hist_agent['IssuedtoPaymentDate(days)'] = (prem_hist_agent['PAYMENT_DATE'] - prem_hist_agent['ISSUE_DATE']).dt.days
prem_hist_agent['IssuedToMaturityDate(days)'] = (prem_hist_agent['MATURITY_DATE'] - prem_hist_agent['ISSUE_DATE']).dt.days
prem_hist_agent['PaymentToMaturityDate(days)'] = (prem_hist_agent['MATURITY_DATE'] - prem_hist_agent['PAYMENT_DATE']).dt.days


# In[7]:


#Ignoring rows which mature immediately
prem_hist_agent = prem_hist_agent[prem_hist_agent['IssuedToMaturityDate(days)']>0]


# In[8]:


#Getting the total premium paid for the policies
policy_amt_paid = prem_hist_agent.groupby(['KEY'])['PREMIUM_PAID'].sum().reset_index().rename(columns={'PREMIUM_PAID':'TotalPremPaid'})

prem_hist_agent = prem_hist_agent.merge(policy_amt_paid,how='inner',on=['KEY'])


# In[9]:


#Categorizing the Payment Frequency - from string to int
prem_hist_agent['PaymentFreq'] = np.where(prem_hist_agent['PAYMENT_FREQUENCY']=='Monthly',1,                                          np.where(prem_hist_agent['PAYMENT_FREQUENCY']=='Annual',12,                                                   np.where(prem_hist_agent['PAYMENT_FREQUENCY']=='Quarterly',3,                                                            np.where(prem_hist_agent['PAYMENT_FREQUENCY']=='Semi Anual',6,0))))


# In[10]:


#Using policy tenure calculating the total premium the user will have to pay
policy_total_amount = prem_hist_agent.groupby(['PaymentFreq','KEY'])['ANNUAL_PREMIUM','IssuedToMaturityDate(days)'].mean().reset_index()

policy_total_amount['TotalPremToBePaid'] = ((policy_total_amount['IssuedToMaturityDate(days)']/30.4375)/policy_total_amount['PaymentFreq'])*policy_total_amount['ANNUAL_PREMIUM']

policy_total_amount = policy_total_amount[['KEY','TotalPremToBePaid']]

prem_hist_agent = prem_hist_agent.merge(policy_total_amount,how='inner',on=['KEY'])


# In[11]:


#Calculating %OfPremiumPaid
prem_hist_agent['PercentageOfTotalPremiumPaid'] = (prem_hist_agent['TotalPremPaid'] / prem_hist_agent['TotalPremToBePaid'])


# In[21]:


#High level stats at an Agent and Status level
#Based on % Of Premium Paid 
agent_roll_up_perc_prem = prem_hist_agent.groupby(['AGENT1','STATUS'])['PercentageOfTotalPremiumPaid'].describe().reset_index().sort_values(by=['count','mean'],ascending=False)

#Renaming columns to avoid confusion
agent_roll_up_perc_prem = agent_roll_up_perc_prem.rename(columns={i:i+'_%PremiumPaid' for i in agent_roll_up_perc_prem.columns[2:]})

#For delay in payments
agent_roll_up_delay = prem_hist_agent.groupby(['AGENT1','STATUS'])['DelayInPayment(days)'].describe().reset_index().sort_values(by=['count','mean'],ascending=False)

#Renaming columns to avoid confusion
agent_roll_up_delay = agent_roll_up_delay.rename(columns={i:i+'_DelayInPaymt' for i in agent_roll_up_delay.columns[2:]})

# for payments to policies
agent_roll_up_number_paid_policies = prem_hist_agent[prem_hist_agent['PAYMENT_DATE'].notnull()].groupby(['AGENT1','STATUS'])['KEY'].size().reset_index().sort_values(by=['KEY'],ascending=False).rename(columns={'KEY':'#PaymentsToPolicies'})

# for missed payments to policies
agent_roll_up_number_unpaid_policies = prem_hist_agent[prem_hist_agent['PAYMENT_DATE'].isnull()].groupby(['AGENT1','STATUS'])['KEY'].size().reset_index().sort_values(by=['KEY'],ascending=False).rename(columns={'KEY':'#PaymentsMissed'})

#Examples of cases where premium is less than amount paid
payment_gt_premium = prem_hist_agent[prem_hist_agent['ANNUAL_PREMIUM']<prem_hist_agent['PREMIUM_PAID']].head(1000)


# In[22]:


#Saving the Files
df_list_str = ['agent_roll_up_perc_prem','agent_roll_up_delay','agent_roll_up_#_paid_policies','agent_roll_up_#_unpaid_policies','Payment_gt_premium']

df_list = [agent_roll_up_perc_prem,agent_roll_up_delay,agent_roll_up_number_paid_policies,agent_roll_up_number_unpaid_policies, payment_gt_premium]

with ExcelWriter('15Feb_PremHist_v2.xlsx') as writer:
    for name, df in zip(df_list_str,df_list):
        df.to_excel(writer,sheet_name= name,index=False)
    writer.save()
writer.close()
