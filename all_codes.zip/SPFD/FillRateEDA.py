df = pd.read_pickle('Data_For_Agent_Modelling_v2.pkl')
ph = pd.read_pickle('clean_payment_hist_v2.pkl')

df = df[(df['ISSUE_DATE'].dt.year>=2000)]
df = df[['KEY','STATUS','ISSUE_DATE','LOB','VAT_ID']].drop_duplicates()

ph['KEY_y'] = ph['KEY']
ph = ph[['KEY_y']].drop_duplicates()

xy = df.merge(ph,how='left',left_on='KEY',right_on='KEY_y')

xy['YEAR'] = xy['ISSUE_DATE'].dt.year
xy['PLAN_DESC'] = pd.Series(random.choice(string.ascii_uppercase) for _ in range(len(xy)))
xy['PLAN_DESC'] = xy['PLAN_DESC'].fillna('A')

xyz = xy.groupby(['YEAR','STATUS','LOB','PLAN_DESC','VAT_ID'])['KEY','KEY_y'].nunique()\
.reset_index().rename(columns={'KEY':'#TotalPolicies','KEY_y':'#PoliciesInPremHist'})

xyz.to_excel('FillRateEDA.xlsx',index=False)