# -*- coding: utf-8 -*-
"""
Created on Tue Feb 12 00:46:26 2019

@author: prathod1
"""

import os
import pandas as pd
import numpy as np

os.chdir(r'\\ns-sisci01hd\home_s01\Citrix_Folder_Redirect\Downloads')

req_data = pd.read_pickle('Merged_data_07022019.pkl')

#req_data = req_data[(req_data['AGENT1']=='11199002')]

req_data_copy = req_data.copy()

req_columns = ['COMPANY', 'POLICY_NUMBER', 'RIDER_NUMBER', 'PAYMENT_FREQUENCY', 
               'INSURED_NAME_master', 'OWNER_NAME_master', 'STATUS_master', 
               'ANNUAL_PREMIUM', 'SEMI_ANNUAL_PREMIUM', 'QUARTERLY_PREMIUM', 
               'MONTHLY_PREMIUM', 'PAID_TO_YEAR', 'PAID_TO_MONTH', 'PAID_TO_DAY',
               'STATUS', 'LOB', 'ISSUE_AGE',  'ISSUE_DATE', 'RIDER_STATUS',
               'GENDER_cov', 'RELATION_cov', 'COVERAGE_AMOUNT', 'COVERAGE_UNITS',
               'DURATION', 'MATURITY_YEAR', 'MATURITY_MONTH', 'MATURITY_DAY',
               'POL_ISSUE_DATE', 'RIDER_COUNT', 'CONTRACT_CENTURY', 'CONTRACT_DATE',
               'CCSPLIT', 'AGENT1', 'COUNTRY', 'PAYOR_NAME', 'PHONE_NUMBER_payor',
               'MOBILE_NUMBER_payor', 'OCCUPATION_payor', 'INSURED_CODE_cust',
               'OWNER_CODE_cust', 'GROUPID_cust', 'RIDER_NUMBER_loan',  'LOAN_PRINCIPLE',
               'CURRENCY', 'curr_multi', 'CONV_ANNUAL_PREMIUM', 
               'CONV_SEMI_ANNUAL_PREMIUM', 'CONV_QUARTERLY_PREMIUM']



req_data = req_data[req_columns]

req_data = req_data[req_data['LOB'] == 10]

req_data.reset_index(drop = True, inplace = True)

req_data['Age_flag'] = req_data['ISSUE_AGE']>65

####computing Paid to date
req_data.loc[req_data['PAID_TO_YEAR'] <= 88,'PAID_TO_CENTURY'] =  20
req_data['PAID_TO_DATE'] = req_data['PAID_TO_CENTURY'].astype(int).astype(str).apply(lambda x: x.zfill(2)) + req_data['PAID_TO_YEAR'].astype(int).astype(str).apply(lambda x: x.zfill(2)) + req_data['PAID_TO_MONTH'].astype(int).astype(str).apply(lambda x: x.zfill(2)) + req_data['PAID_TO_DAY'].astype(int).astype(str).apply(lambda x: x.zfill(2))
req_data['PAID_TO_DATE'] = pd.to_datetime(req_data['PAID_TO_DATE'])

###computing contract date
req_data['CONTRACT_DATE'] = req_data['CONTRACT_DATE'].astype(str)
req_data['CONTRACT_DATE'] = req_data['CONTRACT_DATE'].apply(lambda x: x.zfill(8))
req_data['CONTRACT_YEAR'] = req_data['CONTRACT_DATE'].str[0:2]
req_data['CONTRACT_MONTH'] = req_data['CONTRACT_DATE'].str[2:4]
req_data['CONTRACT_DAY'] = req_data['CONTRACT_DATE'].str[4:6]
req_data['CONTRACT_YEAR_int'] = req_data['CONTRACT_YEAR'].astype(int)
req_data.loc[req_data['CONTRACT_YEAR_int'] > 18,'CONTRACT_CENTURY'] =  19
req_data.loc[req_data['CONTRACT_YEAR_int'] <= 18,'CONTRACT_CENTURY'] =  20
req_data['CONTRACT_CENTURY'] = req_data['CONTRACT_CENTURY'].astype(str)
req_data.drop(['CONTRACT_YEAR_int'], axis = 1, inplace = True)
req_data['CONTRACT_DATE'] = req_data['CONTRACT_CENTURY'].str[0:2] + req_data['CONTRACT_YEAR']+req_data['CONTRACT_MONTH']+req_data['CONTRACT_DAY'] 
req_data['CONTRACT_DATE'] = pd.to_datetime(req_data['CONTRACT_DATE'])


##removing rows premium greater than covergae amount
req_data = req_data[req_data['ANNUAL_PREMIUM']<= req_data['COVERAGE_AMOUNT']]
req_data.reset_index(drop = True, inplace = True)

###computing how many policies insured and owner policies had  with all agents in past 2 yeqrs
count = 0
def company_agent_lob1(df):
    global req_data
    global count
    comp_val = df['COMPANY']
    agent_val = df['AGENT1']
    lob_val  = df['LOB']
    customer_insured = df['INSURED_NAME_master']
    customer_owner = df['OWNER_NAME_master']
    pol_issue_date = df['POL_ISSUE_DATE']
    date_lb_12 = pol_issue_date - pd.Timedelta(days = 730)
    temp  = req_data1[(req_data1['COMPANY'] == comp_val)&(req_data1['LOB']==lob_val)&(req_data1['AGENT1']==agent_val)]
    temp1 = temp[(temp['POL_ISSUE_DATE']<pol_issue_date) & (temp['POL_ISSUE_DATE']>date_lb_12)]
    bool_indi = temp1['INSURED_NAME_master'].isin([customer_insured])
    bool_indi1 = temp1['OWNER_NAME_master'].isin([customer_owner])
    old_customer = len(temp1[bool_indi])
    old_owner = len(temp1[bool_indi1])
    req_data1.loc[count, 'insured_no_of_policies_with_agent_24'] = old_customer
    req_data1.loc[count, 'owner_no_of_policies_with_agent_24'] = old_owner
    count = count+1
    print(count)
    return len(temp1)

req_data1 = req_data[['COMPANY', 'AGENT1', 'LOB',  'POL_ISSUE_DATE', 'INSURED_NAME_master', 'OWNER_NAME_master']].copy()
req_data1.apply(company_agent_lob1, axis =1)
req_data =pd.concat([req_data, req_data1[['insured_no_of_policies_with_agent_24','owner_no_of_policies_with_agent_24' ]]], axis = 1)


#####
# computing how many policies insured and owner policies had
#  with respective agents in past 2 years
###

count = 0
def company_agent_lob2(df):
    global req_data
    global count
    comp_val = df['COMPANY']
    lob_val  = df['LOB']
    customer_insured = df['INSURED_NAME_master']
    customer_owner = df['OWNER_NAME_master']
    pol_issue_date = df['POL_ISSUE_DATE']
    date_lb_12 = pol_issue_date - pd.Timedelta(days = 730)
    temp  = req_data1[(req_data1['COMPANY'] == comp_val)&(req_data1['LOB']==lob_val)]
    temp1 = temp[(temp['POL_ISSUE_DATE']<pol_issue_date) & (temp['POL_ISSUE_DATE']>date_lb_12)]
    bool_indi = temp1['INSURED_NAME_master'].isin([customer_insured])
    bool_indi1 = temp1['OWNER_NAME_master'].isin([customer_owner])
    old_customer = len(temp1[bool_indi])
    old_owner = len(temp1[bool_indi1])
    req_data1.loc[count, 'insured_no_of_policies_with_agent_year_24'] = old_customer
    req_data1.loc[count, 'owner_no_of_policies_with_agent_year_24'] = old_owner
    count = count+1
    print(count)
    return len(temp1)

#req_data1 = req_data[['COMPANY', 'AGENT1', 'LOB',  'POL_ISSUE_DATE', 'INSURED_NAME_master', 'OWNER_NAME_master']].copy()
req_data1.apply(company_agent_lob2, axis =1)
req_data =pd.concat([req_data, req_data1[['insured_no_of_policies_with_agent_year_24','owner_no_of_policies_with_agent_year_24' ]]], axis = 1)

#####
# computing how many policies , avg age of insured to whom he had sold policies, 
# how many policies he sold to people greter than 65 age, no of  unique days he is active
# for  respective agents in past 1 year, 6  months, 3months
####

count = 0
def company_agent_lob3(df):
    global req_data
    global count
    comp_val = df['COMPANY']
    lob_val  = df['LOB']
    pol_issue_date = df['POL_ISSUE_DATE']
    date_lb_12 = pol_issue_date - pd.Timedelta(days = 360)
    date_lb_6 = pol_issue_date - pd.Timedelta(days = 180)
    date_lb_3 = pol_issue_date - pd.Timedelta(days = 90)
    temp  = req_data1[(req_data1['COMPANY'] == comp_val)&(req_data1['LOB']==lob_val) ]
    temp1 = temp[(temp['POL_ISSUE_DATE']<pol_issue_date) & (temp['POL_ISSUE_DATE']>date_lb_12)]
    temp2 = temp1[(temp1['POL_ISSUE_DATE']<pol_issue_date) & (temp1['POL_ISSUE_DATE']>date_lb_6)]
    temp3 = temp2[(temp2['POL_ISSUE_DATE']<pol_issue_date) & (temp2['POL_ISSUE_DATE']>date_lb_3)]
    
    
    no_of_policies = len(temp1)
    avg_age = temp1['ISSUE_AGE'].median()
    no_of_unique_days = temp1['POL_ISSUE_DATE'].nunique()
    req_data1.loc[count, 'no_of_policies_agent_year_12'] = no_of_policies
    req_data1.loc[count, 'avg_age_agent_year_12'] = avg_age
    req_data1.loc[count, 'no_of_unique_days_agent_year_12'] = no_of_unique_days
    req_data1.loc[count, 'no_of_age_flag_agent_year_12'] = temp1['Age_flag'].sum()


    no_of_policies = len(temp2)
    avg_age = temp2['ISSUE_AGE'].median()
    no_of_unique_days = temp2['POL_ISSUE_DATE'].nunique()
    req_data1.loc[count, 'no_of_policies_agent_year_6'] = no_of_policies
    req_data1.loc[count, 'avg_age_agent_year_6'] = avg_age
    req_data1.loc[count, 'no_of_unique_days_agent_year_6'] = no_of_unique_days
    req_data1.loc[count, 'no_of_age_flag_agent_year_6'] = temp2['Age_flag'].sum()

        
    no_of_policies = len(temp3)
    avg_age = temp3['ISSUE_AGE'].median()
    no_of_unique_days = temp3['POL_ISSUE_DATE'].nunique()
    req_data1.loc[count, 'no_of_policies_agent_year_3'] = no_of_policies
    req_data1.loc[count, 'avg_age_agent_year_3'] = avg_age
    req_data1.loc[count, 'no_of_unique_days_agent_year_3'] = no_of_unique_days
    req_data1.loc[count, 'no_of_age_flag_agent_year_3'] = temp3['Age_flag'].sum()
    
    
    count = count+1
    print(count)
    return len(temp1)

req_data1 = req_data[['COMPANY', 'AGENT1', 'LOB',  'ISSUE_AGE','POL_ISSUE_DATE', 'Age_flag' ]].copy()
req_data1.apply(company_agent_lob3, axis =1)
y_v = ['no_of_policies_agent_year_12', 'no_of_policies_agent_year_6', 'no_of_policies_agent_year_3',
 'avg_age_agent_year_12', 'avg_age_agent_year_6', 'avg_age_agent_year_3',
 'no_of_unique_days_agent_year_12','no_of_unique_days_agent_year_6','no_of_unique_days_agent_year_3',
 'no_of_age_flag_agent_year_12', 'no_of_age_flag_agent_year_6', 'no_of_age_flag_agent_year_3' ]
req_data =pd.concat([req_data, req_data1[y_v]], axis = 1)


#####
# computing how many policies , avg age of insured to whom he had sold policies, 
# how many policies he sold to people greter than 65 age, no of  unique days he is active
# for all agents in past 1 year, 6  months, 3months
####
count = 0
def company_agent_lob4(df):
    global req_data
    global count
    comp_val = df['COMPANY']
    agent_val = df['AGENT1']
    lob_val  = df['LOB']
    pol_issue_date = df['POL_ISSUE_DATE']
    date_lb_12 = pol_issue_date - pd.Timedelta(days = 360)
    date_lb_6 = pol_issue_date - pd.Timedelta(days = 180)
    date_lb_3 = pol_issue_date - pd.Timedelta(days = 90)
    temp  = req_data1[(req_data1['COMPANY'] == comp_val)&(req_data1['AGENT1'] == agent_val)&(req_data1['LOB']==lob_val) ]
    temp1 = temp[(temp['POL_ISSUE_DATE']<pol_issue_date) & (temp['POL_ISSUE_DATE']>date_lb_12)]
    temp2 = temp1[(temp1['POL_ISSUE_DATE']<pol_issue_date) & (temp1['POL_ISSUE_DATE']>date_lb_6)]
    temp3 = temp2[(temp2['POL_ISSUE_DATE']<pol_issue_date) & (temp2['POL_ISSUE_DATE']>date_lb_3)]
    
    
    no_of_policies = len(temp1)
    avg_age = temp1['ISSUE_AGE'].median()
    no_of_unique_days = temp1['POL_ISSUE_DATE'].nunique()
    req_data1.loc[count, 'no_of_policies_agent_12'] = no_of_policies
    req_data1.loc[count, 'avg_age_agent_12'] = avg_age
    req_data1.loc[count, 'no_of_unique_days_agent_12'] = no_of_unique_days
    req_data1.loc[count, 'no_of_age_flag_agent_12'] = temp1['Age_flag'].sum()


    no_of_policies = len(temp2)
    avg_age = temp2['ISSUE_AGE'].median()
    no_of_unique_days = temp2['POL_ISSUE_DATE'].nunique()
    req_data1.loc[count, 'no_of_policies_agent_6'] = no_of_policies
    req_data1.loc[count, 'avg_age_agent_6'] = avg_age
    req_data1.loc[count, 'no_of_unique_days_agent_6'] = no_of_unique_days
    req_data1.loc[count, 'no_of_age_flag_agent_6'] = temp2['Age_flag'].sum()

        
    no_of_policies = len(temp3)
    avg_age = temp3['ISSUE_AGE'].median()
    no_of_unique_days = temp3['POL_ISSUE_DATE'].nunique()
    req_data1.loc[count, 'no_of_policies_agent_3'] = no_of_policies
    req_data1.loc[count, 'avg_age_agent_3'] = avg_age
    req_data1.loc[count, 'no_of_unique_days_agent_3'] = no_of_unique_days
    req_data1.loc[count, 'no_of_age_flag_agent_3'] = temp3['Age_flag'].sum()
    
    
    count = count+1
    print(count)
    return len(temp1)

#req_data1 = req_data[['COMPANY', 'AGENT1', 'LOB',  'ISSUE_AGE','POL_ISSUE_DATE', 'Age_flag' ]].copy()
req_data1.apply(company_agent_lob4, axis =1)
a_v = ['no_of_policies_agent_12', 'no_of_policies_agent_6', 'no_of_policies_agent_3',
 'avg_age_agent_12', 'avg_age_agent_6', 'avg_age_agent_3',
 'no_of_unique_days_agent_12','no_of_unique_days_agent_6','no_of_unique_days_agent_3',
 'no_of_age_flag_agent_12', 'no_of_age_flag_agent_6', 'no_of_age_flag_agent_3' ]
req_data =pd.concat([req_data, req_data1[a_v]], axis = 1)


###Creating Agent experience bins
req_data.loc[req_data['CONTRACT_DATE']>req_data['POL_ISSUE_DATE'], 'CONTRACT_DATE'] = req_data['CONTRACT_DATE']-pd.Timedelta(days = 3650)
req_data['AGENT_exp'] = req_data['POL_ISSUE_DATE'] - req_data['CONTRACT_DATE']
req_data['AGENT_exp'] = req_data['AGENT_exp'] / np.timedelta64(1, 'D')

req_data.loc[req_data['AGENT_exp']<=365, 'AGENT_exp_bin'] = '1_yr'
req_data.loc[(req_data['AGENT_exp']>365)&(req_data['AGENT_exp']<=1095), 'AGENT_exp_bin'] = '1_3_yrs'
req_data.loc[(req_data['AGENT_exp']>1095)&(req_data['AGENT_exp']<=1825), 'AGENT_exp_bin'] = '3_5_yr'
req_data.loc[(req_data['AGENT_exp']>1825)&(req_data['AGENT_exp']<=3650), 'AGENT_exp_bin'] = '5_10yr'
req_data.loc[req_data['AGENT_exp']>3650, 'AGENT_exp_bin'] = 'gt_10_yr'

req_data = pd.get_dummies(req_data, columns = ['AGENT_exp_bin'])
req_data['GROUPID_cust'] = req_data['GROUPID_cust'].fillna(0)
req_data.loc[req_data['GROUPID_cust']!= 0, 'GROUPID_cust'] = 1


req_data['Pol_duration'] = req_data['PAID_TO_DATE'] - req_data['POL_ISSUE_DATE']   
req_data['Pol_duration'] = req_data['Pol_duration'] / np.timedelta64(1, 'D')

req_data.loc[req_data['Pol_duration']<= 365, 'Duration_bin'] = 'lt_1_year'
req_data.loc[(req_data['Pol_duration']>365)&(req_data['Pol_duration']<= 730), 'Duration_bin'] = '1_2_year'
req_data.loc[req_data['Pol_duration']>730, 'Duration_bin'] = 'gt_2_years'



###Occurance or likely hood of giving a policy to particular age with in a LOB
###
req_pivot1 = req_data.pivot_table(values = 'RIDER_NUMBER', index = ['LOB'], columns = ['ISSUE_AGE'], aggfunc = 'count')
col_list = req_pivot1.columns
req_pivot1['total'] = req_pivot1.sum(axis= 1)
for i in col_list:
    req_pivot1[i] = (req_pivot1[i]/req_pivot1['total'])*100
req_pivot1.reset_index(inplace = True)
req_pivot1 = req_pivot1.melt(id_vars = ['LOB'], value_vars = col_list, value_name= 'Age_prob')
req_pivot1['ISSUE_AGE'] = pd.to_numeric(req_pivot1['ISSUE_AGE'])
req_data = req_data.merge(req_pivot1, how = 'left', on  = ['LOB' , 'ISSUE_AGE'])

#####


###LOB-COUNTRY
###Occurance or likely hood of giving a policy to particular age with in a LOB
###
req_pivot_lc_a_1 = req_data.pivot_table(values = 'RIDER_NUMBER', index = ['LOB', 'COUNTRY'], columns = ['ISSUE_AGE'], aggfunc = 'count')
col_list_lc_a = req_pivot_lc_a_1.columns
req_pivot_lc_a = req_pivot_lc_a_1[col_list_lc_a[0]].reset_index()
for req_col in col_list_lc_a[1:]:
        req_pivot_lc_a = pd.concat([req_pivot_lc_a, req_pivot_lc_a_1[req_col].reset_index(drop = True)], axis = 1)
req_pivot_lc_a['total'] = req_pivot_lc_a[col_list_lc_a].sum(axis= 1)
for i in col_list_lc_a:
    req_pivot_lc_a[i] = (req_pivot_lc_a[i]/req_pivot_lc_a['total'])*100
req_pivot_lc_a = req_pivot_lc_a.melt(id_vars = ['LOB', 'COUNTRY'], value_vars = col_list_lc_a, value_name= 'LC_Age_prob', var_name = 'ISSUE_AGE')
req_pivot_lc_a['ISSUE_AGE'] = pd.to_numeric(req_pivot_lc_a['ISSUE_AGE'])
req_data = req_data.merge(req_pivot_lc_a, how = 'left', on  = ['LOB' , 'ISSUE_AGE', 'COUNTRY'])

#######
# calculating agent growth 
####

req_data['Pol_issue_year'] = req_data['POL_ISSUE_DATE'].dt.year
req_data['Pol_issue_month'] = req_data['POL_ISSUE_DATE'].dt.month
req_data.loc[req_data['Pol_issue_month']<=3, 'Quarter'] = 'Q1'
req_data.loc[(req_data['Pol_issue_month']>3)&(req_data['Pol_issue_month']<=6), 'Quarter'] = 'Q2'
req_data.loc[(req_data['Pol_issue_month']>6)&(req_data['Pol_issue_month']<=9), 'Quarter']= 'Q3'
req_data.loc[(req_data['Pol_issue_month']>9)&(req_data['Pol_issue_month']<=12), 'Quarter']= 'Q4'

temp_quart = req_data.groupby(['AGENT1', 'Pol_issue_year', 'Quarter']).agg({'COMPANY' : len})
temp_quart.rename(columns = {'COMPANY' : 'no_of_policies_issued'}, inplace = True)
temp_quart.reset_index(inplace = True)

temp_quart_pivot = temp_quart.pivot_table(index = ['AGENT1', 'Pol_issue_year'], values = 'no_of_policies_issued', columns = ['Quarter'])
temp_quart_pivot.reset_index(inplace = True)

temp_quart_pivot.sort_values(['AGENT1', 'Pol_issue_year'], inplace = True)
temp_quart_pivot_copy = temp_quart_pivot.copy()

temp_quart_pivot_shift = temp_quart_pivot.shift(1)
temp_list = []
for col in temp_quart_pivot_shift.columns:
    temp_list.append(col+'_shift')

temp_quart_pivot_shift.columns = temp_list

pol_trend = pd.concat([temp_quart_pivot, temp_quart_pivot_shift], axis = 1)


pol_trend_1 = pol_trend[pol_trend['AGENT1'] == pol_trend['AGENT1_shift']]
pol_trend_1['year_diff'] = pol_trend_1['Pol_issue_year']-pol_trend_1['Pol_issue_year_shift']
pol_trend_2 = pol_trend_1[pol_trend_1['year_diff'] == 1]

pol_trend_2['Q1_diff'] = pol_trend_2['Q1']-pol_trend_2['Q1_shift']
pol_trend_2['Q2_diff'] = pol_trend_2['Q2']-pol_trend_2['Q2_shift']
pol_trend_2['Q3_diff'] = pol_trend_2['Q3']-pol_trend_2['Q3_shift']
pol_trend_2['Q4_diff'] = pol_trend_2['Q4']-pol_trend_2['Q4_shift']

pol_trend_2['Q1_growth'] = pol_trend_2['Q1_diff']/pol_trend_2['Q1_shift']
pol_trend_2['Q2_growth'] = pol_trend_2['Q2_diff']/pol_trend_2['Q2_shift']
pol_trend_2['Q3_growth'] = pol_trend_2['Q3_diff']/pol_trend_2['Q3_shift']
pol_trend_2['Q4_growth'] = pol_trend_2['Q4_diff']/pol_trend_2['Q4_shift']

pol_trend_2['avg_growth'] = pol_trend_2[['Q1_growth', 'Q2_growth', 'Q3_growth', 'Q4_growth']].mean(axis =1)
pol_trend_2.rename(columns ={'avg_growth' : 'agent_growth'}, inplace = True)
pol_trend_2['Pol_issue_year'] = pol_trend_2['Pol_issue_year']+1
req_data = req_data.merge(pol_trend_2[['AGENT1', 'agent_growth', 'Pol_issue_year']], how = 'left', on = ['AGENT1', 'Pol_issue_year'])


########
# calculating  growth at overall level
####

unique_agents = req_data.drop_duplicates(['AGENT1'])[['AGENT1']]
unique_agents.reset_index(drop =True, inplace = True)

pol_trend_year_wise = temp_quart_pivot.groupby(['Pol_issue_year']).sum()
pol_trend_year_wise.reset_index(inplace = True)
pol_agent_year_wise = temp_quart_pivot.groupby(['AGENT1', 'Pol_issue_year']).sum()
pol_agent_year_wise.reset_index(inplace = True)


dlist = pd.date_range(start = '2007/12/31', end= '2017/12/31', freq = pd.offsets.YearBegin())
tdlist= list(dlist)*len(unique_agents)
Agent_model_data = pd.DataFrame(columns= ['AGENT1', 'YEAR_MONTH'])
Agent_model_data['YEAR_MONTH'] = tdlist
Agent_model_data['YEAR_MONTH'] = pd.to_datetime(Agent_model_data['YEAR_MONTH'].dt.date.astype(str))
count =0 
for i in range(0, len(tdlist), 10):
    Agent_model_data.loc[i, ['AGENT1']] = unique_agents['AGENT1'][count]
    count = count + 1
Agent_model_data.ffill(inplace = True)

Agent_model_data.sort_values(['AGENT1', 'YEAR_MONTH'], inplace = True)
Agent_model_data['YEAR_wise'] = Agent_model_data['YEAR_MONTH'].dt.year

Agent_model_data = Agent_model_data.merge(pol_agent_year_wise, how = 'left', left_on = ['AGENT1', 'YEAR_wise'], right_on  = ['AGENT1', 'Pol_issue_year'])

Agent_model_data = Agent_model_data.merge(pol_trend_year_wise, how = 'left', left_on = ['YEAR_wise'], right_on = ['Pol_issue_year'])

Agent_model_data.fillna(0, inplace =True)
Agent_model_data['Q1'] = Agent_model_data['Q1_y']-Agent_model_data['Q1_x']
Agent_model_data['Q2'] = Agent_model_data['Q2_y']-Agent_model_data['Q2_x']
Agent_model_data['Q3'] = Agent_model_data['Q3_y']-Agent_model_data['Q3_x']
Agent_model_data['Q4'] = Agent_model_data['Q4_y']-Agent_model_data['Q4_x']

Agent_model_data_trend = Agent_model_data[['AGENT1', 'YEAR_wise', 'Q1', 'Q2', 'Q3', 'Q4']]
Agent_model_data_trend.sort_values(['AGENT1', 'YEAR_wise'], inplace = True)
Agent_model_data_trend_copy = Agent_model_data_trend.copy()


Agent_model_data_trend_shift = Agent_model_data_trend.shift(1)
temp_list = []
for col in Agent_model_data_trend_shift.columns:
    temp_list.append(col+'_shift')

Agent_model_data_trend_shift.columns = temp_list

year_wise_trend = pd.concat([Agent_model_data_trend, Agent_model_data_trend_shift], axis = 1)

year_wise_trend['year_diff'] = year_wise_trend['YEAR_wise']-year_wise_trend['YEAR_wise_shift']
year_wise_trend_2 = year_wise_trend[year_wise_trend['year_diff'] == 1]

year_wise_trend_2['Q1_diff'] = year_wise_trend_2['Q1']-year_wise_trend_2['Q1_shift']
year_wise_trend_2['Q2_diff'] = year_wise_trend_2['Q2']-year_wise_trend_2['Q2_shift']
year_wise_trend_2['Q3_diff'] = year_wise_trend_2['Q3']-year_wise_trend_2['Q3_shift']
year_wise_trend_2['Q4_diff'] = year_wise_trend_2['Q4']-year_wise_trend_2['Q4_shift']

year_wise_trend_2['Q1_growth'] = year_wise_trend_2['Q1_diff']/year_wise_trend_2['Q1_shift']
year_wise_trend_2['Q2_growth'] = year_wise_trend_2['Q2_diff']/year_wise_trend_2['Q2_shift']
year_wise_trend_2['Q3_growth'] = year_wise_trend_2['Q3_diff']/year_wise_trend_2['Q3_shift']
year_wise_trend_2['Q4_growth'] = year_wise_trend_2['Q4_diff']/year_wise_trend_2['Q4_shift']

year_wise_trend_2['year_growth'] = year_wise_trend_2[['Q1_growth', 'Q2_growth', 'Q3_growth', 'Q4_growth']].mean(axis =1)
year_wise_trend_2.rename(columns = { 'YEAR_wise' : 'Pol_issue_year'}, inplace = True)
year_wise_trend_2['Pol_issue_year'] = year_wise_trend_2['Pol_issue_year']+1

req_data = req_data.merge(year_wise_trend_2[['AGENT1', 'year_growth', 'Pol_issue_year']], how = 'left', on = ['AGENT1', 'Pol_issue_year'])



### 
# calculating max week polcies
##
req_data['week'] = req_data['POL_ISSUE_DATE'].dt.week
week_wise = req_data.groupby(['AGENT1', 'Pol_issue_year', 'week']).agg({'COMPANY':len})
week_wise.rename(columns = {'COMPANY':'no_of_pol_issu_in_max_week'}, inplace =True)
week_wise.reset_index(inplace = True)
week_wise_max = week_wise.groupby(['AGENT1', 'Pol_issue_year']).max()
week_wise_max.reset_index(inplace =True)
week_wise_max['Pol_issue_year'] = week_wise_max['Pol_issue_year']-1
week_wise_max.drop('week', axis = 1, inplace = True)
req_data = req_data.merge(week_wise_max, how='left',  on = ['AGENT1', 'Pol_issue_year'])


###LAPse
# calculating  lapse at agent level
####

req_data = pd.get_dummies(req_data, columns = ['Duration_bin'])

req_data_lapsed  = req_data[req_data['STATUS'].isin(['Terminated - Lapsed no Value'])]
temp_lapsed = req_data_lapsed.groupby(['AGENT1', 'Pol_issue_year']).agg({'Duration_bin_lt_1_year' : sum,'Duration_bin_1_2_year' : sum,'Duration_bin_gt_2_years' : sum })
#temp_lapsed = req_data_lapsed.groupby(['AGENT1', 'Pol_issue_year', 'Quarter']).agg({'Duration_bin_lt_1_year' : sum,'Duration_bin_1_2_year' : sum,'Duration_bin_gt_2_years' : sum })
temp_lapsed.rename(columns = {'Duration_bin_lt_1_year' : 'Lapsed_lt_1_year','Duration_bin_1_2_year' : 'Lapsed_1_2_year','Duration_bin_gt_2_years' : 'Lapsed_gt_2_years'}, inplace = True)
temp_lapsed.reset_index(inplace = True)

temp_lapsed_pivot = temp_lapsed.copy()
temp_quart_pivot_copy1 = temp_lapsed_pivot.merge(temp_quart_pivot_copy, how = 'left', on = ['AGENT1', 'Pol_issue_year'])


for col in (temp_lapsed_pivot.columns)[2:]:
    temp_lapsed_pivot[col] = temp_lapsed_pivot[col]/temp_quart_pivot_copy1[['Q1','Q2','Q3','Q4']].sum(axis=1)
    print(col)


temp_lapsed_pivot_shift = temp_lapsed_pivot.shift(1)
temp_lapsed_list = []
for col in temp_lapsed_pivot_shift.columns:
    temp_lapsed_list.append(col+'_shift')

temp_lapsed_pivot_shift.columns = temp_lapsed_list

lapse_trend = pd.concat([temp_lapsed_pivot, temp_lapsed_pivot_shift], axis = 1)


lapse_trend_1 = lapse_trend[lapse_trend['AGENT1'] == lapse_trend['AGENT1_shift']]
lapse_trend_1['year_diff'] = lapse_trend_1['Pol_issue_year']-lapse_trend_1['Pol_issue_year_shift']
lapse_trend_2 = lapse_trend_1[lapse_trend_1['year_diff'] == 1]

lapse_trend_2['Lapsed_1_2_year_diff'] = lapse_trend_2['Lapsed_1_2_year']-lapse_trend_2['Lapsed_1_2_year_shift']
lapse_trend_2['Lapsed_gt_2_years_diff'] = lapse_trend_2['Lapsed_1_2_year']-lapse_trend_2['Lapsed_gt_2_years_shift']
lapse_trend_2['Lapsed_lt_1_year_diff'] = lapse_trend_2['Lapsed_1_2_year']-lapse_trend_2['Lapsed_lt_1_year_shift']

lapse_trend_2['Lapsed_1_2_year_growth'] = lapse_trend_2['Lapsed_1_2_year_diff']/lapse_trend_2['Lapsed_1_2_year_shift']
lapse_trend_2['Lapsed_gt_2_years_growth'] = lapse_trend_2['Lapsed_gt_2_years_diff']/lapse_trend_2['Lapsed_gt_2_years_shift']
lapse_trend_2['Lapsed_lt_1_year_growth'] = lapse_trend_2['Lapsed_lt_1_year_diff']/lapse_trend_2['Lapsed_lt_1_year_shift']

lapse_trend_2['Lapsed_1_2_year_agent_growth'] = lapse_trend_2[['Lapsed_1_2_year_growth']]
lapse_trend_2['Lapsed_gt_2_year_agent_growth'] = lapse_trend_2[['Lapsed_gt_2_years_growth']]
lapse_trend_2['Lapsed_lt_1_year_agent_growth'] = lapse_trend_2[['Lapsed_lt_1_year_growth']]
lapse_trend_2['Pol_issue_year'] = lapse_trend_2['Pol_issue_year']+1
lapse_trend_2['Lapsed_1_2_year_agent_growth'].replace([np.inf, -np.inf], 0, inplace = True)
lapse_trend_2['Lapsed_gt_2_year_agent_growth'].replace([np.inf, -np.inf], 0, inplace = True)
lapse_trend_2['Lapsed_lt_1_year_agent_growth'].replace([np.inf, -np.inf], 0, inplace = True)
req_data = req_data.merge(lapse_trend_2[['AGENT1', 'Lapsed_lt_1_year_agent_growth','Lapsed_1_2_year_agent_growth', 'Lapsed_gt_2_year_agent_growth', 'Pol_issue_year']], how = 'left', on = ['AGENT1', 'Pol_issue_year'])



####LAPSe yearwise
# calculating  lapse at agent level
####

lapse_trend_year_wise = temp_lapsed_pivot.groupby(['Pol_issue_year']).sum()
lapse_trend_year_wise.reset_index( inplace = True)
lapse_agent_year_wise = temp_lapsed_pivot.copy()

Agent_model_data1 = pd.DataFrame(columns= ['AGENT1', 'YEAR_MONTH'])
Agent_model_data1['YEAR_MONTH'] = tdlist
Agent_model_data1['YEAR_MONTH'] = pd.to_datetime(Agent_model_data1['YEAR_MONTH'].dt.date.astype(str))
count =0 
for i in range(0, len(tdlist), 10):
    Agent_model_data1.loc[i, ['AGENT1']] = unique_agents['AGENT1'][count]
    count = count + 1
Agent_model_data1.ffill(inplace = True)

Agent_model_data1.sort_values(['AGENT1', 'YEAR_MONTH'], inplace = True)
Agent_model_data1['YEAR_wise'] = Agent_model_data1['YEAR_MONTH'].dt.year

Agent_model_data1 = Agent_model_data1.merge(lapse_agent_year_wise, how = 'left', left_on = ['AGENT1', 'YEAR_wise'], right_on  = ['AGENT1', 'Pol_issue_year'])

Agent_model_data1 = Agent_model_data1.merge(lapse_trend_year_wise, how = 'left', left_on = ['YEAR_wise'], right_on = ['Pol_issue_year'])

Agent_model_data1.fillna(0, inplace =True)

Agent_model_data1['Lapsed_1_2_year'] = Agent_model_data1['Lapsed_1_2_year_x']-Agent_model_data1['Lapsed_1_2_year_y']
Agent_model_data1['Lapsed_gt_2_years'] = Agent_model_data1['Lapsed_gt_2_years_x']-Agent_model_data1['Lapsed_gt_2_years_y']
Agent_model_data1['Lapsed_lt_1_year'] = Agent_model_data1['Lapsed_lt_1_year_x']-Agent_model_data1['Lapsed_lt_1_year_y']

Agent_model_data_trend1 = Agent_model_data1[['AGENT1', 'YEAR_wise', 'Lapsed_1_2_year','Lapsed_gt_2_years','Lapsed_lt_1_year']]

Agent_model_data_trend1.sort_values(['AGENT1', 'YEAR_wise'], inplace = True)
Agent_model_data_trend1.reset_index(drop = True, inplace = True)

Agent_model_data_trend_shift1 = Agent_model_data_trend1.shift(1)
temp_list = []
for col in Agent_model_data_trend_shift1.columns:
    temp_list.append(col+'_shift')
    print(col+'_shift')

Agent_model_data_trend_shift1.columns = temp_list

lapse_year_wise_trend = pd.concat([Agent_model_data_trend1, Agent_model_data_trend_shift1], axis = 1)

lapse_year_wise_trend['year_diff'] = lapse_year_wise_trend['YEAR_wise']-lapse_year_wise_trend['YEAR_wise_shift']
lapse_year_wise_trend_2 = lapse_year_wise_trend[lapse_year_wise_trend['year_diff'] == 1]

lapse_year_wise_trend_2['Lapsed_1_2_year_diff'] = lapse_year_wise_trend_2['Lapsed_1_2_year']-lapse_year_wise_trend_2['Lapsed_1_2_year_shift']
lapse_year_wise_trend_2['Lapsed_gt_2_years_diff'] = lapse_year_wise_trend_2['Lapsed_gt_2_years']-lapse_year_wise_trend_2['Lapsed_gt_2_years_shift']
lapse_year_wise_trend_2['Lapsed_lt_1_year_diff'] = lapse_year_wise_trend_2['Lapsed_lt_1_year']-lapse_year_wise_trend_2['Lapsed_lt_1_year_shift']


lapse_year_wise_trend_2['Lapsed_1_2_year_growth'] = lapse_year_wise_trend_2['Lapsed_1_2_year_diff']/lapse_year_wise_trend_2['Lapsed_1_2_year_shift']
lapse_year_wise_trend_2['Lapsed_gt_2_year_growth'] = lapse_year_wise_trend_2['Lapsed_gt_2_years_diff']/lapse_year_wise_trend_2['Lapsed_gt_2_years_shift']
lapse_year_wise_trend_2['Lapsed_lt_1_year_growth'] = lapse_year_wise_trend_2['Lapsed_lt_1_year_diff']/lapse_year_wise_trend_2['Lapsed_lt_1_year_shift']


lapse_year_wise_trend_2['Lapsed_1_2_year_country_growth'] = lapse_year_wise_trend_2[['Lapsed_1_2_year_growth']]
lapse_year_wise_trend_2['Lapsed_gt_2_year_country_growth'] = lapse_year_wise_trend_2[['Lapsed_gt_2_year_growth']]
lapse_year_wise_trend_2['Lapsed_lt_1_year_country_growth'] = lapse_year_wise_trend_2[['Lapsed_lt_1_year_growth']]
lapse_year_wise_trend_2['Pol_issue_year'] = lapse_year_wise_trend_2['YEAR_wise'].copy()
lapse_year_wise_trend_2['Pol_issue_year'] = lapse_year_wise_trend_2['Pol_issue_year']+1

req_data = req_data.merge(lapse_year_wise_trend_2[['AGENT1', 'Lapsed_lt_1_year_country_growth','Lapsed_1_2_year_country_growth', 'Lapsed_gt_2_year_country_growth', 'Pol_issue_year']], how = 'left', on = ['AGENT1', 'Pol_issue_year'])



###claculating Issue Age to avg median age 
req_data['ISSUE_AGE'] = req_data['ISSUE_AGE'].astype(int)
req_data['ISSUE_AGE_to_avg_age_agent_year_12'] = req_data['ISSUE_AGE']/req_data['avg_age_agent_year_12']


###No of policies issued on the same day
same_date = req_data.groupby(['AGENT1', 'POL_ISSUE_DATE']).agg({'COMPANY':len})
same_date.reset_index(inplace = True)
same_date.rename(columns = {'COMPANY' : 'no_of_pols_issu_on_same_day'}, inplace = True)
req_data = req_data.merge(same_date, on = ['AGENT1', 'POL_ISSUE_DATE'], how = 'left')

###computing Premium to Covrage ratio
#req_data['prem_cov_ratio'] = req_data['ANNUAL_PREMIUM']/req_data['COVERAGE_AMOUNT']

###
req_data['Age_flag'] = req_data['Age_flag'].astype(int)

req_data[(req_data['AGENT1']=='11199002')].to_excel('checker.xlsx',index=False)