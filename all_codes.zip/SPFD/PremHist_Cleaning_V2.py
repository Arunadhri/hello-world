
# coding: utf-8

# In[3]:


import os
import pandas as pd
import numpy as np
from pandas import ExcelWriter

os.chdir(r'\\ns-sisci01hd\home_s01\Citrix_Folder_Redirect\Downloads\SPFD')


# In[4]:


df = pd.read_pickle('Premium_History_Data.pkl')
#Empty Row
df = df.drop(14146897)
#Removing whitespaces from strings
df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
df['COMPANY'] = df['COMPANY'].astype(int)
df = df.drop_duplicates()
#Filling NA since we need to group this data
df['VAT_FLAG'] = df[['VAT_FLAG']].fillna('NULL')


# In[5]:


#Rows which are unique at a 'KEY','PREMIUM_DUE_DATE','PREMIUM_TYPE,'VAT_AMOUNT','VAT_FLAG' level
keys1 = df.groupby(['KEY','COMPANY','POLICY_NUMBER','PREMIUM_DUE_DATE','PREMIUM_TYPE','VAT_AMOUNT','VAT_FLAG'])['PAYMENT_DATE'].size().reset_index()[df.groupby(['KEY','COMPANY','POLICY_NUMBER','PREMIUM_DUE_DATE','PREMIUM_TYPE','VAT_AMOUNT','VAT_FLAG'])['PAYMENT_DATE'].size().reset_index()['PAYMENT_DATE']==1][['KEY','COMPANY','POLICY_NUMBER','PREMIUM_DUE_DATE','PREMIUM_TYPE','VAT_AMOUNT','VAT_FLAG']]

#Rows which have multiple values at a 'KEY','PREMIUM_DUE_DATE','PREMIUM_TYPE,'VAT_AMOUNT','VAT_FLAG' level
keys2 = df.groupby(['KEY','COMPANY','POLICY_NUMBER','PREMIUM_DUE_DATE','PREMIUM_TYPE','VAT_AMOUNT','VAT_FLAG'])['PAYMENT_DATE'].size().reset_index()[df.groupby(['KEY','COMPANY','POLICY_NUMBER','PREMIUM_DUE_DATE','PREMIUM_TYPE','VAT_AMOUNT','VAT_FLAG'])['PAYMENT_DATE'].size().reset_index()['PAYMENT_DATE']>1][['KEY','COMPANY','POLICY_NUMBER','PREMIUM_DUE_DATE','PREMIUM_TYPE','VAT_AMOUNT','VAT_FLAG']]


# In[6]:


#Merging with the main DF
keys1_df = df.merge(keys1,how='inner',on=['KEY','COMPANY','POLICY_NUMBER','PREMIUM_DUE_DATE','PREMIUM_TYPE','VAT_AMOUNT','VAT_FLAG'])
keys2_df = df.merge(keys2,how='inner',on=['KEY','COMPANY','POLICY_NUMBER','PREMIUM_DUE_DATE','PREMIUM_TYPE','VAT_AMOUNT','VAT_FLAG'])


# In[9]:


#Dropping nulls
keys2_df = keys2_df.dropna()
#For cases where multiple premiums have been paid on the same date - sum the premium paid amount
#For cases where premium has been paid for the same due date multiple times - sum the amount paid and keep the latest date
keys2_df = keys2_df.groupby(['KEY','COMPANY','POLICY_NUMBER','PREMIUM_DUE_DATE','PREMIUM_TYPE','VAT_AMOUNT','VAT_FLAG'])['PAYMENT_DATE','PREMIUM_PAID'].agg({'PAYMENT_DATE':np.max,'PREMIUM_PAID':np.sum}).reset_index()


# In[10]:


keys1_df = keys1_df[['KEY','COMPANY','POLICY_NUMBER','PREMIUM_DUE_DATE','PAYMENT_DATE','PREMIUM_PAID','PREMIUM_TYPE','VAT_AMOUNT','VAT_FLAG']]
keys2_df = keys2_df[['KEY','COMPANY','POLICY_NUMBER','PREMIUM_DUE_DATE','PAYMENT_DATE','PREMIUM_PAID','PREMIUM_TYPE','VAT_AMOUNT','VAT_FLAG']]


# In[11]:


df_clean = keys1_df.append(keys2_df)


# In[12]:


len(df_clean)


# In[13]:


df_clean.to_pickle('clean_payment_hist_v2.pkl')

