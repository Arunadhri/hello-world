
# coding: utf-8

# In[1]:


import pandas as pd
import os
import numpy as np
import warnings
warnings.filterwarnings('ignore')

os.chdir(r'\\ns-sisci01hd\home_s01\Citrix_Folder_Redirect\Downloads\SPFD')


# In[178]:


df = pd.read_pickle('Data_For_Agent_Modelling_v2.pkl')
ph = pd.read_pickle('clean_payment_hist_v2.pkl')

# In[179]:


df = df[(df['ISSUE_DATE'].dt.year >= 2000) & (df['ISSUE_DATE'].dt.year < 2017)]
df = df[['AGENT1','KEY','ISSUE_DATE','PAID_TO_DATE','STATUS','LOB']]
df['YEAR'] = df['ISSUE_DATE'].dt.year
df['POLICY_DURATION_SO_FAR'] = (df['PAID_TO_DATE']-df['ISSUE_DATE']).dt.days


# In[182]:


left = df[['AGENT1','YEAR','LOB']].drop_duplicates()


# In[183]:


merge_df = left[left['YEAR']>2009].merge(df,how='left',on=['AGENT1','LOB'])
merge_df['diff_years'] = merge_df['YEAR_x'] - merge_df['YEAR_y']
merge_df = merge_df[(merge_df['diff_years']>0) & (merge_df['diff_years']<11)].drop('diff_years',axis=1).rename(columns=                                                                                                               {'YEAR_x':'YEAR'})


# In[166]:


main_df = merge_df.groupby(['AGENT1','LOB','YEAR'])['KEY'].nunique().reset_index().rename(columns={'KEY':'PoliciesSold'})


# In[167]:


for i in ['Terminated - Lapsed no Value','Terminated - Cash Surrender']:
    temp = merge_df[merge_df['STATUS']==i]
    if 'Lapsed' in i:
        TLNV_lte_6months = temp[temp['POLICY_DURATION_SO_FAR']<=183].groupby(['AGENT1','LOB','YEAR'])['KEY'].nunique()        .reset_index().rename(columns={'KEY':'TLNV_lte_6months_LR'})
        
        TLNV_lte_1year = temp[temp['POLICY_DURATION_SO_FAR']<=366].groupby(['AGENT1','LOB','YEAR'])['KEY'].nunique()        .reset_index().rename(columns={'KEY':'TLNV_lte_1year_LR'})
        
        TLNV_gt_1year_lte_2years = temp[(temp['POLICY_DURATION_SO_FAR']>366) &                                      (temp['POLICY_DURATION_SO_FAR']<=731)].groupby(['AGENT1','LOB','YEAR'])['KEY'].nunique()        .reset_index().rename(columns={'KEY':'TLNV_gt_1year_lte_2years_LR'})
        
        TLNV_gt_2years = temp[temp['POLICY_DURATION_SO_FAR']>731].groupby(['AGENT1','LOB','YEAR'])['KEY'].nunique()        .reset_index().rename(columns={'KEY':'TLNV_gt_2years_LR'})

        main_df = main_df.merge(TLNV_lte_6months,how='left',on=['AGENT1','LOB','YEAR'])
        main_df = main_df.merge(TLNV_lte_1year,how='left',on=['AGENT1','LOB','YEAR'])
        main_df = main_df.merge(TLNV_gt_1year_lte_2years,how='left',on=['AGENT1','LOB','YEAR'])
        main_df = main_df.merge(TLNV_gt_2years,how='left',on=['AGENT1','LOB','YEAR'])
    else:
        TCS_lte_6months = temp[temp['POLICY_DURATION_SO_FAR']<=183].groupby(['AGENT1','LOB','YEAR'])['KEY'].nunique()        .reset_index().rename(columns={'KEY':'TCS_lte_6months_LR'})
        
        TCS_lte_1year = temp[temp['POLICY_DURATION_SO_FAR']<=366].groupby(['AGENT1','LOB','YEAR'])['KEY'].nunique()        .reset_index().rename(columns={'KEY':'TCS_lte_1year_LR'})
        
        TCS_gt_1year_lte_2years = temp[(temp['POLICY_DURATION_SO_FAR']>366) &                                      (temp['POLICY_DURATION_SO_FAR']<=731)].groupby(['AGENT1','LOB','YEAR'])['KEY'].nunique()        .reset_index().rename(columns={'KEY':'TCS_gt_1year_lte_2years_LR'})
        
        TCS_gt_2years = temp[temp['POLICY_DURATION_SO_FAR']>731].groupby(['AGENT1','LOB','YEAR'])['KEY'].nunique()        .reset_index().rename(columns={'KEY':'TCS_gt_2years_LR'})

        main_df = main_df.merge(TCS_lte_6months,how='left',on=['AGENT1','LOB','YEAR'])
        main_df = main_df.merge(TCS_lte_1year,how='left',on=['AGENT1','LOB','YEAR'])
        main_df = main_df.merge(TCS_gt_1year_lte_2years,how='left',on=['AGENT1','LOB','YEAR'])
        main_df = main_df.merge(TCS_gt_2years,how='left',on=['AGENT1','LOB','YEAR'])


# In[169]:


main_df['TLNV_lte_6months_LR'] = round((main_df['TLNV_lte_6months_LR']/main_df['PoliciesSold'])*100,2)
main_df['TLNV_lte_1year_LR'] = round((main_df['TLNV_lte_1year_LR']/main_df['PoliciesSold'])*100,2)
main_df['TLNV_gt_1year_lte_2years_LR'] = round((main_df['TLNV_gt_1year_lte_2years_LR']/main_df['PoliciesSold'])*100,2)
main_df['TLNV_gt_2years_LR'] = round((main_df['TLNV_gt_2years_LR']/main_df['PoliciesSold'])*100,2)
main_df['TCS_lte_6months_LR'] = round((main_df['TCS_lte_6months_LR']/main_df['PoliciesSold'])*100,2)
main_df['TCS_lte_1year_LR'] = round((main_df['TCS_lte_1year_LR']/main_df['PoliciesSold'])*100,2)
main_df['TCS_gt_1year_lte_2years_LR'] = round((main_df['TCS_gt_1year_lte_2years_LR']/main_df['PoliciesSold'])*100,2)
main_df['TCS_gt_2years_LR'] = round((main_df['TCS_gt_2years_LR']/main_df['PoliciesSold'])*100,2)


# In[170]:


main_df['AGENT1'].nunique()


# In[171]:


main_df.to_excel('Agent_Year_LOB_data.xlsx',index=False)


# In[174]:


pivot_df = pd.DataFrame()
for index,row in main_df.iterrows():
    d={}
    d['AGENT1'] = row['AGENT1']
    d['YEAR'] = row['YEAR']
    d[row['LOB']+'_PoliciesSold'] = row['PoliciesSold']
    d[row['LOB']+'_TLNV_lte_6months_LR'] = row['TLNV_lte_6months_LR']
    d[row['LOB']+'_TLNV_lte_1year_LR'] = row['TLNV_lte_1year_LR']
    d[row['LOB']+'_TLNV_gt_1year_lte_2years_LR'] = row['TLNV_gt_1year_lte_2years_LR']
    d[row['LOB']+'_TLNV_gt_2years_LR'] = row['TLNV_gt_2years_LR']
    d[row['LOB']+'_TCS_lte_6months_LR'] = row['TCS_lte_6months_LR']
    d[row['LOB']+'_TCS_lte_1year_LR'] = row['TCS_lte_1year_LR']
    d[row['LOB']+'_TCS_gt_1year_lte_2years_LR'] = row['TCS_gt_1year_lte_2years_LR']
    d[row['LOB']+'_TCS_gt_2years_LR'] = row['TCS_gt_2years_LR']
    pivot_df = pivot_df.append(d,ignore_index=True)


# In[175]:


groupby_cols = list(pivot_df.columns)
groupby_cols.remove('AGENT1')
groupby_cols.remove('YEAR')


# In[176]:


final_pivot = pivot_df.groupby(['AGENT1','YEAR'])[groupby_cols].mean().reset_index()


# In[177]:


final_pivot.to_excel('Agent_Year_Data.xlsx',index=False)

#FILL RATE
#Policies which don't have prem history:
df = pd.read_pickle('Data_For_Agent_Modelling_v2.pkl')
print(df[~df['KEY'].isin(ph['KEY'])]['KEY'].nunique())
print(df[df['KEY'].isin(ph['KEY'])]['KEY'].nunique())
print(df['KEY'].nunique())

print(ph['KEY'].nunique())
print(ph[~ph['KEY'].isin(df['KEY'])]['KEY'].nunique())

x = df[~df['KEY'].isin(ph['KEY'])]

x['STATUS'].value_counts().head()
x['LOB'].value_counts()