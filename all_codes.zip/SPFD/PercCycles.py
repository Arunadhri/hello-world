import pandas as pd
import os
import numpy as np
import warnings
warnings.filterwarnings('ignore')
import random
import string
from scipy.stats import zscore
from pandas import ExcelWriter

os.chdir(r'\\ns-sisci01hd\home_s01\Citrix_Folder_Redirect\Downloads\SPFD')

df = pd.read_pickle('Data_For_Agent_Modelling_v2.pkl')
df = df[~(df['PAID_TO_DATE']>df['MATURITY_DATE'])]

df['TENURE'] = (df['PAID_TO_DATE'] - df['ISSUE_DATE']).dt.days
df['DURATION'] = (df['MATURITY_DATE'] - df['ISSUE_DATE']).dt.days

df1 = df[df['STATUS'] == 'In force (Active)']
df = df[df['STATUS'] != 'In force (Active)']

def change_tenure(x):
    if x['STATUS'] == 'In force (Active)':
        x['TENURE'] = x['DURATION']
    return x
df1 = df1.apply(change_tenure,axis=1)
df = df.append(df1)

df['PaymentFreq'] = np.where(df['PAYMENT_FREQUENCY']=='Monthly',1,\
                                          np.where(df['PAYMENT_FREQUENCY']=='Annual',12,\
                                                   np.where(df['PAYMENT_FREQUENCY']=='Quarterly',3,\
                                                            np.where(df['PAYMENT_FREQUENCY']=='Semi Anual',6,0))))

df['DurationMonths'] = df['DURATION']/30.4375
df['TenureMonths'] = df['TENURE']/30.4375

df['TotalCycles'] = (df['DurationMonths']/df['PaymentFreq']) +1
df['PaidCycles'] = (df['TenureMonths']/df['PaymentFreq']) +1
df['PercCyclesCompleted'] = round((df['PaidCycles']/df['TotalCycles'])*100,2)

df.to_pickle('master_data_with_cycles_completed.pkl')

df = df.drop(['DurationMonths','TenureMonths','TotalCycles','PaidCycles'],axis=1)
df['PLAN_DESC'] = pd.Series(random.choice(string.ascii_uppercase) for _ in range(len(df)))
df['PLAN_DESC'] = df['PLAN_DESC'].fillna('A')

left = df[['LOB','PLAN_DESC','TENURE']]
right = df[['LOB','PLAN_DESC','DURATION']]
mean_ten = left.groupby(['LOB','PLAN_DESC'])['TENURE'].mean().reset_index().rename(columns={'TENURE':'mean_ten'})
mean_dur = right.groupby(['LOB','PLAN_DESC'])['DURATION'].mean().reset_index().rename(columns={'DURATION':'mean_dur'})
std_ten = left.groupby(['LOB','PLAN_DESC'])['TENURE'].mean().reset_index().rename(columns={'TENURE':'std_ten'})
std_dur = right.groupby(['LOB','PLAN_DESC'])['DURATION'].mean().reset_index().rename(columns={'DURATION':'std_dur'})
left = left.merge(mean_ten,how='left',on=['LOB','PLAN_DESC'])
right = right.merge(mean_dur,how='left',on=['LOB','PLAN_DESC'])
left = left.merge(std_ten,how='left',on=['LOB','PLAN_DESC'])
right = right.merge(std_dur,how='left',on=['LOB','PLAN_DESC'])
left['zscore_ten'] = (left['TENURE']-left['mean_ten'])/left['std_ten']
right['zscore_dur'] = (right['DURATION']-right['mean_dur'])/right['std_dur']

left = left.drop_duplicates()
right = right.drop_duplicates()

df_list_str = ['Tenure_zscore','Duration_zscore']
df_list = [left,right]

with ExcelWriter('TenureDurationZscore.xlsx') as writer:
    for name, df in zip(df_list_str,df_list):
        df.to_excel(writer,sheet_name= name,index=False)
    writer.save()
writer.close()