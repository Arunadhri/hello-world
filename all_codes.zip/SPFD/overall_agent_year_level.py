# -*- coding: utf-8 -*-
"""
Created on Tue Feb 26 00:35:09 2019

@author: prathod1
"""

# Code for rolling up data at quarterly level
# ** Required Imports
import pandas as pd
import pickle
#from Common_Functions import pivot_and_reset, drop_columns
import numpy as np
from functools import reduce

# ** Define data path here
data_files_path = (r"\\usrisnasp01hd\home_r01\Citrix_Folder_Redirect\Downloads\\")


out_files_path = (r"\\usrisnasp01hd\home_r01\Citrix_Folder_Redirect\Downloads\Projects"
                    r"\\Fraud Detection\Data\Model Data\\")

# ** Importing the dataset
file_name = "Data_For_Agent_Modelling_v2.pkl"
df = pd.read_pickle(data_files_path + file_name)

end_date = '2016/12/31'
yrs_of_data = 16
last_date = pd.to_datetime(end_date)
start_date = last_date - pd.DateOffset(years=yrs_of_data)
print(f"Filtered for {yrs_of_data} years of data from: {start_date.date()} to {last_date.date()}")

# Filter data between analysis dates
cond1 = df.ISSUE_DATE > start_date
cond2 = df.ISSUE_DATE <= last_date
df = df.loc[cond1 & cond2].reset_index(drop=True)

# Get new customer flag
df = df.sort_values(['INSURED_NAME', 'ISSUE_DATE'])
df['NEW_INSURED'] = df.groupby(['AGENT_CODE', 'LOB', 'INSURED_NAME']).cumcount()+1
df['NEW_INSURED'] = np.where(df['NEW_INSURED'] == 1, 1, 0)

df['ISSUE_DATE_YEAR'] = df['ISSUE_DATE'].dt.year
# ** Calculate number of policies per agent and per LOB per year
grp_by = ['AGENT_CODE', 'LOB', 'ISSUE_DATE_YEAR']
agent_lob_yr = df.groupby(grp_by).size().reset_index(name='n_lob_policies')
agent_yr_lob_col = agent_lob_yr.pivot_table(index = ['AGENT_CODE', 'ISSUE_DATE_YEAR'], columns = 'LOB',
                                         aggfunc = 'sum', fill_value = 0, margins = False)
agent_yr_lob_col.columns = [('_').join(col) for col in agent_yr_lob_col.columns]
agent_yr_lob_col.reset_index(inplace = True)


# ** Calculate number of policies per agent and per LOB per year
df['ISSUE_DATE_QUARTER'] = df['ISSUE_DATE'].dt.quarter
df.loc[df['ISSUE_DATE_QUARTER'] == 1, 'ISSUE_DATE_QUARTER'] = 'Q1'
df.loc[df['ISSUE_DATE_QUARTER'] == 2, 'ISSUE_DATE_QUARTER'] = 'Q2'
df.loc[df['ISSUE_DATE_QUARTER'] == 3, 'ISSUE_DATE_QUARTER'] = 'Q3'
df.loc[df['ISSUE_DATE_QUARTER'] == 4, 'ISSUE_DATE_QUARTER'] = 'Q4'

grp_by = ['AGENT_CODE', 'LOB', 'ISSUE_DATE_YEAR', 'ISSUE_DATE_QUARTER']
agent_lob_stat = df.groupby(grp_by).size().reset_index(name='n_policies')
agent_yr_lob_quart_sta = agent_lob_stat.pivot_table(index=['AGENT_CODE', 'ISSUE_DATE_YEAR'],
                                            columns=['ISSUE_DATE_QUARTER', 'LOB'], values = ['n_policies'],fill_value=0,
                                            margins=False, aggfunc='sum')
agent_yr_lob_quart_sta.columns = [('_').join(col) for col in agent_yr_lob_quart_sta.columns]
agent_yr_lob_quart_sta.reset_index(inplace = True)

"""
agent_yr_pol_lob_status = agent_lob_stat.pivot_table(index=['AGENT_CODE', 'ISSUE_DATE_YEAR'],
                                            columns=['LOB', 'STATUS'], values = ['n_policies'],
                                            fill_value=0,margins=False, aggfunc='sum')
agent_yr_pol_lob_status.columns = [('_').join(col) for col in agent_yr_pol_lob_status.columns]
agent_yr_pol_lob_status.reset_index(inplace = True)"""


#agent_lob_stat = pivot_and_reset(agent_lob_stat)
#sel_status = ['AGENT_CODE', 'LOB', 'ISSUE_DATE_YEAR',
#                'n_policies_In force (Active)',
#                'n_policies_Policy not taken']
#agent_lob_stat = agent_yr_pol_lob_status[sel_status]

grp_by = ['AGENT_CODE', 'ISSUE_DATE_YEAR', 'LOB']
df['sixty_above'] = df['ISSUE_AGE'] >= 60
df['n_lapsed_policies'] = (df['STATUS'] == 'Terminated - Lapsed no Value').astype(int)
agg_dict = {
            'ISSUE_DATE': 'nunique',
            'sixty_above': 'sum',
            'n_lapsed_policies': 'sum'}
rename_dict = {'ISSUE_DATE': 'active_days'}
agent_dy_yr = (df.groupby(grp_by).agg(agg_dict)
                .rename(columns=rename_dict)
                .reset_index())

agent_yr_lob_ad_status = agent_dy_yr.pivot_table(index=['AGENT_CODE', 'ISSUE_DATE_YEAR'],
                                            columns=['LOB'], values = ['active_days', 'sixty_above','n_lapsed_policies'  ], fill_value=0,
                                            margins=False, aggfunc='sum')
agent_yr_lob_ad_status.columns = [('_').join(col) for col in agent_yr_lob_ad_status.columns]
agent_yr_lob_ad_status.reset_index(inplace = True)

# Lapse buckets
df['gap_iss_paid'] = (df['PAID_TO_DATE'] - df['ISSUE_DATE']).dt.days
bins = [-1, 180, 365, 2*365]
labels = ['w_180_days', 'w_1_year', 'w_2_years']
df['gap_iss_paid_bkt'] = pd.cut(df['gap_iss_paid'], bins=bins, labels=labels)
df['lapsed'] = (df['STATUS'] == 'Terminated - Lapsed no Value').astype(int)
df['surrender'] = (df['STATUS'] == 'Terminated - Cash Surrender').astype(int)

grp_by = ['AGENT_CODE', 'ISSUE_DATE_YEAR', 'LOB','gap_iss_paid_bkt']
agg_dict = {'lapsed':'sum'
            ,'surrender': 'sum'
            }

df_lapse_surr = df.groupby(grp_by).agg(agg_dict).reset_index()

df_lapse_surr = df_lapse_surr.pivot_table(index=['AGENT_CODE', 'ISSUE_DATE_YEAR'],
                                        columns=[ 'LOB', 'gap_iss_paid_bkt'], values = ['lapsed', 'surrender'],
                                        fill_value=0)
df_lapse_surr.columns = [('_').join(col) for col in df_lapse_surr.columns]
df_lapse_surr.reset_index(inplace = True)

df['ISSUE_DATE_WEEK'] = df['ISSUE_DATE'].dt.week
# Max Policies in a week
grp_by = ['AGENT_CODE', 'ISSUE_DATE_YEAR', 'LOB', 'ISSUE_DATE_WEEK']
df_weekly = df.groupby(grp_by)['KEY'].size().reset_index(name='week_policies')
#df_weekly = df_weekly.groupby(grp_by)['week_policies'].sum().reset_index(name='week_policies')
df_weekly = df_weekly.groupby(['AGENT_CODE', 'ISSUE_DATE_YEAR', 'LOB'])['week_policies'].max()
df_weekly = df_weekly.reset_index(name='max_policies_week')
df_weekly = df_weekly.pivot_table(index=['AGENT_CODE', 'ISSUE_DATE_YEAR'],
                                            columns=['LOB'], values = ['max_policies_week'], fill_value=0,
                                            margins=False, aggfunc='sum')
df_weekly.columns = [('_').join(col) for col in df_weekly.columns]
df_weekly.reset_index(inplace = True)

# new customers
grp_by = ['AGENT_CODE', 'ISSUE_DATE_YEAR', 'LOB']
df_insured = df.groupby(grp_by)['NEW_INSURED'].sum().reset_index(name = 'n_new_insured')
df_insured = df_insured.pivot_table(index=['AGENT_CODE', 'ISSUE_DATE_YEAR'],
                                            columns=['LOB'], values = ['n_new_insured'], fill_value=0,
                                            margins=False, aggfunc='sum')
df_insured.columns = [('_').join(col) for col in df_insured.columns]
df_insured.reset_index(inplace = True)


all_dfs = [agent_yr_lob_col, agent_yr_lob_ad_status,  df_insured, df_lapse_surr,
            df_weekly]

final_df = reduce(lambda left, right: pd.merge(left, right, how='left',
                                                on=['AGENT_CODE', 
                                                    'ISSUE_DATE_YEAR']),
                                                all_dfs)
final_df = final_df.fillna(0, inplace=False)


cols = ['n_lob_policies_Accident & Health',
       'n_lob_policies_Annuity - Education',
       'n_lob_policies_Annuity - Retirement', 'n_lob_policies_Life',
       'n_lob_policies_Unit Linked', 'n_lob_policies_Universal Life',
       'active_days_Accident & Health', 'active_days_Annuity - Education',
       'active_days_Annuity - Retirement', 'active_days_Life',
       'active_days_Unit Linked', 'active_days_Universal Life',
       'n_lapsed_policies_Accident & Health',
       'n_lapsed_policies_Annuity - Education',
       'n_lapsed_policies_Annuity - Retirement', 'n_lapsed_policies_Life',
       'n_lapsed_policies_Unit Linked', 'n_lapsed_policies_Universal Life',
       'sixty_above_Accident & Health', 'sixty_above_Annuity - Education',
       'sixty_above_Annuity - Retirement', 'sixty_above_Life',
       'sixty_above_Unit Linked', 'sixty_above_Universal Life',
       'n_new_insured_Accident & Health', 'n_new_insured_Annuity - Education',
       'n_new_insured_Annuity - Retirement', 'n_new_insured_Life',
       'n_new_insured_Unit Linked', 'n_new_insured_Universal Life',
       'lapsed_Accident & Health_w_180_days',
       'lapsed_Accident & Health_w_1_year',
       'lapsed_Accident & Health_w_2_years',
       'lapsed_Annuity - Education_w_180_days',
       'lapsed_Annuity - Education_w_1_year',
       'lapsed_Annuity - Education_w_2_years', 'lapsed_Life_w_180_days',
       'lapsed_Life_w_1_year', 'lapsed_Life_w_2_years',
       'lapsed_Unit Linked_w_180_days', 'lapsed_Unit Linked_w_1_year',
       'lapsed_Unit Linked_w_2_years', 'lapsed_Universal Life_w_180_days',
       'lapsed_Universal Life_w_1_year', 'lapsed_Universal Life_w_2_years',
       'surrender_Accident & Health_w_180_days',
       'surrender_Accident & Health_w_1_year',
       'surrender_Accident & Health_w_2_years',
       'surrender_Annuity - Education_w_180_days',
       'surrender_Annuity - Education_w_1_year',
       'surrender_Annuity - Education_w_2_years', 'surrender_Life_w_180_days',
       'surrender_Life_w_1_year', 'surrender_Life_w_2_years',
       'surrender_Unit Linked_w_180_days', 'surrender_Unit Linked_w_1_year',
       'surrender_Unit Linked_w_2_years',
       'surrender_Universal Life_w_180_days',
       'surrender_Universal Life_w_1_year',
       'surrender_Universal Life_w_2_years']

max_cols = ['max_policies_week_Accident & Health',
       'max_policies_week_Annuity - Education',
       'max_policies_week_Annuity - Retirement', 'max_policies_week_Life',
       'max_policies_week_Unit Linked', 'max_policies_week_Universal Life']

for col in cols:
    final_df[col + '_p10yr_val'] = (final_df.groupby(['AGENT_CODE'], sort = False)[col]
                                  .rolling(window=11, min_periods=1).sum()
                                  .reset_index(0, drop=True)) - final_df[col]

req_cols = []    
for col in final_df.columns:
    if col.endswith('_p10yr_val'):
        req_cols.append(col)
        
max_df = pd.DataFrame()
for col in max_cols:
    max_df[col + '_p10yr_val'] = (final_df.groupby(['AGENT_CODE'], sort = False)[col]
                                  .rolling(window=10, min_periods=1).max()
                                  .reset_index(0, drop=True))
max_df_columns = max_df.columns
max_df = pd.concat([final_df[['AGENT_CODE', 'ISSUE_DATE_YEAR']], max_df], axis = 1)
max_df['ISSUE_DATE_YEAR'] = max_df['ISSUE_DATE_YEAR']+1
final_df = final_df.merge(max_df, on= ['AGENT_CODE', 'ISSUE_DATE_YEAR'], how = 'left')

policy_count_across_lobs = ['n_lob_policies_Accident & Health_p10yr_val',
'n_lob_policies_Annuity - Education_p10yr_val',
'n_lob_policies_Annuity - Retirement_p10yr_val',
'n_lob_policies_Life_p10yr_val',
'n_lob_policies_Unit Linked_p10yr_val',
'n_lob_policies_Universal Life_p10yr_val']

policy_count_across_lobs_within_yr = ['n_lob_policies_Accident & Health',
       'n_lob_policies_Annuity - Education',
       'n_lob_policies_Annuity - Retirement', 'n_lob_policies_Life',
       'n_lob_policies_Unit Linked', 'n_lob_policies_Universal Life']

##Computig no of policies issued in  previous active 10 years 
final_df['n_lob_policies_p10yr_val'] = final_df[policy_count_across_lobs].sum(axis =1)
final_df['n_lob_policies'] = final_df[policy_count_across_lobs_within_yr].sum(axis =1)

req_cols1 = ['AGENT_CODE', 'ISSUE_DATE_YEAR'] + req_cols + list( max_df_columns) + ['n_lob_policies_p10yr_val','n_lob_policies']
final_df = final_df[req_cols1]

cond1 = final_df['n_lob_policies_p10yr_val'] != 0
cond2 = final_df['ISSUE_DATE_YEAR'] > 2010
cond3 = final_df['n_lob_policies'] > 1
final_df = final_df.loc[cond1 & cond2 & cond3].reset_index(drop=True)

for col in req_cols:
    final_df[col+'_perc'] = (final_df[col]/final_df['n_lob_policies_p10yr_val'])*100

