#!/usr/bin/env python
# coding: utf-8

# In[2]:


import os
import pandas as pd
import numpy as np

os.chdir(r'\\ns-sisci01hd\home_s01\Citrix_Folder_Redirect\Downloads')


# In[197]:


df = pd.read_pickle('Premium_History_Data.pkl')
#Empty Row
df = df.drop(14146897)
#Removing whitespaces from strings
df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
df['COMPANY'] = df['COMPANY'].astype(int)
df = df.drop_duplicates()
#Filling NA since we need to group this data
df['VAT_FLAG'] = df[['VAT_FLAG']].fillna('NULL')


# In[209]:


#Rows which are unique at a 'KEY','PREMIUM_DUE_DATE','VAT_AMOUNT','VAT_FLAG' level
keys1 = df.groupby(['KEY','PREMIUM_DUE_DATE','VAT_AMOUNT','VAT_FLAG'])['PAYMENT_DATE'].size().reset_index()[df.groupby(['KEY','PREMIUM_DUE_DATE','VAT_AMOUNT','VAT_FLAG'])['PAYMENT_DATE'].size().reset_index() ['PAYMENT_DATE']==1][['KEY','PREMIUM_DUE_DATE','VAT_AMOUNT','VAT_FLAG']]

#Rows which have multiple values at a 'KEY','PREMIUM_DUE_DATE','VAT_AMOUNT','VAT_FLAG' level
keys2 = df.groupby(['KEY','PREMIUM_DUE_DATE','VAT_AMOUNT','VAT_FLAG'])['PAYMENT_DATE'].size().reset_index()[df.groupby(['KEY','PREMIUM_DUE_DATE','VAT_AMOUNT','VAT_FLAG'])['PAYMENT_DATE'].size().reset_index() ['PAYMENT_DATE']>1][['KEY','PREMIUM_DUE_DATE','VAT_AMOUNT','VAT_FLAG']]


# In[210]:


#Merging with the main DF to get all columns
keys1_df = df.merge(keys1,how='inner',on=['KEY','PREMIUM_DUE_DATE','VAT_AMOUNT','VAT_FLAG'])
keys2_df = df.merge(keys2,how='inner',on=['KEY','PREMIUM_DUE_DATE','VAT_AMOUNT','VAT_FLAG'])


# In[211]:


#Dropping rows where payment date is null and we have multiple rows for the key and due date
keys2_df = keys2_df.dropna()


# In[212]:


#For cases where multiple premiums have been paid on the same date - sum the premium paid amount
#For cases where premium has been paid for the same due date multiple times - sum the amount paid and keep the latest date
keys2_df = keys2_df.groupby(['KEY','PREMIUM_DUE_DATE','VAT_AMOUNT','VAT_FLAG'])['PAYMENT_DATE','PREMIUM_PAID'].agg({'PAYMENT_DATE':np.max,'PREMIUM_PAID':np.sum}).reset_index()


# In[213]:


#Appending the unilevel and multilevel data
df_clean = keys1_df.append(keys2_df,sort=True)


# In[218]:


df_clean = df_clean[['KEY','COMPANY','POLICY_NUMBER','PREMIUM_DUE_DATE','PAYMENT_DATE','PREMIUM_PAID','PREMIUM_TYPE','VAT_AMOUNT','VAT_FLAG']]


# In[ ]:


df_clean.to_pickle('clean_payment_hist.pkl')


# In[219]:


df_clean.head(10)


# In[266]:


other_data = pd.read_pickle('Data_For_Agent_Modelling_v2.pkl')


# In[269]:


#Merging master data with prem history data
other_data = other_data[['KEY','AGENT1','LOB','ISSUE_DATE','PAYMENT_FREQUENCY']]
other_data = other_data.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
other_data = other_data.drop_duplicates()
prem_hist_agent = df_clean.merge(other_data,how='inner',on='KEY')
prem_hist_agent = prem_hist_agent[prem_hist_agent['LOB']=='Life']


# In[285]:


#Calculating delay parameters
prem_hist_agent['DelayInPayment(days)'] = (prem_hist_agent['PAYMENT_DATE'] - prem_hist_agent['PREMIUM_DUE_DATE']).dt.days
prem_hist_agent['IssuedToDueDate(days)'] = (prem_hist_agent['PREMIUM_DUE_DATE'] - prem_hist_agent['ISSUE_DATE']).dt.days
prem_hist_agent['IssuedToPaidDate(days)'] = (prem_hist_agent['PAYMENT_DATE'] - prem_hist_agent['ISSUE_DATE']).dt.days


# In[318]:


#Agent level basic stats - policies for which payment was made
prem_hist_agent[(prem_hist_agent['PAYMENT_DATE'].notnull()) & (prem_hist_agent['PREMIUM_PAID']>0)].\
groupby(['AGENT1','PAYMENT_FREQUENCY'])['DelayInPayment(days)','IssuedToDueDate(days)','IssuedToPaidDate(days)',\
'KEY'].agg({'KEY':['nunique','count'],'DelayInPayment(days)':'mean','IssuedToDueDate(days)':'mean','IssuedToPaidDate(days)':\
	'mean'}).reset_index().sort_values(by=[('KEY','nunique')],ascending=False).to_excel('Agent_PaidPolicies.xlsx')


# In[317]:


#Agent level basic stats - policies for which payment wasn't made
prem_hist_agent[(prem_hist_agent['PAYMENT_DATE'].isnull())]\
.groupby(['AGENT1','PAYMENT_FREQUENCY'])['DelayInPayment(days)','IssuedToDueDate(days)','IssuedToPaidDate(days)','KEY'].\
agg({'KEY':['nunique','count'],'DelayInPayment(days)':'mean','IssuedToDueDate(days)':'mean','IssuedToPaidDate(days)':'mean'})\
.reset_index().sort_values(by=[('KEY','nunique')],ascending=False).to_excel('Agent_NoPaymentPolicies.xlsx')


# In[ ]:




