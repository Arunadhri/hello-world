#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 22 14:52:52 2018

@author: praveenrathod
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import ShuffleSplit
from sklearn.preprocessing import StandardScaler, MinMaxScaler, MaxAbsScaler, Normalizer
from sklearn.decomposition import PCA, TruncatedSVD

from estimators import (AverageKLPE, MaxKLPE, OCSVM,
                                       KernelSmoothing, IsolationForest, LocalOutlierFactor)
from tuning import anomaly_tuning
import time


def fillAnomaly(req_data_ref, df, scale_param, time_df, ref):
    temp1 = df.copy()
    n_estimator = 50
    N_JOBS = 1
    n_samples = df.shape[0]
    alpha_set = 0.9

    X = np.asarray(df[:])

    algorithms = [AverageKLPE, MaxKLPE, OCSVM, IsolationForest, LocalOutlierFactor]
    #algorithms = [AverageKLPE]
    #algorithms = [IsolationForest]
    #algorithms = [OCSVM]
    #algorithms = [LocalOutlierFactor]
    scaling_techniques = {'StandardScaler' :StandardScaler, 'MinMaxScaler':MinMaxScaler, 'MaxAbsScaler':MaxAbsScaler, 'Normalizer':Normalizer}
    algo_param = {'aklpe': {'k': np.arange(1, min(50, int(0.8 * n_samples)), 2),
                            'novelty': [True]},
                  'mklpe': {'k': np.arange(1, min(50, int(0.8 * n_samples)), 2),
                            'novelty': [True]},
                  'ocsvm': {'sigma': np.linspace(0.01, 5., 50)},
                  'iforest': {'max_samples': np.linspace(0.1, 1., 10)},
                  'ks': {'bandwidth': np.linspace(0.01, 5., 50)},
                  'LOF':{'n_neighbors': np.arange(1, min(50, int(0.8 * n_samples)), 2)}
                  }

    
    if scale_param :
        print('Preparocssing data with ' + scale_param)
        X = scaling_techniques[scale_param]().fit_transform(X)

    
    # Tuning step
    cv = ShuffleSplit(n_splits=n_estimator, test_size=0.2, random_state=42)
    

    
    outliers = {}
    for algo in algorithms:
        
#        if algo.name in ['aklpe', 'LOF']:
#            d_model = PCA(n_components = 0.90)
#            X = d_model.fit_transform(X)

        name_algo = algo.name
        print('--------------', name_algo, ' -------------')
        parameters = algo_param[name_algo]
        dat_length = len(X)
        start_time = time.ctime()

        models, off_set = anomaly_tuning(X, base_estimator=algo,
                                   parameters=parameters,
                                   random_state=42,
                                   cv=cv, n_jobs=N_JOBS)
        
        end_time = time.ctime()
        temp_dict = {"Data_length" :[dat_length], "Algo_name":[algo.name], "start_time":start_time, "end_time":end_time }
        temp_df =pd.DataFrame.from_dict(temp_dict) 
        time_df = pd.concat([time_df, temp_df], ignore_index =True)

        Z_data = np.zeros((n_samples,))
        
        if algo.name == 'LOF':
            for n_est in range(n_estimator):
                clf = models[n_est]
                print("Z_data_shape", Z_data.shape, "clf score sample", (clf.score_samples(X)).shape)
                Z_data += 1. / n_estimator * (clf.score_samples(X))
#                
#                clf = models[n_est]
#                clf_dict = clf.get_params()
#                clf_new = LocalOutlierFactor(**clf_dict)
#                Z_data = clf_new.fit_predict(X)
#    
            off_data = np.percentile(Z_data, 100 * (1 - alpha_set))
            outliers[name_algo] = Z_data - off_data < 0
            
            ####
#            outliers[name_algo] = Z_data
            #####
#            off_data = np.percentile(Z_data, 100 * (1 - alpha_set))
#            outliers[name_algo] = Z_data - off_data < 0
            temp =  pd.DataFrame(outliers)
            temp1 = pd.concat([req_data_ref, temp1], axis=1)
            cln = algo.name + '_scores'
            temp1[cln] = Z_data
            (pd.concat([temp1,temp], axis =1)).to_csv(name_algo+ref+'_results.csv', index = False)
        else:
            
            for n_est in range(n_estimator):
                clf = models[n_est]
                Z_data += 1. / n_estimator * (clf.score_samples(X))
                #Z_data = clf.predict(X)
            off_data = np.percentile(Z_data, 100 * (1 - alpha_set))
            outliers[name_algo] = Z_data - off_data < 0
#            outliers[name_algo] = Z_data
            temp =  pd.DataFrame(outliers)
            temp1 = pd.concat([req_data_ref, temp1], axis=1)
            cln = algo.name + '_scores'
            temp1[cln] = Z_data
            (pd.concat([temp1, temp], axis =1)).to_csv(name_algo+ref+'_results.csv', index = False)
#            if algo.name == 'iforest':
#                rules_df = pd.DataFrame(columns = ['index', 'rules'])
#                count = 0
#
#                for tree_idx, est in enumerate(clf.estimators_):
#                    tree = est.tree_
#                    assert tree.value.shape[1] == 1
#            
#            
#                    iterator = enumerate(zip(tree.children_left, tree.children_right, tree.feature, tree.threshold, tree.value))
#                    for node_idx, data in iterator:
#                        left, right, feature, th, value = data
#            
#                        # left: index of left child (if any)
#                        # right: index of right child (if any)
#                        # feature: index of the feature to check
#                        # th: the threshold to compare against
#                        # value: values associated with classes            
#            
#                        # for classifier, value is 0 except the index of the class to return
#                        class_idx = np.argmax(value[0])
#            
#                        if left == -1 and right == -1:
#                            rules_df.loc[count, 'index'] = node_idx
#                            rules_df.loc[count, 'rules'] = str(node_idx) + ' LEAF: return class=' + str(class_idx)
#                            count = count+1
#                        else:
#                            rules_df.loc[count, 'index'] = node_idx
#                            rules_df.loc[count, 'rules'] = str(node_idx) + ' NODE: if feature[' + str(feature) + '] <' + str(th) + ' then next=' + str(left) + ' else next='+ str(right)
#                            count = count+1
#                rules_df.to_csv(name_algo+ref+'_n_est_' + str(n_est) + '_rules.csv', index = False)
            

            
    outliers = pd.DataFrame(outliers)
    return outliers, time_df, clf, off_set, Z_data
#    if IsolationForest in algorithms:
#        return outliers, time_df, clf, off_set, Z_data, rules_df
#    else:
#        return outliers, time_df, clf, off_set, Z_data, None

res_dict = dict()
res, time, models, off_set, scores = fillAnomaly(req_data_ref = final_df_1[['AGENT1','YEAR']],
                        df=final_df_1.drop(['AGENT1','YEAR'],axis=1),
                       scale_param = 'StandardScaler',
                       time_df = pd.DataFrame(columns = ["Data_length", "Algo_name", "start_time", "end_time"]),
                       ref = 'Overall_Model_klpe')
refer = '_01032019_ul_ag'
res_dict[refer] = [res, time, models, off_set, scores]