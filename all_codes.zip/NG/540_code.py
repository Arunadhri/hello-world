import pandas as pd
import numpy as np
df = pd.read_csv()

df = df.drop(['MJR_XSUSP_3YR_CNT', 'MNR_VIOL_1YR_CNT',
             'MNR_VIOL_3YR_CNT', 'CAF_1YR_CNT', 'CAF_3YR_CNT',
              'NCAF_1YR_CNT', 'NCAF_3YR_CNT', 'BSIC_CVR_IND'], axis=1)

df['YNG_RT_DRV_AGE_YR'] = df['YNG_RT_DRV_AGE_YR']\
                            .apply(lambda x: 0 if x == 'BL' else x)
df['OLD_RT_DRV_AGE_YR'] = df['OLD_RT_DRV_AGE_YR']\
                            .apply(lambda x: 0 if x == 'BL' else x)


def f_GENERATION(x):
    if abs(x["OLD_RT_DRV_AGE_YR"] - x["YNG_RT_DRV_AGE_YR"]) > 19:
        return "DIFF"
    else:
        return "SAME"
df["GENERATION"] = df.apply(f_GENERATION, axis=1)


def f_CLASS(x):
    if x["DRV_CNT"] <= "01" and x["PRNCPL_INS_SEX_CD"] == " ":
        return 1
    if x["DRV_CNT"] <= "01" and x["PRNCPL_INS_SEX_CD"] == "F":
        return 1
    if x["DRV_CNT"] <= "01" and x["PRNCPL_INS_SEX_CD"] == "M":
        return 3
    if x["DRV_CNT"] == "02" and x["VEH_CNT"] <= "01"\
            and x["GENERATION"] == "SAME":
        return 4
    if x["DRV_CNT"] == "02" and x["VEH_CNT"] >= "02"\
            and x["GENERATION"] == "SAME" and x["OLD_RT_DRV_AGE_YR"] < 40:
        return 5
    if x["DRV_CNT"] == "02" and x["VEH_CNT"] >= "02"\
            and x["GENERATION"] == "SAME" and x["OLD_RT_DRV_AGE_YR"] >= 40:
        return 6
    if x["DRV_CNT"] == "02" and x["VEH_CNT"] <= "01"\
            and x["GENERATION"] == "DIFF" and x["YTH_ON_POL_IND"] == "Y":
        return 8
    if x["DRV_CNT"] == "02" and x["VEH_CNT"] <= "01"\
            and x["GENERATION"] == "DIFF" and x["YTH_ON_POL_IND"] == "N":
        return 7
    if x["DRV_CNT"] == "02" and x["VEH_CNT"] >= "02"\
            and x["GENERATION"] == "DIFF" and x["YTH_ON_POL_IND"] == "Y":
        return 8
    if x["DRV_CNT"] == "02" and x["VEH_CNT"] >= "02"\
            and x["GENERATION"] == "DIFF" and x["YTH_ON_POL_IND"] == "N":
        return 7
    if x["DRV_CNT"] >= "03" and x["VEH_CNT"] <= "02"\
            and x["YTH_ON_POL_IND"] == "Y":
        return 8
    if x["DRV_CNT"] >= "03" and x["VEH_CNT"] <= "02"\
            and x["YTH_ON_POL_IND"] == "N":
        return 7
    if x["DRV_CNT"] >= "03" and x["VEH_CNT"] >= "03"\
            and x["YTH_ON_POL_IND"] == "Y":
        return 11
    if x["DRV_CNT"] >= "03" and x["VEH_CNT"] >= "03"\
            and x["YTH_ON_POL_IND"] == "N":
        return 12
    else:
        return 6
df["CLASS"] = df.apply(f_CLASS, axis=1)


def f_MARITAL_STTS(x):
    if x["MRY_STTS_DSCR"] == "            "\
            or x["MRY_STTS_DSCR"] == "SINGLE      ":
        return "SINGLE"
    elif x["MRY_STTS_DSCR"] == "SEPARATED   "\
            or x["MRY_STTS_DSCR"] == "DIVORCED    "\
            or x["MRY_STTS_DSCR"] == "DVRCED/ CUST":
        return "DIVORCE"
    elif x["MRY_STTS_DSCR"] == "MARRIED     ":
        return "MARRY"
    elif x["MRY_STTS_DSCR"] == "WIDOWED     ":
        return "WIDOW"
    else:
        return "SINGLE"
df["MARITAL_STTS"] = df.apply(f_MARITAL_STTS, axis=1)


def f_Parse_Counts(df):
    df['NEGL_IND_1_3_YR'] = df['NEGL_IND_3_YR_Sum'] - df['NEGL_IND_1_YR']
    df['PCT_LIAB_0_IND_1_3_YR'] = df['PCT_LIAB_0_IND_3_YR_Sum'] -\
        df['PCT_LIAB_0_IND_1_YR']
    df['PCT_LIAB_100_IND_1_3_YR'] = df['PCT_LIAB_100_IND_3_YR_Sum'] -\
        df['PCT_LIAB_100_IND_1_YR']
    df['BI_HI_SEV_IND_1_3_YR'] = df['BI_HI_SEV_IND_3_YR_Sum'] -\
        df['BI_HI_SEV_IND_1_YR']
    df['COL_HI_SEV_IND_1_3_YR'] = df['COL_HI_SEV_IND_3_YR_Sum'] -\
        df['COL_HI_SEV_IND_1_YR']
    df['COM_HI_SEV_IND_1_3_YR'] = df['COM_HI_SEV_IND_3_YR_Sum'] -\
        df['COM_HI_SEV_IND_1_YR']
    df['NF_HI_SEV_IND_1_3_YR'] = df['NF_HI_SEV_IND_3_YR_Sum'] -\
        df['NF_HI_SEV_IND_1_YR']
    df['PDL_HI_SEV_IND_1_3_YR'] = df['PDL_HI_SEV_IND_3_YR_Sum'] -\
        df['PDL_HI_SEV_IND_1_YR']
    df['UM_HI_SEV_IND_1_3_YR'] = df['UM_HI_SEV_IND_3_YR_Sum'] -\
        df['UM_HI_SEV_IND_1_YR']
    df['NF_IND_1_3_YR'] = df['NF_IND_3_YR_Sum'] - df['NF_IND_1_YR']
    df['THFT_VNDL_IND_1_3_YR'] = df['THFT_VNDL_IND_3_YR_Sum'] -\
        df['THFT_VNDL_IND_1_YR']
    df['NEGL_IND_3_5_YR'] = df['NEGL_IND_5_YR_Sum'] - df['NEGL_IND_3_YR']
    df['PCT_LIAB_0_IND_3_5_YR'] = df['PCT_LIAB_0_IND_5_YR_Sum'] -\
        df['PCT_LIAB_0_IND_3_YR']
    df['PCT_LIAB_100_IND_3_5_YR'] = df['PCT_LIAB_100_IND_5_YR_Sum'] -\
        df['PCT_LIAB_100_IND_3_YR']
    df['BI_HI_SEV_IND_3_5_YR'] = df['BI_HI_SEV_IND_5_YR_Sum'] -\
        df['BI_HI_SEV_IND_3_YR']
    df['COL_HI_SEV_IND_3_5_YR'] = df['COL_HI_SEV_IND_5_YR_Sum'] -\
        df['COL_HI_SEV_IND_3_YR']
    df['COM_HI_SEV_IND_3_5_YR'] = df['COM_HI_SEV_IND_5_YR_Sum'] -\
        df['COM_HI_SEV_IND_3_YR']
    df['NF_HI_SEV_IND_3_5_YR'] = df['NF_HI_SEV_IND_5_YR_Sum'] -\
        df['NF_HI_SEV_IND_3_YR']
    df['PDL_HI_SEV_IND_3_5_YR'] = df['PDL_HI_SEV_IND_5_YR_Sum'] -\
        df['PDL_HI_SEV_IND_3_YR']
    df['UM_HI_SEV_IND_3_5_YR'] = df['UM_HI_SEV_IND_5_YR_Sum'] -\
        df['UM_HI_SEV_IND_3_YR']
    df['NF_IND_3_5_YR'] = df['NF_IND_5_YR_Sum'] - df['NF_IND_3_YR']
    df['THFT_VNDL_IND_3_5_YR'] = df['THFT_VNDL_IND_5_YR_Sum'] -\
        df['THFT_VNDL_IND_3_YR']

    cols_grt_2 = ["CTSTRPH_ELGBL_IND_1_YR", "NEGL_IND_1_YR",
                  "TOT_LOSS_IND_1_YR", "PCT_LIAB_0_IND_1_YR",
                  "PCT_LIAB_25_IND_1_YR", "PCT_LIAB_50_IND_1_YR",
                  "PCT_LIAB_75_IND_1_YR", "PCT_LIAB_99_IND_1_YR",
                  "PCT_LIAB_100_IND_1_YR", "BI_HI_SEV_IND_1_YR",
                  "COL_HI_SEV_IND_1_YR", "COM_HI_SEV_IND_1_YR",
                  "NF_HI_SEV_IND_1_YR", "PDL_HI_SEV_IND_1_YR",
                  "UM_HI_SEV_IND_1_YR", "NF_IND_1_YR",
                  "THFT_VNDL_IND_1_YR", "LOSS_EARNINGS_IND_1_YR",
                  "LOSS_SERVICES_IND_1_YR", "HAIL_IND_1_YR",
                  "FIRE_IND_1_YR", "WEATHER_NONHAIL_IND_1_YR",
                  "CTSTRPH_ELGBL_IND_1_3_YR", "NEGL_IND_1_3_YR",
                  "TOT_LOSS_IND_1_3_YR", "PCT_LIAB_0_IND_1_3_YR",
                  "PCT_LIAB_25_IND_1_3_YR", "PCT_LIAB_50_IND_1_3_YR",
                  "PCT_LIAB_75_IND_1_3_YR", "PCT_LIAB_99_IND_1_3_YR",
                  "PCT_LIAB_100_IND_1_3_YR", "BI_HI_SEV_IND_1_3_YR",
                  "COL_HI_SEV_IND_1_3_YR", "COM_HI_SEV_IND_1_3_YR",
                  "NF_HI_SEV_IND_1_3_YR", "PDL_HI_SEV_IND_1_3_YR",
                  "UM_HI_SEV_IND_1_3_YR", "NF_IND_1_3_YR",
                  "THFT_VNDL_IND_1_3_YR", "LOSS_EARNINGS_IND_1_3_YR",
                  "LOSS_SERVICES_IND_1_3_YR", "HAIL_IND_1_3_YR",
                  "FIRE_IND_1_3_YR", "WEATHER_NONHAIL_IND_1_3_YR",
                  "CTSTRPH_ELGBL_IND_3_5_YR", "NEGL_IND_3_5_YR",
                  "TOT_LOSS_IND_3_5_YR", "PCT_LIAB_0_IND_3_5_YR",
                  "PCT_LIAB_25_IND_3_5_YR", "PCT_LIAB_50_IND_3_5_YR",
                  "PCT_LIAB_75_IND_3_5_YR", "PCT_LIAB_99_IND_3_5_YR",
                  "PCT_LIAB_100_IND_3_5_YR", "BI_HI_SEV_IND_3_5_YR",
                  "COL_HI_SEV_IND_3_5_YR", "COM_HI_SEV_IND_3_5_YR",
                  "NF_HI_SEV_IND_3_5_YR", "PDL_HI_SEV_IND_3_5_YR",
                  "UM_HI_SEV_IND_3_5_YR", "NF_IND_3_5_YR",
                  "THFT_VNDL_IND_3_5_YR", "LOSS_EARNINGS_IND_3_5_YR",
                  "LOSS_SERVICES_IND_3_5_YR", "HAIL_IND_3_5_YR",
                  "FIRE_IND_3_5_YR", "WEATHER_NONHAIL_IND_3_5_YR"]

    def f_Parse_Counts_replace_grt_2(x):
        return 2 if x >= 2 else x
    df[cols_grt_2] = df[cols_grt_2].applymap()

    def f_Parse_Counts_ACCD_3YR_IND(x):
        if x["ACCD_3YR_CNT"] > x["ACCD_1YR_CNT"]:
            return 1
        else:
            return 0
    df["ACCD_3YR_IND"] = df.apply(f_Parse_Counts_ACCD_3YR_IND, axis=1)

    return df

df = f_Parse_Counts(df)


def f_PFM(x):
    if x["PFM_LVL_CD"] == "  " or x["PFM_LVL_CD"] == "00" \
        or (x["(PFM_LVL_CD"] == "NF" or x["PFM_LVL_CD"] == "NK" or
            x["PFM_LVL_CD"] == "NN" or x["PFM_LVL_CD"] == "NQ")\
            or x["PFM_LVL_CD"] == "2B":
        return "N"
    elif x["PFM_LVL_CD"] == "2G":
        return "2A"
    elif x["PFM_LVL_CD"] == "1G":
        return "1A"
    elif x["PFM_LVL_CD"] == "3G" or x["PFM_LVL_CD"] == "3D":
        return "3A"
    elif x["PFM_LVL_CD"] == "4G" or x["PFM_LVL_CD"] == "4D":
        return "4A"
    elif x["substring(1,1, PFM_LVL_CD)"] == "C":
        return "C"
    elif x["substring(1,1, PFM_LVL_CD)"] == "D":
        return "D"
    elif x["substring(1,1, PFM_LVL_CD)"] == "E":
        return "E"
    elif x["substring(1,1, PFM_LVL_CD)"] == "F":
        return "F"
    elif x["substring(1,1, PFM_LVL_CD)"] == "G":
        return "G_H"
    elif x["substring(1,1, PFM_LVL_CD)"] == "H":
        return "G_H"
    elif x["substring(1,1, PFM_LVL_CD)"] == "B":
        return "B"
    else:
        return x["PFM_LVL_CD"]
df["PFM"] = df.applymap(f_PFM)


def f_PAY_PLANS(x):
    if x["PY_PLN_NM"] == "10 PAY   " or (x["PY_PLN_NM"] == "3 PAY    " or
                                         x["PY_PLN_NM"] == "4 PAY    " or
                                         x["PY_PLN_NM"] == "9 PAY    ")\
            or x["PY_PLN_NM"] == "MONTHLY  ":
        return "N_PAY"
    elif x["PY_PLN_NM"] == "CRED CARD" or x["PY_PLN_NM"] == "EXPRESSIT":
        return "CC"
    else:
        return x["PY_PLN_NM"]
df["PAY_PLANS"] = df.applymap(f_PAY_PLANS)


def f_TIER(x):
    if x["FDB_TIER_CD"] == "N1" or x["FDB_TIER_CD"] == "P1"\
        or x["FDB_TIER_CD"] == "Q1" or x["FDB_TIER_CD"] == "R1"\
        or x["FDB_TIER_CD"] == "S1" or x["FDB_TIER_CD"] == "T1"\
            or x["FDB_TIER_CD"] == "U1":
        return "20_UP"
    elif x["FDB_TIER_CD"] == "J1" or x["FDB_TIER_CD"] == "JI":
        return "13_15"
    elif x["FDB_TIER_CD"] == "H1":
        return "06_12"
    elif x["FDB_TIER_CD"] == "K1":
        return "16_19"
    elif x["FDB_TIER_CD"] == "L1":
        return "16_19"
    elif x["FDB_TIER_CD"] == "M1":
        return "20_UP"
    elif x["FDB_TIER_CD"] >= "20":
        return "20_UP"
    elif x["FDB_TIER_CD"] >= "16" and x["FDB_TIER_CD"] <= "19":
        return "16_19"
    elif x["FDB_TIER_CD"] >= "13" and x["FDB_TIER_CD"] <= "15":
        return "13_15"
    elif x["FDB_TIER_CD"] >= "06" and x["FDB_TIER_CD"] <= "12":
        return "06_12"
    elif x["FDB_TIER_CD"] >= "00" and x["FDB_TIER_CD"] <= "05":
        return "00_05"
    else:
        return "13_15"
df["TIER"] = df.apply(f_TIER, axis=1)


def f_BUS_SOURCE(x):
    if x["SRC_OF_BUS_CD"] == "IB " or x["SRC_OF_BUS_CD"] == "PCS" or\
            x["SRC_OF_BUS_CD"] == "DRM":
        return "OTHR"
    elif x["SRC_OF_BUS_CD"] == "TSU":
        return "IA "
    else:
        return x["SRC_OF_BUS_CD"]
df["BUS_SOURCE"] = df.applymap(f_BUS_SOURCE)

cols_to_trim = ["LIAB_ONLY_IND", "ALT_GRG_IND", "MULTIVEH_IND", "PELP_POL_IND",
                "BOAT_POL_IND", "CONDO_POL_IND", "RNT_POL_IND", "OWN_POL_IND",
                "HOME_POL_IND", "LNDLRD_POL_IND", "HIGH_VAL_CUST_IND"]


def f_Blank_IND(x):
    return "N" if x.strip() == "" else x

df[cols_to_trim] = df[cols_to_trim].applymap(f_Blank_IND)


def f_BI_LIMIT(x):
    if x["BI_POL_LMT_DSCR"] == "          ":
        return "BLANK"
    elif (x["(BI_POL_LMT_DSCR"] == "  50/100  " or
          x["BI_POL_LMT_DSCR"] == "  50/50   ")\
        or (x["(BI_POL_LMT_DSCR"] == "  60      " or
            x["BI_POL_LMT_DSCR"] == " 100      "):
        return "050_100"
    elif x["BI_POL_LMT_DSCR"] == " 100/200  " or\
        x["BI_POL_LMT_DSCR"] == " 100/300  " \
        or x["BI_POL_LMT_DSCR"] == " 200      " or\
            x["BI_POL_LMT_DSCR"] == " 300      " \
            or x["BI_POL_LMT_DSCR"] == " 300/300  ":
        return "100_300"
    elif x["BI_POL_LMT_DSCR"] == "  25/50   ":
        return "025_050"
    elif (x["(BI_POL_LMT_DSCR"] == " 500      " or
          x["BI_POL_LMT_DSCR"] == " 500/1000 " or
          x["BI_POL_LMT_DSCR"] == " 500/500  " or
            x["BI_POL_LMT_DSCR"] == "1000      " or
            x["BI_POL_LMT_DSCR"] == "1000/1000 "):
        return "500_1000"
    elif x["BI_POL_LMT_DSCR"] == " 250/500  ":
        return "250_500"
    else:
        return "100_300"
df["BI_LIMIT"] = df.apply(f_BI_LIMIT, axis=1)

df["NO_LATE_PAY_IND"] = df["N_LT_PY_CD"].apply(lambda x: 1 if x == "Y" else 0)
df["HOWN_CLM_CNT"] = df["HOWN_CLM_CNT"]\
    .apply(lambda x: "03_04" if x >= "03" else x)
df["HOWN_CLM_CNT"] = df["HOWN_CLM_CNT"]\
    .apply(lambda x: "BLNK" if x.strip() == "" else x)
df["HOWN_CLM_CNT"] = df["HOWN_CLM_CNT"]\
    .apply(lambda x: "01_02" if x.strip() in ["01", "02"] "" else x)


def f_OCCUPATION(x):
    if x["OCC_DSCR"] == "                              " \
            or x["OCC_DSCR"] == "UNKNOWN                       ":
        return "UNKN"
    elif x["OCC_DSCR"] == "CNTRCTRS/BLDRS- SELF-EMPL     " \
        or x["OCC_DSCR"] == "OTHER SELF-EMPLOYED           " \
        or (x["(OCC_DSCR"] == "SALES (SELF-EMPLOYED)         " or
            x["OCC_DSCR"] == "SELF-EMPLOYED                 ")or\
            x["OCC_DSCR"] == "STORE OWNER                   ":
        return "SELF"
    elif x["OCC_DSCR"] == "EXECUTIVE/PROFESSIONAL        " \
            or x["OCC_DSCR"] == "PROFESSIONALS                 ":
        return "Z_OTHER"
    elif x["OCC_DSCR"] == "EMPLOYED                      ":
        return "EMPL"
    elif x["OCC_DSCR"] == "STUDENT                       ":
        return "STUD"
    elif x[" OCC_DSCR"] == "UNEMPLOYED                    ":
        return "UNEMPL"
    elif x["OCC_DSCR"] == "NON-MANAGEMENT STAFF          ":
        return "NON_MNG_STF"
    elif x["OCC_DSCR"] == "OTHER EMPLOYED                ":
        return "OTHR_EMPL"
    elif x["OCC_DSCR"] == "HOUSEWIFE                     ":
        return "HS_WIFE"
    elif x[" OCC_DSCR"] == "MANAGEMENT STAFF              ":
        return "MNG_STF"
    elif x["OCC_DSCR"] == "RETIRED                       ":
        return "RET"
    elif x["OCC_DSCR"] == "CLERICAL                      ":
        return "Z_OTHER"
    else:
        return "Z_OTHER"
df["OCCUPATION"] = df.apply(f_OCCUPATION, axis=1)


def f_POLICY_EVENT(x):
    if x["LIF_EVNT_DSCR"] == "                       " \
        or x["LIF_EVNT_DSCR"] == "GRNDFTHRD TENURE       " \
            or x["LIF_EVNT_DSCR"] == "REWRITES               ":
        return "Z_OTHR"
    elif x["LIF_EVNT_DSCR"] == "SPIN-OFF               ":
        return "SPIN"
    elif x["LIF_EVNT_DSCR"] == "ST TO ST TRANSF        ":
        return "ST_2_ST"
    elif x["LIF_EVNT_DSCR"] == "YTHFUL SPINOFF         ":
        return "Y_SPIN"
    else:
        return "Z_OTHR"
df["POLICY_EVENT"] = df.apply(f_POLICY_EVENT, axis=1)

df.loc[df["TENURE"] == -1, "TENURE"] = 0
df.loc[df["TENURE"] >= 31, "TENURE"] = 31


def f_MINIMUM_SYMBOL(x):
    if x["MIN_SYMBOL"].isnull():
        return "10_12"
    if x["MIN_SYMBOL"] == 0:
        return "10_12"
    if x["MIN_SYMBOL"] == 1:
        return "01_05"
    if x["MIN_SYMBOL"] == 2:
        return "01_05"
    if x["MIN_SYMBOL"] == 3:
        return "01_05"
    if x["MIN_SYMBOL"] == 4:
        return "01_05"
    if x["MIN_SYMBOL"] == 5:
        return "01_05"
    if x["MIN_SYMBOL"] == 6:
        return "6"
    if x["MIN_SYMBOL"] == 7:
        return "7"
    if x["MIN_SYMBOL"] == 8:
        return "8"
    if x["MIN_SYMBOL"] == 9:
        return "9"
    if x["MIN_SYMBOL"] == 10:
        return "10_12"
    if x["MIN_SYMBOL"] == 11:
        return "10_12"
    if x["MIN_SYMBOL"] == 12:
        return "10_12"
    if x["MIN_SYMBOL"] == 13:
        return "13"
    if x["MIN_SYMBOL"] == 14:
        return "14_UP"
    if x["MIN_SYMBOL"] == 15:
        return "14_UP"
    if x["MIN_SYMBOL"] == 16:
        return "14_UP"
    if x["MIN_SYMBOL"] == 17:
        return "14_UP"
    if x["MIN_SYMBOL"] == 18:
        return "14_UP"
    if x["MIN_SYMBOL"] == 19:
        return "14_UP"
    if x["MIN_SYMBOL"] == 20:
        return "14_UP"
    if x["MIN_SYMBOL"] == 21:
        return "14_UP"
    if x["MIN_SYMBOL"] == 22:
        return "14_UP"
    if x["MIN_SYMBOL"] == 23:
        return "14_UP"
    if x["MIN_SYMBOL"] >= 24:
        return "14_UP"
df["MINIMUM_SYMBOL"] = df.apply(f_MINIMUM_SYMBOL, axis=1)


def f_MAX_MNS_MIN_SYMB(x):

    if (x["MAX_SYMBOL"] - x["MIN_SYMBOL"]).isnull() and\
            x["MULTIVEH_IND"].strip() == "Y":
        return "00Y"
    if (x["MAX_SYMBOL"] - x["MIN_SYMBOL"]).isnull() and\
            x["MULTIVEH_IND"] == "N":
        return "00N"
    if (x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 0) and\
            x["MULTIVEH_IND"].strip() == "Y":
        return "00Y"
    if (x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 0) and\
            x["MULTIVEH_IND"].strip() == "N":
        return "00N"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 1:
        return "1"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 2:
        return "02_03"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 3:
        return "02_03"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 4:
        return "04_05"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 5:
        return "04_05"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 6:
        return "06_07"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 7:
        return "06_07"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 8:
        return "08_10"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 9:
        return "08_10"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 10:
        return "08_10"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 11:
        return "11_UP"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 12:
        return "11_UP"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 13:
        return "11_UP"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 14:
        return "11_UP"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 15:
        return "11_UP"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 16:
        return "11_UP"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] == 17:
        return "11_UP"
    if x["MAX_SYMBOL"] - x["MIN_SYMBOL"] >= 18:
        return "11_UP"
df["MAX_MNS_MIN_SYMB"] = df.apply(f_MAX_MNS_MIN_SYMB, axis=1)


def f_Reclassify(df):
    restrict_cols = ["NEGL_IND_1_YR", "PCT_LIAB_100_IND_1_YR",
                     "BI_HI_SEV_IND_1_YR", "COL_HI_SEV_IND_1_YR",
                     "COM_HI_SEV_IND_1_YR", "NF_HI_SEV_IND_1_YR",
                     "PDL_HI_SEV_IND_1_YR", "UM_HI_SEV_IND_1_YR",
                     "NF_IND_1_YR", "THFT_VNDL_IND_1_YR",
                     "BI_HI_SEV_IND_1_3_YR", "COL_HI_SEV_IND_1_3_YR",
                     "COM_HI_SEV_IND_1_3_YR", "NF_HI_SEV_IND_1_3_YR",
                     "PDL_HI_SEV_IND_1_3_YR", "UM_HI_SEV_IND_1_3_YR",
                     "NF_IND_1_3_YR", "THFT_VNDL_IND_1_3_YR",
                     "NEGL_IND_3_5_YR", "BI_HI_SEV_IND_3_5_YR",
                     "COL_HI_SEV_IND_3_5_YR", "COM_HI_SEV_IND_3_5_YR",
                     "NF_HI_SEV_IND_3_5_YR", "PDL_HI_SEV_IND_3_5_YR",
                     "UM_HI_SEV_IND_3_5_YR", "NF_IND_3_5_YR",
                     "THFT_VNDL_IND_3_5_YR"]

    def f_Reclassify_restrict(x):
        return 1 if x >= 1 else x

        df[restrict_cols] = df[restrict_cols].applymap(f_Reclassify_restrict)

        fix_blanks_n = ["GOOD_STUD_IND", "YTH_ON_POL_IND", "PCIS_ORPH_BUS_IND",
                        "ALT_GRG_IND", "MULTIVEH_IND", "HIGH_TIER_IND",
                        "PELP_POL_IND", "BOAT_POL_IND", "CONDO_POL_IND",
                        "RNT_POL_IND", "OWN_POL_IND", "HOME_POL_IND",
                        "LNDLRD_POL_IND"]

    def f_Reclassify_fix_blanks_n(x):
        return "N" if x.strip() == "" else x

    df[fix_blanks_n] = df[fix_blanks_n].applymap(f_Reclassify_fix_blanks_n)

    fix_blanks_00 = ["ACCD_1YR_CNT", "THFT_VNDL_1YR_CNT"]

    def f_Reclassify_fix_blanks_00(x):
        return "00" if x.strip() == "" else x

    df[fix_blanks_00] = df[fix_blanks_00].applymap(f_Reclassify_fix_blanks_00)

    df.loc[df["THFT_VNDL_1YR_CNT"] >= "01", "THFT_VNDL_1YR_CNT"] = "01"
    df.loc[df["ACCD_1YR_CNT"] >= "02", "ACCD_1YR_CNT"] = "02"
    df.loc[df["PRNCPL_INS_SEX_CD"].strip() == "", "PRNCPL_INS_SEX_CD"] = "BLNK"
    df.loc[df["RISK_REGION"].strip() == "", "RISK_REGION"] = "BLNK"
    df.loc[(df["RISK_REGION"] == "BH") or
           (df["RISK_REGION"] == "BL"), "RISK_REGION"] = "BU"
    df.loc[df["PAY_PLANS"] == "HOME ACCT", "PAY_PLANS"] = "FLEX PAY "
    df.loc[df["RISK_REGION"].isnull(), "RISK_REGION"] = "UP"

    def f_Reclassify_TENURE(x):
        if x == 4:
            return "04_06"
        if x == 5:
            return "04_06"
        if x == 6:
            return "04_06"
        if x == 7:
            return "07_10"
        if x == 8:
            return "07_10"
        if x == 9:
            return "07_10"
        if x == 10:
            return "07_10"
        if x == 11:
            return "11_12"
        if x == 12:
            return "11_12"
        if x == 13:
            return "13_14"
        if x == 14:
            return "13_14"
        if x == 15:
            return "15_UP"
        if x == 16:
            return "15_UP"
        if x == 17:
            return "15_UP"
        if x == 18:
            return "15_UP"
        if x == 19:
            return "15_UP"
        if x == 20:
            return "15_UP"
        if x == 21:
            return "15_UP"
        if x == 22:
            return "15_UP"
        if x == 23:
            return "15_UP"
        if x == 24:
            return "15_UP"
        if x == 25:
            return "15_UP"
        if x == 26:
            return "15_UP"
        if x == 27:
            return "15_UP"
        if x == 28:
            return "15_UP"
        if x == 29:
            return "15_UP"
        if x == 30:
            return "15_UP"
        if x == 31:
            return "15_UP"
    df["TENURE"] = df.apply(f_Reclassify_TENURE, axis=1)

    df.loc[df["PFM"].strip().isin(["4A", "4B"]), "PFM"] = "04"
    df.loc[df["PFM"].strip().isin(["3A", "3B"]), "PFM"] = "03"
    df.loc[df["PFM"].strip().isin(["2A"]), "PFM"] = "02"
    df.loc[df["PFM"].strip().isin(["1A", "1B"]), "PFM"] = "01"

    return df

df = f_Reclassify(df)


def f_NEW_VARS(df):

    def f_NEW_VARS_HI_SEV_1YR_IND(x):
        if (x["BI_HI_SEV_IND_1_YR"] + x["COL_HI_SEV_IND_1_YR"] +
            x["COM_HI_SEV_IND_1_YR"] + x["NF_HI_SEV_IND_1_YR"] +
                x["PDL_HI_SEV_IND_1_YR"] + x["UM_HI_SEV_IND_1_YR)"]) >= 1:
            return 1
        else:
            return 0
    df["HI_SEV_1YR_IND"] = df.apply(f_NEW_VARS_HI_SEV_1YR_IND, axis=1)

    def f_NEW_VARS_PELP_BOAT_IND(x):
        if x["PELP_POL_IND"] == "Y" or x["BOAT_POL_IND"] == "Y":
            return "Y"
        else:
            return "N"
    df["PELP_BOAT_IND"] = df.apply(f_NEW_VARS_PELP_BOAT_IND, axis=1)

    def f_NEW_VARS_RENT_CONDO_IND(x):
        if x["RNT_POL_IND"] == "Y" or x["CONDO_POL_IND"] == "Y":
            return "Y"
        else:
            return "N"
    df["RENT_CONDO_IND"] = df.apply(f_NEW_VARS_RENT_CONDO_IND, axis=1)

    def f_NEW_VARS_HOME_LANDL_IND(x):
        if x["HOME_POL_IND"] == "Y" or x["LNDLRD_POL_IND"] == "Y":
            return "Y"
        else:
            return "N"
    df["HOME_LANDL_IND"] = df.apply(f_NEW_VARS_HOME_LANDL_IND, axis=1)

    def f_NEW_VARS_HI_SEV_1_3YR_IND(x):
        if (x["BI_HI_SEV_IND_1_3_YR"] + x["COL_HI_SEV_IND_1_3_YR"] +
            x["COM_HI_SEV_IND_1_3_YR"] + x["NF_HI_SEV_IND_1_3_YR"] +
                x["PDL_HI_SEV_IND_1_3_YR"] + x["UM_HI_SEV_IND_1_3_YR)"]) >= 1:
            return 1
        else:
            return 0
    df["HI_SEV_1_3YR_IND"] = df.apply(f_NEW_VARS_HI_SEV_1_3YR_IND, axis=1)

    def f_NEW_VARS_HI_SEV_3_5YR_IND(x):
        if (x["BI_HI_SEV_IND_3_5_YR"] + x["COL_HI_SEV_IND_3_5_YR"] +
            x["COM_HI_SEV_IND_3_5_YR"] + x["NF_HI_SEV_IND_3_5_YR"] +
                x["PDL_HI_SEV_IND_3_5_YR"] + x["UM_HI_SEV_IND_3_5_YR)"]) >= 1:
            return 1
        else:
            return 0
    df["HI_SEV_3_5YR_IND"] = df.apply(f_NEW_VARS_HI_SEV_3_5YR_IND, axis=1)

    def f_NEW_VARS_SRC_REGION(x):
        if x["BUS_SOURCE"] == "GPC " and x["AGENT_REGION"].isnull():
            return "G_NL"
        elif x["BUS_SOURCE"] == "GPC " and (x["AGENT_REGION"] == "BF" or
                                            x["AGENT_REGION"] == "UP"):
            return "G_UP"
        elif x["BUS_SOURCE"] == "GPC " and (x["AGENT_REGION"] == "LI"):
            return "G_LI"
        elif x["BUS_SOURCE"] == "GPC " and x["AGENT_REGION"] == "WC":
            return "G_WC"
        elif x["BUS_SOURCE"] == "GPC " and (x["AGENT_REGION"] == "BH" or
                                            x["AGENT_REGION"] == "BL"):
            return "G_BU"
        elif x["BUS_SOURCE"] == "IA  " and x["AGENT_REGION"].isnull():
            return "I_NL"
        elif x["BUS_SOURCE"] == "IA  " and (x["AGENT_REGION"] == "BF" or
                                            x["AGENT_REGION"] == "UP"):
            return "I_UP"
        elif x["BUS_SOURCE"] == "IA  " and (x["AGENT_REGION"] == "BH" or
                                            x["AGENT_REGION"] == "BL"):
            return "I_BU"
        elif x["BUS_SOURCE"] == "IA  " and x["AGENT_REGION"] == "LI":
            return "I_LI"
        elif x["BUS_SOURCE"] == "IA  " and x["AGENT_REGION"] == "WC":
            return "I_WC"
        elif x["BUS_SOURCE"] == "OTHR" and x["AGENT_REGION"].isnull():
            return "O_NL"
        elif x["BUS_SOURCE"] == "OTHR" and (x["AGENT_REGION"] == "BF" or
                                            x["AGENT_REGION"] == "UP"):
            return "O_UP"
        elif x["BUS_SOURCE"] == "OTHR" and (x["AGENT_REGION"] == "BH" or
                                            x["AGENT_REGION"] == "BL"):
            return "O_BU"
        elif x["BUS_SOURCE"] == "OTHR" and x["AGENT_REGION"] == "LI":
            return "O_LI"
        elif x["BUS_SOURCE"] == "OTHR" and x["AGENT_REGION"] == "WC":
            return "O_WC"
        else:
            return "G_UP"
    df["SRC_REGION"] = df.apply(f_NEW_VARS_SRC_REGION, axis=1)

    def f_NEW_VARS_fillers(df):
        df.loc[(df["SRC_REGION"].strip() == "G_NL") &
               (df["RISK_REGION"].strip() == "BU"), "SRC_REGION"] = "G_BU"

        df.loc[(df["SRC_REGION"].strip() == "G_NL") &
               (df["RISK_REGION"].strip() == "BF"), "SRC_REGION"] = "G_UP"

        df.loc[(df["SRC_REGION"].strip() == "G_NL") &
               (df["RISK_REGION"].strip() == "WC"), "SRC_REGION"] = "G_WC"

        df.loc[(df["SRC_REGION"].strip() == "G_NL") &
               (df["RISK_REGION"].strip() == "LI"), "SRC_REGION"] = "G_LI"

        df.loc[(df["SRC_REGION"].strip() == "I_NL") &
               (df["RISK_REGION"].strip() == "BU"), "SRC_REGION"] = "I_BU"

        df.loc[(df["SRC_REGION"].strip() == "I_NL") &
               (df["RISK_REGION"].strip() == "BF"), "SRC_REGION"] = "I_UP"

        df.loc[(df["SRC_REGION"].strip() == "I_NL") &
               (df["RISK_REGION"].strip() == "WC"), "SRC_REGION"] = "I_WC"

        df.loc[(df["SRC_REGION"].strip() == "I_NL") &
               (df["RISK_REGION"].strip() == "LI"), "SRC_REGION"] = "I_LI"

        df.loc[(df["SRC_REGION"].strip() == "O_NL") &
               (df["RISK_REGION"].strip() == "BU"), "SRC_REGION"] = "O_BU"

        df.loc[(df["SRC_REGION"].strip() == "O_NL") &
               (df["RISK_REGION"].strip() == "BF"), "SRC_REGION"] = "O_UP"

        df.loc[(df["SRC_REGION"].strip() == "O_NL") &
               (df["RISK_REGION"].strip() == "WC"), "SRC_REGION"] = "O_WC"

        df.loc[(df["SRC_REGION"].strip() == "O_NL") &
               (df["RISK_REGION"].strip() == "LI"), "SRC_REGION"] = "O_LI"

        return df

    df = f_NEW_VARS_fillers(df)

    df.loc[df["BILL_REGION"].isin(["BH", "BL"]), "BILL_REGION"] = "BU"
    df.loc[df["BILL_REGION"].isnull(), "BILL_REGION"] = "UP"

    def f_NEW_VARS_ALT_GAR_IND_DERIVED(x):
        if x["BILL_REGION"].strip() != x["RISK_REGION"].strip():
            return "Y"
        else:
            return "N"
    df["ALT_GAR_IND_DERIVED"] = df.apply(f_NEW_VARS_ALT_GAR_IND_DERIVED,
                                         axis=1)

    def f_NEW_VARS_HI_SEV_0_5YR_IND(x):
        if (x["HI_SEV_1YR_IND"] + x["HI_SEV_1_3YR_IND"] +
                x["HI_SEV_3_5YR_IND)"]) >= 1:
            return 1
        else:
            return 0
    df["HI_SEV_0_5YR_IND"] = df.apply(f_NEW_VARS_HI_SEV_0_5YR_IND, axis=1)

    def f_NEW_VARS_NF_0_5YR_IND(x):
        if (x["NF_IND_1_YR"] + x["NF_IND_1_3_YR"] + x["NF_IND_3_5_YR)"]) >= 1:
            return 1
        else:
            return 0
    df["NF_0_5YR_IND"] = df.apply(f_NEW_VARS_NF_0_5YR_IND, axis=1)

    def f_NEW_VARS_THFT_VNDL_0_5YR_IND(x):
        if (x["THFT_VNDL_IND_1_YR"] + x["THFT_VNDL_IND_1_3_YR"] +
                x["THFT_VNDL_IND_3_5_YR)"]) >= 1:
            return 1
        else:
            return 0
    df["THFT_VNDL_0_5YR_IND"] = df.apply(f_NEW_VARS_THFT_VNDL_0_5YR_IND,
                                         axis=1)

    df.loc[(df["YTH_ON_POL_IND"] == "Y") &
           (df["GOOD_STUD_IND"] == "N"), "GOOD_STUD_IND"] = "NY"

    def f_NEW_VARS_CONF_USE_VAR(x):
        if x["CONFIDENCE_USE_CD"].strip() == "3":
            return "02"
        elif x["CONFIDENCE_USE_CD"].strip() == "2":
            return "02"
        elif x["CONFIDENCE_USE_CD"].isnull():
            return "NL"
        elif x["CONFIDENCE_USE_CD"].strip() == "1":
            return "01"
        else:
            return "01"
    df["CONF_USE_VAR"] = df.apply(f_NEW_VARS_CONF_USE_VAR, axis=1)

    def f_NEW_VARS_MKT_DEC_VAR(x):
        if x["MKT_DEC"].isnull():
            return "NL"
        elif x["MKT_DEC"].strip() == "01" or x["MKT_DEC"].strip() == "02":
            return "01_04"
        elif x["MKT_DEC"].strip() == "03" or x["MKT_DEC"].strip() == "04":
            return "01_04"
        elif x["MKT_DEC"].strip() == "05" or x["MKT_DEC"].strip() == "06" or\
                x["MKT_DEC"].strip() == "07":
            return "05_10"
        elif x["MKT_DEC"].strip() == "08" or x["MKT_DEC"].strip() == "09" or\
                x["MKT_DEC"].strip() == "10":
            return "05_10"
        elif x["MKT_DEC"].strip() == "":
            return "BLK"
        else:
            return "BLK"
    df["MKT_DEC_VAR"] = df.apply(f_NEW_VARS_MKT_DEC_VAR, axis=1)

    def f_NEW_VARS_PROPERTY_TYPE_VAR(x):
        if x["PROPERTY_TYPE"].strip() == "B":
            return "B"
        elif x["PROPERTY_TYPE"].isnull():
            return "NL"
        elif x["PROPERTY_TYPE"].strip() == "":
            return "BLK"
        elif x["PROPERTY_TYPE"].strip() == "A":
            return "A"
        elif x["PROPERTY_TYPE"].strip() == "C":
            return "C"
        else:
            return "C"
    df["PROPERTY_TYPE_VAR"] = df.apply(f_NEW_VARS_PROPERTY_TYPE_VAR, axis=1)

    def f_NEW_VARS_ESI_VAR(x):
        if x["ESI"].isnull():
            return "NL"
        elif x["ESI"].strip() == "" or x["ESI"].strip() == "01" or\
                x["ESI"].strip() == "02":
            return "01_05"
        elif x["ESI"].strip() == "03" or x["ESI"].strip() == "04" or\
                x["ESI"].strip() == "05":
            return "01_05"
        elif x["ESI"].strip() == "06" or x["ESI"].strip() == "07" or\
                x["ESI"].strip() == "08" or x["ESI"].strip() == "09":
            return "06_09"
        elif x["ESI"].strip() == "10" or x["ESI"].strip() == "11" or\
            x["ESI"].strip() == "12" or x["ESI"].strip() == "13" or\
                x["ESI"].strip() == "14" or x["ESI"].strip() == "15":
            return "10_30"
        elif x["ESI"].strip() == "16" or x["ESI"].strip() == "17" or\
            x["ESI"].strip() == "18" or x["ESI"].strip() == "19" or\
            x["ESI"].strip() == "20" or x["ESI"].strip() == "21" or\
            x["ESI"].strip() == "22" or x["ESI"].strip() == "23" or\
            x["ESI"].strip() == "24" or x["ESI"].strip() == "25" or\
            x["ESI"].strip() == "26" or x["ESI"].strip() == "27" or\
            x["ESI"].strip() == "28" or x["ESI"].strip() == "29" or\
                x["ESI"].strip() == "30":
            return "10_30"
        else:
            return "01_05"
    df["ESI_VAR"] = df.apply(f_NEW_VARS_ESI_VAR, axis=1)

    def f_NEW_VARS_HEAVY_TRAN_VAR(x):
        if x["HEAVY_TRAN"].isnull():
            return "NL"
        elif x["HEAVY_TRAN"].strip() == "" or x["HEAVY_TRAN"].strip() == "01"\
                or x["HEAVY_TRAN"].strip() == "02":
            return "01_11"
        elif x["HEAVY_TRAN"].strip() == "03" or\
                x["HEAVY_TRAN"].strip() == "04":
            return "01_11"
        elif x["HEAVY_TRAN"].strip() == "05" or\
            x["HEAVY_TRAN"].strip() == "06" or\
                x["HEAVY_TRAN"].strip() == "07":
            return "01_11"
        elif x["HEAVY_TRAN"].strip() == "08" or\
            x["HEAVY_TRAN"].strip() == "09" or\
            x["HEAVY_TRAN"].strip() == "10" or\
                x["HEAVY_TRAN"].strip() == "11":
            return "01_11"
        elif x["HEAVY_TRAN"].strip() >= "12":
            return "12_20"
        else:
            return "01_11"
    df["HEAVY_TRAN_VAR"] = df.apply(f_NEW_VARS_HEAVY_TRAN_VAR, axis=1)

    def f_NEW_VARS_DYTM_TV_VAR(x):
        if x["DYTM_TV_SCOR_CD"].isnull():
            return "NL"
        elif x["DYTM_TV_SCOR_CD"].strip() == "" or\
            x["DYTM_TV_SCOR_CD"].strip() == "01" or\
            x["DYTM_TV_SCOR_CD"].strip() == "02" or\
                x["DYTM_TV_SCOR_CD"].strip() == "03":
            return "01_03"
        elif x["DYTM_TV_SCOR_CD"].strip() == "04" or\
            x["DYTM_TV_SCOR_CD"].strip() == "05" or\
                x["DYTM_TV_SCOR_CD"].strip() == "06":
            return "04_06"
        elif x["DYTM_TV_SCOR_CD"].strip() == "07" or\
                x["DYTM_TV_SCOR_CD"].strip() == "08":
            return "07_10"
        elif x["DYTM_TV_SCOR_CD"].strip() == "09" or\
                x["DYTM_TV_SCOR_CD"].strip() == "10":
            return "07_10"
        else:
            return "04_06"
    df["DYTM_TV_VAR"] = df.apply(f_NEW_VARS_DYTM_TV_VAR, axis=1)

    def f_NEW_VARS_CSN_GM_VAR(x):
        if x["CSN_GM_PRPNST_SCOR_CD"].isnull():
            return "NL"
        elif x["CSN_GM_PRPNST_SCOR_CD"].strip() == "01":
            return "01_07"
        elif x[" CSN_GM_PRPNST_SCOR_CD"].strip() == "02" or\
                x["CSN_GM_PRPNST_SCOR_CD"].strip() == "":
            return "01_07"
        elif x[" CSN_GM_PRPNST_SCOR_CD"].strip() == "03":
            return "01_07"
        elif x["CSN_GM_PRPNST_SCOR_CD"].strip() == "04" or\
                x["CSN_GM_PRPNST_SCOR_CD"].strip() == "05":
            return "01_07"
        elif x["CSN_GM_PRPNST_SCOR_CD"].strip() == "06" or\
                x["CSN_GM_PRPNST_SCOR_CD"].strip() == "07":
            return "01_07"
        elif x["CSN_GM_PRPNST_SCOR_CD"].strip() == "08" or\
            x["CSN_GM_PRPNST_SCOR_CD"].strip() == "09" or\
                x["CSN_GM_PRPNST_SCOR_CD"].strip() == "10":
            return "08_10"
        else:
            return "01_07"
    df["CSN_GM_VAR"] = df.apply(f_NEW_VARS_CSN_GM_VAR, axis=1)

    def f_NEW_VARS_GARDEN_VAR(x):
        if x["BUY_GARDENING_C"].isnull():
            return "NL"
        elif x["BUY_GARDENING_C"].strip() == "1":
            return "Y"
        else:
            return "N"
    df["GARDEN_VAR"] = df.apply(f_NEW_VARS_GARDEN_VAR, axis=1)

    return df

df = f_NEW_VARS(df)

filter_cols = ["PCT_LIAB_0_IND_1_3_YR", "PCT_LIAB_100_IND_1_3_YR",
               "BI_HI_SEV_IND_1_3_YR", "COL_HI_SEV_IND_1_3_YR",
               "COM_HI_SEV_IND_1_3_YR", "NF_HI_SEV_IND_1_3_YR",
               "PDL_HI_SEV_IND_1_3_YR", "UM_HI_SEV_IND_1_3_YR",
               "PCT_LIAB_0_IND_3_5_YR", "PCT_LIAB_100_IND_3_5_YR",
               "BI_HI_SEV_IND_3_5_YR", "COL_HI_SEV_IND_3_5_YR",
               "COM_HI_SEV_IND_3_5_YR", "NF_HI_SEV_IND_3_5_YR",
               "PDL_HI_SEV_IND_3_5_YR", "UM_HI_SEV_IND_3_5_YR"]

df = df.drop(filter_cols, axis=1)

df["LOG_EP"] = np.log(100)

trim_cols = ["VEH_CNT", "DRV_CNT", "HIGH_VAL_CUST_IND", "YTH_ON_POL_IND",
             "GOOD_STUD_IND", "MULTIVEH_IND", "HOWN_CLM_CNT", "ACCD_1YR_CNT",
             "PRNCPL_INS_SEX_CD", "RISK_REGION", "BILL_REGION", "AGENT_REGION",
             "PFM", "PAY_PLANS", "TIER", "BUS_SOURCE", "MKT_DEC_VAR",
             "PROPERTY_TYPE_VAR", "ESI_VAR", "HEAVY_TRAN_VAR", "DYTM_TV_VAR",
             "CSN_GM_VAR", "GARDEN_VAR"]


def f_trim_cols(x):
    return x.strip()

df[trim_cols] = df[trim_cols].applymap(f_trim_cols)

# ROUND LOSS (CHAMP_ALL_DATA) Nugget
beta_coeff_file = pd.read_pickle("beta.pkl")
offset = df['LOG_EP'].unique()[0]
model_vars = list(beta_coeff_file['name'].unique())
all_vars = list(df.columns)
id_vars = [i for i in all_vars if i not in model_vars]
df_melt = df.melt(id_vars=id_vars, value_vars=model_vars, var_name='name', value_name='value')
df_melt = beta_coeff_file.merge(df_melt, how='inner', on=['name', 'value'])

def f_distribution(x):
	if x['optype'] == 'categorical':
		return x['beta']
	elif x['optype'] == 'continuous':
		return x['beta'] * x['value']
	else:
		return np.nan

df_melt['Importance'] = df_melt.apply(f_distribution, axis=1)
df_melt = df_melt.groupby(id_vars)['Importance'].sum().reset_index()
intercept = beta_coeff_file[beta_coeff_file['name'] == 'INTERCEPT']['beta'].iloc[0]

df_melt["$G-ROUND_LOSS"] = df_melt['Importance'].apply(lambda x: offset*(x+intercept))
df_melt = df_melt[id_vars+['$G-ROUND_LOSS']]
df = df.merge(df_melt,how='left', on=id_vars)
#df["$G-ROUND_LOSS"] = df['LOG_EP'] * np.exp(intercept + df_melt["Importance"].sum())

df["PRED_LR"] = df["$G-ROUND_LOSS"] / 100


def f_CENTILE(x):
    if x["PRED_LR"] <= 0.2887151910831118:
        return 1
    elif x["PRED_LR"] <= 0.308861930193402:
        return 2
    elif x["PRED_LR"] <= 0.32257842608167286:
        return 3
    elif x["PRED_LR"] <= 0.3332646079736832:
        return 4
    elif x["PRED_LR"] <= 0.34242800160535036:
        return 5
    elif x["PRED_LR"] <= 0.35062889648771184:
        return 6
    elif x["PRED_LR"] <= 0.3579633052088016:
        return 7
    elif x["PRED_LR"] <= 0.3647228051226559:
        return 8
    elif x["PRED_LR"] <= 0.37105784782705525:
        return 9
    elif x["PRED_LR"] <= 0.37699021353937473:
        return 10
    elif x["PRED_LR"] <= 0.38271615704099965:
        return 11
    elif x["PRED_LR"] <= 0.3882374367353451:
        return 12
    elif x["PRED_LR"] <= 0.3933995937698128:
        return 13
    elif x["PRED_LR"] <= 0.39846403395394386:
        return 14
    elif x["PRED_LR"] <= 0.40339362816949587:
        return 15
    elif x["PRED_LR"] <= 0.408256435730666:
        return 16
    elif x["PRED_LR"] <= 0.41297600059972833:
        return 17
    elif x["PRED_LR"] <= 0.4175136287077612:
        return 18
    elif x["PRED_LR"] <= 0.42191325018199777:
        return 19
    elif x["PRED_LR"] <= 0.4263400030871915:
        return 20
    elif x["PRED_LR"] <= 0.4307223585183877:
        return 21
    elif x["PRED_LR"] <= 0.4351170148832047:
        return 22
    elif x["PRED_LR"] <= 0.4393304808030923:
        return 23
    elif x["PRED_LR"] <= 0.44364152005551555:
        return 24
    elif x["PRED_LR"] <= 0.4479279477184844:
        return 25
    elif x["PRED_LR"] <= 0.45213586635457975:
        return 26
    elif x["PRED_LR"] <= 0.4563647008838989:
        return 27
    elif x["PRED_LR"] <= 0.46060171308683184:
        return 28
    elif x["PRED_LR"] <= 0.46468825586100876:
        return 29
    elif x["PRED_LR"] <= 0.46882799370083106:
        return 30
    elif x["PRED_LR"] <= 0.47320157743128816:
        return 31
    elif x["PRED_LR"] <= 0.47740290887717785:
        return 32
    elif x["PRED_LR"] <= 0.48149605301701964:
        return 33
    elif x["PRED_LR"] <= 0.48574637963538103:
        return 34
    elif x["PRED_LR"] <= 0.49005961823764754:
        return 35
    elif x["PRED_LR"] <= 0.494236200731162:
        return 36
    elif x["PRED_LR"] <= 0.49849527740000343:
        return 37
    elif x["PRED_LR"] <= 0.5028157034494269:
        return 38
    elif x["PRED_LR"] <= 0.5072254595786869:
        return 39
    elif x["PRED_LR"] <= 0.5114627571560864:
        return 40
    elif x["PRED_LR"] <= 0.5157302364447314:
        return 41
    elif x["PRED_LR"] <= 0.5201190155587998:
        return 42
    elif x["PRED_LR"] <= 0.5246446575597028:
        return 43
    elif x["PRED_LR"] <= 0.5290860869715963:
        return 44
    elif x["PRED_LR"] <= 0.5335117351910206:
        return 45
    elif x["PRED_LR"] <= 0.5380931272608929:
        return 46
    elif x["PRED_LR"] <= 0.5426919211940594:
        return 47
    elif x["PRED_LR"] <= 0.5473695799341042:
        return 48
    elif x["PRED_LR"] <= 0.5520373261017937:
        return 49
    elif x["PRED_LR"] <= 0.5567711400673843:
        return 50
    elif x["PRED_LR"] <= 0.5616384174461426:
        return 51
    elif x["PRED_LR"] <= 0.5665475121643543:
        return 52
    elif x["PRED_LR"] <= 0.5714968385852904:
        return 53
    elif x["PRED_LR"] <= 0.5766390444125253:
        return 54
    elif x["PRED_LR"] <= 0.5819884267708059:
        return 55
    elif x["PRED_LR"] <= 0.5872349718495959:
        return 56
    elif x["PRED_LR"] <= 0.5926303125193614:
        return 57
    elif x["PRED_LR"] <= 0.5980753436351175:
        return 58
    elif x["PRED_LR"] <= 0.6037318948876275:
        return 59
    elif x["PRED_LR"] <= 0.609586718884201:
        return 60
    elif x["PRED_LR"] <= 0.6155587091553468:
        return 61
    elif x["PRED_LR"] <= 0.6214997314156989:
        return 62
    elif x["PRED_LR"] <= 0.62765627743495:
        return 63
    elif x["PRED_LR"] <= 0.6339883775935822:
        return 64
    elif x["PRED_LR"] <= 0.64041018574986:
        return 65
    elif x["PRED_LR"] <= 0.6471356080065852:
        return 66
    elif x["PRED_LR"] <= 0.654096719382146:
        return 67
    elif x["PRED_LR"] <= 0.6612350666685202:
        return 68
    elif x["PRED_LR"] <= 0.6685662364424652:
        return 69
    elif x["PRED_LR"] <= 0.6761051186409012:
        return 70
    elif x["PRED_LR"] <= 0.683935033582835:
        return 71
    elif x["PRED_LR"] <= 0.6918270744529532:
        return 72
    elif x["PRED_LR"] <= 0.7001991246152617:
        return 73
    elif x["PRED_LR"] <= 0.7087944997339051:
        return 74
    elif x["PRED_LR"] <= 0.7178718228511921:
        return 75
    elif x["PRED_LR"] <= 0.7273594831066805:
        return 76
    elif x["PRED_LR"] <= 0.7372232592536291:
        return 77
    elif x["PRED_LR"] <= 0.7476460154897084:
        return 78
    elif x["PRED_LR"] <= 0.7584868978559691:
        return 79
    elif x["PRED_LR"] <= 0.7699346229556367:
        return 80
    elif x["PRED_LR"] <= 0.7824383650382609:
        return 81
    elif x["PRED_LR"] <= 0.7956493708192104:
        return 82
    elif x["PRED_LR"] <= 0.8095647813459939:
        return 83
    elif x["PRED_LR"] <= 0.8245430095621226:
        return 84
    elif x["PRED_LR"] <= 0.8405451301295306:
        return 85
    elif x["PRED_LR"] <= 0.8576042773942195:
        return 86
    elif x["PRED_LR"] <= 0.8766225200246819:
        return 87
    elif x["PRED_LR"] <= 0.8966025526407742:
        return 88
    elif x["PRED_LR"] <= 0.9194096415564296:
        return 89
    elif x["PRED_LR"] <= 0.9447799633030747:
        return 90
    elif x["PRED_LR"] <= 0.9741013032191222:
        return 91
    elif x["PRED_LR"] <= 1.0077020254143525:
        return 92
    elif x["PRED_LR"] <= 1.0466464798023387:
        return 93
    elif x["PRED_LR"] <= 1.0945353699117935:
        return 94
    elif x["PRED_LR"] <= 1.1520060171022957:
        return 95
    elif x["PRED_LR"] <= 1.2269712563896151:
        return 96
    elif x["PRED_LR"] <= 1.3326914511012296:
        return 97
    elif x["PRED_LR"] <= 1.495941836131652:
        return 98
    elif x["PRED_LR"] <= 1.8165889240280724:
        return 99
    elif x["PRED_LR"] >= 1.8165889240280724:
        return 100
    else:
        return 999
df["CENTILE"] = df.apply(f_CENTILE, axis=1)

df1 = pd.read_sql("SELECT * from BFELKEL.TERMINATED_NY_AGENTS")
df1 = df1.rename(columns={"TERM_AGENT_ID": "PCIS_AGNT_ID"})
df1["TERMINATED_AGENT_IND"] = 1

df = df.merge(df1, how="left", on="PCIS_AGNT_ID")
df["TERMINATED_AGENT_IND"].fillna(0, inplace=True)

# Some distinct Node

df2 = pd.read_sql("SELECT * from BFELKEL.NY_CNTL_EXP_LR")
df = df.merge(df2, how="left", on="CENTILE")

df = df[["EXP_LOSS_RATIO", "TERMINATED_AGENT_IND", "CENTILE"]]
df.loc[df["RISK_REGION"] == "BF", "RISK_REGION"] = "BUFFALO"
df.loc[df["RISK_REGION"] == "WC", "RISK_REGION"] = "LOWER HUDSON VALLEY"
df.loc[df["RISK_REGION"] == "UP", "RISK_REGION"] = "UPSTATE"
df.loc[df["RISK_REGION"] == "LI", "RISK_REGION"] = "LONG ISLAND"
df.loc[df["RISK_REGION"] == "BU", "RISK_REGION"] = "NEW YORK CITY"

df = df.sort_values(by=["INT_POL_NUM", "INT_POL_SFX_CD"])

df3 = pd.read_sql("SELECT * from NY_MDL_SCORE_TABLE_1")

# Aggregate node

cols_to_fill = ["MJR_XSUSP_3YR_CNT", "MNR_VIOL_2YR_CNT", "MNR_VIOL_1YR_CNT",
                "MNR_VIOL_3YR_CNT", "CAF_1YR_CNT", "CAF_2YR_CNT",
                "CAF_3YR_CNT", "NCAF_1YR_CNT", "NCAF_2YR_CNT", "NCAF_3YR_CNT"]


def f_Blank_IND(x):
    return "00" if x.strip() == "" else x
df3[cols_to_fill] = df3[cols_to_fill].applymap(f_Blank_IND)
df3[cols_to_fill] = df3[cols_to_fill].apply(pd.to_numeric)


def f_MANY_ACC_IND(x):
    if (x["CAF_1YR_CNT"] + x["NCAF_1YR_CNT"]) >= 1 and\
            (x["CAF_3YR_CNT"] + x["NCAF_3YR_CNT"]) >= 3:
        return 1
    else:
        return 0
df3["MANY_ACC_IND"] = df3.apply(f_MANY_ACC_IND, axis=1)


def f_MAJOR_VIO_HH_RULE_IND(x):
    if x["MJR_XSUSP_3YR_CNT"] >= 2:
        return 1
    else:
        return 0
df3["MAJOR_VIO_HH_RULE_IND"] = df3.apply(f_MAJOR_VIO_HH_RULE_IND, axis=1)


def f_MINOR_VIO_HH_RULE_IND(x):
    if x["MNR_VIOL_3YR_CNT"] >= 4 and x["MNR_VIOL_1YR_CNT"] >= 1:
        return 1
    else:
        return 0
df3["MINOR_VIO_HH_RULE_IND"] = df3.apply(f_MINOR_VIO_HH_RULE_IND, axis=1)

df3 = df3.groupby(["INT_POL_NUM", "INT_POL_SFX_CD"])["MANY_ACC_IND",
                                                     "MAJOR_VIO_HH_RULE_IND",
                                                     "MINOR_VIO_HH_RULE_IND"]\
    .sum().reset_index()

df3.loc[df3["MANY_ACC_IND"] >= 1, "MANY_ACC_IND_Sum"] = 1
df3.loc[df3["MAJOR_VIO_HH_RULE_IND"] >= 1, "MAJOR_VIO_HH_RULE_IND_Sum"] = 1
df3.loc[df3["MINOR_VIO_HH_RULE_IND"] >= 1, "MINOR_VIO_HH_RULE_IND_Sum"] = 1

df4 = pd.read_sql("SELECT * from NY_MDL_INCDNT_TABLE_2B")
df4 = df4.rename(columns={"MINOR_VIO_YTH_RULE": "MINOR_VIO_YTH_RULE_IND",
                          "MAJOR_VIO_YTH_RULE": "MAJOR_VIO_YTH_RULE_IND"})

df3 = df3.merge(df4, how='left', on=["INT_POL_NUM", "INT_POL_SFX_CD"])
df3["MINOR_VIO_YTH_RULE_IND"] = df3["MINOR_VIO_YTH_RULE_IND"].fillna(0)
df3["MAJOR_VIO_YTH_RULE_IND"] = df3["MAJOR_VIO_YTH_RULE_IND"].fillna(0)

df = df.merge(df3, how='left', on=["INT_POL_NUM", "INT_POL_SFX_CD"])
df["MINOR_VIO_YTH_RULE_IND"] = df["MINOR_VIO_YTH_RULE_IND"].fillna(0)
df["MAJOR_VIO_YTH_RULE_IND"] = df["MAJOR_VIO_YTH_RULE_IND"].fillna(0)
df["MANY_ACC_IND"] = df["MANY_ACC_IND"].fillna(0)

df5 = pd.read_sql("SELECT * from NY_MDL_SCORE_TABLE_1")
df5["ALT_GRG"] = df5["ALT_GRG_IND"].apply(lambda x: 1 if x == "Y" else 0)

df5 = df5.groupby(["INT_POL_NUM", "INT_POL_SFX_CD"])["ALT_GRG"].sum()
df5["ALT_GRG_IND"] = df5["ALT_GRG"].apply(lambda x: 1 if x >= 1 else 0)
df5 = df5.drop("ALT_GRG", axis=1)

df = df.merge(df5, how='left', on=["INT_POL_NUM", "INT_POL_SFX_CD"])

df.to_sql("NY_REG90_LR_OUTPUT")
