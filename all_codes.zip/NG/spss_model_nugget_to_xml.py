import modeler
import modeler.api
import os
stream = modeler.script.stream()
taskrunner = modeler.script.session().getTaskRunner()

class ModelApplierFilter(modeler.api.NodeFilter):
    """A node filter for super nodes"""

    def accept(this, node):
        return isinstance(node, modeler.api.ModelApplier)

modelfilter = ModelApplierFilter()
models = stream.findAll(modelfilter, True)

for item in list(models):
    file_name = item.getName() + '_nuid_' + item.ID + '.xml'
    taskrunner.exportModelToFile(item.createModelOutput(True), file_name, modeler.api.FileFormat.XML)
