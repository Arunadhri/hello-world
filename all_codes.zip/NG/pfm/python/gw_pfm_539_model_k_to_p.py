##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Prabakar Subramani
# Creation Date          : 08FEB2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_model_k_to_p.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Contains methods to initiate Model K, L, M, N,
#                          O, P
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################

# ------------------------------------------------------------------------

"""
Start Node: id4HNQVXEIT1X
End Node: id7A8QXRYCQ6B / id8K7QMPIRL7Z
"""

# ----------------------------------------------------------------------------
import pandas as pd

from gw_pfm_539_model_k import pfm_model_k
from gw_pfm_539_model_l import pfm_model_l
from gw_pfm_539_model_m import pfm_model_m
from gw_pfm_539_model_n import pfm_model_n
from gw_pfm_539_model_o import pfm_model_o
from gw_pfm_539_model_p import pfm_model_p


def f_model_V3(df):
    ''''
    Start Nugget ID: idRNQL55E7QV
    End Nugget ID: id32GQ81B1V2M
    '''

    df = df[((df["Model"] >= "K") & (df["Model"] <= "P"))]

    df.drop(labels=["S004", "G096", "G089", "RE30", "RE31", "G007",
                    "MT01", "IHI01", "MT02", "G004", "AGE_IN_MONTHS"],
            axis=1, inplace=True)

    df.rename(columns={"AT06": "aop06m",
                       "AT09": "aop24m",
                       "AT20": "moldaop",
                       "AT36": "mrecdel",
                       "G001": "del30d84m",
                       "G002": "del60d84m",
                       "G003": "del90d84m",
                       "G061": "del30pd24m",
                       "G066": "del60pd24m",
                       "G071": "del90pd24m",
                       "G091": "apd",
                       "G093": "ndpr",
                       "G094": "nbankrupt",
                       "G095": "mrecdpr",
                       "G098": "inq06m",
                       "G960": "inq24m",
                       "PH_AGE": "age",
                       "RE09": "raop24m",
                       "RE20": "moldraop",
                       "RE28": "rlimit",
                       "RE33": "rbal",
                       "S011": "nopa",
                       "S012": "nopra",
                       "S060": "mophi",
                       "S064": "colldoll"}, inplace=True)

    df.rename(columns={"DPRAMT": "dpramt"}, inplace=True)

    return df


def pfm_model_k_to_p(df_model_K_to_P, pkl_path, pkl_file_name):

    model_V3_df = f_model_V3(df_model_K_to_P)

    model_K_df = model_V3_df[model_V3_df["Model"] == "K"]
    model_L_df = model_V3_df[model_V3_df["Model"] == "L"]
    model_M_df = model_V3_df[model_V3_df["Model"] == "M"]
    model_N_df = model_V3_df[model_V3_df["Model"] == "N"]
    model_O_df = model_V3_df[model_V3_df["Model"] == "O"]
    model_P_df = model_V3_df[model_V3_df["Model"] == "P"]

    retain_cols = ["TRAN_ID", "PFMScore", "Level", "TimeStamp",
                   "PolicyNumber", "PolicySuffix", "GuidewireAccountNumber",
                   "PolEffDt", "WritingCo", "Leverage", "PolAppDt",
                   "GuidewireID", "DPR24m", "CallingAppName", "GeneratedNumber",
                   "ProviderStartDateTs", "Model", "Reasons"]

    models_appended = pd.DataFrame()

    if model_K_df.index.values.size > 0:
        model_K_df = pfm_model_k(model_K_df, pkl_path, pkl_file_name)
        model_K_df = model_K_df[retain_cols]
        models_appended = pd.concat([models_appended, model_K_df], ignore_index=True)
    if model_L_df.index.values.size > 0:
        model_L_df = pfm_model_l(model_L_df)
        model_L_df = model_L_df[retain_cols]
        models_appended = pd.concat([models_appended, model_L_df], ignore_index=True)
    if model_M_df.index.values.size > 0:
        model_M_df = pfm_model_m(model_M_df)
        model_M_df = model_M_df[retain_cols]
        models_appended = pd.concat([models_appended, model_M_df], ignore_index=True)
    if model_N_df.index.values.size > 0:
        model_N_df = pfm_model_n(model_N_df)
        model_N_df = model_N_df[retain_cols]
        models_appended = pd.concat([models_appended, model_N_df], ignore_index=True)
    if model_O_df.index.values.size > 0:
        model_O_df = pfm_model_o(model_O_df)
        model_O_df = model_O_df[retain_cols]
        models_appended = pd.concat([models_appended, model_O_df], ignore_index=True)
    if model_P_df.index.values.size > 0:
        model_P_df = pfm_model_p(model_P_df, pkl_path, pkl_file_name)
        model_P_df = model_P_df[retain_cols]
        models_appended = pd.concat([models_appended, model_P_df], ignore_index=True)

    models_appended["PFMScore"] = models_appended["PFMScore"].astype("str")
    models_appended.drop(labels=["Leverage", "DPR24m"], axis=1, inplace=True)
    return models_appended
