##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Prabakar Subramani
# Creation Date          : 28MAR2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_ds_functions.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Contains custom functions for
#                          the US-PNC-PNC-GW-PFM usecase.
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################

import pandas as pd
import numpy as np
import pickle
from sklearn.metrics import (confusion_matrix, accuracy_score, roc_auc_score,
                             f1_score, recall_score, precision_score, roc_curve, auc)
import matplotlib.pyplot as plt
plt.switch_backend('agg')  # configure pyplot to not try to use the display
from datetime import datetime

#####################################################################
#
# General Utilities
#
#####################################################################


def save_pickle(pyobject, path, file_name):
    '''Saves the python object to a pickle file

    Parameters:
        pyobject (object): The object that needs to be dumped
        path (string): The path/location to save file
        file_name (string): Name for file being saved

    Example:
        save_pickle(lr_model, '/home/METNET/user/', 'lr_model.pkl')
    '''
    path_file_name = path + file_name
    with open(path_file_name, 'wb') as pickle_file:
        pickle.dump(pyobject, pickle_file)


def load_pickle(path, file_name):
    '''Loads the specified pickle file

    Parameters:
        path (string): Path where object to be loaded is located
        filename (string): Name of file to load

    Example:
        logistic_model = load_pickle('/home/METNET/user/','lr_model.pkl')
    '''
    path_file_name = path + file_name
    with open(path_file_name, "rb") as f:
        pyobject = pickle.load(f)

    return pyobject


def write_scoring_file(op_file_path, op_file_name, sparkDF):
    '''Writes final spark scoring dataframe to specified location

        The module writes as csv format with pipe delimiter
        Filename is appended with timestamp

    Parameters:
        op_file_path: location to write output file
        op_file_name: name for output file
        op_data: final scoring dataframe (spark) to write

    Example:
        write_scoring_file("hdfs:///Data/analytics/ghcmo/model_results/",
                           "ltd_rtw_results_set",
                           rtw_scpark_scoreDF)
    '''
    op_file_ts = op_file_path + op_file_name + "_" + str(datetime.now().strftime("%Y_%m_%d-%H_%M_%S"))
    sparkDF.write.csv(op_file_ts,
                      sep="|",
                      header=True,
                      mode="overwrite")


#####################################################################
#
# Categorical Encoding
#
#####################################################################
def make_categorical_dict(string_vars, train_df, save_path):
    '''Returns a dictionary of object variables and their categories

    This function takes a list of variable names needed for modeling
    and creates a dictionary with the key representing the object
    variable and the values represent a list of categories found in
    that variable from the training DataFrame. The dictionary is saved
    to a pickle file to be reused on scoring data.

    Parameters:
        string_vars (list): List of string variables needed.
        train_df (dataframe): The training DataFrame.
        save_path (string): Path to where to save the pickle file.

    Returns:
        categories_dict (dictionary): variables and their categories.

    Examples:
        >>> categories_dict = make_categorical_dict(string_vars, train_df=train, save_path='H:/LTC_FWA/ltc_fwa_lr_v1.pkl')

    '''
    # create dictionary
    categories_dict = {}
    # fills dictionary with variables and their respective categories
    for var in string_vars:
        categories_dict[var] = train_df[var].astype(str).astype('category').cat.categories.tolist()
    # saves dictionary as pickle file
    with open(save_path, 'wb') as f:
        pickle.dump(categories_dict, f)
    return categories_dict


def cat_encoding_train(categories_dict, train_df, test_df, drop_first=True):
    '''Encodes categorical variables in the train and test dataframes

    The expected categories should have already been derived to
    categories_dict using make_categorical_dict(). This function uses the
    categories to consistently derive the same dummy variables,
    whether the category exists or not in the testing data. Optional, the first
    level gets removed to get k-1. Both train and test will end up
    with the same columns.

    Parameters:
        categories_dict (dictionary): Output of make_categorical_dict().
        train_df (dataframe): The training DataFrame.
        test_df (dataframe): The testing DataFrame.
        drop_first (boolean): Default True. Parameter for get_dummies
                              to get k-1 dummies out of k categorical
                              levels by removing the first level.

    Returns:
        train_df (dataframe): The updated training DataFrame.
        test_df (dataframe): The updated testing DataFrame.
        dummy_columns (list): List of dummy columns added.

    Examples:
        >>> train, test, dummy_columns = cat_encoding_train(categories_dict, train_df=train, test_df=test)
        >>> train, test, dummy_columns = cat_encoding_train(categories_dict, train_df=train, test_df=test, drop_first=False)

    '''
    # Get the string variables from the passed dictionary
    string_vars = list(categories_dict.keys())
    # Taking copy of categorical columns to be encoded
    train_ctgDF = train_df.loc[:, string_vars]
    test_ctgDF = test_df.loc[:, string_vars]
    # iterate through dictionary to convert object variables to categories type
    for key, value in categories_dict.items():
        value = list(map(lambda x: str(x), value))
        train_ctgDF.loc[:, key] = train_ctgDF.loc[:, key].astype(str).astype('category', categories=value)
        test_ctgDF.loc[:, key] = test_ctgDF.loc[:, key].astype(str).astype('category', categories=value)
    # create dummy columns based on categories passed in through the dictionary
    train_dummies = pd.get_dummies(train_ctgDF, columns=string_vars, drop_first=drop_first)
    # Concatenate dummy columns with original training DataFrame
    train_df = pd.concat([train_df, train_dummies], axis=1)
    # create a list of dummy columns
    dummy_columns = train_dummies.columns.tolist()
    # create dummy columns based on categories passed in through the dictionary
    test_dummies = pd.get_dummies(test_ctgDF, columns=string_vars, drop_first=drop_first)
    # Concatenate dummy columns with original testing DataFrame
    test_df = pd.concat([test_df, test_dummies], axis=1)
    return train_df, test_df, dummy_columns


def cat_encoding_scoring(categories_dict, scoring_df, drop_first=True):
    '''Encodes categorical variables in scoring data

    The expected categories should be saved in a pickle file during
    training. Load pickle file. This function will derive the same
    dummy variables used in the training data.

    Parameters:
        categories_dict (dictionary): Output of make_categorical_dict().
        scoring_df (dataframe): The scoring DataFrame.
        drop_first (boolean): Default True. Parameter for get_dummies
                              to get k-1 dummies out of k categorical
                              levels by removing the first level.

    Returns:
        scoring_df (dataframe): The updated scoring DataFrame.
        dummy_columns (list): List of dummy columns added.

    Examples:
        >>> df, dummy_columns = cat_encoding_scoring(categories_dict, scoring_df=df)

    '''
    # Get the string variables from the passed dictionary
    string_vars = list(categories_dict.keys())
    # Taking copy of categorical columns to be encoded
    ctg_colsDF = scoring_df.loc[:, string_vars]
    # iterate through dictionary to convert object variables to categories type
    for key, value in categories_dict.items():
        value = list(map(lambda x: str(x), value))
        ctg_colsDF[key] = ctg_colsDF[key].astype(str).astype('category', categories=value)
    # create dummy columns based on categories passed in through the dictionary
    df_dummies = pd.get_dummies(ctg_colsDF, columns=string_vars, drop_first=drop_first)
    # Concatenate dummy columns with original training DataFrame
    scoring_df = pd.concat([scoring_df, df_dummies], axis=1)
    # create a list of dummy columns
    dummy_columns = df_dummies.columns.tolist()
    return scoring_df, dummy_columns


#####################################################################
#
# Model Evaluation
#
#####################################################################
def classification_metrics(model, X, y, predicted):
    '''Generates popular classification metrics for model evaluation

    Parameters:
        model (class): name of trained model.
        X (dataframe): Name of testing data.
        y (series): Name of target for testing.
        predicted (array): predicted class label.

    Examples:
        >>> lr = LogisticRegression(random_state=12345)
        >>> lr.fit(X_train, y_train)
        >>> predictions = lr.predict(X_test)
        >>> classification_metrics(model=lr, X=X_test, y=y_test, predicted=predictions)

        >>> lr.fit(X_train[features], y_train)
        >>> y_predicted = lr.predict(X_test[features])
        >>> classification_metrics(model=lr, X=X_test[features], y=y_test, predicted=y_predicted)

    '''
    prob_predicted = model.predict_proba(X)  # probability estimates
    return print('\nAccuracy:  ', accuracy_score(y, predicted),
                 '\nAUC:       ', roc_auc_score(y, prob_predicted[:, 1]),
                 '\nPrecision: ', precision_score(y, predicted),
                 '\nRecall:    ', recall_score(y, predicted),
                 '\nF1:        ', f1_score(y, predicted),
                 '\n\nConfusion Matrix (columns show predicted, rows show actuals):',
                 '\n', confusion_matrix(y, predicted))


def roc_curve_plot(model, X, y, path):
    '''Creates and saves an roc curve plot

    Parameters:
        model (class): name of trained model.
        X (dataframe): Name of testing data.
        y (series): Name of target for testing.
        path (string): Location to save plot.

    Examples:
        >>> lr = LogisticRegression()
        >>> lr.fit(X_train, y_train)
        >>> roc_curve_plot(model=lr, X=X_test[features], y=y_test, path='/home/METNET/abeasock/lr_roc_curve2.png')

    '''
    prob_predicted = model.predict_proba(X)  # probability estimates
    prob_1 = prob_predicted[:, 1]  # probability of 1
    # Calculate the fpr and tpr for all thresholds of the classification
    fpr, tpr, threshold = roc_curve(y, prob_1)
    # Plot ROC curve
    plt.title('ROC Curve')
    plt.plot(fpr, tpr, 'b', label='Target')
    plt.legend(loc='lower right')
    plt.plot([-0.05, 1.05], [-0.05, 1.05], 'r--')
    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.ylabel('True Positive Rate')
    plt.xlabel('False Positive Rate')
    plt.savefig(path)
    plt.close()


def intercept_coefficients(model, X):
    '''Generates model intercept and coefficients

    Parameters:
        model (class): name of trained model.
        X (dataframe): Name of training data.

    Returns:
        intercept (string): intercept for model.
        coefficients (dataframe): Features and coefficients in model.

    Examples:
        >>> lr = LogisticRegression()
        >>> lr.fit(X_train, y_train)
        >>> intercept, coefficents = intercept_coefficients(model=lr, X=X_train[features])

    '''
    # Intercept
    intercept = 'Intercept ' + str(model.intercept_).replace('[', '').replace(']', '')
    # Coefficients
    coefficients = pd.concat([pd.DataFrame(X.columns, columns=['parameter']), pd.DataFrame(np.transpose(model.coef_), columns=['coef'])], axis=1)
    return intercept, coefficients


def classifier_metrics(y, predicted, pred_probab=None):
    '''Generates popular classification metrics for model evaluation

    Parameters:
        y (series): name of target variable.
        predicted (array): name of model predicted class labels.
        pred_probab (array): name of model predicted probabilities
                             (required in case of binary classification)

    Examples:
        >>> lr = LogisticRegression(random_state=12345)
        >>> lr.fit(X_train, y_train)
        >>> predictions = lr.predict(X_test)
        # Binary classification
        # Fetch probabilities for target class to compute AUC
        >>> probabilities = lr.predict_proba(X_test[features])[:, 1]
        >>> classifier_metrics(y=y_test, predicted=predictions, pred_probab=probabilites)
        # Multiclass classification
        >>> classifier_metrics(y=y_test, predicted=predictions)
    '''
    no_of_classes = len(np.unique(y))
    # Binary classification
    if no_of_classes == 2:
        return print('\nAccuracy:  ', (accuracy_score(y, predicted)*100),
                     '\nAUC:       ', (roc_auc_score(y, pred_probab)*100),
                     '\nPrecision: ', (precision_score(y, predicted)*100),
                     '\nRecall:    ', (recall_score(y, predicted)*100),
                     '\nF1:        ', (f1_score(y, predicted)*100),
                     '\n\nConfusion Matrix (columns show predicted, rows show actuals):',
                     '\n', confusion_matrix(y, predicted))
    # Multiclass
    else:
        return print("\nAccuracy:  ", (accuracy_score(y, predicted)*100),
                     "\nPrecision: ", (precision_score(y, predicted, average=None)*100),
                     "\nRecall:    ", (recall_score(y, predicted, average=None)*100),
                     "\nF1:        ", (f1_score(y, predicted, average=None)*100),
                     "\nConfusion Matrix (columns show predicted, rows show actuals):",
                     "\n", confusion_matrix(y, predicted))
