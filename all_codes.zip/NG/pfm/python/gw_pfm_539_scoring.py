##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Prabakar Subramani
# Creation Date          : 28MAR2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_scoring.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Contains functions to score the data.
# Data used              : Input Data,
#                          gw_pfm_539_training.pkl
#
# Output Files           : Output Data
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################

import os
import sys

sys.path.insert(0, "./utils")
sys.path.append("./python")

import time
import logging

from config import Config

try:
    from gw_pfm_539_import_data import pfm_data_import
    from gw_pfm_539_data_prep import pfm_data_prep
    from gw_pfm_539_modelling import pfm_modelling
    from gw_pfm_539_post_processing import pfm_post_processing
    from gw_pfm_539_export_scored import pfm_export_scored
except IOError:
    logging.error("Cannot import required modules")
except Exception:
    logging.exception("Failed to import required modules.")


def data_import(input_path):
    input_df = pfm_data_import(input_path)
    return input_df


def data_prep(input_df):
    data_errorDF, CIS_AppendedDF, CIS_Hits = pfm_data_prep(input_df)
    return data_errorDF, CIS_AppendedDF, CIS_Hits


def modelling(CIS_Hits, pkl_path, pkl_file_name):
    df_all_models = pfm_modelling(CIS_Hits, pkl_path, pkl_file_name)
    return df_all_models


def post_processing(data_errorDF, CIS_AppendedDF, df_all_models):
    scored_df = pfm_post_processing(data_errorDF, CIS_AppendedDF, df_all_models)
    return scored_df


def export_scored(scored_df, export_path):
    pfm_export_scored(scored_df, export_path)
    return


if __name__ == "__main__":

    start_time = time.time()
    # fetch config params and load required data
    try:
        env = os.environ.get("ENV")
        app_path = os.getcwd()
        config = Config(env, app_path)
        log = config.get_logger()
    except Exception:
        logging.error("Failed to initiate config and log file.")

    try:
        pkl_path = config.getConfigValueFor("pkl_path")
        pkl_file_name = config.getConfigValueFor("pkl_file_name")
        input_file_path = config.getConfigValueFor("input_file_path")
        export_file_path = config.getConfigValueFor("export_file_path")
        input_file_name = config.getConfigValueFor("input_file_name")
        export_file_name = config.getConfigValueFor("export_file_name")
    except Exception:
        logging.error("Failed to read the input and export data path")

    input_path = os.path.join(input_file_path, input_file_name)
    export_path = os.path.join(export_file_path, export_file_name)

    log.debug("Found the export file path as {}".format(export_path))

    ###########################################################################
    # Importing Input Data

    log.info("Data Import method has started running.")

    try:
        input_df = data_import(input_path)

        log.info("Data import is now complete")
    except IOError:
        log.error("Could not load the input data.", input_path)
    except Exception:
        log.exception("Failed to load the input data.")

    ###########################################################################

    log.info("Data preparation has started")

    try:
        data_errorDF, CIS_AppendedDF, CIS_Hits = data_prep(input_df)
        log.info("Data preparation is now complete")
    except Exception:
        log.exception("Failed to prepare the data for scoring.")

    ###########################################################################

    log.info("Modeling scoring started")

    try:
        df_all_models = modelling(CIS_Hits, pkl_path, pkl_file_name)
        log.info("Modeling scoring completed")
    except Exception:
        log.exception("Failed to score the data.")

    ###########################################################################

    log.info("Post processing has started")

    try:
        scored_df = post_processing(data_errorDF, CIS_AppendedDF, df_all_models)
        log.info("Post processing is now complete")
    except Exception:
        log.exception("Failed to post process the data.")

    ###########################################################################

    log.info("Export scored method has started")

    try:
        export_scored(scored_df, export_path)
        log.info("Exporting scored df is now complete")
    except IOError:
        log.error("Could not export the scored data.", input_path)
    except Exception:
        log.exception("Failed to export the scored data.")

    ###########################################################################

    # Log and end scoring process
    log.info("Scoring is complete")
    log.warning("The scoring is completed in: [ %s ] Seconds ---" % (time.time() - start_time))
