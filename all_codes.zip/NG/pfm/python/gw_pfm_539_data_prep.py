##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Prabakar Subramani
# Creation Date          : 28MAR2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_data_prep.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Contains functions to prepare the data for 
#                          scoring.
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################


from datetime import datetime


def to_upper_and_trim(x):
    # Converts string to upper case and strips whitespace
    x = str(x).upper()
    x = x.strip()
    return (x)


def f_default_value(df):
    value_92 = ["CRATE2", "INQEVLI", "LOCINQS_30", "LP30P", "LP30P24",
                "LP60P", "LP60P24", "LP90P", "LP90P24", "PRDEROG",
                "PRDEROG24_EX", "TOPEN", "TOPEN24", "TOPEN6", "TOPENR_REP",
                "TOPENR24", "TROPENB50", "TROPENB75", "TRR29"]
    for col in value_92:
        df.loc[df[col] > 92, col] = 0
    value_992 = ["CRDPTH", "CRDPTHREV", "PRAGE", "PRAGE_BKP", "TMINAGE_REP"]
    for col in value_992:
        df.loc[df[col] > 9992, col] = 0
    value_9999992 = ["AMTPD", "COLLSAMT", "PRAMT", "TSBALR", "TSHICR"]
    for col in value_9999992:
        df.loc[df[col] > 9999992, col] = 0
    df.loc[df['BRHICRAT'] > 9.9992, 'BRHICRAT'] = 0
    df.loc[df['AVGMOS'] > 992, 'AVGMOS'] = 0
    df.loc[df['WRRATE_MER'] > 9, 'WRRATE_MER'] = 0
    df.loc[df['WRRATE_MER'] == 6, 'WRRATE_MER'] = 8
    return df


def error_condition_Flag_check_1(row):
    """
    Nugget ID: idPTSMSU4B53 ----> Same condition is available for
    Nugget ID: id29YT3MMQEZ7
    Since this particular condition is very large, for readability it is
    converted into a function. This function ceck whether the value in the
    given column of the row contains "". If yes, it returns True else
    it returns False.
    Arguments:
    row -------> Row in the dataframe (DType - Pandas Series).
    Return:
    val_return -------> Boolean value.
    """
    val_return = False
    cols_to_check = ["AMTPD", "AVGMOS", "BRHICRAT", "CRATE2", "CRDPTH",
                     "INQEVLI", "LOCINQS_30", "PRAGE", "PRAGE_BKP", "PRDEROG",
                     "PRDEROG24_EX", "TOPEN", "TOPEN24", "TOPEN6", "TRR29",
                     "TMINAGE_REP", "CRDPTHREV", "TSHICR", "TSBALR",
                     "TOPENR_REP", "WRRATE_MER", "COLLSAMT", "AGE_REP",
                     "TROPENB50", "TROPENB75", "LP30P", "LP30P24", "LP60P",
                     "LP60P24", "LP90P", "LP90P24", "PRAMT", "TOPENR24",
                     "MTGOPN", "MTGREV"]
    for col in cols_to_check:
        if row[col] == "":
            val_return = True
            break
    return val_return


def error_condition_Flag(row):
    """
    Nugget ID: idPTSMSU4B53

    Function to fill the "Flag" column in the DataFrame "initialDF".

    Arguments:
    row -------> Row in the dataframe (DType - Pandas Series).

    Return:
    temp_value -------> Boolean value.
    """
    temp_value = False
    if row["GuidewireID"].strip() == "":
        temp_value = True
    elif row["GuidewireAccountNumber"].strip() == "":
        temp_value = True
    elif row["State"].strip() == "":
        temp_value = True
    elif row["WritingCo"].strip() == "":
        temp_value = True
    elif row["PolEffDt"] == "":
        temp_value = True
    elif row["PolAppDt"] == "":
        temp_value = True
    elif (row["LOBCd"] != "HOME") & (row["LOBCd"] != "AUTO"):
        temp_value = True
    elif ((row["CreditInquiryStatus"] != "CREDIT BUREAU NO-HIT")
          & (row["CreditInquiryStatus"] != "UNSCORED")
          & (row["CreditInquiryStatus"] != "COMPLETE, NO REPORT (CREDIT BUREAU MANUAL REPORT)")
          & (row["CreditInquiryStatus"] != "COMPLETE")):
        temp_value = True
    elif error_condition_Flag_check_1(row):
        temp_value = True
    elif (((row["LOBSubCd"] != "HOMEOWNERS") & (row["LOBSubCd"] != "AUTO")
           & (row["LOBSubCd"] != "RENTERS") & (row["LOBSubCd"] != "CONDO"))
          or row["LOBSubCd"] == ""):
        temp_value = True
    elif (row["NewRenewInd"] == "") or ((row["NewRenewInd"] != "NEW")
                                        & (row["NewRenewInd"] != "RENEW")):
        temp_value = True
    return temp_value


def data_error_condition_check_2(row):
    """
    Nugget ID: id29YT3MMQEZ7

    Since this particular condition is very large, for readability it is
    converted into a function. This function ceck whether the value in the
    given column of the row contains "". If yes, it returns True else
    it returns False.

    Arguments:
    row -------> Row in the dataframe (DType - Pandas Series).

    Return:
    val_return -------> Boolean value.
    """
    val_return = False
    cols_to_check = ["AMTPD", "AVGMOS", "BRHICRAT", "CRATE2", "CRDPTH",
                     "INQEVLI", "LOCINQS_30", "PRAGE", "PRAGE_BKP", "PRDEROG",
                     "PRDEROG24_EX", "TOPEN", "TOPEN24", "TOPEN6", "TRR29",
                     "TMINAGE_REP", "CRDPTHREV", "TSHICR", "TSBALR",
                     "TOPENR_REP", "WRRATE_MER", "COLLSAMT", "AGE_REP",
                     "TROPENB50", "TROPENB75", "LP30P", "LP30P24", "LP60P",
                     "LP60P24", "LP90P", "LP90P24", "PRAMT", "TOPENR24",
                     "MTGOPN", "MTGREV"]
    for col in cols_to_check:
        if row[col] == "":
            val_return = True
            break
    return val_return


def data_error_ProviderErrorCd(row):
    """
    Nugget ID: id29YT3MMQEZ7

    Function to fill the "ProviderErrorCd" column in the DataFrame "subset2".

    Arguments:
    row -------> Row in the dataframe (DType - Pandas Series).

    Return:
    temp_value -------> Boolean value.
    """
    temp_value = ""
    if row["State"].strip() == "":
        temp_value = "ST"
    elif (row["LOBCd"] != "HOME") & (row["LOBCd"] != "AUTO"):
        temp_value = "LB"
    elif row["WritingCo"].strip() == "":
        temp_value = "WC"
    elif row["GuidewireID"].strip() == "":
        temp_value = "GW"
    elif row["GuidewireAccountNumber"].strip() == "":
        temp_value = "AN"
    elif row["PolEffDt"] == "":
        temp_value = "ED"
    elif row["PolAppDt"] == "":
        temp_value = "AD"
    elif (row["CreditInquiryStatus"] not in ["CREDIT BUREAU NO-HIT",
                                             "UNSCORED",
                                             "COMPLETE, NO REPORT (CREDIT BUREAU MANUAL REPORT)",
                                             "COMPLETE"]):
        temp_value = "CI"
    elif data_error_condition_check_2(row):
        temp_value = "LN"
    elif ((row["NewRenewInd"] == "") or
          ((row["NewRenewInd"] != "NEW") & (row["NewRenewInd"] != "RENEW"))):
        temp_value = "NR"
    elif ((row["LOBSubCd"] == "") or
          ((row["LOBSubCd"] != ["HOMEOWNERS", "AUTO", "RENTERS", "CONDO"]))):
        temp_value = "SC"
    else:
        temp_value = ""
    return temp_value


def data_error_provider_error_desc(x):
    """
    Nugget ID: id7WLT3QJKLCX

    Function to map the error descriptions according to the value in the
    "ProviderErrorCd" column.

    Arguments:
    x -------> Value in the "ProviderErrorCd" column of each row.

    Return:
    mapped_value -------> Mapped Error Description.
    """
    mapped_value = ""
    if x == "ST":
        mapped_value = "State is missing"
    elif x == "LB":
        mapped_value = "LOBCd is not AUTO/HOME"
    elif x == "WC":
        mapped_value = "WritingCo is missing"
    elif x == "GW":
        mapped_value = "GuidewireID is missing"
    elif x == "AN":
        mapped_value = "GuidewireAccountNumber is missing"
    elif x == "ED":
        mapped_value = "Effective Date is missing"
    elif x == "AD":
        mapped_value = "App Date is missing"
    elif x == "CI":
        mapped_value = "Unexpected CreditInquiryStatus"
    elif x == "LN":
        mapped_value = "Unexpected Missing Value in Credit Data"
    elif x == "NR":
        mapped_value = "Unexpected NewRenewInd"
    elif x == "SC":
        mapped_value = "Unexpected LOBSubCd"
    else:
        mapped_value = ""
    return mapped_value


def data_error_flow(df):

    df["ProviderErrorCd"] = ""
    df["ProviderErrorCd"] = df.apply(data_error_ProviderErrorCd, axis=1)
    df["ProviderErrorDsc"] = df["ProviderErrorCd"].apply(data_error_provider_error_desc)

    df["Model"] = ""
    df["Reasons"] = ""
    df["Level"] = ""

    df = df[["CallingAppName", "GuidewireID", "GuidewireAccountNumber",
             "PolicyNumber", "PolicySuffix", "GeneratedNumber", "WritingCo",
             "PolEffDt", "PolAppDt", "ProviderStartDateTs", "ProviderErrorCd",
             "ProviderErrorDsc", "Model", "Reasons", "Level"]]

    df["PFMScore"] = ""

    df = df[["GuidewireID", "GuidewireAccountNumber", "PolicyNumber",
             "PolicySuffix", "ProviderStartDateTs", "ProviderErrorCd",
             "ProviderErrorDsc", "Model", "Reasons", "Level", "PFMScore"]]
    df.rename(columns={"Model": "PFMModel",
                       "Reasons": "PFMReasons",
                       "Level": "PFMLevel"}, inplace=True)

    return df


def g_processing_Model(x):
    # nugget-id: id81BSPWPNJC8
    home_model_U = ["AL", "AR", "AZ", "CO", "DE", "IA", "ID", "IL", "IN", "KS",
                    "KY", "LA", "MA", "ME", "MI", "MN", "MO", "MS", "ND", "NE",
                    "NH", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "UT",
                    "VA",  "VT", "WI", "WV", "WY"]
    auto_model_U = ["AL", "AR", "AZ", "CO", "DE", "IA", "ID", "IL", "IN", "KS",
                    "KY", "LA", "ME", "MI", "MN", "MO", "MS", "ND", "NE",
                    "NH", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "UT",
                    "VA",  "VT", "WI", "WV", "WY"]
    if (x["LOBCd"] == "HOME"):
        if (x["State"] in home_model_U):
            Model = "U"
        elif (x["State"] in ["CT", "NM", "WA"]):
            Model = "N"
        elif (x["State"] in ["DC", "FL"]):
            Model = "G"
        elif (x["State"] in ["NC", "NJ", "TX"]):
            Model = "L"
        elif (x["State"] == "GA"):
            Model = "P"
        elif (x["State"] == "MT"):
            Model = "O"
        elif (x["State"] == "NV"):
            Model = "V"
        elif (x["State"] == "NY"):
            Model = "K"
        elif (x["State"] in ["HI", "AK", "CA", "MD"]):
            Model = "z"
    elif (x["LOBCd"] == "AUTO"):
        if (x["State"] in auto_model_U):
            Model = "U"
        elif (x["State"] in ["CT", "NM", "WA"]):
            Model = "N"
        elif (x["State"] == "DC"):
            Model = "G"
        elif (x["State"] in ["FL", "NV"]):
            Model = "V"
        elif (x["State"] == "GA"):
            Model = "P"
        elif (x["State"] in ["NC", "NJ", "TX"]):
            Model = "L"
        elif (x["State"] == "MT"):
            Model = "O"
        elif (x["State"] == "NY"):
            Model = "K"
        elif (x["State"] == "MD"):
            Model = "M"
        elif (x["State"] in ["HI", "AK", "CA", "MA"]):
            Model = "z"
    else:
        Model = "z"
    return Model


def pre_model_data_processing(df):

    df["Model"] = df.apply(g_processing_Model, axis=1)
    df["G960"] = df["INQEVLI"]
    df["MT02"] = df["MTGOPN"]

    dropcols = ["MOSOPEN_AK", "TOPEN24_WA", "TR29P24_BKP",
                "COLLSBOB_54B", "HELOANS"]
    df.drop(dropcols, axis=1, inplace=True)
    df.rename(columns={"AMTPD": "G091",
                       "AVGMOS": "S004",
                       "BRHICRAT": "Leverage",
                       "CRATE2": "G001",
                       "CRDPTH": "AT20",
                       "INQEVLI": "G096",
                       "LOCINQS_30": "G098",
                       "PRAGE": "G095",
                       "PRDEROG": "G093",
                       "TOPEN": "S011",
                       "TOPEN24": "AT09",
                       "TOPEN6": "AT06",
                       "TRR29": "S060",
                       "TMINAGE_REP": "AT36",
                       "CRDPTHREV": "RE20",
                       "TSHICR": "RE28",
                       "TSBALR": "RE33",
                       "TOPENR_REP": "S012",
                       "WRRATE_MER": "G089",
                       "COLLSAMT": "S064",
                       "AGE_REP": "PH_AGE",
                       "TROPENB50": "RE30",
                       "TROPENB75": "RE31",
                       "LP30P": "G007",
                       "LP30P24": "G061",
                       "LP60P24": "G066",
                       "LP90P24": "G071",
                       "PRAMT": "DPRAMT",
                       "TOPENR24": "RE09",
                       "MTGOPN": "MT01",
                       "MTGREV": "IHI01"}, inplace=True)

    df["G002"] = df["G007"] - df["LP60P"]

    df["G003"] = df["LP60P"] - df["LP90P"]

    df["G094"] = df["G093"] - df["PRAGE_BKP"]

    df["G004"] = df["LP60P"] - df["LP90P"]

    df["ntaxlien"] = 0

    df["AGE_IN_MONTHS"] = df["PH_AGE"]*12
    return df


def f_hub1_operations_level(x):
    if x["Model"] >= "A" and x["Model"] <= "J":
        Level = "2B"
    elif x["Model"] == "z":
        Level = ""
    else:
        if x["PH_AGE"] >= 16 and x["PH_AGE"] < 30:
            Level = "NQ"
        elif x["PH_AGE"] >= 30 and x["PH_AGE"] < 65:
            Level = "NK"
        elif x["PH_AGE"] >= 65 and x["PH_AGE"] < 130:
            Level = "NF"
        else:
            Level = "NN"
    return Level


def pre_model_hits_no_hits(df):
    '''
    from nugget id: id6XHRBIFQIYS to nugget id: id8ZTPY4B2RMR
     also returns data from nugget id: id7ILQU9GU84Y
    '''

    df.rename(columns={"PRDEROG24_EX": "DPR24m"}, inplace=True)

    hub_cis_comp = df[df["CreditInquiryStatus"] == "COMPLETE"]

    cond1 = hub_cis_comp["AT06"].isnull()
    cond2 = hub_cis_comp["AT20"].isnull()
    cond3 = ((hub_cis_comp["G096"] == 0) & (hub_cis_comp["S011"] == 0) &
             (hub_cis_comp["G093"] == 0) & (hub_cis_comp["S060"] == 0) &
             (hub_cis_comp["S064"] == 0) & (hub_cis_comp["G091"] == 0))

    cis_no_hits = hub_cis_comp[cond1 | cond2 | cond3]

    cis_no_hits["Reasons"] = "IJ"

    if not cis_no_hits.empty:
        cis_no_hits["Level"] = cis_no_hits.apply(f_hub1_operations_level, axis=1)
    else:
        cis_no_hits["Level"] = ""

    retain_cols = ["CallingAppName", "GuidewireID", "GuidewireAccountNumber",
                   "PolicyNumber", "PolicySuffix", "GeneratedNumber",
                   "NewRenewInd", "State", "WritingCo", "PolEffDt", "PolAppDt",
                   "PH_AGE", "ProviderStartDateTs", "Model", "Reasons", "Level"]
    cis_no_hits = cis_no_hits[retain_cols]

    cis_hits = hub_cis_comp[~(cond1 | cond2 | cond3)]
    cis_hits_copy = cis_hits.copy()

    cis_hits = cis_hits[(cis_hits["Model"] >= "z") | (cis_hits["Model"] == "")
                        | (cis_hits["Model"] < "A") | (cis_hits["Model"] > "W")]

    cis_hits["Reasons"] = "IJ"

    cis_hits["Level"] = ""

    cis_hits = cis_hits[retain_cols]

    cond1 = df["CreditInquiryStatus"] == "CREDIT BUREAU NO-HIT"
    cond2 = df["CreditInquiryStatus"] == "COMPLETE, NO REPORT (CREDIT BUREAU MANUAL REPORT)"
    cond3 = df["CreditInquiryStatus"] == "UNSCORED"
    cis_nohits_statuscheck = df[cond1 | cond2 | cond3]

    cis_nohits_statuscheck["Reasons"] = "IJ"

    if not cis_nohits_statuscheck.empty:
        cis_nohits_statuscheck["Level"] = cis_nohits_statuscheck.apply(f_hub1_operations_level, axis=1)
    else:
        cis_nohits_statuscheck["Level"] = ""

    cis_nohits_statuscheck = cis_nohits_statuscheck[retain_cols]

    cis_append = cis_nohits_statuscheck.append([cis_hits, cis_no_hits], ignore_index=True)
    return cis_append, cis_hits_copy


def CIS_AppendedDF_PFMScore(row):

    val_to_return = ""
    if (row["Model"] >= "A") & (row["Model"] <= "J"):
        val_to_return = ""
    elif row["Model"] == "z":
        val_to_return = ""
    else:
        if (row["PH_AGE"] >= 16) & (row["PH_AGE"] <= 30):
            val_to_return = "008"
        elif (row["PH_AGE"] >= 30) & (row["PH_AGE"] <= 65):
            val_to_return = "006"
        elif (row["PH_AGE"] >= 65) & (row["PH_AGE"] <= 130):
            val_to_return = "005"
        else:
            val_to_return = "007"

    return val_to_return


def pfm_data_prep(initialDF):

    initialDF["GuidewireID"] = initialDF["GuidewireID"].astype("str")
    initialDF["GuidewireAccountNumber"] = initialDF.GuidewireAccountNumber.astype(str)

    initialDF = f_default_value(initialDF)

    up_trim_cols = ["LOBCd", "CreditInquiryStatus", "State", "NewRenewInd",
                    "LOBSubCd"]
    for col in up_trim_cols:
        initialDF[col] = initialDF[col].apply(to_upper_and_trim)

    initialDF["ProviderStartDateTs"] = datetime.now().strftime("%m/%d/%Y %H:%M:%S")

    # ---------------------------check for error data--------------------------

    initialDF["Flag"] = initialDF.apply(error_condition_Flag, axis=1)

    data_errorDF = initialDF[initialDF["Flag"] == True]
    no_data_errorDF = initialDF[initialDF["Flag"] == False]

    data_errorDF.drop("Flag", inplace=True, axis=1)
    no_data_errorDF.drop("Flag", inplace=True, axis=1)

    # ----------------------------data error flow------------------------------

    if not data_errorDF.empty:
        data_errorDF = data_error_flow(data_errorDF)

    # -------------------------------------------------------------------------
    no_data_errorDF = pre_model_data_processing(no_data_errorDF)

    # ----------------------------------------------------------------------------
    no_data_errorDF["CreditInquiryStatus"] = no_data_errorDF["CreditInquiryStatus"].apply(to_upper_and_trim)

    CIS_AppendedDF, CIS_Hits = pre_model_hits_no_hits(no_data_errorDF)

    if not CIS_AppendedDF.empty:
        CIS_AppendedDF["PFMScore"] = CIS_AppendedDF.apply(CIS_AppendedDF_PFMScore, axis=1)
    else:
        CIS_AppendedDF["PFMScore"] = ""
    CIS_AppendedDF.drop(labels=["PH_AGE", "State", "NewRenewInd"], axis=1, inplace=True)

    # ----------------------------------------------------------------------------
    retain_cols = ["TRAN_ID", "TimeStamp", "PH_AGE", "G091", "S004",
                   "Leverage", "S064", "G001", "AT20", "RE20", "CallingAppName",
                   "GeneratedNumber", "GuidewireAccountNumber", "GuidewireID",
                   "G096", "G098", "G007", "G061", "G066", "G071", "MT01", "IHI01",
                   "G095", "DPRAMT", "G093", "DPR24m", "PolAppDt", "PolEffDt",
                   "PolicyNumber", "PolicySuffix", "State", "AT36", "S011", "AT09",
                   "AT06", "RE09", "S012", "RE30", "RE31", "S060", "RE33", "RE28",
                   "G089", "WritingCo", "ProviderStartDateTs", "Model", "G960",
                   "MT02", "G002", "G003", "G094", "G004", "ntaxlien",
                   "AGE_IN_MONTHS"]

    CIS_Hits = CIS_Hits[retain_cols]

    return data_errorDF, CIS_AppendedDF, CIS_Hits
