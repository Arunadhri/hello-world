##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Prabakar Subramani
# Creation Date          : 08FEB2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_read_model_data.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Contains the function to read the model
#                          coefficient of trained model.
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################

# ------------------------------------------------------------------------

"""
Created on Tue Feb 19 06:58:06 2019

@author: psubramani5
"""


def read_model_data(model_name, nugget_id, pkl_obj_dict):
    """
    Read the pickle object containing the SPSS Model coefficients and
    return it in dataframe.

    Arguments:
    model_name -------> Name of the model in the SPSS stream.
    nugget_id -------> Nugget ID of the model in the SPSS stream.
    pkl_obj_dict -------> Pickle object containing the model coefficients.

    Return:
    model_coeff -------> Pandas DataFrame containing the model coefficients.
    """
    # import pickle
    # with open(file_path, "rb") as f:
    #     dict_object = pickle.load(f)
    key = "".join([model_name, "_nuid_", nugget_id])
    model_coeff = pkl_obj_dict[key].copy()

    return model_coeff
