##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Sushant Kulkarni, Prabakar Subramani
# Creation Date          : 08FEB2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_model_u_to_v.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Contains methods to initiate Model U, V
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################

# ------------------------------------------------------------------------

import pandas as pd

from gw_pfm_539_model_u import pfm_model_u
from gw_pfm_539_model_v import pfm_model_v


# -------------------------------------------------------------------------
# -------------------------------------------------------------------------
# ---------------------------------Model V---------------------------------
# -------------------------------------------------------------------------
# -------------------------------------------------------------------------
def f_derive_variables_ACD_COMBO(x):

    if (x["APD_FLAG"] + x["COLL_FLAG"] + x["DPR_FLAG"]) == 0:
        ACD_COMBO = "A"
    elif (((x["APD_FLAG"] + x["COLL_FLAG"]) == 0) & (x["DPR_FLAG"] >= 1)) | \
         ((x["APD_FLAG"] + x["DPR_FLAG"] == 0) & (x["COLL"] < 200)):
        ACD_COMBO = "B"
    elif (x["APD_FLAG"] + x["DPR_FLAG"] == 0) & (x["COLL"] < 1000):
        ACD_COMBO = "C"
    else:
        ACD_COMBO = "D"

    return ACD_COMBO


def f_derive_variables_MOP_COMBO(x):

    if (x["HIMOPEVER"] >= 7) & (x["MOPHI"] >= 2):
        MOP_COMBO = "C"
    elif (x["MOPHI"] == 0) & ((x["HIMOPEVER"] == "") | (x["HIMOPEVER"] < 2)):
        MOP_COMBO = "A"
    else:
        MOP_COMBO = "B"

    return MOP_COMBO


def f_derive_variables_DDC_PRE(x):

    if x["DEL24"] == 0:
        suffix = "00"
    elif x["DEL24"] < 4:
        suffix = "01"
    elif x["DEL24"] < 7:
        suffix = "04"
    elif x["DEL24"] < 12:
        suffix = "07"
    else:
        suffix = "12"
    DDC_PRE = x["MOP_COMBO"] + x["ACD_COMBO"] + suffix

    return DDC_PRE


def f_derive_variables_DDC_COMBO(x):

    DDC_PRE_6 = ["AD00", "BA07", "BA12", "BB07", "BB12", "BC00", "BC01",
                 "BC04", "BC07", "BC12", "BD00", "BD01", "BD04", "BD07",
                 "BD12", "CA07", "CA12", "CB00", "CB01", "CB04", "CB07",
                 "CB12", "CC00", "CD00"]
    if x == "AA00":
        DDC_COMBO = 1
    elif x == "AB00":
        DDC_COMBO = 2
    elif x in ["BA00", "BA01", "BA04"]:
        DDC_COMBO = 3
    elif x in ["AC00", "BB00", "CA00"]:
        DDC_COMBO = 4
    elif x in ["BB01", "BB04", "CA01", "CA04"]:
        DDC_COMBO = 5
    elif x in DDC_PRE_6:
        DDC_COMBO = 6
    elif x in ["CC01", "CC04", "CC07", "CC12"]:
        DDC_COMBO = 7
    elif x in ["CD01", "CD04", "CD07", "CD12"]:
        DDC_COMBO = 8
    else:
        DDC_COMBO = 9

    return DDC_COMBO


def f_derive_variables_DDC_COMBO2(x):

    list8 = ["BA07", "BA12", "BB07", "BB12", "BC01", "BC04", "BC07",
             "BC12", "BD01", "BD04", "BD07", "BD12", "CA07", "CA12",
             "CB01", "CB04", "CB07", "CB12"]
    if x == "AA00":
        DDC_COMBO2 = 1
    elif x == "AB00":
        DDC_COMBO2 = 2
    elif x == "BA00":
        DDC_COMBO2 = 3
    elif x in ["BA01", "BA04"]:
        DDC_COMBO2 = 4
    elif x in ["AC00", "BB00", "CA00"]:
        DDC_COMBO2 = 5
    elif x in ["BB01", "BB04", "CA01", "CA04"]:
        DDC_COMBO2 = 6
    elif x in ["AD00" "BC00" "BD00" "CB00" "CC00" "CD00"]:
        DDC_COMBO2 = 7
    elif x in list8:
        DDC_COMBO2 = 8
    elif x in ["CC01", "CC04", "CC07", "CC12"]:
        DDC_COMBO2 = 9
    elif x in ["CD01", "CD04", "CD07", "CD12"]:
        DDC_COMBO2 = 10
    else:
        DDC_COMBO2 = 11

    return DDC_COMBO2


def f_derive_variables_AWOAO_BIN(x):

    if x["AGE_IN_MONTHS"] == 0:
        AWOAO_BIN = 0
    elif x["AWOAO"] < 1:
        AWOAO_BIN = 0
    elif x["AWOAO"] < 18:
        AWOAO_BIN = 1
    elif (x["AWOAO"] >= 18) & (x["AWOAO"] < 45):
        AWOAO_BIN = x["AWOAO"]
    else:
        AWOAO_BIN = 45

    return AWOAO_BIN


def f_derive_variables_NOPA_AVGMAO(x):

    if x["NOPA"] < 4 & x["AVGMAO"] < 0:
        NOPA_AVGMAO = "0_00"
    elif(x["NOPA"] < 4) & (x["AVGMAO"] >= 0) & (x["AVGMAO"] < 20):
        NOPA_AVGMAO = "0_01"
    elif(x["NOPA"] < 4) & (x["AVGMAO"] >= 20) & (x["AVGMAO"] < 40):
        NOPA_AVGMAO = "0_02"
    elif(x["NOPA"] < 4) & (x["AVGMAO"] >= 40) & (x["AVGMAO"] < 74):
        NOPA_AVGMAO = "0_03"
    elif(x["NOPA"] >= 4) & (x["AVGMAO"] < 0):
        NOPA_AVGMAO = "4_00"
    elif (x["NOPA"] >= 4) & (x["AVGMAO"] >= 0) & (x["AVGMAO"] < 20):
        NOPA_AVGMAO = "4_01"
    elif (x["NOPA"] >= 4) & (x["AVGMAO"] >= 20) & (x["AVGMAO"] < 40):
        NOPA_AVGMAO = "4_02"
    elif (x["NOPA"] >= 4) & (x["AVGMAO"] >= 40) & (x["AVGMAO"] < 55):
        NOPA_AVGMAO = "4_03"
    elif (x["NOPA"] >= 4) & (x["AVGMAO"] >= 55) & (x["AVGMAO"] < 74):
        NOPA_AVGMAO = "4_04"
    elif (x["AVGMAO"] >= 74):
        NOPA_AVGMAO = "A_05"
    else:
        NOPA_AVGMAO = "0_00"

    return NOPA_AVGMAO


def f_derive_variables_NOPA_CAP(x):

    if x == 0:
        NOPA_CAP = 0
    elif x >= 25:
        NOPA_CAP = 25
    else:
        NOPA_CAP = x

    return NOPA_CAP


def f_derive_variables_NOPA_IADIF(x):

    if x["NOPA"] < 4:
        if x["IADIF"] <= -1:
            NOPA_IADIF = "0_E-1"
        else:
            if x["IADIF"] == 0:
                NOPA_IADIF = "0_P_0"
            elif x["IADIF"] == 1:
                NOPA_IADIF = "0_P_1"
            elif x["IADIF"] == 2:
                NOPA_IADIF = "0_P_2"
            elif x["IADIF"] == 3:
                NOPA_IADIF = "0_P_3"
            else:
                NOPA_IADIF = "0_P_4"
    else:
        if x["IADIF"] <= -5:
            NOPA_IADIF = "4_A-5"
        elif x["IADIF"] == -4:
            NOPA_IADIF = "4_B-4"
        elif x["IADIF"] == -3:
            NOPA_IADIF = "4_C-3"
        elif x["IADIF"] == -2:
            NOPA_IADIF = "4_D-2"
        elif x["IADIF"] == -1:
            NOPA_IADIF = "4_E-1"
        else:
            if x["IADIF"] == 0:
                NOPA_IADIF = "4_P_0"
            elif x["IADIF"] == 1:
                NOPA_IADIF = "4_P_1"
            elif x["IADIF"] == 2:
                NOPA_IADIF = "4_P_2"
            else:
                NOPA_IADIF = "4_P_3"

    return NOPA_IADIF


def f_derive_variables_NOPA_INQ24(x):

    if x["NOPA"] < 4:
        NOPA_INQ24 = "0ALL"
    else:
        if x["INQ24"] == 0:
            NOPA_INQ24 = "4_00"
        elif x["INQ24"] == 1:
            NOPA_INQ24 = "4_01"
        elif x["INQ24"] == 2:
            NOPA_INQ24 = "4_02"
        elif x["INQ24"] == 3:
            NOPA_INQ24 = "4_03"
        elif x["INQ24"] == 4:
            NOPA_INQ24 = "4_04"
        elif x["INQ24"] == 5:
            NOPA_INQ24 = "4_05"
        elif x["INQ24"] == 6:
            NOPA_INQ24 = "4_06"
        elif x["INQ24"] == 7:
            NOPA_INQ24 = "4_07"
        elif x["INQ24"] == 8:
            NOPA_INQ24 = "4_08"
        elif x["INQ24"] == 9:
            NOPA_INQ24 = "4_09"
        elif x["INQ24"] == 10:
            NOPA_INQ24 = "4_10"
        elif x["INQ24"] == 11:
            NOPA_INQ24 = "4_11"
        elif x["INQ24"] == 12:
            NOPA_INQ24 = "4_12"
        elif x["INQ24"] == 13:
            NOPA_INQ24 = "4_13"
        elif x["INQ24"] == 14:
            NOPA_INQ24 = "4_14"
        elif x["INQ24"] == 15:
            NOPA_INQ24 = "4_15"
        elif x["INQ24"] == 16:
            NOPA_INQ24 = "4_16"
        elif x["INQ24"] == 17:
            NOPA_INQ24 = "4_17"
        elif x["INQ24"] == 18:
            NOPA_INQ24 = "4_18"
        elif x["INQ24"] == 19:
            NOPA_INQ24 = "4_19"
        else:
            NOPA_INQ24 = "4_20"
    return NOPA_INQ24


def f_derive_variables_NOPA_NOPRA(x):

    if x["NOPA"] < 4:
        if x["NOPA"] - x["NOPRA"] == 0:
            return "0_P0"
        elif x["NOPA"] - x["NOPRA"] == 1:
            return "0_P1"
        else:
            return "0_P2"
    else:
        if x["NOPRA"] == 0:
            return "4_00"
        elif x["NOPRA"] == 1:
            return "4_01"
        elif x["NOPRA"] == 2:
            return "4_02"
        elif x["NOPRA"] == 3:
            return "4_03"
        elif x["NOPRA"] == 4:
            return "4_04"
        elif x["NOPRA"] == 5:
            return "4_05"
        elif x["NOPRA"] == 6:
            return "4_06"
        elif x["NOPRA"] == 7:
            return "4_07"
        elif x["NOPRA"] == 8:
            return "4_08"
        elif x["NOPRA"] == 9:
            return "4_09"
        elif x["NOPRA"] == 10:
            return "4_10"
        elif x["NOPRA"] == 11:
            return "4_11"
        elif x["NOPRA"] == 12:
            return "4_12"
        elif x["NOPRA"] == 13:
            return "4_13"
        elif x["NOPRA"] == 14:
            return "4_14"
        elif x["NOPRA"] == 15:
            return "4_15"
        elif x["NOPRA"] == 16:
            return "4_16"
        elif x["NOPRA"] == 17:
            return "4_17"
        elif x["NOPRA"] == 18:
            return "4_18"
        elif x["NOPRA"] == 19:
            return "4_19"
        elif x["NOPRA"] == 20:
            return "4_20"
        elif x["NOPRA"] == 21:
            return "4_21"
        elif x["NOPRA"] == 22:
            return "4_22"
        elif x["NOPRA"] == 23:
            return "4_23"
        elif x["NOPRA"] == 24:
            return "4_24"
        else:
            return "4_25"


def f_derive_variables_NOPA_PORAL50(x):

    if x["NOPA"] < 4:
        if x["NOPRA"] == 0:
            NOPA_PORAL50 = "0_N_-1"
        elif (x["PORAL50"] >= 0) & (x["PORAL50"] < 100):
            NOPA_PORAL50 = "0_P000"
        else:
            NOPA_PORAL50 = "0_P100"
    elif x["NOPRA"] == 0:
        NOPA_PORAL50 = "4_N_-1"
    elif (x["PORAL50"] >= 66.66):
        NOPA_PORAL50 = "4_P067"
    elif (x["PORAL50"] == 0):
        NOPA_PORAL50 = "4_P000"
    elif (x["PORAL50"] > 0) & (x["PORAL50"] < 15):
        NOPA_PORAL50 = "4_P001"
    elif (x["PORAL50"] >= 15) & (x["PORAL50"] < 25):
        NOPA_PORAL50 = "4_P015"
    else:
        NOPA_PORAL50 = "4_P025"
    return NOPA_PORAL50


def f_derive_variables_NOPA_RLEVTYPE(x):

    if x["NOPA_GRP"] == 0:
        if x["RLEV"] < 0:
            NOPA_RLEVTYPE = "0_-1"
        else:
            NOPA_RLEVTYPE = "0_00"
    elif x["RLEV"] < 0:
        NOPA_RLEVTYPE = "4_-1"
    else:
        NOPA_RLEVTYPE = "4_00"

    return NOPA_RLEVTYPE


def f_derive_variables_PORAL50_BIN(x):

    if ["NOPRA"] == 0:
        PORAL50_BIN = -1
    elif x["PORAL50"] >= 100:
        PORAL50_BIN = 100
    elif x["PORAL50"] >= 66.66:
        PORAL50_BIN = 67
    elif x["PORAL50"] >= 40:
        PORAL50_BIN = 40
    elif x["PORAL50"] >= 25:
        PORAL50_BIN = 25
    elif x["PORAL50"] >= 15:
        PORAL50_BIN = 15
    elif x["PORAL50"] >= 1:
        PORAL50_BIN = 1
    elif x["PORAL50"] > 0:
        PORAL50_BIN = 0
    elif x["PORAL50"] == 0:
        PORAL50_BIN = 0
    else:
        PORAL50_BIN = x["PORAL50"]
    return PORAL50_BIN


def f_derive_variables_AOP24_BIN(x):

    if x >= 6:
        return 6
    elif x >= 3:
        return 3
    else:
        return x


def f_derive_variables_AVGMAO_BIN(x):

    if (x >= 0) & (x < 20):
        AVGMAO_BIN = 1
    elif (x >= 20) & (x < 40):
        AVGMAO_BIN = 2
    elif (x >= 40) & (x < 48):
        AVGMAO_BIN = 3
    elif (x >= 48) & (x < 55):
        AVGMAO_BIN = 4
    elif (x >= 55) & (x < 65):
        AVGMAO_BIN = 5
    elif (x >= 65) & (x < 74):
        AVGMAO_BIN = 6
    elif (x >= 74) & (x < 81):
        AVGMAO_BIN = 7
    elif (x >= 81) & (x < 89):
        AVGMAO_BIN = 8
    elif (x >= 89) & (x < 97):
        AVGMAO_BIN = 9
    elif (x >= 97) & (x < 109):
        AVGMAO_BIN = 10
    elif (x >= 109) & (x < 116):
        AVGMAO_BIN = 11
    elif (x >= 116) & (x < 128):
        AVGMAO_BIN = 12
    elif (x >= 128) & (x < 152):
        AVGMAO_BIN = 13
    elif x >= 152:
        AVGMAO_BIN = 14
    else:
        AVGMAO_BIN = 1

    return AVGMAO_BIN


def f_derive_variables_NOPA_INQ24B(x):

    if x["NOPA"] == 0:
        NOPA = "0_"
    elif x["NOPA"] == 1:
        NOPA = "1_"
    elif x["NOPA"] == 2:
        NOPA = "2_"
    elif x["NOPA"] == 3:
        NOPA = "3_"
    else:
        NOPA = "4_"
    if x["INQ24"] == 0:
        INQ24B = "0"
    else:
        INQ24B = "1"

    return NOPA + INQ24B


def f_derive_variables_NOPA_NMORTHEL(x):

    if x["NOPA"] < 4:
        NOPA = "0_"
    else:
        NOPA = "4_"
    if x["NMORTHEL"] == 0:
        NMORTHEL = "0"
    elif x["NMORTHEL"] == 1:
        NMORTHEL = "1"
    else:
        NMORTHEL = "2"
    return NOPA + NMORTHEL


def f_derive_variables_NOPA_RLEV(x):

    if x["NOPA"] < 4:
        if x["RLEV"] < 0:
            return "0_0"
        elif x["RLEV"] < 0.095:
            return "0_1"
        else:
            return "0_6"
    elif x["RLEV"] < 0:
        return "4_0"
    elif x["RLEV"] == 0:
        return "4_1"
    elif x["RLEV"] < 0.005:
        return "4_2"
    elif x["RLEV"] < 0.025:
        return "4_3"
    elif x["RLEV"] < 0.055:
        return "4_4"
    elif x["RLEV"] < 0.095:
        return "4_5"
    else:
        return "4_6"


def f_derive_variables_NOPA_ACD(x):

    if x["NOPA"] < 4:
        NOPA = "0_"
    else:
        NOPA = "4_"
    if (x["COLL_FLAG"] + x["APD_FLAG"] + x["DPR_FLAG"]) == 0:
        ACD = "1"
    elif ((x["COLL_FLAG"] + x["APD_FLAG"] == 0) &
          (x["DPR_FLAG"] >= 1)) | (x["COLL"] < 200):
        ACD = "2"
    elif (x["APD_FLAG"] + x["DPR_FLAG"] == 0) & (x["COLL"] < 1000):
        ACD = "3"
    elif (x["COLL"] < 1000) | (x["APD_FLAG"] + x["DPR_FLAG"] == 0):
        ACD = "4"
    else:
        ACD = "5"
    return (NOPA + ACD)


def f_derive_variables_NOPA_MOP(x):

    if x["NOPA"] < 4:
        NOPA = "0_"
    else:
        NOPA = "4_"
    if x["HIMOPEVER"] >= 7:
        if x["MOPHI"] >= 5:
            MOP = "7"
        elif x["MOPHI"] >= 2:
            MOP = "6"
        else:
            MOP = "5"
    elif x["MOPHI"] == 0:
        if x["HIMOPEVER"] >= 3:
            MOP = "3"
        elif x["HIMOPEVER"] >= 2:
            MOP = "2"
        else:
            MOP = "1"
    else:
        MOP = "4"
    return (NOPA + MOP)


def f_derive_variables(df):
    # Move decimal on PORALS
    df.loc[:, "PORAL50"] = (df["PORAL50"]/df["NOPRA"]) * 100
    df.loc[:, "PORAL75"] = (df["PORAL75"]/df["NOPRA"]) * 100
    df.loc[:, "AWOAO"] = ((df["AGE_IN_MONTHS"] - df["MOLDAOP"])/12).astype(int)
    df.loc[:, "IADIF"] = df["INQ24"] - df["AOP24"]
    df.loc[:, "NMORTHEL"] = df["NMORT"] + df["NHELOAN"]
    df.loc[:, "RLEV"] = df.apply(lambda x: -1 if x["RLIM"] <= 0 else
                                 (x["RBAL"]/x["RLIM"])*1, axis=1)
    df.loc[:, "APD_FLAG"] = df["APD"].apply(lambda x: 1 if x >= 130 else 0)
    df.loc[:, "COLL_FLAG"] = df["COLL"].apply(lambda x: 1 if x > 0 else 0)
    df.loc[:, "DPR_FLAG"] = df["DPR"].apply(lambda x: 1 if x > 0 else 0)
    df.loc[:, "ACD_COMBO"] = df.apply(f_derive_variables_ACD_COMBO, axis=1)
    df.loc[:, "MOP_COMBO"] = df.apply(f_derive_variables_MOP_COMBO, axis=1)
    df.loc[:, "DDC_PRE"] = df.apply(f_derive_variables_DDC_PRE, axis=1)
    df.loc[:, "DDC_COMBO"] = df.DDC_PRE.apply(f_derive_variables_DDC_COMBO)
    df.loc[:, "DDC_COMBO2"] = df.DDC_PRE.apply(f_derive_variables_DDC_COMBO2)
    df.loc[:, "AVGMAO"] = df.apply(lambda x: -1 if x["NOPA"] <= 0 else
                                   x["AVGMAO"], axis=1)
    df.loc[:, "PORAL50"] = df.apply(lambda x: -1 if x["NOPRA"] <= 0 else
                                    x["PORAL50"], axis=1)
    df.loc[:, "PORAL75"] = df.apply(lambda x: -1 if x["NOPRA"] <= 0 else
                                    x["PORAL75"], axis=1)
    df.loc[:, "NOPA_GRP"] = df.NOPRA.apply(lambda x: 0 if x < 4 else 4)
    df.loc[:, "AWOAO_BIN"] = df.apply(f_derive_variables_AWOAO_BIN, axis=1)
    df.loc[:, "NOPA_AVGMAO"] = df.apply(f_derive_variables_NOPA_AVGMAO, axis=1)
    df.loc[:, "NOPA_CAP"] = df.NOPA.apply(f_derive_variables_NOPA_CAP)
    df.loc[:, "NOPA_DEL84"] = df.apply(lambda x: "0_2" if ((x["NOPA"] < 4) &
                                       (x["DEL84"] >= 2)) else "OTH", axis=1)
    df.loc[:, "NOPA_IADIF"] = df.apply(f_derive_variables_NOPA_IADIF, axis=1)
    df.loc[:, "NOPA_INQ06"] = df.apply(lambda x: "0_5" if ((x["NOPA"] < 4) &
                                       (x["INQ06"] >= 5)) else "OTH", axis=1)
    df.loc[:, "NOPA_INQ24"] = df.apply(f_derive_variables_NOPA_INQ24, axis=1)
    df.loc[:, "NOPA_NOPRA"] = df.apply(f_derive_variables_NOPA_NOPRA, axis=1)
    df.loc[:, "NOPA_PORAL50"] = df.apply(f_derive_variables_NOPA_PORAL50,
                                         axis=1)
    df.loc[:, "NOPA_RLEVTYPE"] = df.apply(f_derive_variables_NOPA_RLEVTYPE,
                                          axis=1)
    df.loc[:, "DEL24_CAP"] = df.DEL24.apply(lambda x: 3 if x >= 3 else x)
    df.loc[:, "NOMORT_CAP"] = df.NOMORT.apply(lambda x: 1 if x >= 1 else 0)
    df.loc[:, "PORAL50_BIN"] = df.apply(f_derive_variables_PORAL50_BIN, axis=1)
    df.loc[:, "AVGMAO_BIN"] = df.AVGMAO.apply(f_derive_variables_AVGMAO_BIN)
    df.loc[:, "AOP24_BIN"] = df["AOP24"].apply(f_derive_variables_AOP24_BIN)
    df.loc[:, "NOPA_INQ24B"] = df.apply(f_derive_variables_NOPA_INQ24B, axis=1)
    df.loc[:, "NOPA_NMORTHEL"] = df.apply(f_derive_variables_NOPA_NMORTHEL,
                                          axis=1)
    df.loc[:, "NOPA_RLEV"] = df.apply(f_derive_variables_NOPA_RLEV, axis=1)
    df.loc[:, "NOPA_ACD"] = df.apply(f_derive_variables_NOPA_ACD, axis=1)
    df.loc[:, "NOPA_MOP"] = df.apply(f_derive_variables_NOPA_MOP, axis=1)
    dropcols = ["DEL30D84", "DEL60PD24", "DEL90PD24", "DEL60D84", "DEL90D84",
                "DEL120D84", "DDC_PRE"]
    df = df.drop(labels=dropcols, axis=1)
    return df


def pfm_model_u_to_v(df):

    df = df.drop(["G096", "RE09"], axis=1)
    df.rename(columns={"G091": "APD",
                       "S004": "AVGMAO",
                       "S064": "COLL",
                       "G001": "DEL30D84",
                       "AT20": "MOLDAOP",
                       "RE20": "MOLDRAOP",
                       "G096": "INQ24",
                       "G098": "INQ06",
                       "G007": "DEL84",
                       "G061": "DEL24",
                       "G066": "DEL60PD24",
                       "G071": "DEL90PD24",
                       "MT01": "NMORT",
                       "IHI01": "NHELOAN",
                       "G095": "MRECDPR",
                       "G093": "DPR",
                       "AT36": "MRECDEL",
                       "S011": "NOPA",
                       "AT09": "AOP24",
                       "AT06": "AOP06",
                       "RE09": "RAOP24",
                       "S012": "NOPRA",
                       "RE30": "PORAL50",
                       "RE31": "PORAL75",
                       "S060": "MOPHI",
                       "RE33": "RBAL",
                       "RE28": "RLIM",
                       "G089": "HIMOPEVER",
                       "G960": "INQ24",
                       "MT02": "NOMORT",
                       "G002": "DEL60D84",
                       "G003": "DEL90D84",
                       "G094": "NBANKRUPT",
                       "G004": "DEL120D84",
                       "ntaxlien": "NTAXLIEN"}, inplace=True)
    df_derive_var = f_derive_variables(df)
    model_U_df = df_derive_var[df_derive_var["Model"] == "U"]
    model_V_df = df_derive_var[df_derive_var["Model"] == "V"]
    models_appended = pd.DataFrame()
    if model_U_df.index.values.size > 0:
        model_U_df = pfm_model_u(model_U_df)
        models_appended = pd.concat([models_appended, model_U_df],
                                    ignore_index=True)
    if model_V_df.index.values.size > 0:
        model_V_df = pfm_model_v(model_V_df)
        models_appended = pd.concat([models_appended, model_V_df],
                                    ignore_index=True)

    return models_appended
