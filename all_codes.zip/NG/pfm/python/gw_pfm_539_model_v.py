##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Sushant Kulkarni, Prabakar Subramani
# Creation Date          : 08FEB2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_model_v.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Model V
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################

# ------------------------------------------------------------------------

import numpy as np


def f_v_factors_AVGMAO_FACT_V(x):
    # nugget-id: idVATHVTJNYI
    if x["NOPA"] == 0:
        return 1.005
    elif (x["AVGMAO"] >= 0) & (x["AVGMAO"] <= 11):
        return 1.327
    elif x["AVGMAO"] < 24:
        return 1.224
    elif x["AVGMAO"] < 36:
        return 1.111
    elif x["AVGMAO"] < 60:
        return 1.077
    elif x["AVGMAO"] < 72:
        return 1.005
    elif x["AVGMAO"] < 108:
        return 0.976
    elif x["AVGMAO"] >= 108:
        return 0.915
    else:
        return None


def f_v_factors_AWOAO_FACT_V(x):
    # nugget-id: id8EHT3MSKPFX
    if x <= 0:
        return 1.210
    elif x > 0 and x < 18:
        return 0.946
    elif x == 18:
        return 0.886
    elif x < 25:
        return 0.913
    elif x < 27:
        return 0.972
    elif x < 33:
        return 1.030
    elif x < 40:
        return 1.062
    elif x < 45:
        return 1.099
    elif x >= 45:
        return 1.179
    else:
        return None


def f_v_factors_COMB_A_V(x):
    # nugget-id: id2VRT5TKPNLX
    if (x["COLL"] == 0) & (x["DPR"] == 0) & (x["APD"] < 130):
        return 1
    elif (x["COLL"] == 0) & (x["DPR"] > 0) & (x["APD"] < 130):
        return 2
    elif (x["COLL"] > 0) & x["COLL"] < 200 & x["DPR"] == 0 & (x["APD"] < 130):
        return 2
    elif (x["COLL"] >= 200) & (x["COLL"] < 1000) & (x["DPR"] == 0) & (x["APD"] < 130):
        return 3
    elif (x["COLL"] >= 1000) & (x["DPR"] == 0) & (x["APD"] < 130):
        return 5
    elif (x["COLL"] > 0) & (x["COLL"] < 200) & (x["DPR"] > 0) & (x["APD"] < 130):
        return 4
    elif (x["COLL"] >= 200) & (x["COLL"] < 1000) & (x["DPR"] > 0) & (x["APD"] < 130):
        return 5
    elif (x["COLL"] >= 1000) & (x["DPR"] > 0) & (x["APD"] < 130):
        return 6
    elif (x["COLL"] >= 0) & (x["COLL"] < 200) & (x["APD"] >= 130):
        return 4
    elif (x["COLL"] >= 200) & (x["COLL"] < 1000) & (x["APD"] >= 130):
        return 5
    elif (x["COLL"] >= 1000) & (x["APD"] >= 130):
        return 6
    else:
        return None


def f_v_factors_COMB_B_V(x):
    # nugget-id: id5GLT7IHNNWV
    if (x["HIMOPEVER"] == 0) & (x["MOPHI"] == 0):
        return 1
    elif (x["HIMOPEVER"] == 1) & (x["MOPHI"] == 0):
        return 1
    elif (x["HIMOPEVER"] == 2) & (x["MOPHI"] == 0):
        return 2
    elif (x["HIMOPEVER"] >= 3) & (x["HIMOPEVER"] <= 6) & (x["MOPHI"] == 0):
        return 3
    elif (x["HIMOPEVER"] >= 7) & (x["HIMOPEVER"] <= 9) & (x["MOPHI"] == 0):
        return 5
    elif (x["HIMOPEVER"] >= 0) & (x["HIMOPEVER"] <= 6) & (x["MOPHI"] >= 1):
        return 4
    elif (x["HIMOPEVER"] >= 7) & (x["HIMOPEVER"] <= 9) & (x["MOPHI"] == 1):
        return 5
    elif (x["HIMOPEVER"] >= 7) & (x["HIMOPEVER"] <= 9) & (x["MOPHI"] >= 2) & (x["MOPHI"] <= 4):
        return 6
    elif (x["HIMOPEVER"] >= 7) & (x["HIMOPEVER"] <= 9) & (x["MOPHI"] >= 5):
        return 7
    else:
        return None


def f_v_factors_COMB_C_V(x):
    # nugget-id: id29PT771ISZU
    if x["COMB_A_V"] == 1 & (x["COMB_B_V"] == 1):
        return 1
    elif x["COMB_A_V"] == 2 & (x["COMB_B_V"] == 1):
        return 2
    elif x["COMB_A_V"] == 3 & (x["COMB_B_V"] == 1):
        return 5
    elif x["COMB_A_V"] == 4 & (x["COMB_B_V"] == 1):
        return 5
    elif (x["COMB_A_V"] == 5) & (x["COMB_B_V"] == 1):
        return 5
    elif (x["COMB_A_V"] == 6) & (x["COMB_B_V"] == 1):
        return 7
    elif (x["COMB_A_V"] == 1) & (x["COMB_B_V"] > 1) & (x["COMB_B_V"] < 6) & (x["DEL24"] == 0):
        return 3
    elif (x["COMB_A_V"] == 1) & (x["COMB_B_V"] > 1) & (x["COMB_B_V"] < 6) & (x["DEL24"] > 0) & (x["DEL24"] < 7):
        return 4
    elif (x["COMB_A_V"] == 1) & (x["COMB_B_V"] > 1) & (x["COMB_B_V"] < 6) & (x["DEL24"] > 6):
        return 8
    elif (x["COMB_A_V"] == 1) & (x["COMB_B_V"] > 5) & (x["DEL24"] == 0):
        return 5
    elif (x["COMB_A_V"] == 1) & (x["COMB_B_V"] > 5) & (x["DEL24"] > 0) & (x["DEL24"] < 7):
        return 6
    elif (x["COMB_A_V"] == 1) & (x["COMB_B_V"] > 5) & (x["DEL24"] > 6):
        return 8
    elif (x["COMB_A_V"] == 2) & (x["COMB_B_V"] > 1) & (x["COMB_B_V"] < 6) & (x["DEL24"] == 0):
        return 5
    elif (x["COMB_A_V"] == 2) & (x["COMB_B_V"] > 1) & (x["COMB_B_V"] < 6) & (x["DEL24"] > 0) & (x["DEL24"] < 7):
        return 6
    elif (x["COMB_A_V"] == 2) & (x["COMB_B_V"] > 1) & (x["COMB_B_V"] < 6) & (x["DEL24"] > 6):
        return 8
    elif (x["COMB_A_V"] == 2) & (x["COMB_B_V"] > 5) & (x["DEL24"] == 0):
        return 7
    elif (x["COMB_A_V"] == 2) & (x["COMB_B_V"] > 5) & (x["DEL24"] > 0):
        return 8
    elif (x["COMB_A_V"] == 3) & (x["COMB_B_V"] > 1) & (x["DEL24"] == 0):
        return 7
    elif (x["COMB_A_V"] == 3) & (x["COMB_B_V"] > 1) & (x["COMB_B_V"] < 6) & (x["DEL24"] > 0):
        return 8
    elif (x["COMB_A_V"] == 3) & (x["COMB_B_V"] > 5) & (x["DEL24"] > 0):
        return 9
    elif (x["COMB_A_V"] == 4) & (x["COMB_B_V"] > 1) & (x["DEL24"] == 0):
        return 7
    elif (x["COMB_A_V"] == 4) & (x["COMB_B_V"] > 1) & (x["COMB_B_V"] < 6) & x["DEL24"] > 0:
        return 8
    elif (x["COMB_A_V"] == 4) & (x["COMB_B_V"] > 5) & (x["DEL24"] > 0):
        return 9
    elif (x["COMB_A_V"] == 5) & (x["COMB_B_V"] > 1) & (x["DEL24"] == 0):
        return 7
    elif (x["COMB_A_V"] == 5) & (x["COMB_B_V"] > 1) & (x["COMB_B_V"] < 6) & (x["DEL24"] > 0):
        return 8
    elif (x["COMB_A_V"] == 5) & (x["COMB_B_V"] > 5) & (x["DEL24"] > 0):
        return 9
    elif (x["COMB_A_V"] == 6) & (x["COMB_B_V"] > 1) & (x["DEL24"] == 0):
        return 7
    elif (x["COMB_A_V"] == 6) & (x["COMB_B_V"] > 1) & (x["COMB_B_V"] < 6) & (x["DEL24"] > 0):
        return 8
    elif (x["COMB_A_V"] == 6) & (x["COMB_B_V"] > 5) & (x["DEL24"] > 0):
        return 10
    else:
        return None


def f_v_factors_INQ24_FACT_V(x):
    # nugget-id: idP5SYE4UY3N
    if x == 0:
        return 0.931
    elif x == 1:
        return 0.965
    elif x == 2:
        return 0.966
    elif x < 7:
        return 0.994
    elif x == 7:
        return 1.045
    elif x == 8:
        return 1.048
    elif x < 15:
        return 1.102
    elif x < 25:
        return 1.215
    elif x >= 25:
        return 1.389
    else:
        return None


def f_v_factors_NOPA_FACT_V(x):
    # nugget-id: id4JFT3AMJ4F3
    if x == 0:
        return 1.012
    elif x == 1:
        return 1.052
    elif x < 4:
        return 0.959
    elif x < 8:
        return 0.938
    elif x == 8:
        return 0.952
    elif x == 9:
        return 0.979
    elif x < 12:
        return 1.003
    elif x < 20:
        return 1.075
    elif x >= 20:
        return 1.080
    else:
        return None


def f_v_factors_PORAL50_FACT_V(x):
    # nugget-id: id17DT77CXD5J
    if x <= 0:
        return 0.945
    elif x <= 11.1:
        return 1.014
    elif x <= 14.3:
        return 1.024
    elif x <= 33.0:
        return 1.053
    elif x <= 66.0:
        return 1.061
    elif x <= 100.0:
        return 1.096
    else:
        return None


def f_v_factors(df):
    # nugget-id: idVATHVTJNYI
    df["AVGMAO_FACT_V"] = df.apply(f_v_factors_AVGMAO_FACT_V, axis=1)
    # nugget-id: id8EHT3MSKPFX
    df["AWOAO_FACT_V"] = df.AWOAO_BIN.apply(f_v_factors_AWOAO_FACT_V)
    # nugget-id: id2VRT5TKPNLX
    df["COMB_A_V"] = df.apply(f_v_factors_COMB_A_V, axis=1)
    # nugget-id: id5GLT7IHNNWV
    df["COMB_B_V"] = df.apply(f_v_factors_COMB_B_V, axis=1)
    # nugget-id: id29PT771ISZU
    df["COMB_C_V"] = df.apply(f_v_factors_COMB_C_V, axis=1)
    # nugget-id: idP5SYE4UY3N
    df["INQ24_FACT_V"] = df.INQ24.apply(f_v_factors_INQ24_FACT_V)
    # nugget-id: id4JFT3AMJ4F3
    df["NOPA_FACT_V"] = df.NOPA.apply(f_v_factors_NOPA_FACT_V)
    # nugget-id: id17DT77CXD5J
    df["PORAL50_FACT_V"] = df.PORAL50.apply(f_v_factors_PORAL50_FACT_V)
    return df


def f_add_V_Factos_COMB_A_FACT_V(x):
    # nugget-id: id3XKSJKGPL3T
    if x["COMB_A_V"] == 1:
        return 0.987
    elif x["COMB_A_V"] == 2:
        return 0.987
    elif x["COMB_A_V"] == 3:
        return 1.066
    elif x["COMB_A_V"] == 4:
        return 1.066
    elif x["COMB_A_V"] == 5:
        return 1.066
    elif x["COMB_A_V"] == 6:
        return 1.066
    else:
        return None


def f_add_V_Factos_COMB_C_FACT_V(x):
    # nugget-id:
    if x["COMB_C_V"] == 1:
        return 0.890
    elif x["COMB_C_V"] == 2:
        return 1.025
    elif x["COMB_C_V"] == 3:
        return 1.032
    elif x["COMB_C_V"] == 4:
        return 1.037
    elif x["COMB_C_V"] == 5:
        return 1.097
    elif x["COMB_C_V"] == 6:
        return 1.157
    elif x["COMB_C_V"] == 7:
        return 1.189
    elif x["COMB_C_V"] == 8:
        return 1.226
    elif x["COMB_C_V"] == 9:
        return 1.250
    elif x["COMB_C_V"] == 10:
        return 1.371
    else:
        return None


def f_add_V_Factos_DEL24_FACT_V(x):
    if x["DEL24_CAP"] == 0:
        return 0.997
    elif x["DEL24_CAP"] == 1:
        return 0.997
    elif x["DEL24_CAP"] == 2:
        return 1.019
    else:
        return None


def f_add_V_Factos_IADIF_FACT_V(x):
    if x["IADIF"] <= -2:
        return 1.000000
    elif x["IADIF"] == -1:
        return 0.982344
    elif x["IADIF"] == 0:
        return 0.989949
    elif x["IADIF"] == 1:
        return 0.996494
    elif x["IADIF"] == 2:
        return 1.002497
    elif x["IADIF"] == 3:
        return 1.008464
    elif x["IADIF"] >= 4:
        return 1.024207
    else:
        return None


def f_add_V_Factos_DDC_FACT_V(x):
    # nugget-id: id2ILT79FTUQ1
    if x["DDC_COMBO"] == 1:
        return 0.952890
    elif x["DDC_COMBO"] == 2:
        return 1.009455
    elif x["DDC_COMBO"] == 3:
        return 1.009455
    elif x["DDC_COMBO"] == 4:
        return 1.009455
    elif x["DDC_COMBO"] == 5:
        return 1.051190
    elif x["DDC_COMBO"] == 6:
        return 1.051190
    elif x["DDC_COMBO"] == 7:
        return 1.098636
    elif x["DDC_COMBO"] == 8:
        return 1.098636
    elif x["DDC_COMBO"] == 9:
        return 1.098636
    elif x["DDC_COMBO"] == 10:
        return 1.133137
    else:
        return None


def f_add_V_Factors(df):
    # nugget-id: id3XKSJKGPL3T
    df["COMB_A_FACT_V"] = df.apply(f_add_V_Factos_COMB_A_FACT_V, axis=1)
    df["COMB_C_FACT_V"] = df.apply(f_add_V_Factos_COMB_C_FACT_V, axis=1)
    df["DEL24_FACT_V"] = df.apply(f_add_V_Factos_DEL24_FACT_V, axis=1)
    # nugget-id: id5JZTJ9A874S
    df["IADIF_FACT_V"] = df.apply(f_add_V_Factos_IADIF_FACT_V, axis=1)
    # nugget-id: id2ILT79FTUQ1
    df["DDC_FACT_V"] = df.apply(f_add_V_Factos_DDC_FACT_V, axis=1)
    return df


def f_scaled_score_pre(x):
    score = round((573.781 * x["AVGMAO_FACT_V"] * x["AWOAO_FACT_V"] *
                   x["INQ24_FACT_V"] * x["NOPA_FACT_V"] * x["PORAL50_FACT_V"] *
                   x["COMB_C_FACT_V"] * x["COMB_A_FACT_V"] - 200), 5)
    return score


def f_scale_score_scaled(x):
    if x < 10:
        return 10
    elif x > 999:
        return 999
    else:
        return round(x)


def f_PFMV_LEVEL(x):
    # nugget-id: id6V6SJYUE6U
    if (x["PFMV_SCORE"] >= 10) & (x["PFMV_SCORE"] < 184):
        return "BD"
    elif (x["PFMV_SCORE"] >= 184) & (x["PFMV_SCORE"] < 199):
        return "BH"
    elif (x["PFMV_SCORE"] >= 199) & (x["PFMV_SCORE"] < 213):
        return "BL"
    elif (x["PFMV_SCORE"] >= 213) & (x["PFMV_SCORE"] < 227):
        return "BP"
    elif (x["PFMV_SCORE"] >= 227) & (x["PFMV_SCORE"] < 241):
        return "BT"
    elif (x["PFMV_SCORE"] >= 241) & (x["PFMV_SCORE"] < 251):
        return "BW"
    elif (x["PFMV_SCORE"] >= 251) & (x["PFMV_SCORE"] < 262):
        return "CD"
    elif (x["PFMV_SCORE"] >= 262) & (x["PFMV_SCORE"] < 276):
        return "CH"
    elif (x["PFMV_SCORE"] >= 276) & (x["PFMV_SCORE"] < 287):
        return "CL"
    elif (x["PFMV_SCORE"] >= 287) & (x["PFMV_SCORE"] < 297):
        return "CP"
    elif (x["PFMV_SCORE"] >= 297) & (x["PFMV_SCORE"] < 305):
        return "CT"
    elif (x["PFMV_SCORE"] >= 305) & (x["PFMV_SCORE"] < 315):
        return "CW"
    elif (x["PFMV_SCORE"] >= 315) & (x["PFMV_SCORE"] < 319):
        return "DD"
    elif (x["PFMV_SCORE"] >= 319) & (x["PFMV_SCORE"] < 330):
        return "DG"
    elif (x["PFMV_SCORE"] >= 330) & (x["PFMV_SCORE"] < 340):
        return "DJ"
    elif (x["PFMV_SCORE"] >= 340) & (x["PFMV_SCORE"] < 350):
        return "DN"
    elif (x["PFMV_SCORE"] >= 350) & (x["PFMV_SCORE"] < 361):
        return "DQ"
    elif (x["PFMV_SCORE"] >= 361) & (x["PFMV_SCORE"] < 372):
        return "DT"
    elif (x["PFMV_SCORE"] >= 372) & (x["PFMV_SCORE"] < 384):
        return "DW"
    elif (x["PFMV_SCORE"] >= 384) & (x["PFMV_SCORE"] < 394):
        return "ED"
    elif (x["PFMV_SCORE"] >= 394) & (x["PFMV_SCORE"] < 407):
        return "EG"
    elif (x["PFMV_SCORE"] >= 407) & (x["PFMV_SCORE"] < 422):
        return "EJ"
    elif (x["PFMV_SCORE"] >= 422) & (x["PFMV_SCORE"] < 435):
        return "EN"
    elif (x["PFMV_SCORE"] >= 435) & (x["PFMV_SCORE"] < 453):
        return "EQ"
    elif (x["PFMV_SCORE"] >= 453) & (x["PFMV_SCORE"] < 471):
        return "ET"
    elif (x["PFMV_SCORE"] >= 471) & (x["PFMV_SCORE"] < 477):
        return "EW"
    elif (x["PFMV_SCORE"] >= 477) & (x["PFMV_SCORE"] < 500):
        return "FD"
    elif (x["PFMV_SCORE"] >= 500) & (x["PFMV_SCORE"] < 526):
        return "FG"
    elif (x["PFMV_SCORE"] >= 526) & (x["PFMV_SCORE"] < 554):
        return "FJ"
    elif (x["PFMV_SCORE"] >= 554) & (x["PFMV_SCORE"] < 575):
        return "FN"
    elif (x["PFMV_SCORE"] >= 575) & (x["PFMV_SCORE"] < 593):
        return "FQ"
    elif (x["PFMV_SCORE"] >= 593) & (x["PFMV_SCORE"] < 617):
        return "FT"
    elif (x["PFMV_SCORE"] >= 617) & (x["PFMV_SCORE"] < 638):
        return "FW"
    elif (x["PFMV_SCORE"] >= 638) & (x["PFMV_SCORE"] < 660):
        return "GD"
    elif (x["PFMV_SCORE"] >= 660) & (x["PFMV_SCORE"] < 682):
        return "GH"
    elif (x["PFMV_SCORE"] >= 682) & (x["PFMV_SCORE"] < 703):
        return "GL"
    elif (x["PFMV_SCORE"] >= 703) & (x["PFMV_SCORE"] < 722):
        return "GP"
    elif (x["PFMV_SCORE"] >= 722) & (x["PFMV_SCORE"] < 745):
        return "GT"
    elif (x["PFMV_SCORE"] >= 745) & (x["PFMV_SCORE"] < 771):
        return "HD"
    elif (x["PFMV_SCORE"] >= 771) & (x["PFMV_SCORE"] < 806):
        return "HH"
    elif (x["PFMV_SCORE"] >= 806) & (x["PFMV_SCORE"] < 846):
        return "HL"
    elif (x["PFMV_SCORE"] >= 846) & (x["PFMV_SCORE"] < 902):
        return "HP"
    elif (x["PFMV_SCORE"] >= 902) & (x["PFMV_SCORE"] < 999):
        return "HT"
    elif (x["PFMV_SCORE"] >= 999) & (x["PFMV_SCORE"] <= 999):
        return "HW"
    else:
        return "ZZ"


def f_reason_percentiles_RPCT_A(x):
    # nugget-id: id8LWS1TY6KRU
    if x["APD"] < 1:
        return 100
    elif x["APD"] < 100:
        return 5.89
    elif x["APD"] < 200:
        return 4.55
    elif x["APD"] < 300:
        return 4.01
    elif x["APD"] < 400:
        return 3.59
    elif x["APD"] < 500:
        return 3.21
    elif x["APD"] < 600:
        return 2.91
    elif x["APD"] < 700:
        return 2.67
    elif x["APD"] < 800:
        return 2.47
    elif x["APD"] < 900:
        return 2.27
    elif x["APD"] < 1000:
        return 2.11
    elif x["APD"] < 1100:
        return 1.96
    elif x["APD"] < 1200:
        return 1.84
    elif x["APD"] < 1300:
        return 1.73
    elif x["APD"] < 1400:
        return 1.63
    elif x["APD"] < 1500:
        return 1.53
    elif x["APD"] < 1600:
        return 1.46
    elif x["APD"] < 1700:
        return 1.39
    elif x["APD"] < 1800:
        return 1.32
    elif x["APD"] < 1900:
        return 1.26
    elif x["APD"] < 2000:
        return 1.20
    elif x["APD"] < 2100:
        return 1.15
    elif x["APD"] < 2200:
        return 1.11
    elif x["APD"] < 2300:
        return 1.05
    elif x["APD"] < 2400:
        return 1.01
    elif x["APD"] < 2500:
        return 0.97
    else:
        return 0.94


def f_reason_percentiles_RPCT_B(x):
    if x["COLL"] < 1:
        return 100.00
    elif x["COLL"] < 100:
        return 18.08
    elif x["COLL"] < 200:
        return 16.29
    elif x["COLL"] < 300:
        return 13.81
    elif x["COLL"] < 400:
        return 12.15
    elif x["COLL"] < 500:
        return 10.91
    elif x["COLL"] < 600:
        return 9.92
    elif x["COLL"] < 700:
        return 9.15
    elif x["COLL"] < 800:
        return 8.48
    elif x["COLL"] < 900:
        return 7.91
    elif x["COLL"] < 1000:
        return 7.43
    elif x["COLL"] < 1100:
        return 6.98
    elif x["COLL"] < 1200:
        return 6.57
    elif x["COLL"] < 1300:
        return 6.22
    elif x["COLL"] < 1400:
        return 5.92
    elif x["COLL"] < 1500:
        return 5.63
    elif x["COLL"] < 1600:
        return 5.37
    elif x["COLL"] < 1700:
        return 5.14
    elif x["COLL"] < 1800:
        return 4.91
    elif x["COLL"] < 1900:
        return 4.71
    elif x["COLL"] < 2000:
        return 4.51
    elif x["COLL"] < 2100:
        return 4.33
    elif x["COLL"] < 2200:
        return 4.15
    elif x["COLL"] < 2300:
        return 4.00
    elif x["COLL"] < 2400:
        return 3.86
    elif x["COLL"] < 2500:
        return 3.71
    elif x["COLL"] < 2600:
        return 3.57
    elif x["COLL"] < 2700:
        return 3.45
    elif x["COLL"] < 2800:
        return 3.34
    elif x["COLL"] < 2900:
        return 3.23
    elif x["COLL"] < 3000:
        return 3.13
    elif x["COLL"] < 3200:
        return 3.02
    elif x["COLL"] < 3400:
        return 2.84
    elif x["COLL"] < 3600:
        return 2.66
    elif x["COLL"] < 3800:
        return 2.51
    elif x["COLL"] < 4000:
        return 2.36
    elif x["COLL"] < 4200:
        return 2.22
    elif x["COLL"] < 4400:
        return 2.10
    elif x["COLL"] < 4600:
        return 1.99
    elif x["COLL"] < 4800:
        return 1.89
    elif x["COLL"] < 5000:
        return 1.79
    elif x["COLL"] < 5500:
        return 1.71
    elif x["COLL"] < 6000:
        return 1.51
    elif x["COLL"] < 6500:
        return 1.34
    elif x["COLL"] < 7000:
        return 1.18
    elif x["COLL"] < 7500:
        return 1.06
    elif x["COLL"] < 8000:
        return 0.95
    else:
        return 0.87


def f_reason_percentiles_RPCT_G(x):
    if x["RRG_FACT"] < 0.9058:
        return 100.00
    elif x["RRG_FACT"] < 0.9150:
        return 95.00
    elif x["RRG_FACT"] < 0.9421:
        return 89.00
    elif x["RRG_FACT"] < 0.9494:
        return 83.00
    elif x["RRG_FACT"] < 0.9519:
        return 79.00
    elif x["RRG_FACT"] < 0.9556:
        return 75.00
    elif x["RRG_FACT"] < 0.9590:
        return 72.00
    elif x["RRG_FACT"] < 0.9593:
        return 70.00
    elif x["RRG_FACT"] < 0.9656:
        return 64.00
    elif x["RRG_FACT"] < 0.9676:
        return 61.00
    elif x["RRG_FACT"] < 0.9690:
        return 59.00
    elif x["RRG_FACT"] < 0.9714:
        return 57.00
    elif x["RRG_FACT"] < 0.9751:
        return 53.00
    elif x["RRG_FACT"] < 0.9815:
        return 52.00
    elif x["RRG_FACT"] < 0.9833:
        return 50.00
    elif x["RRG_FACT"] < 0.9850:
        return 48.00
    elif x["RRG_FACT"] < 0.9875:
        return 47.00
    elif x["RRG_FACT"] < 0.9909:
        return 44.00
    elif x["RRG_FACT"] < 0.9933:
        return 42.00
    elif x["RRG_FACT"] < 0.9975:
        return 41.00
    elif x["RRG_FACT"] < 0.9981:
        return 40.00
    elif x["RRG_FACT"] < 1.0010:
        return 39.00
    elif x["RRG_FACT"] < 1.0035:
        return 38.00
    elif x["RRG_FACT"] < 1.0058:
        return 36.00
    elif x["RRG_FACT"] < 1.0095:
        return 35.00
    elif x["RRG_FACT"] < 1.0124:
        return 34.00
    elif x["RRG_FACT"] < 1.0128:
        return 33.00
    elif x["RRG_FACT"] < 1.0160:
        return 32.00
    elif x["RRG_FACT"] < 1.0185:
        return 31.00
    elif x["RRG_FACT"] < 1.0206:
        return 30.00
    elif x["RRG_FACT"] < 1.0246:
        return 29.00
    elif x["RRG_FACT"] < 1.0252:
        return 28.00
    elif x["RRG_FACT"] < 1.0275:
        return 27.00
    elif x["RRG_FACT"] < 1.0336:
        return 26.00
    elif x["RRG_FACT"] < 1.0355:
        return 25.00
    elif x["RRG_FACT"] < 1.0406:
        return 24.00
    elif x["RRG_FACT"] < 1.0423:
        return 23.00
    elif x["RRG_FACT"] < 1.0486:
        return 22.00
    elif x["RRG_FACT"] < 1.0560:
        return 21.00
    elif x["RRG_FACT"] < 1.0580:
        return 20.00
    elif x["RRG_FACT"] < 1.0583:
        return 19.00
    elif x["RRG_FACT"] < 1.0710:
        return 18.00
    elif x["RRG_FACT"] < 1.0727:
        return 17.00
    elif x["RRG_FACT"] < 1.0877:
        return 15.00
    elif x["RRG_FACT"] < 1.0882:
        return 14.00
    elif x["RRG_FACT"] < 1.0969:
        return 13.00
    elif x["RRG_FACT"] < 1.1032:
        return 12.00
    elif x["RRG_FACT"] < 1.1080:
        return 11.00
    elif x["RRG_FACT"] < 1.1191:
        return 10.00
    elif x["RRG_FACT"] < 1.1380:
        return 9.00
    elif x["RRG_FACT"] < 1.1540:
        return 7.00
    elif x["RRG_FACT"] < 1.1690:
        return 6.00
    elif x["RRG_FACT"] < 1.1840:
        return 5.00
    elif x["RRG_FACT"] < 1.2140:
        return 4.00
    elif x["RRG_FACT"] < 1.2436:
        return 3.00
    elif x["RRG_FACT"] < 1.2875:
        return 2.00
    elif x["RRG_FACT"] < 1.3830:
        return 1.00
    elif x["RRG_FACT"] < 1.4010:
        return 0.49
    elif x["RRG_FACT"] < 1.4045:
        return 0.43
    elif x["RRG_FACT"] < 1.4349:
        return 0.38
    else:
        return 0.33


def f_reason_percentiles_RPCT_H(x):
    # Reason Percentile for Reason Code H = MOPhi
    # nugget-id: id1F8TLN9JWLU
    if x["MOPHI"] < 1:
        return 100.00
    elif x["MOPHI"] < 2:
        return 17.29
    elif x["MOPHI"] < 3:
        return 11.15
    elif x["MOPHI"] < 4:
        return 8.38
    elif x["MOPHI"] < 5:
        return 6.44
    elif x["MOPHI"] < 6:
        return 4.91
    elif x["MOPHI"] < 7:
        return 3.73
    elif x["MOPHI"] < 8:
        return 2.80
    elif x["MOPHI"] < 9:
        return 2.10
    else:
        return 1.56


def f_reason_percentiles_RPCT_U(x):
    # Reason Percentile for Reason Code U = AOP
    # nugget-id: id78SKR8E4QM
    if x["RRU_FACT"] < 0.9899:
        return 100.00
    elif x["RRU_FACT"] < 0.9965:
        return 85.00
    elif x["RRU_FACT"] < 1.0000:
        return 66.00
    elif x["RRU_FACT"] < 1.0025:
        return 55.00
    elif x["RRU_FACT"] < 1.0085:
        return 30.00
    elif x["RRU_FACT"] < 1.0242:
        return 23.00
    else:
        return 17.00


def f_reason_percentiles_RPCT_2(x):
    # Reason Percentile for Reason Code 2 = NOP
    # nugget-id: id3ZUSHX92RKZ
    if x["RR2_FACT"] < 0.9350:
        return 100.00
    elif x["RR2_FACT"] < 0.9380:
        return 93.00
    elif x["RR2_FACT"] < 0.9390:
        return 86.00
    elif x["RR2_FACT"] < 0.9480:
        return 79.00
    elif x["RR2_FACT"] < 0.9500:
        return 72.00
    elif x["RR2_FACT"] < 0.9770:
        return 67.00
    elif x["RR2_FACT"] < 0.9800:
        return 60.00
    elif x["RR2_FACT"] < 0.9920:
        return 53.00
    elif x["RR2_FACT"] < 1.0150:
        return 48.00
    elif x["RR2_FACT"] < 1.0320:
        return 42.00
    elif x["RR2_FACT"] < 1.0640:
        return 37.00
    elif x["RR2_FACT"] < 1.0700:
        return 31.00
    elif x["RR2_FACT"] < 1.0740:
        return 26.00
    elif x["RR2_FACT"] < 1.0770:
        return 22.00
    elif x["RR2_FACT"] < 1.0790:
        return 18.00
    elif x["RR2_FACT"] < 1.0810:
        return 15.00
    elif x["RR2_FACT"] < 1.0830:
        return 13.00
    elif x["RR2_FACT"] < 1.0850:
        return 10.00
    elif x["RR2_FACT"] < 1.0890:
        return 8.00
    elif x["RR2_FACT"] < 1.0930:
        return 7.00
    elif x["RR2_FACT"] < 1.0950:
        return 6.00
    elif x["RR2_FACT"] < 1.0970:
        return 5.00
    elif x["RR2_FACT"] < 1.0990:
        return 4.00
    else:
        return 3.00


def f_reason_percentiles_RPCT_3(x):
    # Reason Percentile for Reason Code 3 = DEL
    # nugget-id: id6TXTKGNAFTG
    if x["RR3_FACT"] < 1.0064:
        return 100.00
    elif x["RR3_FACT"] < 1.0286:
        return 48.00
    elif x["RR3_FACT"] < 1.0480:
        return 27.00
    elif x["RR3_FACT"] < 1.0712:
        return 23.00
    elif x["RR3_FACT"] < 1.0953:
        return 18.00
    elif x["RR3_FACT"] < 1.1195:
        return 16.00
    elif x["RR3_FACT"] < 1.1297:
        return 10.00
    elif x["RR3_FACT"] < 1.1547:
        return 3.00
    else:
        return 2.00


def f_reason_percentiles_RPCT_5(x):
    # Reason Percentile for Reason Code 5 = AWOAO
    # nugget-id: id1IGRVJ4M6QL
    if x["NOPA"] < 1:
        return 100.00
    elif x["RR5_FACT"] < 0.8900:
        return 100.00
    elif x["RR5_FACT"] < 0.9010:
        return 92.00
    elif x["RR5_FACT"] < 0.9090:
        return 86.00
    elif x["RR5_FACT"] < 0.9130:
        return 81.00
    elif x["RR5_FACT"] < 0.9180:
        return 76.00
    elif x["RR5_FACT"] < 0.9330:
        return 71.00
    elif x["RR5_FACT"] < 0.9720:
        return 66.00
    elif x["RR5_FACT"] < 0.9890:
        return 62.00
    elif x["RR5_FACT"] < 1.0050:
        return 57.00
    elif x["RR5_FACT"] < 1.0070:
        return 53.00
    elif x["RR5_FACT"] < 1.0200:
        return 48.00
    elif x["RR5_FACT"] < 1.0320:
        return 44.00
    elif x["RR5_FACT"] < 1.0370:
        return 41.00
    elif x["RR5_FACT"] < 1.0420:
        return 38.00
    elif x["RR5_FACT"] < 1.0470:
        return 35.00
    elif x["RR5_FACT"] < 1.0510:
        return 32.00
    elif x["RR5_FACT"] < 1.0550:
        return 29.00
    elif x["RR5_FACT"] < 1.0600:
        return 26.00
    elif x["RR5_FACT"] < 1.0650:
        return 24.00
    elif x["RR5_FACT"] < 1.0740:
        return 22.00
    elif x["RR5_FACT"] < 1.0820:
        return 20.00
    elif x["RR5_FACT"] < 1.0900:
        return 18.00
    elif x["RR5_FACT"] < 1.0990:
        return 16.00
    elif x["RR5_FACT"] < 1.1070:
        return 15.00
    elif x["RR5_FACT"] < 1.1150:
        return 13.00
    elif x["RR5_FACT"] < 1.1240:
        return 12.00
    elif x["RR5_FACT"] < 1.1330:
        return 11.00
    elif x["RR5_FACT"] < 1.2180:
        return 10.00
    else:
        return 9.00


def f_reason_percentiles_RPCT_7(x):
    # Reason Percentile for Reason Code 7 = AVGMAO
    # nugget-id: id3EUS9I25JM6
    if x["RR7_FACT"] < 0.9000:
        return 100.00
    elif x["RR7_FACT"] < 0.9010:
        return 98.00
    elif x["RR7_FACT"] < 0.9020:
        return 97.00
    elif x["RR7_FACT"] < 0.9030:
        return 96.00
    elif x["RR7_FACT"] < 0.9040:
        return 94.00
    elif x["RR7_FACT"] < 0.9050:
        return 92.00
    elif x["RR7_FACT"] < 0.9530:
        return 87.00
    elif x["RR7_FACT"] < 0.9670:
        return 80.00
    elif x["RR7_FACT"] < 0.9870:
        return 69.00
    elif x["RR7_FACT"] < 1.0090:
        return 54.00
    elif x["RR7_FACT"] < 1.0740:
        return 38.00
    elif x["RR7_FACT"] < 1.1020:
        return 25.00
    elif x["RR7_FACT"] < 1.1130:
        return 16.00
    elif x["RR7_FACT"] < 1.2140:
        return 10.00
    else:
        return 6.00


def f_reason_percentiles_RPCT_8(x):
    # Reason Percentile for Reason Code 8 = PORALHI
    # nugget-id: id6SNSDUHM5QZ
    if x["RR8_FACT"] < 0.9760:
        return 100.00
    elif x["RR8_FACT"] < 1.0060:
        return 48.00
    elif x["RR8_FACT"] < 1.0420:
        return 38.00
    elif x["RR8_FACT"] < 1.0640:
        return 31.00
    else:
        return 11.00


def f_reason_percentiles(df):
    # df["RRF_FACT"] = df.RLEV_FACT_U1.apply(lambda x: round(x * 10000)/10000)
    # nugget-id: id65XRVV3G5S3
    df["RRG_FACT"] = df.apply(lambda x: round(x["INQ24_FACT_V"] * x["IADIF_FACT_V"] * 10000)/10000, axis=1)
    # nugget-id: id6EGSSRLMH12
    df["RRU_FACT"] = df.IADIF_FACT_V.apply(lambda x: round(x * 10000)/10000)
    # nugget-id: id5QNSB1J52J4
    df["RR2_FACT"] = df.NOPA_FACT_V.apply(lambda x: round(x * 10000)/10000)
    # nugget-id: id44HS3L8MKPV

    df["RR3_FACT"] = df.apply(lambda x: x["DEL24_FACT_V"] * x["DDC_FACT_V"] * 10000, axis=1)
    df["RR3_FACT"] = df["RR3_FACT"].round() / 10000
    # df["RR3_FACT"] = df.apply(lambda x: round(x["DEL24_FACT_V"] * x["DDC_FACT_V"] *10000)/10000, axis=1)
    # nugget-id: id4DXT6SXETVY
    df["RR5_FACT"] = df.AWOAO_FACT_V.apply(lambda x: round(x * 10000)/10000)
    # nugget-id: id54XTIS17GLZ
    df["RR7_FACT"] = df.AVGMAO_FACT_V.apply(lambda x: round(x * 10000)/10000)
    # nugget-id: id88HSBJKNBEX
    df["RR8_FACT"] = df.PORAL50_FACT_V.apply(lambda x: round(x * 10000)/10000)
    # nugget-id: id8LWS1TY6KRU
    df["RPCT_A"] = df.apply(f_reason_percentiles_RPCT_A, axis=1)
    # nugget-id: id7AFS3LLFEKP
    df["RPCT_B"] = df.apply(f_reason_percentiles_RPCT_B, axis=1)

    df["RPCT_G"] = df.apply(f_reason_percentiles_RPCT_G, axis=1)
    # nugget-id: id7YBS2BX75TN
    df["RPCT_H"] = df.apply(f_reason_percentiles_RPCT_G, axis=1)
    # nugget-id: id1F8TLN9JWLU
    df["RPCT_H"] = df.apply(f_reason_percentiles_RPCT_H, axis=1)
    # Reason Percentile for Reason Code K = Bankrupt
    # nugget-id: id35RTCWRSCJU
    df["RPCT_K"] = df.NBANKRUPT.apply(lambda x: 100.00 if x < 1 else 5.00)

    df["RPCT_M"] = df.NTAXLIEN.apply(lambda x: 100.00 if x < 1 else 3.00)
    # nugget-id: id78SKR8E4QM
    df["RPCT_U"] = df.apply(f_reason_percentiles_RPCT_U, axis=1)
    # nugget-id: id3ZUSHX92RKZ
    df["RPCT_2"] = df.apply(f_reason_percentiles_RPCT_2, axis=1)
    # nugget-id: id6TXTKGNAFTG
    df["RPCT_3"] = df.apply(f_reason_percentiles_RPCT_3, axis=1)
    # nugget-id: id1IGRVJ4M6QL
    df["RPCT_5"] = df.apply(f_reason_percentiles_RPCT_5, axis=1)
    # nugget-id: id3EUS9I25JM6
    df["RPCT_7"] = df.apply(f_reason_percentiles_RPCT_7, axis=1)
    # nugget-id: id6SNSDUHM5QZ
    df["RPCT_8"] = df.apply(f_reason_percentiles_RPCT_8, axis=1)
    return df


def f_reason_ranks_RRA(x):
    a = 0
    if x["RPCT_A"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    return a + 1


def f_reason_ranks_RRB(x):
    a = 0
    if x["RPCT_B"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    return a + 1


def f_reason_ranks_RRC(x):
    a = 0
    if x["RPCT_C"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    return a + 1


def f_reason_ranks_RRF(x):
    a = 0
    if x["RPCT_F"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    return a + 1


def f_reason_ranks_RRG(x):
    a = 0
    if x["RPCT_G"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    return a + 1


def f_reason_ranks_RRH(x):
    a = 0
    if x["RPCT_H"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    return a + 1


def f_reason_ranks_RRK(x):
    a = 0
    if x["RPCT_K"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    return a + 1


def f_reason_ranks_RRM(x):
    a = 0
    if x["RPCT_M"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    return a + 1


def f_reason_ranks_RRU(x):
    a = 0
    if x["RPCT_U"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    return a + 1


def f_reason_ranks_RR2(x):
    a = 0
    if x["RPCT_2"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    return a + 1


def f_reason_ranks_RR3(x):
    a = 0
    if x["RPCT_3"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    return a + 1


def f_reason_ranks_RR5(x):
    a = 0
    if x["RPCT_5"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    return a + 1


def f_reason_ranks_RR7(x):
    a = 0
    if x["RPCT_7"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    return a + 1


def f_reason_ranks_RR8(x):
    a = 0
    if x["RPCT_8"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    return a + 1


def f_reason_ranks_RC1(x):
    if x["PFMV_LEVEL"] == "BD":
        return ""
    elif (x["RRA"] == 1) & (x["RPCT_A"] < 100):
        return "A"
    elif (x["RRB"] == 1) & (x["RPCT_B"] < 100):
        return "B"
    elif (x["RRG"] == 1) & (x["RPCT_G"] < 100):
        return "G"
    elif (x["RRH"] == 1) & (x["RPCT_H"] < 100):
        return "H"
    elif (x["RRK"] == 1) & (x["RPCT_K"] < 100):
        return "K"
    elif (x["RRM"] == 1) & (x["RPCT_M"] < 100):
        return "M"
    elif (x["RRU"] == 1) & (x["RPCT_U"] < 100):
        return "U"
    elif (x["RR2"] == 1) & (x["RPCT_2"] < 100):
        return "2"
    elif (x["RR3"] == 1) & (x["RPCT_3"] < 100):
        return "3"
    elif (x["RR5"] == 1) & (x["RPCT_5"] < 100):
        return "5"
    elif (x["RR7"] == 1) & (x["RPCT_7"] < 100):
        return "7"
    elif (x["RR8"] == 1) & (x["RPCT_8"] < 100):
        return "8"
    else:
        return ""


def f_reason_ranks_RC2(x):
    if x["PFMV_LEVEL"] == "BD":
        return ""
    elif x["RRA"] == 2 and x["RPCT_A"] < 100:
        return "A"
    elif x["RRB"] == 2 and x["RPCT_B"] < 100:
        return "B"
    elif x["RRG"] == 2 and x["RPCT_G"] < 100:
        return "G"
    elif x["RRH"] == 2 and x["RPCT_H"] < 100:
        return "H"
    elif x["RRK"] == 2 and x["RPCT_K"] < 100:
        return "K"
    elif x["RRM"] == 2 and x["RPCT_M"] < 100:
        return "M"
    elif x["RRU"] == 2 and x["RPCT_U"] < 100:
        return "U"
    elif x["RR2"] == 2 and x["RPCT_2"] < 100:
        return "2"
    elif x["RR3"] == 2 and x["RPCT_3"] < 100:
        return "3"
    elif x["RR5"] == 2 and x["RPCT_5"] < 100:
        return "5"
    elif x["RR7"] == 2 and x["RPCT_7"] < 100:
        return "7"
    elif x["RR8"] == 2 and x["RPCT_8"] < 100:
        return "8"
    else:
        return ""


def f_reason_ranks_RC3(x):
    if x["PFMV_LEVEL"] == "BD":
        return ""
    elif x["RRA"] == 3 and x["RPCT_A"] < 100:
        return "A"
    elif x["RRB"] == 3 and x["RPCT_B"] < 100:
        return "B"
    elif x["RRG"] == 3 and x["RPCT_G"] < 100:
        return "G"
    elif x["RRH"] == 3 and x["RPCT_H"] < 100:
        return "H"
    elif x["RRK"] == 3 and x["RPCT_K"] < 100:
        return "K"
    elif x["RRM"] == 3 and x["RPCT_M"] < 100:
        return "M"
    elif x["RRU"] == 3 and x["RPCT_U"] < 100:
        return "U"
    elif x["RR2"] == 3 and x["RPCT_2"] < 100:
        return "2"
    elif x["RR3"] == 3 and x["RPCT_3"] < 100:
        return "3"
    elif x["RR5"] == 3 and x["RPCT_5"] < 100:
        return "5"
    elif x["RR7"] == 3 and x["RPCT_7"] < 100:
        return "7"
    elif x["RR8"] == 3 and x["RPCT_8"] < 100:
        return "8"
    else:
        return ""


def f_reason_ranks_RC4(x):
    if x["PFMV_LEVEL"] == "BD":
        return ""
    elif x["RRA"] == 4 and x["RPCT_A"] < 100:
        return "A"
    elif x["RRB"] == 4 and x["RPCT_B"] < 100:
        return "B"
    elif x["RRG"] == 4 and x["RPCT_G"] < 100:
        return "G"
    elif x["RRH"] == 4 and x["RPCT_H"] < 100:
        return "H"
    elif x["RRK"] == 4 and x["RPCT_K"] < 100:
        return "K"
    elif x["RRM"] == 4 and x["RPCT_M"] < 100:
        return "M"
    elif x["RRU"] == 4 and x["RPCT_U"] < 100:
        return "U"
    elif x["RR2"] == 4 and x["RPCT_2"] < 100:
        return "2"
    elif x["RR3"] == 4 and x["RPCT_3"] < 100:
        return "3"
    elif x["RR5"] == 4 and x["RPCT_5"] < 100:
        return "5"
    elif x["RR7"] == 4 and x["RPCT_7"] < 100:
        return "7"
    elif x["RR8"] == 4 and x["RPCT_8"] < 100:
        return "8"
    else:
        return ""


def f_reason_ranks_RC5(x):
    if x["PFMV_LEVEL"] == "BD":
        return ""
    elif x["RRA"] == 5 and x["RPCT_A"] < 100:
        return "A"
    elif x["RRB"] == 5 and x["RPCT_B"] < 100:
        return "B"
    elif x["RRG"] == 5 and x["RPCT_G"] < 100:
        return "G"
    elif x["RRH"] == 5 and x["RPCT_H"] < 100:
        return "H"
    elif x["RRK"] == 5 and x["RPCT_K"] < 100:
        return "K"
    elif x["RRM"] == 5 and x["RPCT_M"] < 100:
        return "M"
    elif x["RRU"] == 5 and x["RPCT_U"] < 100:
        return "U"
    elif x["RR2"] == 5 and x["RPCT_2"] < 100:
        return "2"
    elif x["RR3"] == 5 and x["RPCT_3"] < 100:
        return "3"
    elif x["RR5"] == 5 and x["RPCT_5"] < 100:
        return "5"
    elif x["RR7"] == 5 and x["RPCT_7"] < 100:
        return "7"
    elif x["RR8"] == 5 and x["RPCT_8"] < 100:
        return "8"
    else:
        return ""


def f_reason_ranks(df):
    df['RPCT_A'] = df['RPCT_A'] + 0.0001
    df['RPCT_B'] = df['RPCT_B'] + 0.0002
    # df['RPCT_C'] = df['RPCT_C'] + 0.0003
    # df['RPCT_F'] = df['RPCT_F'] + 0.0004
    df['RPCT_G'] = df['RPCT_G'] + 0.0005
    df['RPCT_H'] = df['RPCT_H'] + 0.0006
    df['RPCT_K'] = df['RPCT_K'] + 0.0007
    df['RPCT_M'] = df['RPCT_M'] + 0.0008
    df['RPCT_U'] = df['RPCT_U'] + 0.0009
    df['RPCT_2'] = df['RPCT_2'] + 0.0010
    df['RPCT_3'] = df['RPCT_3'] + 0.0011
    df['RPCT_5'] = df['RPCT_5'] + 0.0012
    df['RPCT_7'] = df['RPCT_7'] + 0.0013
    df['RPCT_8'] = df['RPCT_8'] + 0.0014
    df["RRA"] = df.apply(f_reason_ranks_RRA, axis=1)
    df["RRB"] = df.apply(f_reason_ranks_RRB, axis=1)
    # df["RRC"] = df.apply(f_reason_ranks_RRC, axis=1)
    # df["RRF"] = df.apply(f_reason_ranks_RRF, axis=1)
    df["RRG"] = df.apply(f_reason_ranks_RRG, axis=1)
    df["RRH"] = df.apply(f_reason_ranks_RRH, axis=1)
    df["RRK"] = df.apply(f_reason_ranks_RRK, axis=1)
    df["RRM"] = df.apply(f_reason_ranks_RRM, axis=1)
    df["RRU"] = df.apply(f_reason_ranks_RRU, axis=1)
    df["RR2"] = df.apply(f_reason_ranks_RR2, axis=1)
    df["RR3"] = df.apply(f_reason_ranks_RR3, axis=1)
    df["RR5"] = df.apply(f_reason_ranks_RR5, axis=1)
    df["RR7"] = df.apply(f_reason_ranks_RR7, axis=1)
    df["RR8"] = df.apply(f_reason_ranks_RR8, axis=1)
    df["RC1"] = df.apply(f_reason_ranks_RC1, axis=1)
    df["RC2"] = df.apply(f_reason_ranks_RC2, axis=1)
    df["RC3"] = df.apply(f_reason_ranks_RC3, axis=1)
    df["RC4"] = df.apply(f_reason_ranks_RC4, axis=1)
    df["RC5"] = df.apply(f_reason_ranks_RC5, axis=1)
    df['Reasons'] = (df['RC1'].astype(str) + df['RC2'].astype(str) +
                     df['RC3'].astype(str) + df['RC4'].astype(str) +
                     df['RC5'].astype(str))
    return df


def f_model_v_filters(df):
    # nugget-id: id631STGQ3C3Y
    incl_cols = ["TRAN_ID", "TimeStamp", "CallingAppName", "GuidewireID", "GuidewireAccountNumber",
                 "PolicyNumber", "PolicySuffix", "GeneratedNumber",
                 "WritingCo", "PolEffDt", "PolAppDt", "Leverage", "DPR24m",
                 "ProviderStartDateTs", "Model", "PFMV_SCORE",
                 "PFMV_LEVEL", "RC5", "Reasons"]
    df = df[incl_cols]
    # nugget-id: id5S7TNEHHLIZ
    df.drop(["Leverage", "DPR24m"], axis=1, inplace=True)
    df.rename(columns={"PFMV_LEVEL": "Level"}, inplace=True)
    # nugget-id: id18QSJ6I1QTE
    df["PFMScore"] = df["PFMV_SCORE"].astype(str)
    # nugget-id: id5YDSKW3CE9V
    df.drop(["PFMV_SCORE", "RC5"], axis=1, inplace=True)
    return df


def pfm_model_v(df):
    # Subset model V
    df_model_V = df[df["Model"] == "V"]
    # nugget-id: id8HCTCIFZLID
    df_model_V_post = f_v_factors(df_model_V)
    # nugget-id: idCVSG2V9PPP
    df_add_V_vec = f_add_V_Factors(df_model_V_post)
    # nugget-id: id1Q8S7YDFDZB
    df_add_V_vec["SCALED_SCORE_PRE"] = df_add_V_vec.apply(f_scaled_score_pre, axis=1)
    df_add_V_vec["SCALED_SCORE"] = df_add_V_vec.SCALED_SCORE_PRE.apply(f_scale_score_scaled)
    df_add_V_vec.drop(["SCALED_SCORE_PRE"], axis=1, inplace=True)
    df_add_V_vec.rename(columns={"SCALED_SCORE": "PFMV_SCORE"}, inplace=True)
    # PFMV_Level
    # nugget-id: id6V6SJYUE6UW
    df_add_V_vec["PFMV_LEVEL"] = df_add_V_vec.apply(f_PFMV_LEVEL, axis=1)
    # Reason Percentiles
    # nugget-id: id3T7SW9NMWCM
    df_reas_perc = f_reason_percentiles(df_add_V_vec)
    # Reason Ranks
    # nugget-id: id1ITRS2XCY9G
    df_reas_ranks = f_reason_ranks(df_reas_perc)
    # Post reasoning filters
    # nugget-id: id631STGQ3C3Y to id5YDSKW3CE9V
    df_V_Final = f_model_v_filters(df_reas_ranks)
    return df_V_Final
