##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Prabakar Subramani
# Creation Date          : 28MAR2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_modelling.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Contains functions to appropriate model to
#                          score the data point.
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################


import pandas as pd

from gw_pfm_539_model_g import pfm_model_g
from gw_pfm_539_model_k_to_p import pfm_model_k_to_p
from gw_pfm_539_model_u_to_v import pfm_model_u_to_v


def pfm_modelling(CIS_Hits, pkl_path, pkl_file_name):

    df_model_G = CIS_Hits[(((CIS_Hits["Model"] >= "A") & (CIS_Hits["Model"] <= "J")) | ((CIS_Hits["Model"] >= "Q") & (CIS_Hits["Model"] <= "T")))]

    df_model_K_to_P = CIS_Hits[((CIS_Hits["Model"] >= "K") & (CIS_Hits["Model"] <= "P"))]

    df_model_U_to_V = CIS_Hits[((CIS_Hits["Model"] >= "U") & (CIS_Hits["Model"] <= "W"))]

    df_all_models = pd.DataFrame()

    if df_model_G.index.values.size > 0:
        df_model_G = pfm_model_g(df_model_G)
        df_all_models = pd.concat([df_all_models, df_model_G],
                                  ignore_index=True)
    if df_model_K_to_P.index.values.size > 0:
        df_model_K_to_P = pfm_model_k_to_p(df_model_K_to_P, pkl_path, pkl_file_name)
        df_all_models = pd.concat([df_all_models, df_model_K_to_P],
                                  ignore_index=True)
    if df_model_U_to_V.index.values.size > 0:
        df_model_U_to_V = pfm_model_u_to_v(df_model_U_to_V)
        df_all_models = pd.concat([df_all_models, df_model_U_to_V],
                                  ignore_index=True)
    return df_all_models
