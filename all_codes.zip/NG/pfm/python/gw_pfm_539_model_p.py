##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Shanmugaraja Dakshinamoorthy,,
#                          Prabakar Subramani
# Creation Date          : 08FEB2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_model_p.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Model P
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################

# ------------------------------------------------------------------------


import re

import numpy as np
import pandas as pd

from ds_functions import load_pickle
from gw_pfm_539_ds_functions import cat_encoding_scoring
from gw_pfm_539_read_model_data import read_model_data


def model_P_fill_empty_cells_with_0(dataframe, list_of_columns):
    # Replace Blanks with 0
    for column in list_of_columns:
        dataframe[column] = dataframe[column].replace(r"\s+",
                                                      np.nan, regex=True)
        dataframe[column] = dataframe[column].fillna(0)
    return dataframe


def model_P_recode_empty_cells(dataframe, list_of_columns):
    # Replace Blanks with negative one
    for column in list_of_columns:
        dataframe[column] = dataframe[column].replace(r"\s+",
                                                      np.nan, regex=True)
        dataframe[column] = dataframe[column].fillna(-1)
    return dataframe


def subtraction(dataframe, x, y, z):
    dataframe[x] = dataframe[y] - dataframe[z]
    return dataframe


def model_P_sum111(dataframe, a, b, c, d):
    dataframe[a] = dataframe[b] + dataframe[c] + dataframe[d]
    return dataframe


def model_P_sum123(dataframe, a, b, c, d):
    dataframe[a] = (dataframe[b]*1) + (dataframe[c]*2) + (dataframe[d]*3)
    return dataframe


def aopratio(row):
    if row["nopa"] > 0:
        val = row["aop24m"] / row["nopa"]
    else:
        val = -1
    return val


def dprflag(row):
        if ((row["State"] > "IN") & (row["nbankrupt"] >= row["ndpr"])):
            val = 0
        elif ((row["ndpr"] > 0) & (row["mrecdpr"] >= 0) & (row["mrecdpr"] < 84)):
            val = 1
        else:
            val = 0
        return val


def collflag(row):
    if (row["colldoll"] > 0):
        val = 1
    else:
        val = 0
    return val


def mopflag(row):
    if (row["mophi"] > 0):
        val = 1
    else:
        val = 0
    return val


def apdflag(row):
    if (row["apd"] > 130):
        val = 1
    else:
        val = 0
    return val


def function__derogs(row):
    if (((row["dprflag"] + row["collflag"] + row["mopflag"] +
          row["apdflag"]) == 0) & (row["apd"] > 0)):
        val = 0.5
    else:
        val = (row["dprflag"] + row["collflag"] + row["mopflag"] + row["apdflag"])
    return val


def Rlev_calc(row):
    if (row["rlimit"] <= 0):
        val = -1
    elif ((row["rbal"] > 0) & (row["rbal"] / row["rlimit"] < 0.01)):
        val = 0.01
    else:
        val = int((row["rbal"] / row["rlimit"])*100)/100
    return val


def arlim(row):
    if (row["nopra"] > 0):
        val = row["rlimit"]/row["nopra"]
    else:
        val = -1
    return val


def submodel(row):
    if (row["nopa"] < 4):
        if ((row["age"] < 65) | (np.isnan(row["age"]))):
            val = "D"
        else:
            val = "C"
    elif(((row["age"] >= 35) & (row["age"] < 65)) | (np.isnan(row["age"]))):
        val = "A"
    elif(row["age"] < 35):
        val = "B"

    elif(row["age"] >= 65):
        val = "C"
    else:
        val = "Z"
    return val


def p_model_functions(df):
    df["aopratio"] = df.apply(aopratio, axis=1)
    df["dprflag"] = df.apply(dprflag, axis=1)
    df["collflag"] = df.apply(collflag, axis=1)
    df["mopflag"] = df.apply(mopflag, axis=1)
    df["apdflag"] = df.apply(apdflag, axis=1)
    df["derogs"] = df.apply(function__derogs, axis=1)
    df["Rlev_calc"] = df.apply(Rlev_calc, axis=1)
    df["arlim"] = df.apply(arlim, axis=1)
    df["submodel"] = df.apply(submodel, axis=1)
    return df


def model_P_func_aopratio_b(row):
    if row["aopratio"] < 0:
        val = 1
    elif row["aopratio"] < 0.1:
        val = 2
    elif row["aopratio"] < 0.2:
        val = 3
    elif row["aopratio"] < 0.3:
        val = 4
    elif row["aopratio"] < 0.4:
        val = 5
    elif row["aopratio"] < 0.5:
        val = 6
    elif row["aopratio"] < 0.6:
        val = 7
    elif row["aopratio"] < 0.7:
        val = 8
    elif row["aopratio"] < 0.8:
        val = 9
    elif row["aopratio"] < 0.9:
        val = 10
    elif row["aopratio"] < 1:
        val = 11
    else:
        val = 12
    return val


def model_P_func_del123_group(row):
    if row["delw24_123"] < 1:
        val = 0
    elif row["delw24_123"] < 5:
        val = row["delw24_123"]
    elif row["delw24_123"] < 8:
        val = 5
    elif row["delw24_123"] < 10:
        val = 8
    elif row["delw24_123"] < 11:
        val = 10
    elif row["delw24_123"] < 15:
        val = 11
    elif row["delw24_123"] < 25:
        val = 15
    elif row["delw24_123"] < 40:
        val = 25
    else:
        val = 40
    return val


def model_P_func_del111_group(row):
    if row["delw24_111"] < 1:
        val = 0
    elif row["delw24_111"] < 5:
        val = row["delw24_111"]
    elif row["delw24_111"] < 8:
        val = 5
    elif row["delw24_111"] < 10:
        val = 8
    elif row["delw24_111"] < 11:
        val = 10
    elif row["delw24_111"] < 15:
        val = 11
    elif row["delw24_111"] < 25:
        val = 15
    elif row["delw24_111"] < 40:
        val = 25
    else:
        val = 40
    return val


def model_P_derog(row):
        if row["derogs"] >= 1:
            val = 1.0
        elif row["delw24_123"] > 0:
            val = 0.0
        else:
            val = float(row["derogs"])
        return val


def model_P_derog2(row):
        if row["derogs"] >= 1:
            val = 1.0
        elif row["delw24_111"] > 0:
            val = 0.0
        else:
            val = float(row["derogs"])
        return val


def model_P_derog3(row):
        if row["del123_group"] >= 10:
            strings = [str(row["derog123_group"])[:3], "_",  str(row["del123_group"])]
            val = "".join(strings)
        else:
            strings = [str(row["derog123_group"])[:3], "_", "0",  str(row["del123_group"])]
            val = "".join(strings)
        return val


def model_P_derog4(row):
        if row["del111_group"] >= 10:
            strings = [str(row["derog111_group"])[:3], "_",  str(row["del111_group"])]
            val = "".join(strings)
        else:
            strings = [str(row["derog111_group"])[:3], "_", "0",  str(row["del111_group"])]
            val = "".join(strings)
        return val


def model_p_del123_derog_b(row):
    val = row["del_derog123_group"]
    if row["del_derog123_group"] == "0.0_00":
        val = 1
    elif row["del_derog123_group"] == "0.0_01":
        val = 3
    elif row["del_derog123_group"] == "0.0_02":
        val = 4
    elif row["del_derog123_group"] == "0.0_03":
        val = 5
    elif row["del_derog123_group"] == "0.0_04":
        val = 6
    elif row["del_derog123_group"] == "0.0_05":
        val = 7
    elif row["del_derog123_group"] == "0.0_08":
        val = 7
    elif row["del_derog123_group"] == "0.0_10":
        val = 8
    elif row["del_derog123_group"] == "0.0_11":
        val = 8
    elif row["del_derog123_group"] == "0.0_15":
        val = 8
    elif row["del_derog123_group"] == "0.0_25":
        val = 8
    elif row["del_derog123_group"] == "0.0_40":
        val = 8
    elif row["del_derog123_group"] == "0.5_00":
        val = 2
    elif row["del_derog123_group"] == "1.0_00":
        val = 9
    elif row["del_derog123_group"] == "1.0_01":
        val = 10
    elif row["del_derog123_group"] == "1.0_02":
        val = 11
    elif row["del_derog123_group"] == "1.0_03":
        val = 12
    elif row["del_derog123_group"] == "1.0_04":
        val = 13
    elif row["del_derog123_group"] == "1.0_05":
        val = 14
    elif row["del_derog123_group"] == "1.0_08":
        val = 15
    elif row["del_derog123_group"] == "1.0_10":
        val = 15
    elif row["del_derog123_group"] == "1.0_11":
        val = 16
    elif row["del_derog123_group"] == "1.0_15":
        val = 17
    elif row["del_derog123_group"] == "1.0_25":
        val = 18
    elif row["del_derog123_group"] == "1.0_40":
        val = 19
    return val


def model_p_del111_derog_b(row):
    val = row["del_derog111_group"]
    if row["del_derog111_group"] == "0.0_00":
        val = 1
    elif row["del_derog111_group"] == "0.0_01":
        val = 3
    elif row["del_derog111_group"] == "0.0_02":
        val = 4
    elif row["del_derog111_group"] == "0.0_03":
        val = 5
    elif row["del_derog111_group"] == "0.0_04":
        val = 6
    elif row["del_derog111_group"] == "0.0_05":
        val = 7
    elif row["del_derog111_group"] == "0.0_08":
        val = 7
    elif row["del_derog111_group"] == "0.0_10":
        val = 8
    elif row["del_derog111_group"] == "0.0_11":
        val = 8
    elif row["del_derog111_group"] == "0.0_15":
        val = 8
    elif row["del_derog111_group"] == "0.0_25":
        val = 8
    elif row["del_derog111_group"] == "0.0_40":
        val = 8
    elif row["del_derog111_group"] == "0.5_00":
        val = 2
    elif row["del_derog111_group"] == "1.0_00":
        val = 9
    elif row["del_derog111_group"] == "1.0_01":
        val = 10
    elif row["del_derog111_group"] == "1.0_02":
        val = 11
    elif row["del_derog111_group"] == "1.0_03":
        val = 12
    elif row["del_derog111_group"] == "1.0_04":
        val = 13
    elif row["del_derog111_group"] == "1.0_05":
        val = 14
    elif row["del_derog111_group"] == "1.0_08":
        val = 15
    elif row["del_derog111_group"] == "1.0_10":
        val = 15
    elif row["del_derog111_group"] == "1.0_11":
        val = 16
    elif row["del_derog111_group"] == "1.0_15":
        val = 17
    elif row["del_derog111_group"] == "1.0_25":
        val = 18
    elif row["del_derog111_group"] == "1.0_40":
        val = 19
    return val


def model_p_delw84_123_b(row):
    if row["delw84_123"] < 1:
        val = 1
    elif row["delw84_123"] < 4:
        val = 2
    elif row["delw84_123"] < 7:
        val = 3
    elif row["delw84_123"] < 10:
        val = 4
    elif row["delw84_123"] < 15:
        val = 5
    elif row["delw84_123"] < 20:
        val = 6
    elif row["delw84_123"] < 30:
        val = 7
    elif row["delw84_123"] < 40:
        val = 8
    elif row["delw84_123"] < 60:
        val = 9
    elif row["delw84_123"] < 80:
        val = 10
    elif row["delw84_123"] < 100:
        val = 11
    elif row["delw84_123"] < 125:
        val = 12
    else:
        val = 13
    return val


def model_p_delw84_111_b(row):
    if row["delw84_123"] < 1:
        val = 1
    elif row["delw84_123"] < 4:
        val = 2
    elif row["delw84_111"] < 7:
        val = 3
    elif row["delw84_111"] < 10:
        val = 4
    elif row["delw84_111"] < 15:
        val = 5
    elif row["delw84_111"] < 20:
        val = 6
    elif row["delw84_111"] < 30:
        val = 7
    elif row["delw84_111"] < 40:
        val = 8
    elif row["delw84_111"] < 60:
        val = 9
    elif row["delw84_111"] < 80:
        val = 10
    elif row["delw84_111"] < 100:
        val = 11
    elif row["delw84_111"] < 125:
        val = 12
    else:
        val = 13
    return val


def model_p_delw24_123_b(row):
    if row["delw24_123"] < 1:
        val = 1
    elif row["delw24_123"] < 4:
        val = 2
    elif row["delw24_123"] < 7:
        val = 3
    elif row["delw24_123"] < 10:
        val = 4
    elif row["delw24_123"] < 15:
        val = 5
    elif row["delw24_123"] < 20:
        val = 6
    elif row["delw24_123"] < 30:
        val = 7
    elif row["delw24_123"] < 40:
        val = 8
    elif row["delw24_123"] < 60:
        val = 9
    elif row["delw24_123"] < 80:
        val = 10
    elif row["delw24_123"] < 100:
        val = 11
    elif row["delw24_123"] < 125:
        val = 12
    else:
        val = 13
    return val


def model_p_delw24_111_b(row):
    if row["delw24_111"] < 1:
        val = 1
    elif row["delw24_111"] < 4:
        val = 2
    elif row["delw24_111"] < 7:
        val = 3
    elif row["delw24_111"] < 10:
        val = 4
    elif row["delw24_111"] < 15:
        val = 5
    elif row["delw24_111"] < 20:
        val = 6
    elif row["delw24_111"] < 30:
        val = 7
    elif row["delw24_111"] < 40:
        val = 8
    elif row["delw24_111"] < 60:
        val = 9
    elif row["delw24_111"] < 80:
        val = 10
    elif row["delw24_111"] < 100:
        val = 11
    elif row["delw24_111"] < 125:
        val = 12
    else:
        val = 13
    return val


def model_p_delwdif123_b(row):
    if row["delwdif_123"] < 1:
        val = 1
    elif row["delwdif_123"] < 10:
        val = row["delwdif_123"]+1
    elif row["delwdif_123"] < 12:
        val = 11
    elif row["delwdif_123"] < 15:
        val = 12
    elif row["delwdif_123"] < 18:
        val = 13
    elif row["delwdif_123"] < 21:
        val = 14
    elif row["delwdif_123"] < 25:
        val = 15
    elif row["delwdif_123"] < 30:
        val = 16
    elif row["delwdif_123"] < 50:
        val = 17
    elif row["delwdif_123"] < 70:
        val = 18
    else:
        val = 19
    return val


def model_p_delwdif111_b(row):
    if row["delwdif_111"] < 1:
        val = 1
    elif row["delwdif_111"] < 10:
        val = row["delwdif_111"]+1
    elif row["delwdif_111"] < 12:
        val = 11
    elif row["delwdif_111"] < 15:
        val = 12
    elif row["delwdif_111"] < 18:
        val = 13
    elif row["delwdif_111"] < 21:
        val = 14
    elif row["delwdif_111"] < 25:
        val = 15
    elif row["delwdif_111"] < 30:
        val = 16
    elif row["delwdif_111"] < 50:
        val = 17
    elif row["delwdif_111"] < 70:
        val = 18
    else:
        val = 19
    return val


def model_p_derogflags_b(row):
    if row["derogs"] == 0:
        val = 1
    elif row["derogs"] < 1:
        val = 2
    elif row["derogs"] < 2:
        val = 3
    else:
        val = 4
    return val


def model_p_ia24diff_b(row):
    if row["iadif"] < 0:
        val = 1
    elif row["iadif"] < 10:
        val = row["iadif"] + 2
    elif row["iadif"] < 12:
        val = 12
    elif row["iadif"] < 15:
        val = 13
    else:
        val = 14
    return val


def model_p_inq6m2_b(row):

    if row["inq06m"] < 1:
        val = 1
    elif row["inq06m"] < 10:
        val = row["inq06m"] + 1
    else:
        val = 11
    return val


def model_p_inq24m2_b(row):
    if row["inq24m"] < 1:
        val = 1
    elif row["inq24m"] < 11:
        val = row["inq24m"] + 1
    elif row["inq24m"] < 13:
        val = 12
    elif row["inq24m"] < 15:
        val = 13
    elif row["inq24m"] < 17:
        val = 14
    elif row["inq24m"] < 20:
        val = 15
    elif row["inq24m"] < 25:
        val = 16
    else:
        val = 17
    return val


def model_p_inqdiff2_b(row):
    if row["inqdif"] < 1:
        val = 1
    elif row["inqdif"] < 8:
        val = row["inqdif"] + 1
    elif row["inqdif"] < 10:
        val = 9
    elif row["inqdif"] < 12:
        val = 10
    elif row["inqdif"] < 15:
        val = 11
    else:
        val = 12
    return val


def model_p_moldaop2_b(row):
    if row["moldaop"] < 0:
        val = 1
    elif row["moldaop"] < 12:
        val = 2
    elif row["moldaop"] < 24:
        val = 3
    elif row["moldaop"] < 36:
        val = 4
    elif row["moldaop"] < 60:
        val = 5
    elif row["moldaop"] < 96:
        val = 6
    elif row["moldaop"] < 120:
        val = 7
    elif row["moldaop"] < 144:
        val = 8
    elif row["moldaop"] < 156:
        val = 9
    elif row["moldaop"] < 192:
        val = 10
    elif row["moldaop"] < 300:
        val = 11
    elif row["moldaop"] < 360:
        val = 12
    else:
        val = 13
    return val


def model_p_moldraop2_b(row):
    if row["moldraop"] < 0:
        val = 1
    elif row["moldraop"] < 24:
        val = 2
    elif row["moldraop"] < 60:
        val = 3
    elif row["moldraop"] < 108:
        val = 4
    elif row["moldraop"] < 132:
        val = 5
    elif row["moldraop"] < 168:
        val = 6
    elif row["moldraop"] < 216:
        val = 7
    elif row["moldraop"] < 300:
        val = 8
    else:
        val = 9
    return val


def model_p_nopacct2_b(row):
    if row["nopa"] < 1:
        val = 1
    elif row["nopa"] < 18:
        val = row["nopa"]+1
    else:
        val = 19
    return val


def model_p_nopracct2_b(row):
    if row["nopra"] < 1:
        val = 1
    elif row["nopra"] < 18:
        val = row["nopra"]+1
    else:
        val = 19
    return val


def nopdiff2_b(x):
    if x < 1:
        val = 1
    elif x < 3:
        val = x + 1
    else:
        val = 4
    return val


def rlev_group(row):
    if row["Rlev_calc"] < 0:
        val = -1
    elif row["rbal"] == 0:
        val = 0
    elif row["Rlev_calc"] < 0.05:
        val = 1
    elif row["Rlev_calc"] < 0.18:
        val = 2
    elif row["Rlev_calc"] < 1:
        val = 3
    else:
        val = 4

    return val


def arlim_group(x):
    if x < 1:
        val = "-1"
    elif x == 0:
        val = "00000"
    elif x < 100:
        val = "00001"
    elif x < 1250:
        val = "00100"
    elif x < 2250:
        val = "01250"
    elif x < 3250:
        val = "02250"
    elif x < 6000:
        val = "03250"
    elif x < 10000:
        val = "06000"
    else:
        val = "10000"
    return val


def model_p_rlev_arlim_b(row):
    if row["rlev_arlim_group"] == "-1_-1":
        val = 1
    elif row["rlev_arlim_group"] == "-1_00000":
        val = 1
    elif row["rlev_arlim_group"] == "-1_00001":
        val = 1
    elif row["rlev_arlim_group"] == "-1_00100":
        val = 1
    elif row["rlev_arlim_group"] == "-1_01250":
        val = 1
    elif row["rlev_arlim_group"] == "-1_02250":
        val = 1
    elif row["rlev_arlim_group"] == "-1_03250":
        val = 1
    elif row["rlev_arlim_group"] == "-1_06000":
        val = 1
    elif row["rlev_arlim_group"] == "-1_10000":
        val = 1
    elif row["rlev_arlim_group"] == "0_-1":
        val = 1
    elif row["rlev_arlim_group"] == "0_00000":
        val = 1
    elif row["rlev_arlim_group"] == "0_00001":
        val = 2
    elif row["rlev_arlim_group"] == "0_00100":
        val = 3
    elif row["rlev_arlim_group"] == "0_01250":
        val = 3
    elif row["rlev_arlim_group"] == "0_02250":
        val = 3
    elif row["rlev_arlim_group"] == "0_03250":
        val = 3
    elif row["rlev_arlim_group"] == "0_06000":
        val = 3
    elif row["rlev_arlim_group"] == "0_10000":
        val = 3
    elif row["rlev_arlim_group"] == "1_-1":
        val = 1
    elif row["rlev_arlim_group"] == "1_00000":
        val = 1
    elif row["rlev_arlim_group"] == "1_00001":
        val = 2
    elif row["rlev_arlim_group"] == "1_00100":
        val = 4
    elif row["rlev_arlim_group"] == "1_01250":
        val = 5
    elif row["rlev_arlim_group"] == "1_02250":
        val = 6
    elif row["rlev_arlim_group"] == "1_03250":
        val = 7
    elif row["rlev_arlim_group"] == "1_06000":
        val = 8
    elif row["rlev_arlim_group"] == "1_10000":
        val = 9
    elif row["rlev_arlim_group"] == "2_-1":
        val = 1
    elif row["rlev_arlim_group"] == "2_00000":
        val = 1
    elif row["rlev_arlim_group"] == "2_00001":
        val = 2
    elif row["rlev_arlim_group"] == "2_00100":
        val = 4
    elif row["rlev_arlim_group"] == "2_01250":
        val = 5
    elif row["rlev_arlim_group"] == "2_02250":
        val = 10
    elif row["rlev_arlim_group"] == "2_03250":
        val = 11
    elif row["rlev_arlim_group"] == "2_06000":
        val = 12
    elif row["rlev_arlim_group"] == "2_10000":
        val = 13
    elif row["rlev_arlim_group"] == "3_-1":
        val = 1
    elif row["rlev_arlim_group"] == "3_00000":
        val = 1
    elif row["rlev_arlim_group"] == "3_00001":
        val = 2
    elif row["rlev_arlim_group"] == "3_00100":
        val = 14
    elif row["rlev_arlim_group"] == "3_01250":
        val = 15
    elif row["rlev_arlim_group"] == "3_02250":
        val = 16
    elif row["rlev_arlim_group"] == "3_03250":
        val = 17
    elif row["rlev_arlim_group"] == "3_06000":
        val = 18
    elif row["rlev_arlim_group"] == "3_10000":
        val = 19
    elif row["rlev_arlim_group"] == "4_-1":
        val = 1
    elif row["rlev_arlim_group"] == "4_00000":
        val = 1
    elif row["rlev_arlim_group"] == "4_00001":
        val = 2
    elif row["rlev_arlim_group"] == "4_00100":
        val = 20
    elif row["rlev_arlim_group"] == "4_01250":
        val = 20
    elif row["rlev_arlim_group"] == "4_02250":
        val = 20
    elif row["rlev_arlim_group"] == "4_03250":
        val = 20
    elif row["rlev_arlim_group"] == "4_06000":
        val = 20
    elif row["rlev_arlim_group"] == "4_10000":
        val = 20
    return val


def rlev_b(row):
    if (row["Rlev_calc"] < 0):
        val = 1
    elif (row["rbal"] == 0):
        val = 2
    elif (row["Rlev_calc"] < 0.05):
        val = 3
    elif (row["Rlev_calc"] < 0.18):
        val = 4
    elif (row["Rlev_calc"] < 0.25):
        val = 5
    elif (row["Rlev_calc"] < 0.35):
        val = 6
    elif (row["Rlev_calc"] < 0.5):
        val = 7
    elif (row["Rlev_calc"] < 0.75):
        val = 8
    elif (row["Rlev_calc"] < 1):
        val = 9
    elif (row["Rlev_calc"] == 1):
        val = 10
    else:
        val = 11
    return val


def model_p_f_rename(df):
    # drops the specified columns from the dataframe df
    # Renames the specified columns with the specified new names

    df.drop(labels=["del123_derog_b", "del111_derog_b",
                    "rlev_arlim_b"], axis=1, inplace=True)
    df.rename(columns={"del123_derog_b_integer": "del123_derog_b",
                       "del111_derog_b_integer": "del111_derog_b",
                       "drlev_arlim_b_integer": "rlev_arlim_b"},
              inplace=True)
    return df


def model_p_preptoscore(df):
    df.rename(columns={"delw84_123": "del84m2",
                       "aop24m2_b": "aop24_b",
                       "aopdiff2_b": "aopdif_b",
                       "aopratio_b": "aoprat_b",
                       "delw84_123_b": "delw84_b",
                       "delwdif123_b": "delwdif_b",
                       "derogflags_b": "derogs_b",
                       "ia24diff_b": "iadif_b",
                       "inq6m2_b": "inq06_b",
                       "inq24m2_b": "inq24_b",
                       "inqdiff2_b": "inqdif_b",
                       "moldaop2_b": "molda_b",
                       "moldraop2_b": "moldra_b",
                       "nopacct2_b": "nopa_b",
                       "nopracct2_b": "nopra_b",
                       "nopdiff2_b": "nopdif_b",
                       "del123_derog_b": "del_derog_b"}, inplace=True)

    dummy_vars_dict = {"aop24_b": np.arange(1, 13), "aopdif_b": np.arange(1, 5), "aoprat_b": np.arange(1, 13),
                       "del_derog_b": np.arange(1, 20), "delw84_b": np.arange(1, 14), "delwdif_b": np.arange(1, 20),
                       "derogs_b": np.arange(1, 5), "iadif_b": np.arange(1, 15), "inq06_b": np.arange(1, 12),
                       "inq24_b": np.arange(1, 18), "inqdif_b": np.arange(1, 13), "molda_b": np.arange(1, 14),
                       "moldra_b": np.arange(1, 10), "nopa_b": np.arange(1, 20), "nopdif_b": np.arange(1, 5),
                       "nopra_b": np.arange(1, 20), "rlev_arlim_b": np.arange(1, 21)}

    appended_df, dummy_cols_list = cat_encoding_scoring(
        dummy_vars_dict, df, drop_first=False)

    cols_to_drop = ["mrecdel", "aop06m", "aop24m", "rlimit", "moldaop", "del30pd24m", "nopa", "rbal", "del90pd24m",
                    "del30d84m", "inq06m", "del60pd24m", "inq24m", "del60d84m", "del90d84m",
                    "del30d24m", "del60d24m", "delw24_123", "delw24_111", "del84m2", "delw84_111", "delwdif_123",
                    "delwdif_111", "inqdif", "nopdif", "aopdif", "iadif", "aopratio", "dprflag", "collflag", "mopflag",
                    "apdflag", "derogs", "Rlev_calc", "arlim", "aop24_b", "aopdif_b", "aoprat_b", "del123_group",
                    "del111_group", "derog123_group", "derog111_group", "del_derog123_group", "del_derog111_group",
                    "delw84_b", "delw84_111_b", "delw24_123_b", "delw24_111_b", "delwdif_b", "delwdif111_b", "derogs_b",
                    "iadif_b", "inq06_b", "inq24_b", "inqdif_b", "molda_b", "moldra_b", "nopa_b", "nopra_b", "nopdif_b",
                    "rlev_group", "arlim_group", "rlev_arlim_group", "rlev_b", "del_derog_b", "del111_derog_b"]
    df = appended_df.drop(labels=cols_to_drop, axis=1)
    return df


def model_P_sub_RC_Rank_sort_orders(data, inp_col, all_cols_list,
                                    tar_col, init_val, if_val,
                                    else_val):
    data.loc[:, tar_col] = init_val

    if else_val == 0:
        for col in all_cols_list:
            data.loc[:, tar_col] = np.where(data[inp_col] > data[col],
                                     data[tar_col] + if_val,
                                     data[tar_col])
    else:
        for col in all_cols_list:
            data.loc[:, tar_col] = np.where(data[inp_col] > data[col],
                                     data[tar_col] + if_val,
                                     data[tar_col])
            data.loc[:, tar_col] = np.where(data[inp_col] < data[col],
                                     data[tar_col] + else_val,
                                     data[tar_col])
    return data


def model_P_sub_RC_Rank_Ranks(data, inp_col, PredRC_cols_dict, tar_col,
                              init_val, if_val, else_val):
    data.loc[:, tar_col] = init_val

    if else_val == 0:
        for col in PredRC_cols_dict:
            data.loc[:, tar_col] = np.where(data[inp_col] < data[PredRC_cols_dict[col]["sort"]],
                                     data[tar_col] + if_val,
                                     data[tar_col])
    else:
        for col in PredRC_cols_dict:
            data.loc[:, tar_col] = np.where(data[inp_col] < data[PredRC_cols_dict[col]["sort"]],
                                     data[tar_col] + if_val,
                                     data[tar_col])
            data.loc[:, tar_col] = np.where(data[inp_col] > data[PredRC_cols_dict[col]["sort"]],
                                     data[tar_col] + else_val,
                                     data[tar_col])
    return data


def model_P_sub_RC_Rank_RC(data, all_cols_list, PredRC_cols_dict,
                           target_col, init_val, val_1, val_2):
    data.loc[:, target_col] = init_val
    data.loc[:, target_col] = np.where(data["Level"] == "BD", data[target_col], "")

    for col in all_cols_list:
        if not col == "PredRC_Blank":
            data.loc[:, target_col] = np.where((data[PredRC_cols_dict[col]["rank"]] == val_1) & (data[col] > val_2),
                                        PredRC_cols_dict[col]["code"],
                                        data[target_col])
    return data


def submodel_RC_rank(data):
    """
    Function for nodes in super node "Sub RC Rank" for respective
    regression model streams.
    """
    data.at[data["apd"] <= 0, "PredRC_A"] = 0
    data.at[data["colldoll"] <= 0, "PredRC_B"] = 0
    data.at[data["mophi"] <= 0, "PredRC_H"] = 0
    data.at[data["nbankrupt"] <= 0, "PredRC_K"] = 0
    data.at[data["ntaxlien"] <= 0, "PredRC_M"] = 0
    data.at[data["moldraop"] < 0, "PredRC_E"] = 0
    data.at[data["nopra"] == 0, "PredRC_2"] = 0
    data.at[data["rlev_arlim_b"] == 0, "PredRC_4"] = 0

    all_cols_list = ["PredRC_2", "PredRC_3", "PredRC_4", "PredRC_A",
                     "PredRC_B", "PredRC_C", "PredRC_E", "PredRC_G",
                     "PredRC_H", "PredRC_K", "PredRC_M", "PredRC_U",
                     "PredRC_Blank"]
    PredRC_cols_dict = {"PredRC_2": {"sort": "PRC2_sort",
                                     "rank": "PRC2_sort_rank",
                                     "code": "2", "init_val": 1.00012},
                        "PredRC_3": {"sort": "PRC3_sort",
                                     "rank": "PRC3_sort_rank",
                                     "code": "3", "init_val": 1.00011},
                        "PredRC_4": {"sort": "PRC4_sort",
                                     "rank": "PRC4_sort_rank",
                                     "code": "4", "init_val": 1.00010},
                        "PredRC_A": {"sort": "PRCA_sort",
                                     "rank": "PRCA_sort_rank",
                                     "code": "A", "init_val": 1.00009},
                        "PredRC_B": {"sort": "PRCB_sort",
                                     "rank": "PRCB_sort_rank",
                                     "code": "B", "init_val": 1.00008},
                        "PredRC_C": {"sort": "PRCC_sort",
                                     "rank": "PRCC_sort_rank",
                                     "code": "C", "init_val": 1.00007},
                        "PredRC_E": {"sort": "PRCE_sort",
                                     "rank": "PRCE_sort_rank",
                                     "code": "E", "init_val": 1.00006},
                        "PredRC_G": {"sort": "PRCG_sort",
                                     "rank": "PRCG_sort_rank",
                                     "code": "G", "init_val": 1.00005},
                        "PredRC_H": {"sort": "PRCH_sort",
                                     "rank": "PRCH_sort_rank",
                                     "code": "H", "init_val": 1.00004},
                        "PredRC_K": {"sort": "PRCK_sort",
                                     "rank": "PRCK_sort_rank",
                                     "code": "K", "init_val": 1.00003},
                        "PredRC_M": {"sort": "PRCM_sort",
                                     "rank": "PRCM_sort_rank",
                                     "code": "M", "init_val": 1.00002},
                        "PredRC_U": {"sort": "PRCU_sort",
                                     "rank": "PRCU_sort_rank",
                                     "code": "U", "init_val": 1.00001},
                        "PredRC_Blank": {"sort": "PRCBlank_sort",
                                         "rank": "PRCBlank_sort_rank",
                                         "code": "", "init_val": 1.00000}}

    for col in all_cols_list:
        inp_col = col
        tar_col = PredRC_cols_dict[col]["sort"]
        init_val = PredRC_cols_dict[col]["init_val"]
        if_val = 1
        else_val = 0
        data = model_P_sub_RC_Rank_sort_orders(data, inp_col, all_cols_list,
                                               tar_col, init_val, if_val,
                                               else_val)

    for col in all_cols_list:
        inp_col = PredRC_cols_dict[col]["sort"]
        tar_col = PredRC_cols_dict[col]["rank"]
        init_val = 1
        if_val = 1
        else_val = 0
        data = model_P_sub_RC_Rank_Ranks(data, inp_col, PredRC_cols_dict,
                                         tar_col, init_val, if_val, else_val)

    data = model_P_sub_RC_Rank_RC(data, all_cols_list, PredRC_cols_dict,
                                  target_col="RC1st", init_val="",
                                  val_1=1, val_2=0)
    data = model_P_sub_RC_Rank_RC(data, all_cols_list, PredRC_cols_dict,
                                  target_col="RC2nd", init_val="",
                                  val_1=2, val_2=0)
    data = model_P_sub_RC_Rank_RC(data, all_cols_list, PredRC_cols_dict,
                                  target_col="RC3rd", init_val="",
                                  val_1=3, val_2=0)
    data = model_P_sub_RC_Rank_RC(data, all_cols_list, PredRC_cols_dict,
                                  target_col="RC4th", init_val="",
                                  val_1=4, val_2=0)
    data = model_P_sub_RC_Rank_RC(data, all_cols_list, PredRC_cols_dict,
                                  target_col="RC5th", init_val="",
                                  val_1=5, val_2=0)

    data.loc[:, "Reasons"] = data.apply(lambda row: row[["RC1st", "RC2nd",
                                                  "RC3rd", "RC4th",
                                                  "RC5th"]].str.cat(sep=""),
                                 axis=1)

    data = data[["Level", "TRAN_ID", "TimeStamp", "CallingAppName", "GuidewireID",
                 "GuidewireAccountNumber", "PolicyNumber", "PolicySuffix",
                 "GeneratedNumber", "WritingCo", "PolEffDt", "PolAppDt",
                 "Leverage", "DPR24m", "raop24m", "ProviderStartDateTs",
                 "Model", "moldraop_adj", "nopra_adj", "rlev_arlim_adj",
                 "KtoP_adj", "Pscore", "RC5th", "Reasons"]]

    return data


def SubA_RC_drop_columns(df):
    df = df.drop(labels=["$L-RC_A", "$LP-RC_A", "$L-RC_H", "$LP-RC_H", "$L-RC_B",
                    "$LP-RC_B", "$L-RC_K", "$LP-RC_K", "$L-RC_M", "$LP-RC_M",
                    "$L-RC_3", "$LP-RC_3", "$L-RC_G", "$LP-RC_G", "$L-RC_U",
                    "$LP-RC_U", "$L-RC_Blank", "$LP-RC_Blank", "$L-RC_2",
                    "$LP-RC_2", "$L-RC_E", "$LP-RC_E", "$L-RC_4",
                    "$LP-RC_4"],
            axis=1)
    return df


def SubA_RC_zero_out_low_prob(x):
    pred_var1 = ["PredRC_A", "PredRC_H", "PredRC_B", "PredRC_K", "PredRC_M",
                 "PredRC_3", "PredRC_G", "PredRC_U", "PredRC_Blank",
                 "PredRC_2", "PredRC_E", "PredRC_4"]

    for i in range(len(pred_var1)):
        data.loc[:, pred_var1[i]] = np.where(x[pred_var1[i]] < 0.01, 0, x[pred_var1[i]])
    return x


def SubA_RC_PredRC_C(row):
    if row["nbankrupt"] + row["ntaxlien"] > 0:
        val = 0
    elif row["ndpr"] > 0:
        val = 0.99
    else:
        val = 0
    return val


def get_logistic_score(data, target, target_cat, model_name, nugg_id, pkl_obj_dict):
    model_data = read_model_data(model_name, nugg_id,
                                 pkl_obj_dict=pkl_obj_dict)

    model_data["weights"] = pd.to_numeric(model_data["beta"])

    constant = 0
    constant_index = []

    for index, row in model_data.iterrows():
        if (re.search(r"P0000001", row["predictorName"], re.I)):
            if (row["weights"] != 0) & (constant_index == []):
                constant = float(row["weights"])
                constant_index.append(index)
            else:
                constant_index.append(index)

    model_data.drop(constant_index, axis=0, inplace=True)
    model_data.drop(["df", "targetCategory"], axis=1, inplace=True)
    model_data.set_index("predictorName", inplace=True)

    param_names = model_data.index.values

    data.loc[:, target] = (np.dot(data[param_names].values, model_data["weights"].values) + constant)
    data.loc[:, target] = 1 / (1 + (1 / np.exp(data[target])))
    data.loc[:, target_cat] = data[target].apply(lambda x: 1 if x >= 0.5 else 0)

    return data


def model_P_Sub_RC(data, logit_list, logit_nugg_id, pkl_obj_dict):
    target_list = ["$LP-RC_A", "$LP-RC_H", "$LP-RC_B", "$LP-RC_K", "$LP-RC_M",
                   "$LP-RC_3", "$LP-RC_G", "$LP-RC_U", "$LP-RC_Blank",
                   "$LP-RC_2", "$LP-RC_E", "$LP-RC_4"]
    target_cat_list = ["$L-RC_A", "$L-RC_H", "$L-RC_B", "$L-RC_K",
                       "$L-RC_M", "$L-RC_3", "$L-RC_G", "$L-RC_U",
                       "$L-RC_Blank", "$L-RC_2", "$L-RC_E", "$L-RC_4"]
    pred_var = ["PredRC_A", "PredRC_H", "PredRC_B", "PredRC_K", "PredRC_M",
                "PredRC_3", "PredRC_G", "PredRC_U", "PredRC_Blank",
                "PredRC_2", "PredRC_E", "PredRC_4"]

    for i in range(len(logit_list)):

        model_name = logit_list[i]
        nugg_id = logit_nugg_id[i]
        target = target_list[i]
        target_cat = target_cat_list[i]
        data = get_logistic_score(data, target, target_cat,
                                  model_name, nugg_id, pkl_obj_dict)
        data.loc[:, pred_var[i]] = 1 - data[target]

    data.loc[:, "PredRC_C"] = data.apply(SubA_RC_PredRC_C, axis=1)

    data = SubA_RC_zero_out_low_prob(data)
    data = SubA_RC_drop_columns(data)
    return data


def model_P_APD_bin(value):
    if value == 0:
        return_value = 0
    elif value < 200:
        return_value = 1
    elif value >= 1300:
        return_value = 13
    else:
        return_value = int(value/100)
    return return_value


def model_P_Coll_bin(value):
    if value == 0:
        return_value = 0
    elif value < 100:
        return_value = 1
    elif value >= 3900:
        return_value = 40
    else:
        return_value = int(value) + 1
    return return_value


def model_P_Derog_Bins_Flags(data):
    """
    Function for nodes in super node "Derog Bins, Flags" for respective
    regression model streams.
    """
    data.loc[:, "APD_bin"] = data["apd"].apply(model_P_APD_bin)
    data.loc[:, "Coll_bin"] = data["colldoll"].apply(model_P_Coll_bin)
    data.loc[:, "MOPhi_bin"] = data["mophi"].apply(lambda x: 9 if x >= 8 else x + 1)
    data.loc[:, "Bankrupt_flag"] = data["nbankrupt"].apply(lambda x: 1 if x > 0 else 0)
    data.loc[:, "Taxlien_flag"] = data["ntaxlien"].apply(lambda x: 1 if x > 0 else 0)
    data.loc[:, "DPRother_flag"] = data.apply(lambda x: 1 if ((x["ndpr"] - x["nbankrupt"] - x["ntaxlien"]) > 0) else 0, axis=1)
    return data


def model_P_Level(p_score):
    """
    Function to execute condition in model P - Level
    """
    return_value = ""
    if p_score < 10:
        return_value = ""
    elif p_score < 56:
        return_value = "BD"
    elif p_score < 75:
        return_value = "BH"
    elif p_score < 88:
        return_value = "BL"
    elif p_score < 99:
        return_value = "BP"
    elif p_score < 109:
        return_value = "BT"
    elif p_score < 117:
        return_value = "BW"
    elif p_score < 124:
        return_value = "CD"
    elif p_score < 131:
        return_value = "CH"
    elif p_score < 138:
        return_value = "CL"
    elif p_score < 144:
        return_value = "CP"
    elif p_score < 150:
        return_value = "CT"
    elif p_score < 156:
        return_value = "CW"
    elif p_score < 158:
        return_value = "DD"
    elif p_score < 163:
        return_value = "DG"
    elif p_score < 169:
        return_value = "DJ"
    elif p_score < 175:
        return_value = "DN"
    elif p_score < 181:
        return_value = "DQ"
    elif p_score < 188:
        return_value = "DT"
    elif p_score < 195:
        return_value = "DW"
    elif p_score < 201:
        return_value = "ED"
    elif p_score < 208:
        return_value = "EG"
    elif p_score < 216:
        return_value = "EJ"
    elif p_score < 225:
        return_value = "EN"
    elif p_score < 234:
        return_value = "EQ"
    elif p_score < 243:
        return_value = "ET"
    elif p_score < 247:
        return_value = "EW"
    elif p_score < 260:
        return_value = "FD"
    elif p_score < 275:
        return_value = "FG"
    elif p_score < 291:
        return_value = "FJ"
    elif p_score < 303:
        return_value = "FN"
    elif p_score < 316:
        return_value = "FQ"
    elif p_score < 331:
        return_value = "FT"
    elif p_score < 348:
        return_value = "FW"
    elif p_score < 369:
        return_value = "GD"
    elif p_score < 382:
        return_value = "GH"
    elif p_score < 396:
        return_value = "GL"
    elif p_score < 410:
        return_value = "GP"
    elif p_score < 426:
        return_value = "GT"
    elif p_score < 446:
        return_value = "HD"
    elif p_score < 470:
        return_value = "HH"
    elif p_score < 503:
        return_value = "HL"
    elif p_score < 549:
        return_value = "HP"
    elif p_score < 641:
        return_value = "HT"
    elif p_score <= 999:
        return_value = "HW"
    else:
        return_value = ""
    return return_value


def model_P_reg_A_moldraop_adj(row):
    if ((row["moldra_b_1"] == 1) or (row["moldra_b_2"] == 1) or (row["moldra_b_3"] == 1)):
        return_value = 1.02999
    elif row["moldra_b_6"] == 1:
        return_value = 1.017365
    elif row["moldra_b_7"] == 1:
        return_value = 1.026804
    else:
        return_value = 1
    return return_value


def model_P_reg_A_k_to_p_adj(data):
    """
    Function for nodes in super node "K to P adj" for regression model A.
    """
    data.loc[:, "moldraop_adj"] = data.apply(model_P_reg_A_moldraop_adj, axis=1)
    data.loc[:, "nopra_adj"] = data["nopra_b_1"].apply(lambda x: 1.01867 if x == 1 else 1)
    data.loc[:, "rlev_arlim_adj"] = data["rlev_arlim_b_1"].apply(lambda x: 0.671942 if x == 1 else 1)
    data.loc[:, "KtoP_adj"] = (data["moldraop_adj"] * data["nopra_adj"] * data["rlev_arlim_adj"])
    return data


def model_P_reg_B_moldraop_adj(row):
    if ((row["moldra_b_1"] == 1) or (row["moldra_b_2"] == 1) or (row["moldra_b_3"] == 1)):
        return_value = 1.014199
    elif row["moldra_b_6"] == 1:
        return_value = 1.030928
    elif row["moldra_b_7"] == 1:
        return_value = 1.031992
    else:
        return_value = 1
    return return_value


def model_P_reg_B_nopra_adj(row):
    if row["nopra_b_1"] == 1:
        return_value = 1.06474
    elif row["nopra_b_2"] == 1:
        return_value = 1.06474
    elif row["nopra_b_3"] == 1:
        return_value = 1.06474
    elif row["nopra_b_4"] == 1:
        return_value = 1.06474
    else:
        return_value = 1
    return return_value


def model_P_reg_B_rlev_arlim_adj(row):
    if row["rlev_arlim_b_1"] == 1:
        return_value = 0.733229
    elif (row["rlev_arlim_b_3"] == 1) or (row["rlev_arlim_b_7"] == 1):
        return_value = 1.005348
    elif (row["rlev_arlim_b_8"] == 1) or (row["rlev_arlim_b_9"] == 1):
        return_value = 1.023965
    elif (row["rlev_arlim_b_12"] == 1) or (row["rlev_arlim_b_13"] == 1):
        return_value = 1.014024
    else:
        return_value = 1
    return return_value


def model_P_reg_B_k_to_p_adj(data):
    """
    Function for nodes in super node "K to P adj" for regression model B.
    """
    data.loc[:, "moldraop_adj"] = data.apply(model_P_reg_B_moldraop_adj, axis=1)
    data.loc[:, "nopra_adj"] = data.apply(model_P_reg_B_nopra_adj, axis=1)
    data.loc[:, "rlev_arlim_adj"] = data.apply(model_P_reg_B_rlev_arlim_adj, axis=1)
    data.loc[:, "KtoP_adj"] = (data["moldraop_adj"] * data["nopra_adj"] * data["rlev_arlim_adj"])
    return data


def model_P_reg_C_rlev_arlim_adj(row):
    if row["rlev_arlim_b_1"] == 1:
        return_value = 0.768091
    elif row["rlev_arlim_b_9"] == 1:
        return_value = 1.205198
    elif row["rlev_arlim_b_13"] == 1:
        return_value = 1.297496
    else:
        return_value = 1
    return return_value


def model_P_reg_C_k_to_p_adj(data):
    """
    Function for nodes in super node "K to P adj" for regression model C.
    """
    data.loc[:, "moldraop_adj"] = data["moldra_b_1"].apply(lambda x: 0.962488 if x == 1 else 1)
    data.loc[:, "nopra_adj"] = data["nopra_b_1"].apply(lambda x: 1.045169 if x == 0 else 1)
    data.loc[:, "rlev_arlim_adj"] = data.apply(model_P_reg_C_rlev_arlim_adj, axis=1)
    data.loc[:, "KtoP_adj"] = (data["moldraop_adj"] * data["nopra_adj"] * data["rlev_arlim_adj"])
    return data


def model_P_reg_D_nopra_adj(row):
    # Model P - Regression D - K to P Adj - nopra_adj
    if row["nopra_b_1"] == 1:
        return_value = 0.999001
    elif ((row["nopra_b_2"]) == 1 or (row["nopra_b_3"] == 1) or (row["nopra_b_4"] == 1)):
        return_value = 1.001001
    else:
        return_value = 1
    return return_value


def model_P_reg_D_rlev_arlim_adj(row):
    # Model P - Regression D - K to P Adj - rlev_arlim_adj
    if row["rlev_arlim_b_1"] == 1:
        return_value = 0.965251
    elif row["rlev_arlim_b_4"] == 1:
        return_value = 1.003009
    elif ((row["rlev_arlim_b_5"] == 1) or (row["rlev_arlim_b_5"] == 1)):
        return_value = 1.071811
    elif row["rlev_arlim_b_7"] == 1:
        return_value = 1.138952
    elif ((row["rlev_arlim_b_8"] == 1) or (row["rlev_arlim_b_9"] == 1)):
        return_value = 1.231527
    elif row["rlev_arlim_b_10"] == 1:
        return_value = 1.071811
    elif ((row["rlev_arlim_b_11"] == 1) or (row["rlev_arlim_b_12"] == 1) or (row["rlev_arlim_b_13"] == 1)):
        return_value = 1.123596
    elif row["rlev_arlim_b_14"] == 1:
        return_value = 1.005025
    elif ((row["rlev_arlim_b_15"] == 1) or (row["rlev_arlim_b_16"] == 1) or (row["rlev_arlim_b_17"] == 1) or (row["rlev_arlim_b_18"] == 1) or (row["rlev_arlim_b_19"] == 1)):
        return_value = 1.020408
    else:
        return_value = 1
    return return_value


def model_P_reg_D_k_to_p_adj(data):
    """
    Function for nodes in super node "K to P adj" for regression model D.
    """
    data.loc[:, "moldraop_adj"] = data["moldra_b_1"].apply(lambda x: 1.011411 if x == 1 else 1)
    data.loc[:, "nopra_adj"] = data.apply(model_P_reg_D_nopra_adj, axis=1)
    data.loc[:, "rlev_arlim_adj"] = data.apply(model_P_reg_D_rlev_arlim_adj, axis=1)
    data.loc[:, "KtoP_adj"] = (data["moldraop_adj"] * data["nopra_adj"] * data["rlev_arlim_adj"])
    return data


def get_linear_score(data, target, model_name, nugg_id, pkl_obj_dict):
    """
    Function to calculate the score from linear regression model. Model
    coefficients are read from the pickle object present in the pickle file
    path passed via argument.

    Arguments:
    data -------> Pandas DataFrame containing the columns which will chosen
                  as features (Predictors (or) Inputs).
    target -------> Column name where the predicted score will be saved
                    (Target (or) Output).
    model_name -------> Name of the model for which the model coefficients
                        are stored in the pickle object.
    nugg_id -------> Nugget ID of the node of the Regression model.
    pkl_obj_dict -------> Pickle object containing model coefficient.

    Return:
    data -------> Pandas DataFrame containing the orginal columns and also
                  the predicted linear score in the target column.
    """
    model_data = read_model_data(model_name, nugg_id,
                                 pkl_obj_dict=pkl_obj_dict)
    model_data["weights"] = pd.to_numeric(model_data["beta"])

    constant = 0
    constant_index = []
    for index, row in model_data.iterrows():
        if re.search(r"constant", row["parameterName"], re.I):
            constant_index.append(index)
            constant = float(row["weights"])
            break

    model_data.drop(constant_index, axis=0, inplace=True)
    model_data.drop(["df", "targetCategory"], axis=1, inplace=True)
    model_data.set_index("parameterName", inplace=True)
    param_names = model_data.index.values
    data.loc[:, target] = np.dot(data[param_names].values, model_data["weights"].values) + constant
    return data


def model_P_submodel(data, ln_score_target, model_name, nugg_id, pkl_obj_dict, constant_val, logit_list, logit_nugg_id):
    """
    Function for nodes in super node "K to P adj" for regression model B.
    """
    data = get_linear_score(data, target=ln_score_target,
                            model_name=model_name,
                            nugg_id=nugg_id,
                            pkl_obj_dict=pkl_obj_dict)

    if model_name == "Regression A":
        data = model_P_reg_A_k_to_p_adj(data)
    elif model_name == "Regression B":
        data = model_P_reg_B_k_to_p_adj(data)
    elif model_name == "Regression C":
        data = model_P_reg_C_k_to_p_adj(data)
    elif model_name == "Regression D":
        data = model_P_reg_D_k_to_p_adj(data)

    data.loc[:, "Constant"] = constant_val
    data.loc[:, "Pscore"] = (np.exp(data["LnScore"]) * data["KtoP_adj"] * data["Constant"] * 600)
    data.loc[:, "Pscore"] = (data["Pscore"] - 175).round()
    data.loc[:, "Pscore"] = np.where(data["Pscore"] < 10, 10, data["Pscore"])
    data.loc[:, "Pscore"] = np.where(data["Pscore"] > 999, 999, data["Pscore"])
    data.loc[:, "Level"] = data["Pscore"].apply(model_P_Level)

    data = model_P_Derog_Bins_Flags(data)
    data = model_P_Sub_RC(data, logit_list, logit_nugg_id, pkl_obj_dict)
    data = submodel_RC_rank(data)
    return data


def model_P_submodel_A(data, model_coeff_dict):
    logit_model_name_list = ["RC_A", "RC_H", "RC_B", "RC_K", "RC_M",  "RC_3",
                             "RC_G", "RC_U", "RC_Blank", "RC_2",  "RC_E",
                             "RC_4"]
    logit_model_nugg_id_list = ["id3GGRBC1REFT", "id7NEPLRYH3TQ", "id2XZQ7DG5NB4",
                                "id1HIQ57U5BAI", "id8BHQYXTW4NT", "id3GIQT3T98V8",
                                "id1Z7PIMWEG5H", "id3NLQR8CZ88A", "id6P8QG64C9VZ",
                                "id2EHQK8G66IR", "id5VBQVC1YFL7", "id5LKQATMMTRL"]
    data = model_P_submodel(data, ln_score_target="LnScore",
                            model_name="Regression A",
                            nugg_id="id3RCRE247G6R",
                            pkl_obj_dict=model_coeff_dict,
                            constant_val=0.612,
                            logit_list=logit_model_name_list,
                            logit_nugg_id=logit_model_nugg_id_list)
    return data


def model_P_submodel_B(data, model_coeff_dict):
    logit_model_name_list = ["RC_A_subB", "RC_H_subB", "RC_B_subB", "RC_K_subB",
                             "RC_M_subB", "RC_3_subB", "RC_G_subB", "RC_U_subB",
                             "RC_Blank_subB", "RC_2_subB",  "RC_E_subB",
                             "RC_4_subB"]
    logit_model_nugg_id_list = ["id8ZMQZR71Z26", "id7YRFE3CCV7", "id5ZPR8U8REYI",
                                "id1BSQBHAMHJL", "id3D9R9JHDIJU", "id6ZSPU8D65E4",
                                "id3NGPYH3UZHH", "id7YGQ9Q639LI", "idXQHR99RJ6",
                                "idEGRBZE6DRE", "id4QAPW5IIXIZ", "id3X6QF2XHL5P"]
    data = model_P_submodel(data, ln_score_target="LnScore",
                            model_name="Regression B",
                            nugg_id="id3K7QQTVK95M",
                            pkl_obj_dict=model_coeff_dict,
                            constant_val=0.704,
                            logit_list=logit_model_name_list,
                            logit_nugg_id=logit_model_nugg_id_list)
    return data


def model_P_submodel_C(data, model_coeff_dict):
    logit_model_name_list = ["RC_A_subC", "RC_H_subC", "RC_B_subC", "RC_K_subC",
                             "RC_M_subC", "RC_3_subC", "RC_G_subC", "RC_U_subC",
                             "RC_Blank_subC", "RC_2_subC",  "RC_E_subC",
                             "RC_4_subC"]
    logit_model_nugg_id_list = ["id7B6QHUAL3GP", "id583RZWTMUC2", "id86IPVSM8MN7",
                                "id4Q3REYIP295", "id75DREEGLY2N", "id5VNPM396VMJ",
                                "id6P2PXBJ9Q6X", "id6P1Q4IDC6CE", "id62BQXQRQ8KY",
                                "id7J2QBASRZTD", "idMYRANBII57", "id6J4Q1SZ8RV8"]
    data = model_P_submodel(data, ln_score_target="LnScore",
                            model_name="Regression C",
                            nugg_id="id8G3QGUN5F55",
                            pkl_obj_dict=model_coeff_dict,
                            constant_val=0.623,
                            logit_list=logit_model_name_list,
                            logit_nugg_id=logit_model_nugg_id_list)
    return data


def model_P_submodel_D(data, model_coeff_dict):
    logit_model_name_list = ["RC_A_subD", "RC_H_subD", "RC_B_subD", "RC_K_subD",
                             "RC_M_subD", "RC_3_subD", "RC_G_subD", "RC_U_subD",
                             "RC_Blank_subD", "RC_2_subD",  "RC_E_subD",
                             "RC_4_subD"]
    logit_model_nugg_id_list = ["id49IRCY31XLU", "id2DCQU1AF1R3", "id4G9QBY5K6J6",
                                "id7BIPQXXMPLM", "id3DJQ4DHDTQW", "id7J9Q3QWAJQB",
                                "id4AUQZXZ8UZ5", "id3U5PU6P2FYS", "idARQ44AMJKH",
                                "id439QG62PTKA", "id1YBRD4ZDA7D", "id5JXQXFTNL1L"]
    data = model_P_submodel(data, ln_score_target="LnScore",
                            model_name="Regression D",
                            nugg_id="id62TQCDPXKMT",
                            pkl_obj_dict=model_coeff_dict,
                            constant_val=0.812,
                            logit_list=logit_model_name_list,
                            logit_nugg_id=logit_model_nugg_id_list)
    return data


def pfm_model_p(hub_data, pkl_path, pkl_file_name):
    modelp = hub_data.loc[(hub_data.Model == "P")]
    replacezero = ["aop06m", "aop24m", "rlimit", "rbal", "del30d84m",
                   "del60d84m", "del90d84m", "del30pd24m", "del60pd24m",
                   "del90pd24m", "apd", "ndpr", "nbankrupt", "inq24m",
                   "inq06m", "nopa", "nopra", "mophi", "dpramt", "colldoll",
                   "ntaxlien"]
    replaceminusone = ["moldaop", "mrecdel", "moldraop", "mrecdpr"]

    modelp = model_P_fill_empty_cells_with_0(modelp, replacezero)
    modelp = model_P_recode_empty_cells(modelp, replaceminusone)
    modelp = subtraction(modelp, "del30d24m", "del30pd24m", "del60pd24m")
    modelp = subtraction(modelp, "del60d24m", "del60pd24m", "del90pd24m")
    modelp["delw24_123"] = ((modelp["del30d24m"] * 1) + (modelp["del60d24m"] * 2) + (modelp["del90pd24m"] * 3))
    modelp = model_P_sum111(modelp, "delw24_111", "del30d24m", "del60d24m",
                            "del90pd24m")
    modelp = model_P_sum123(modelp, "delw84_123", "del30d84m", "del60d84m",
                            "del90d84m")
    modelp = model_P_sum111(modelp, "delw84_111", "del30d84m", "del60d84m",
                            "del90d84m")
    modelp = subtraction(modelp, "delwdif_123", "delw84_123", "delw24_123")
    modelp = subtraction(modelp, "delwdif_111", "delw84_111", "delw24_111")
    modelp = subtraction(modelp, "inqdif", "inq24m", "inq06m")
    modelp = subtraction(modelp, "nopdif", "nopa", "nopra")
    modelp = subtraction(modelp, "aopdif", "aop24m", "aop06m")
    modelp = subtraction(modelp, "iadif", "inq24m", "aop24m")
    modelp = p_model_functions(modelp)

    modelp["aop24m2_b"] = modelp.aop24m.apply(lambda x: 12 if x > 10 else x+1)
    modelp["aopdiff2_b"] = modelp.aopdif.apply(lambda x: 4 if x > 2 else x+1)
    modelp["aopratio_b"] = modelp.apply(model_P_func_aopratio_b, axis=1)
    modelp["del123_group"] = modelp.apply(model_P_func_del123_group, axis=1)
    modelp["del111_group"] = modelp.apply(model_P_func_del111_group, axis=1)
    modelp["derog123_group"] = modelp.apply(model_P_derog, axis=1)
    modelp["derog111_group"] = modelp.apply(model_P_derog2, axis=1)
    modelp["del_derog123_group"] = modelp.apply(model_P_derog3, axis=1)
    modelp["del_derog111_group"] = modelp.apply(model_P_derog4, axis=1)
    modelp["del123_derog_b"] = modelp.apply(model_p_del123_derog_b, axis=1)
    modelp["del111_derog_b"] = modelp.apply(model_p_del111_derog_b, axis=1)
    modelp["delw84_123_b"] = modelp.apply(model_p_delw84_123_b, axis=1)
    modelp["delw84_111_b"] = modelp.apply(model_p_delw84_111_b, axis=1)
    modelp["delw24_123_b"] = modelp.apply(model_p_delw24_123_b, axis=1)
    modelp["delw24_111_b"] = modelp.apply(model_p_delw24_111_b, axis=1)
    modelp["delwdif123_b"] = modelp.apply(model_p_delwdif123_b, axis=1)
    modelp["delwdif111_b"] = modelp.apply(model_p_delwdif111_b, axis=1)
    modelp["derogflags_b"] = modelp.apply(model_p_derogflags_b, axis=1)
    modelp["ia24diff_b"] = modelp.apply(model_p_ia24diff_b, axis=1)
    modelp["inq6m2_b"] = modelp.apply(model_p_inq6m2_b, axis=1)
    modelp["inq24m2_b"] = modelp.apply(model_p_inq24m2_b, axis=1)
    modelp["inqdiff2_b"] = modelp.apply(model_p_inqdiff2_b, axis=1)
    modelp["moldaop2_b"] = modelp.apply(model_p_moldaop2_b, axis=1)
    modelp["moldraop2_b"] = modelp.apply(model_p_moldraop2_b, axis=1)
    modelp["nopacct2_b"] = modelp.apply(model_p_nopacct2_b, axis=1)
    modelp["nopracct2_b"] = modelp.apply(model_p_nopracct2_b, axis=1)
    modelp["nopdiff2_b"] = modelp["nopdif"].apply(nopdiff2_b)
    modelp["rlev_group"] = modelp.apply(rlev_group, axis=1)
    modelp["arlim_group"] = modelp["arlim"].apply(arlim_group)
    modelp["rlev_arlim_group"] = modelp.apply(lambda x: "_".join([str(x["rlev_group"]), str(x["arlim_group"])]), axis=1)
    modelp["rlev_arlim_b"] = modelp.apply(model_p_rlev_arlim_b, axis=1)
    modelp["rlev_b"] = modelp.apply(rlev_b, axis=1)

    # converting into integer
    modelp["del123_derog_b_integer"] = modelp["del123_derog_b"].astype(int)
    modelp["del111_derog_b_integer"] = modelp["del111_derog_b"].astype(int)
    modelp["drlev_arlim_b_integer"] = modelp["rlev_arlim_b"].astype(int)
    modelp = model_p_f_rename(modelp)
    modelp = model_p_preptoscore(modelp)

    data_A = modelp[modelp["submodel"] == "A"]
    data_B = modelp[modelp["submodel"] == "B"]
    data_C = modelp[modelp["submodel"] == "C"]
    data_D = modelp[modelp["submodel"] == "D"]

    # Reading the model coefficient pickle file.
    model_coeff_dict = load_pickle(pkl_path, pkl_file_name)
    modelp_append = pd.DataFrame()

    if not data_A.empty:
        modelp_append = pd.concat([modelp_append, model_P_submodel_A(data_A, model_coeff_dict)])
    if not data_B.empty:
        modelp_append = pd.concat([modelp_append, model_P_submodel_B(data_B, model_coeff_dict)])
    if not data_C.empty:
        modelp_append = pd.concat([modelp_append, model_P_submodel_C(data_C, model_coeff_dict)])
    if not data_D.empty:
        modelp_append = pd.concat([modelp_append, model_P_submodel_D(data_D, model_coeff_dict)])

    modelp_append = modelp_append.rename(columns={"Pscore": "PFMScore"})
    return modelp_append
