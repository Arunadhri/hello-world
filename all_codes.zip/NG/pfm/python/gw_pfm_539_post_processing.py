##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Prabakar Subramani
# Creation Date          : 28MAR2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_post_processing.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Contains functions to perform the
#                          post-processing of scored data point.
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################


import pandas as pd
import numpy as np
from datetime import datetime


def CIS_AppendedDF_PFMScore(row):

    val_to_return = ""
    if (row["Model"] >= "A") & (row["Model"] <= "J"):
        val_to_return = ""
    elif row["Model"] == "z":
        val_to_return = ""
    else:
        if (row["PH_AGE"] >= 16) & (row["PH_AGE"] <= 30):
            val_to_return = "008"
        elif (row["PH_AGE"] >= 30) & (row["PH_AGE"] <= 65):
            val_to_return = "006"
        elif (row["PH_AGE"] >= 65) & (row["PH_AGE"] <= 130):
            val_to_return = "005"
        else:
            val_to_return = "007"

    return val_to_return


def f_provider_error(df):
    df = df.drop(['CallingAppName', 'GeneratedNumber', 'WritingCo',
                  'PolEffDt', 'PolAppDt'], axis=1)
    df = df.rename(columns={'Model': 'PFMModel', 'Level': 'PFMLevel',
                            'Reasons': 'PFMReasons'})
    df['ProviderErrorCd'] = ''
    df['ProviderErrorDsc'] = ''
    return df


def f_pfm_reasons_cd(df):
    # PFMReasonCd
    df['PFMReasonCd1'] = df['PFMReasons'].apply(lambda x: x[0] if len(x) >= 1 else np.nan)
    df['PFMReasonCd2'] = df['PFMReasons'].apply(lambda x: x[1] if len(x) >= 2 else np.nan)
    df['PFMReasonCd3'] = df['PFMReasons'].apply(lambda x: x[2] if len(x) >= 3 else np.nan)
    df['PFMReasonCd4'] = df['PFMReasons'].apply(lambda x: x[3] if len(x) >= 4 else np.nan)
    df['PFMReasonCd5'] = ""
    df = df.drop('PFMReasons', axis=1)
    df['ProviderEndDateTs'] = datetime.now()
    # Field reorder
    return df


def pfm_post_processing(data_errorDF, CIS_AppendedDF, df_all_models):

    if (not CIS_AppendedDF.empty) and (not df_all_models.empty):
        df_all_models = pd.concat([CIS_AppendedDF, df_all_models], ignore_index=True)
    elif not CIS_AppendedDF.empty and (df_all_models.empty):
        df_all_models = CIS_AppendedDF.copy()
    else:
        pass

    df_all_models = f_provider_error(df_all_models)

    if (not data_errorDF.empty) and (df_all_models.empty):
        df_all_models = data_errorDF.copy()
    elif not data_errorDF.empty:
        df_all_models = df_all_models.append([data_errorDF], ignore_index=True)

    df_all_models = f_pfm_reasons_cd(df_all_models)

    return df_all_models
