##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Prabakar Subramani
# Creation Date          : 28MAR2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_import_data.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Contains functions to import the input data.
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################


import pandas as pd


def pfm_data_import(input_path):

    initialDF = pd.read_csv(input_path)
    initialDF.loc[:, initialDF.dtypes == object] = initialDF.loc[:, initialDF.dtypes == object].fillna('')

    return initialDF
