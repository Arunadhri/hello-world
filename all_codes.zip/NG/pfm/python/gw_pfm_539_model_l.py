##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Prakash Ranjan, Prabakar Subramani
# Creation Date          : 08FEB2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_model_l.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Model L
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################

# ------------------------------------------------------------------------

import numpy as np


def rlev(row):
    if row['rlimit'] == 0:
        return -1
    elif (row['rbal'] > 0) & (row['rbal'] / row['rlimit'] < 0.01):
        return 0.01
    else:
        return int((row['rbal'] / row['rlimit'])*100) / 100


def fix_calculation(df):
    df['mrecdpr'] = df['mrecdpr'].replace(np.nan, 999)
    df['moldaop'] = df['moldaop'].replace(np.nan, -1)
    df['rlev'] = df.apply(rlev, axis=1)
    return df


def derogs(df):
    df['bankrupt_IN'] = np.where(df['State'] == "IN", 0, df['nbankrupt'])
    df['ndpr_IN'] = df.apply(lambda x: max(0, (x['ndpr']-x['nbankrupt'])) if x['State'] == 'IN' else x['ndpr'], axis=1)
    df['bankrupt84'] = np.where(df['mrecdpr'] < 84, df['bankrupt_IN'], 0)
    df['ndpr84'] = np.where(df['mrecdpr'] < 84, df['ndpr_IN'], 0)
    df['ntaxlien84'] = np.where(df['mrecdpr'] < 84, df['ntaxlien'], 0)
    df['dprflag'] = np.where(df['ndpr84'] > 0, 1, 0)
    df['collflag'] = np.where(df['colldoll'] > 0, 1, 0)
    df['mophiflag'] = np.where(df['mophi'] > 0, 1, 0)
    df['apdflag'] = np.where(df['apd'] >= 130, 1, 0)
    series = df['dprflag'] + df['collflag'] + df['mophiflag'] + df['apdflag']
    cond1 = series == 0
    df['derogs'] = np.where(cond1, np.where(df['apd'] > 0, 0.5, 0), (df['dprflag'] + df['collflag'] + df['mophiflag'] + df['apdflag']))
    return df


def aopFact(x):
    if x < 1:
        return 0.94
    elif x == 1:
        return 0.95
    elif x == 2:
        return 0.988
    elif x == 3:
        return 0.997
    elif x == 4:
        return 1.024
    elif x < 7:
        return 1.045
    elif x < 10:
        return 1.081
    else:
        return 1.127


def delFact(x):
    if x < 1:
        return 0.972
    elif x == 1:
        return 1.04
    elif x == 2:
        return 1.042
    elif x < 9:
        return 1.075
    else:
        return 1.103


def inqFact(x):
    if x < 1:
        return 0.92
    elif x == 1:
        return 0.949
    elif x == 2:
        return 0.978
    elif x == 3:
        return 0.988
    elif x == 4:
        return 1.02
    elif x == 5:
        return 1.034
    elif x < 9:
        return 1.076
    elif x < 11:
        return 1.134
    elif x < 15:
        return 1.157
    else:
        return 1.223


def moldFact(x):
    if x < 0:
        return 1.205
    elif x < 12:
        return 1.418
    elif x < 24:
        return 1.284
    elif x < 36:
        return 1.188
    elif x < 60:
        return 1.16
    elif x < 96:
        return 1.098
    elif x < 156:
        return 1
    else:
        return 0.965


def nopaFact(x):
    if x < 1:
        return 1.162
    elif x == 1:
        return 1.065
    elif x == 2:
        return 1.047
    elif x < 5:
        return 1.031
    elif x == 5:
        return 1.004
    elif x < 10:
        return 0.969
    else:
        return 0.996


def rlevFact(x):
    if x < 0:
        return 1.066
    elif x == 0:
        return 1.014
    elif x < 0.05:
        return 0.955
    elif x < 0.18:
        return 0.972
    elif x < 0.25:
        return 0.987
    elif x < 0.35:
        return 0.996
    elif x < 0.75:
        return 1.025
    else:
        return 1.063


def score_factor(df):

    df['aopFact'] = df.aop24m.apply(aopFact)
    df['delFact'] = df.del30pd24m.apply(delFact)
    df['inqFact'] = df.inq24m.apply(inqFact)
    df['derogFact'] = np.where(df['derogs'] == 0, 0.962, np.where(df['derogs'] == 0.5, 1.037, np.where(df['derogs'] == 1, 1.084, 1.106)))
    df['moldFact'] = df.moldaop.apply(moldFact)
    df['nopaFact'] = df.nopa.apply(nopaFact)
    df['rlevFact'] = df.rlev.apply(rlevFact)

    return df


def aopRR(x):
    if x < 1:
        return 999
    elif x == 1:
        return 107
    elif x == 2:
        return 103
    elif x == 3:
        return 99
    elif x == 4:
        return 96
    elif x < 7:
        return 88
    elif x < 10:
        return 76
    else:
        return 52


def delRR(x):
    if x < 1:
        return 999
    elif x == 1:
        return 91
    elif x == 2:
        return 85
    elif x < 9:
        return 81
    else:
        return 58


def inqRR(x):
    if x < 1:
        return 999
    elif x == 1:
        return 10
    elif x == 2:
        return 102
    elif x == 3:
        return 98
    elif x == 4:
        return 94
    elif x == 5:
        return 90
    elif x < 9:
        return 86
    elif x < 11:
        return 75
    elif x < 15:
        return 67
    else:
        return 44


def moldRR(x):
    if x < 0:
        return 46
    elif x < 12:
        return 3
    elif x < 24:
        return 31
    elif x < 36:
        return 53
    elif x < 60:
        return 67
    elif x < 96:
        return 78
    elif x < 156:
        return 92
    else:
        return 999


def nopaRR(x):
    if x < 1:
        return 32
    elif x == 1:
        return 60
    elif x == 2:
        return 72
    elif x < 5:
        return 83
    elif x == 5:
        return 86
    elif x < 10:
        return 999
    else:
        return 103


def rlevRR(x):
    if x < 0:
        return 64
    elif x == 0:
        return 96
    elif x < 0.05:
        return 999
    elif x < 0.18:
        return 105
    elif x < 0.25:
        return 100
    elif x < 0.35:
        return 99
    elif x < 0.75:
        return 94
    else:
        return 81


def apdRR(x):
    if x >= 1300:
        return 6
    elif x >= 1200:
        return 11
    elif x >= 1100:
        return 15
    elif x >= 1000:
        return 19
    elif x >= 900:
        return 23
    elif x >= 800:
        return 28
    elif x >= 700:
        return 34
    elif x >= 600:
        return 39
    elif x >= 500:
        return 42
    elif x >= 400:
        return 48
    elif x >= 300:
        return 55
    elif x >= 200:
        return 62
    elif x >= 1:
        return 70
    else:
        return 999


def collRR(x):
    if x >= 3900:
        return 2
    elif x >= 3800:
        return 4
    elif x >= 3700:
        return 5
    elif x >= 3600:
        return 7
    elif x >= 3500:
        return 8
    elif x >= 3400:
        return 10
    elif x >= 3300:
        return 12
    elif x >= 3200:
        return 13
    elif x >= 3100:
        return 14
    elif x >= 3000:
        return 16
    elif x >= 2900:
        return 17
    elif x >= 2800:
        return 18
    elif x >= 2700:
        return 20
    elif x >= 2600:
        return 21
    elif x >= 2500:
        return 22
    elif x >= 2400:
        return 25
    elif x >= 2300:
        return 26
    elif x >= 2200:
        return 27
    elif x >= 2100:
        return 29
    elif x >= 2000:
        return 30
    elif x >= 1900:
        return 33
    elif x >= 1800:
        return 35
    elif x >= 1700:
        return 36
    elif x >= 1600:
        return 38
    elif x >= 1500:
        return 40
    elif x >= 1400:
        return 41
    elif x >= 1300:
        return 43
    elif x >= 1200:
        return 47
    elif x >= 1100:
        return 49
    elif x >= 1000:
        return 51
    elif x >= 900:
        return 54
    elif x >= 800:
        return 56
    elif x >= 700:
        return 57
    elif x >= 600:
        return 63
    elif x >= 500:
        return 65
    elif x >= 400:
        return 68
    elif x >= 300:
        return 70
    elif x >= 200:
        return 73
    elif x >= 100:
        return 77
    elif x >= 1:
        return 82
    else:
        return 999


def mophiRR(x):
    if x > 7:
        return 1
    elif x == 1:
        return 80
    elif x == 2:
        return 72
    elif x == 3:
        return 63
    elif x == 4:
        return 50
    elif x == 5:
        return 37
    elif x == 6:
        return 24
    elif x == 7:
        return 9
    else:
        return 999


def RR(row, x):
    existing_columns = ['apdRR', 'collRR', 'forecjRR', 'moldRR', 'rlevRR', 'inqRR', 'mophiRR', 'bankruptRR', 'taxlienRR', 'aopRR', 'nopaRR', 'delRR']
    existing_columns.remove(x)
    c = 0
    for i in range(0, len(existing_columns)):
        if row[x] > row[existing_columns[i]]:
            c = c+1
    return c+1


def RC(row, x):
    if row['Level'] == "BD":
        return ""
    elif (row['RRA'] == x) & (row['apdRR'] < 999):
        return "A"
    elif (row['RRB'] == x) & (row['collRR'] < 999):
        return "B"
    elif (row['RRC'] == x) & (row['forecjRR'] < 999):
        return "C"
    elif (row['RRE'] == x) & (row['moldRR'] < 999):
        return "E"
    elif (row['RRF'] == x) & (row['rlevRR'] < 999):
        return "F"
    elif (row['RRG'] == x) & (row['inqRR'] < 999):
        return "G"
    elif (row['RRH'] == x) & (row['mophiRR'] < 999):
        return "H"
    elif (row['RRK'] == x) & (row['bankruptRR'] < 999):
        return "K"
    elif (row['RRM'] == x) & (row['taxlienRR'] < 999):
        return "M"
    elif (row['RRU'] == x) & (row['aopRR'] < 999):
        return "U"
    elif (row['RR2'] == x) & (row['nopaRR'] < 999):
        return "2"
    elif (row['RR3'] == x) & (row['delRR'] < 999):
        return "3"
    else:
        return ""


def Reason_rank(df):

    df['aopRR'] = df.aop24m.apply(aopRR)
    df['delRR'] = df.del30pd24m.apply(delRR)
    df['inqRR'] = df.inq24m.apply(inqRR)
    df['moldRR'] = df.moldaop.apply(moldRR)
    df['nopaRR'] = df.nopa.apply(nopaRR)
    df['rlevRR'] = df.rlev.apply(rlevRR)
    df['apdRR'] = df.apd.apply(apdRR)
    df['collRR'] = df.colldoll.apply(collRR)
    df['mophiRR'] = df.mophi.apply(mophiRR)
    df['bankruptRR'] = np.where(df['bankrupt84'] > 0, 45, 999)
    df['taxlienRR'] = np.where(df['ntaxlien84'] > 0, 59, 999)

    cond1 = (df['bankrupt84']+df['ntaxlien84']) > 0
    df['forecjRR'] = np.where(cond1, 999, np.where(df['ndpr84'] > 0, 60, 999))

    existing_columns = ['apdRR', 'collRR', 'forecjRR', 'moldRR', 'rlevRR', 'inqRR', 'mophiRR', 'bankruptRR', 'taxlienRR', 'aopRR', 'nopaRR', 'delRR']
    new_columns = ['RRA', 'RRB', "RRC", "RRE", "RRF", "RRG", "RRH", "RRK", "RRM", "RRU", "RR2", "RR3"]

    for i in range(0, len(existing_columns)):
        df[new_columns[i]] = df.apply(RR, x=existing_columns[i], axis=1)

    df['RC1'] = df.apply(RC, x=1, axis=1).astype(str)
    df['RC2'] = df.apply(RC, x=2, axis=1).astype(str)
    df['RC3'] = df.apply(RC, x=3, axis=1).astype(str)
    df['RC4'] = df.apply(RC, x=4, axis=1).astype(str)
    df['RC5'] = df.apply(RC, x=5, axis=1).astype(str)
    df['Reasons'] = df['RC1']+df['RC2']+df['RC3']+df['RC4']+df['RC5']

    return df


def score(row):
    return max(10, min(999, round((684 * row['aopFact'] * row['delFact'] * row['inqFact']*row['derogFact'] * row['moldFact'] * row['nopaFact'] * row['rlevFact']) - 483)))


def Level(x):
    if (x >= 10) & (x < 30):
        return "BD"
    elif (x >= 30) & (x < 42):
        return "BH"
    elif (x >= 42) & (x < 51):
        return "BL"
    elif (x >= 51) & (x < 60):
        return "BP"
    elif (x >= 60) & (x < 69):
        return "BT"
    elif (x >= 69) & (x < 77):
        return "BW"
    elif (x >= 77) & (x < 85):
        return "CD"
    elif (x >= 85) & (x < 94):
        return "CH"
    elif (x >= 94) & (x < 103):
        return "CL"
    elif (x >= 103) & (x < 111):
        return "CP"
    elif (x >= 111) & (x < 119):
        return "CT"
    elif (x >= 119) & (x < 128):
        return "CW"
    elif (x >= 128) & (x < 131):
        return 'DD'
    elif (x >= 131) & (x < 139):
        return "DG"
    elif (x >= 139) & (x < 148):
        return "DJ"
    elif (x >= 148) & (x < 157):
        return "DN"
    elif (x >= 157) & (x < 166):
        return "DQ"
    elif (x >= 166) & (x < 177):
        return "DT"
    elif (x >= 177) & (x < 189):
        return "DW"
    elif (x >= 189) & (x < 199):
        return "ED"
    elif (x >= 199) & (x < 210):
        return "EG"
    elif (x >= 210) & (x < 222):
        return "EJ"
    elif (x >= 222) & (x < 234):
        return "EN"
    elif (x >= 234) & (x < 248):
        return "EQ"
    elif (x >= 248) & (x < 263):
        return "ET"
    elif (x >= 263) & (x < 269):
        return "EW"
    elif (x >= 269) & (x < 288):
        return "FD"
    elif (x >= 288) & (x < 308):
        return "FG"
    elif (x >= 308) & (x < 332):
        return "FJ"
    elif (x >= 332) & (x < 349):
        return "FN"
    elif (x >= 349) & (x < 366):
        return "FQ"
    elif (x >= 366) & (x < 385):
        return "FT"
    elif (x >= 385) & (x < 404):
        return "FW"
    elif (x >= 404) & (x < 431):
        return "GD"
    elif (x >= 431) & (x < 447):
        return "GH"
    elif (x >= 447) & (x < 461):
        return "GL"
    elif (x >= 461) & (x < 476):
        return "GP"
    elif (x >= 476) & (x < 494):
        return "GT"
    elif (x >= 494) & (x < 515):
        return "HD"
    elif (x >= 515) & (x < 539):
        return "HH"
    elif (x >= 539) & (x < 570):
        return "HL"
    elif (x >= 570) & (x < 616):
        return "HP"
    elif (x >= 616) & (x < 692):
        return "HT"
    elif (x >= 692) & (x <= 999):
        return "HW"


def pfm_model_l(df):
    df = df[df['Model'] == 'L']
    df = fix_calculation(df)
    df = derogs(df)
    df = score_factor(df)
    df['score'] = df.apply(score, axis=1)
    df['Level'] = df.score.apply(Level)
    df = Reason_rank(df)
    df = df.rename(columns={'score': 'PFMScore'})

    return df
