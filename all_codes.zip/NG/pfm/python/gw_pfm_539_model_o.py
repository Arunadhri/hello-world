##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Prakash Ranjan, Prabakar Subramani
# Creation Date          : 08FEB2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_model_o.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Model O
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################

# ------------------------------------------------------------------------

import numpy as np


def fix_calculation(df):
    df['moldaop'] = df['moldaop'].replace(np.nan, -1)
    return df


def derogs(df):
    df['bankrupt_IN'] = np.where(df['State'] == "IN", 0, df['nbankrupt'])

    df['ndpr_IN'] = df.apply(lambda x: max(0, (x['ndpr']-x['nbankrupt'])) if x['State'] == 'IN' else x['ndpr'], axis=1)

    df['bankrupt84'] = np.where(df['mrecdpr'] < 84, df['bankrupt_IN'], 0)

    df['ndpr84'] = np.where(df['mrecdpr'] < 84, df['ndpr_IN'], 0)

    df['ntaxlien84'] = np.where(df['mrecdpr'] < 84, df['ntaxlien'], 0)

    df['dprflag'] = np.where(df['ndpr84'] > 0, 1, 0)

    df['collflag'] = np.where(df['colldoll'] > 0, 1, 0)

    df['mophiflag'] = np.where(df['mophi'] > 0, 1, 0)

    df['apdflag'] = np.where(df['apd'] >= 130, 1, 0)

    series = df['dprflag'] + df['collflag'] + df['mophiflag'] + df['apdflag']
    cond1 = series == 0
    df['derogs'] = np.where(cond1, np.where(df['apd'] > 0, 0.5, 0),
                            (df['dprflag'] + df['collflag'] + df['mophiflag'] + df['apdflag']))
    return df


def raopFact(x):
    if x < 1:
        return 0.885
    elif x == 1:
        return 0.914
    elif x == 2:
        return 0.972
    elif x == 3:
        return 0.997
    elif x == 4:
        return 1.040
    elif x == 5:
        return 1.077
    elif x == 6:
        return 1.090
    elif x == 7:
        return 1.126
    elif x == 8:
        return 1.160
    elif x == 9:
        return 1.194
    elif x == 10:
        return 1.228
    else:
        return 1.251


def nopaFact(x):
    if x < 1:
        return 1.218
    elif x == 1:
        return 1.095
    elif x == 2:
        return 1.065
    elif x == 3:
        return 1.048
    elif x == 4:
        return 1.029
    elif x == 5:
        return 1.006
    elif x == 6:
        return 0.990
    elif x == 7:
        return 0.975
    elif x == 8:
        return 0.965
    elif x == 9:
        return 0.969
    elif x == 10:
        return 0.971
    elif x == 11:
        return 0.973
    elif x == 12:
        return 0.976
    elif x == 13:
        return 0.978
    elif x == 14:
        return 0.981
    elif x == 15:
        return 0.984
    elif x == 16:
        return 0.988
    elif x == 17:
        return 0.992
    else:
        return 1.007


def moldFact(x):
    if x < 0:
        return 1.250
    elif x < 12:
        return 1.463
    elif x < 24:
        return 1.338
    elif x < 36:
        return 1.214
    elif x < 60:
        return 1.182
    elif x < 96:
        return 1.112
    elif x < 120:
        return 1.022
    elif x < 144:
        return 1.006
    elif x < 156:
        return 0.998
    elif x < 192:
        return 0.987
    elif x < 300:
        return 0.963
    elif x < 360:
        return 0.930
    else:
        return 0.915


def delFact(x):
    if x < 1:
        return 0.962
    elif x == 1:
        return 1.053
    elif x == 2:
        return 1.065
    elif x == 3:
        return 1.081
    elif x == 4:
        return 1.099
    elif x == 5:
        return 1.108
    elif x == 6:
        return 1.113
    elif x == 7:
        return 1.116
    elif x == 8:
        return 1.121
    elif x == 9:
        return 1.125
    elif x == 10:
        return 1.130
    elif x < 15:
        return 1.140
    elif x < 25:
        return 1.164
    elif x < 40:
        return 1.188
    else:
        return 1.198


def score_factor(df):

    df['raopFact'] = df.raop24m.apply(raopFact)

    df['nopaFact'] = df.nopa.apply(nopaFact)

    df['rlevFact'] = np.where(df['rbal'] <= df['rlimit'], 0.999, 1.033)

    df['moldFact'] = df.moldaop.apply(moldFact)

    df['delFact'] = df.del30pd24m.apply(delFact)

    df['derogFact'] = np.where(
        df['derogs'] == 0, 0.945, np.where(
            df['derogs'] == 0.5, 1.035, np.where(
                df['derogs'] == 1, 1.111, 1.170)))
    return df


def raopRR(x):
    if x < 1:
        return 999
    elif x == 1:
        return 117
    elif x == 2:
        return 112
    elif x == 3:
        return 108
    elif x == 4:
        return 102
    elif x == 5:
        return 97
    elif x == 6:
        return 92
    elif x == 7:
        return 86
    elif x == 8:
        return 78
    elif x == 9:
        return 71
    elif x == 10:
        return 57
    else:
        return 44


def delRR(x):
    if x < 1:
        return 999
    elif x == 1:
        return 99
    elif x == 2:
        return 96
    elif x == 3:
        return 91
    elif x == 4:
        return 85
    elif x == 5:
        return 83
    elif x == 6:
        return 81
    elif x == 7:
        return 74
    elif x == 8:
        return 72
    elif x == 9:
        return 64
    elif x == 10:
        return 58
    elif x < 15:
        return 54
    elif x < 25:
        return 31
    elif x < 40:
        return 2
    else:
        return 1


def moldRR(x):
    if x < 0:
        return 46
    elif x < 12:
        return 4
    elif x < 24:
        return 36
    elif x < 36:
        return 61
    elif x < 60:
        return 77
    elif x < 96:
        return 89
    elif x < 120:
        return 95
    elif x < 144:
        return 98
    elif x < 156:
        return 101
    elif x < 192:
        return 106
    elif x < 300:
        return 116
    elif x < 360:
        return 119
    else:
        return 999


def nopaRR(x):
    if x < 1:
        return 24
    elif x == 1:
        return 65
    elif x == 2:
        return 82
    elif x == 3:
        return 88
    elif x == 4:
        return 94
    elif x == 5:
        return 103
    elif x == 6:
        return 105
    elif x == 7:
        return 114
    elif x == 8:
        return 999
    elif x == 9:
        return 120
    elif x == 10:
        return 118
    elif x == 11:
        return 115
    elif x == 12:
        return 113
    elif x == 13:
        return 111
    elif x == 14:
        return 110
    elif x == 15:
        return 109
    elif x == 16:
        return 107
    elif x == 17:
        return 104
    else:
        return 100


def apdRR(x):
    if x >= 1300:
        return 8
    elif x >= 1200:
        return 13
    elif x >= 1100:
        return 17
    elif x >= 1000:
        return 21
    elif x >= 900:
        return 26
    elif x >= 800:
        return 32
    elif x >= 700:
        return 37
    elif x >= 600:
        return 43
    elif x >= 500:
        return 48
    elif x >= 400:
        return 52
    elif x >= 300:
        return 60
    elif x >= 200:
        return 68
    elif x >= 1:
        return 76
    else:
        return 999


def collRR(x):
    if x >= 3900:
        return 5
    elif x >= 3800:
        return 6
    elif x >= 3700:
        return 7
    elif x >= 3600:
        return 9
    elif x >= 3500:
        return 10
    elif x >= 3400:
        return 12
    elif x >= 3300:
        return 14
    elif x >= 3200:
        return 15
    elif x >= 3100:
        return 16
    elif x >= 3000:
        return 18
    elif x >= 2900:
        return 19
    elif x >= 2800:
        return 20
    elif x >= 2700:
        return 22
    elif x >= 2600:
        return 23
    elif x >= 2500:
        return 25
    elif x >= 2400:
        return 28
    elif x >= 2300:
        return 29
    elif x >= 2200:
        return 30
    elif x >= 2100:
        return 33
    elif x >= 2000:
        return 34
    elif x >= 1900:
        return 35
    elif x >= 1800:
        return 38
    elif x >= 1700:
        return 39
    elif x >= 1600:
        return 42
    elif x >= 1500:
        return 45
    elif x >= 1400:
        return 47
    elif x >= 1300:
        return 49
    elif x >= 1200:
        return 51
    elif x >= 1100:
        return 53
    elif x >= 1000:
        return 56
    elif x >= 900:
        return 59
    elif x >= 800:
        return 62
    elif x >= 700:
        return 63
    elif x >= 600:
        return 70
    elif x >= 500:
        return 73
    elif x >= 400:
        return 75
    elif x >= 300:
        return 79
    elif x >= 200:
        return 84
    elif x >= 100:
        return 87
    elif x >= 1:
        return 93
    else:
        return 999


def mophiRR(x):
    if x > 7:
        return 3
    elif x == 1:
        return 90
    elif x == 2:
        return 80
    elif x == 3:
        return 69
    elif x == 4:
        return 55
    elif x == 5:
        return 41
    elif x == 6:
        return 27
    elif x == 7:
        return 11
    else:
        return 999


def RR(row, x):
    existing_columns = [
        'apdRR',
        'collRR',
        'forecjRR',
        'moldRR',
        'rlevRR',
        'mophiRR',
        'bankruptRR',
        'taxlienRR',
        'raopRR',
        'nopaRR',
        'delRR']
    existing_columns.remove(x)
    c = 0
    for i in range(0, len(existing_columns)):
        if row[x] > row[existing_columns[i]]:
            c = c + 1
    return c + 1


def RC(row, x):
    if row['Level'] == "BD":
        return ""
    elif (row['RRA'] == x) & (row['apdRR'] < 999):
        return "A"
    elif (row['RRB'] == x) & (row['collRR'] < 999):
        return "B"
    elif (row['RRC'] == x) & (row['forecjRR'] < 999):
        return "C"
    elif (row['RRE'] == x) & (row['moldRR'] < 999):
        return "E"
    elif (row['RRF'] == x) & (row['rlevRR'] < 999):
        return "F"
    elif (row['RRH'] == x) & (row['mophiRR'] < 999):
        return "H"
    elif (row['RRK'] == x) & (row['bankruptRR'] < 999):
        return "K"
    elif (row['RRM'] == x) & (row['taxlienRR'] < 999):
        return "M"
    elif (row['RRU'] == x) & (row['raopRR'] < 999):
        return "U"
    elif (row['RR2'] == x) & (row['nopaRR'] < 999):
        return "2"
    elif (row['RR3'] == x) & (row['delRR'] < 999):
        return "3"
    else:
        ""


def Reason_rank(df):

    df['raopRR'] = df.raop24m.apply(raopRR)

    df['delRR'] = df.del30pd24m.apply(delRR)

    df['moldRR'] = df.moldaop.apply(moldRR)

    df['nopaRR'] = df.nopa.apply(nopaRR)

    df['rlevRR'] = np.where(df['rbal'] <= df['rlimit'], 999, 40)

    df['apdRR'] = df.apd.apply(apdRR)

    df['collRR'] = df.colldoll.apply(collRR)

    df['mophiRR'] = df.mophi.apply(mophiRR)

    df['bankruptRR'] = np.where(df['bankrupt84'] > 0, 67, 999)

    df['taxlienRR'] = np.where(df['ntaxlien84'] > 0, 50, 999)

    cond1 = df['bankrupt84'] + df['ntaxlien84'] > 0

    df['forecjRR'] = np.where(cond1, 999, np.where(df['ndpr84'] > 0, 66, 999))

    existing_columns = [
        'apdRR',
        'collRR',
        'forecjRR',
        'moldRR',
        'rlevRR',
        'mophiRR',
        'bankruptRR',
        'taxlienRR',
        'raopRR',
        'nopaRR',
        'delRR']
    new_columns = ['RRA', 'RRB', "RRC", "RRE", "RRF", "RRH",
                   "RRK", "RRM", "RRU", "RR2", "RR3"]  # columns to creat
    for i in range(0, len(existing_columns)):
        df[new_columns[i]] = df.apply(RR, x=existing_columns[i], axis=1)

    df['RC1'] = df.apply(RC, x=1, axis=1)
    df['RC2'] = df.apply(RC, x=2, axis=1)
    df['RC3'] = df.apply(RC, x=3, axis=1)
    df['RC4'] = df.apply(RC, x=4, axis=1)
    df['RC5'] = df.apply(RC, x=5, axis=1)

    df['Reasons'] = df['RC1'] + df['RC2'] + df['RC3'] + df['RC4'] + df['RC5']
    return df


def score(row):
    return max(10, min(999, round((738.045 * row['raopFact'] * row['nopaFact'] *
                                   row['rlevFact'] * row['moldFact'] * row['delFact'] * row['derogFact']) - 525)))


def Level(x):
    if (x == 10) & (x < 27):
        return "BD"
    elif (x == 27) & (x < 42):
        return "BH"
    elif (x == 42) & (x < 52):
        return "BL"
    elif (x == 52) & (x < 63):
        return "BP"
    elif (x == 63) & (x < 73):
        return "BT"
    elif (x == 73) & (x < 84):
        return "BW"
    elif (x == 84) & (x < 92):
        return "CD"
    elif (x == 92) & (x < 102):
        return "CH"
    elif (x == 102) & (x < 110):
        return "CL"
    elif (x == 110) & (x < 120):
        return "CP"
    elif (x == 120) & (x < 128):
        return "CT"
    elif (x == 128) & (x < 137):
        return "CW"
    elif (x == 137) & (x < 142):
        return "DD"
    elif (x == 142) & (x < 151):
        return "DG"
    elif (x == 151) & (x < 160):
        return "DJ"
    elif (x == 160) & (x < 169):
        return "DN"
    elif (x == 169) & (x < 178):
        return "DQ"
    elif (x == 178) & (x < 188):
        return "DT"
    elif (x == 188) & (x < 200):
        return "DW"
    elif (x == 200) & (x < 210):
        return "ED"
    elif (x == 210) & (x < 223):
        return "EG"
    elif (x == 223) & (x < 235):
        return "EJ"
    elif (x == 235) & (x < 249):
        return "EN"
    elif (x == 249) & (x < 264):
        return "EQ"
    elif (x == 264) & (x < 278):
        return "ET"
    elif (x == 278) & (x < 283):
        return "EW"
    elif (x == 283) & (x < 302):
        return "FD"
    elif (x == 302) & (x < 324):
        return "FG"
    elif (x == 324) & (x < 348):
        return "FJ"
    elif (x == 348) & (x < 365):
        return "FN"
    elif (x == 365) & (x < 378):
        return "FQ"
    elif (x == 378) & (x < 396):
        return "FT"
    elif (x == 396) & (x < 414):
        return "FW"
    elif (x == 414) & (x < 442):
        return "GD"
    elif (x == 442) & (x < 456):
        return "GH"
    elif (x == 456) & (x < 465):
        return "GL"
    elif (x == 465) & (x < 480):
        return "GP"
    elif (x == 480) & (x < 495):
        return "GT"
    elif (x == 495) & (x < 516):
        return "HD"
    elif (x == 516) & (x < 538):
        return "HH"
    elif (x == 538) & (x < 566):
        return "HL"
    elif (x == 566) & (x < 605):
        return "HP"
    elif (x == 605) & (x < 671):
        return "HT"
    elif (x == 671) & (x <= 999):
        return "HW"


def pfm_model_o(df):
    df = df[df['Model'] == 'O']
    df = fix_calculation(df)
    df = derogs(df)
    df = score_factor(df)
    df['score'] = df.apply(score, axis=1)

    df['Level'] = df.score.apply(Level)
    df = Reason_rank(df)
    df = df.rename(columns={'score': 'PFMScore'})

    return df
