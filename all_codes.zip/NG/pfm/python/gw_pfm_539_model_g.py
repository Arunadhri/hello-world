##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Sushant Kulkarni, Prabakar Subramani
# Creation Date          : 08FEB2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_model_g.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Model G
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################

# ------------------------------------------------------------------------


def f_model_G_Strike(x):
    '''
    Supernode ID: id59UTVBU9I13
    Nugget ID: id4J2SJZQD7XI
    '''
    Strike = 0
    if x["DPR84m"] > 0:
        Strike = Strike + 1
    if x["MOPhi"] > 0:
        Strike = Strike + 1
    if x["CollDoll"] > 0:
        Strike = Strike + 1
    if x["APD"] > 100:
        Strike = Strike + 1
    if x["Inq24m"] >= 8:
        Strike = Strike + 1
    if x["Leverage"] >= 0.80:
        Strike = Strike + 1
    if x["AOTL"] < 7.0:
        Strike = Strike + 1
    return Strike


def f_model_G_RC7(x):
    '''
    Supernode ID: id59UTVBU9I13
    Nugget ID: id2K8TCHM99GV
    '''
    if (x["DPR84m"] > 0) & (x["nbankrupt"] > 0):
        RC7 = "K"
    elif (x["DPR84m"] > 0) & (x["ntaxlien"] > 0):
        RC7 = "M"
    else:
        RC7 = ""
    return RC7


def f_model_G_level(x):
    '''
    Nugget ID: id85SPP9R7JEI
    '''

    if x["Strike"] == 7:
        Level = "4B"
    elif x["Strike"] == 6:
        Level = "4B"
    elif x["Strike"] == 5:
        Level = "4B"
    elif x["Strike"] == 4:
        Level = "4B"
    elif x["Strike"] == 3:
        Level = "4A"
    elif x["Strike"] == 2:
        Level = "3B"
    elif (x["Strike"] == 1) & (x["Condition2"] == 1):
        Level = "3B"
    elif (x["Strike"] == 1) & (x["Condition15"] == 1):
        Level = "3B"
    elif (x["Strike"] == 1) & (x["Condition3"] == 1):
        Level = "3B"
    elif (x["Strike"] == 1) & (x["Condition4"] == 1):
        Level = "3A"
    elif (x["Strike"] == 1) & (x["Condition5"] == 1):
        Level = "3A"
    elif ((x["Strike"] == 1) | (x["Strike"] == 0)) & (x["Condition6"] == 1):
        Level = "3A"
    elif ((x["Strike"] == 1) | (x["Strike"] == 0)) & \
         ((x["Condition7"] == 1) & (x["Condition8"] == 1) &
          (x["Condition9"] == 1)):
        Level = "3A"
    elif ((x["Strike"] == 1) | (x["Strike"] == 0)) & \
         ((x["Condition10"] == 1) & (x["Condition11"] == 1)):
        Level = "3A"
    elif x["Strike"] == 1:
        Level = "2A"
    elif (x["Strike"] == 0) & (x["Condition7"] == 1) & (x["Condition8"] == 1):
        Level = "2A"
    elif (x["Strike"] == 0) & (x["Condition7"] == 1) & (x["Condition12"] == 1):
        Level = "2A"
    elif (x["Strike"] == 0) & (x["Condition8"] == 1) & (x["Condition11"] == 1):
        Level = "2A"
    elif (x["Strike"] == 0) & (x["Condition12"] == 1) & (x["Condition13"] == 1):
        Level = "2A"
    elif (x["Strike"] == 0) & (x["Condition7"] == 1) & \
         (x["Condition9"] == 1) & (x["Condition14"] == 1):
        Level = "2A"
    elif (x["Strike"] == 0) & (x["Condition8"] == 1) & \
         (x["Condition9"] == 1) & (x["Condition14"] == 1):
        Level = "2A"
    elif (x["Strike"] == 0) & (x["Condition11"] == 1) & (x["Condition14"] == 1):
        Level = "2A"
    elif (x["Strike"] == 0) & (x["Condition7"] == 1):
        Level = "1B"
    elif (x["Strike"] == 0) & (x["Condition8"] == 1):
        Level = "1B"
    elif (x["Strike"] == 0) & (x["Condition9"] == 1):
        Level = "1B"
    elif x["Strike"] == 0:
        Level = "1A"
    else:
        Level = ""

    return Level


def f_model_G_Reasons(x):
    ''''
    Nugget ID: id2DNQL3QPVQS
    '''

    if (x["Strike"] >= 2) & (x["Strike"] <= 7):
        Reasons = str.strip(str(x["RC1"]) + str(x["RC2"]) + str(x["RC3"]) +
                            str(x["RC4"]) + str(x["RC5"]) + str(x["RC6"]) +
                            str(x["RC7"]))
    elif (x["Strike"] == 1) & (x["Condition2"] == 1):
        Reasons = str.strip(str(x["RC1"]) + str(x["RC2"]) + str(x["RC3"]) +
                            str(x["RC4"]) + str(x["RC5"]) + str(x["RC6"]) +
                            str(x["RC7"]) + "U")
    elif (x["Strike"] == 1) & (x["Condition15"] == 1):
        Reasons = str.strip(str(x["RC1"]) + str(x["RC2"]) + str(x["RC3"]) +
                            str(x["RC4"]) + str(x["RC5"]) + str(x["RC6"]) +
                            str(x["RC7"]) + "G")
    elif (x["Strike"] == 1) & (x["Condition3"] == 1):
        Reasons = "G"
    elif (x["Strike"] == 1) & (x["Condition4"] == 1):
        Reasons = str.strip(str(x["RC1"]) + str(x["RC2"]) + str(x["RC3"]) +
                            str(x["RC4"]) + str(x["RC5"]) + str(x["RC6"]) +
                            str(x["RC7"]))
    elif (x["Strike"] == 1) & (x["Condition5"] == 1):
        Reasons = "H"
    elif ((x["Strike"] == 1) | (x["Strike"] == 0)) & (x["Condition6"] == 1):
        Reasons = "A"
    elif ((x["Strike"] == 1) | (x["Strike"] == 0)) & \
         ((x["Condition7"] == 1) & (x["Condition8"] == 1) & (x["Condition9"] == 1)):
        Reasons = "FGU"
    elif ((x["Strike"] == 1) | (x["Strike"] == 0)) & \
         ((x["Condition10"] == 1) & (x["Condition11"] == 1)):
        Reasons = "EV"
    elif x["Strike"] == 1:
        Reasons = str.strip(str(x["RC1"]) + str(x["RC2"]) + str(x["RC3"]) +
                            str(x["RC4"]) + str(x["RC5"]) + str(x["RC6"]) +
                            str(x["RC7"]))
    elif (x["Strike"] == 0) & (x["Condition7"] == 1) & (x["Condition8"] == 1):
        Reasons = "FG"
    elif (x["Strike"] == 0) & (x["Condition7"] == 1) & (x["Condition12"] == 1):
        Reasons = "FU"
    elif (x["Strike"] == 0) & (x["Condition8"] == 1) & (x["Condition11"] == 1):
        Reasons = "EG"
    elif (x["Strike"] == 0) & (x["Condition12"] == 1) & (x["Condition13"] == 1):
        Reasons = "GU"
    elif (x["Strike"] == 0) & (x["Condition7"] == 1) & \
         (x["Condition9"] == 1) & (x["Condition14"] == 1):
        Reasons = "FUV"
    elif (x["Strike"] == 0) & (x["Condition8"] == 1) & \
         (x["Condition9"] == 1) & (x["Condition14"] == 1):
        Reasons = "GUV"
    elif (x["Strike"] == 0) & (x["Condition11"] == 1) & (x["Condition14"] == 1):
        Reasons = "EV"
    elif (x["Strike"] == 0) & (x["Condition7"] == 1):
        Reasons = "F"
    elif (x["Strike"] == 0) & (x["Condition8"] == 1):
        Reasons = "G"
    elif (x["Strike"] == 0) & (x["Condition9"] == 1):
        Reasons = "U"
    elif x["Strike"] == 0:
        Reasons = ""
    else:
        Reasons = ""
    return Reasons


# Update model used for State/WRC/product
def pfm_model_g(df):
    """
    Arguments:
    df -------> Pandas DataFrame returned from the "Hub"
                      nugget ID: id4HNQVXEIT1X and contains the data-points
                      where (Model >= "A" and Model <= "J")
                      or (Model >= "Q" and Model <= "T")

    Return:
    df -------> Pandas DataFrame returned from the filter node of
                        nugget id: "id5H7RCUSRNJQ"
    """
    '''
    Start Nugget ID: id5SZQ8XDIMTV
    End Nugget ID: id5H7RCUSRNJQ
    '''

    df.drop(labels=["S004", "G096", "G089", "RE30", "RE31", "G007",
                    "RE09", "MT01", "IHI01", "MT02", "AGE_IN_MONTHS"],
            axis=1, inplace=True)
    df.rename(columns={"PH_AGE": "age",
                       "G091": "apd",
                       "S064": "colldoll",
                       "G001": "del30d84m",
                       "AT20": "AOTL",
                       "RE20": "moldraop",
                       "G098": "inq06m",
                       "G061": "del30pd24m",
                       "G066": "del60pd24m",
                       "G071": "del90pd24m",
                       "G095": "mrecdpr",
                       "G093": "ndpr",
                       "AT36": "mrecdel",
                       "S011": "nopa",
                       "AT09": "aop24m",
                       "AT06": "aop06m",
                       "S012": "nopra",
                       "S060": "mophi",
                       "RE33": "rbal",
                       "RE28": "rlimit",
                       "G960": "inq24m",
                       "G002": "del60d84m",
                       "G003": "del90d84m",
                       "G094": "nbankrupt",
                       "G004": "del120d84m"}, inplace=True)

    df.drop(["del30d84m", "del30pd24m", "del60pd24m", "del90pd24m",
             "del60d84m", "del90d84m", "del120d84m"], axis=1, inplace=True)

    df.rename(columns={"apd": "APD",
                       "colldoll": "CollDoll",
                       "ndpr": "DPR84m",
                       "mrecdel": "mRecDel",
                       "aop24m": "AOP24m",
                       "mophi": "MOPhi",
                       "inq24m": "Inq24m"}, inplace=True)

    df["Strike"] = df.apply(f_model_G_Strike, axis=1)
    df["RC7"] = df.apply(f_model_G_RC7, axis=1)
    df["RC6"] = df.MOPhi.apply(lambda x: "H" if x > 0 else "")
    df["RC2"] = df.CollDoll.apply(lambda x: "B" if x > 0 else "")
    df["RC1"] = df.APD.apply(lambda x: "A" if x > 100 else "")
    df["RC5"] = df.Inq24m.apply(lambda x: "G" if x >= 8 else "")
    df["RC4"] = df.Leverage.apply(lambda x: "F" if x >= 0.80 else "")
    df["RC3"] = df.AOTL.apply(lambda x: "E" if x < 7.0 else "")
    df["Condition2"] = df.AOP24m.apply(lambda x: 1 if x >= 8 else 0)
    df["Condition3"] = df.Inq24m.apply(lambda x: 1 if x >= 10 else 0)
    df["Condition4"] = df.DPR24m.apply(lambda x: 1 if x > 0 else 0)
    df["Condition5"] = df.MOPhi.apply(lambda x: 1 if x > 0 else 0)
    df["Condition6"] = df.APD.apply(lambda x: 1 if x > 0 else 0)
    df["Condition7"] = df.Leverage.apply(lambda x: 1 if x >= 0.2 else 0)
    df["Condition8"] = df.Inq24m.apply(lambda x: 1 if x >= 4 else 0)
    df["Condition9"] = df.AOP24m.apply(lambda x: 1 if x >= 3 else 0)
    df["Condition10"] = df.mRecDel.apply(lambda x: 1 if x <= 24 else 0)
    df["Condition11"] = df.AOTL.apply(lambda x: 1 if x < 15 else 0)
    df["Condition12"] = df.AOP24m.apply(lambda x: 1 if x >= 5 else 0)
    df["Condition13"] = df.Inq24m.apply(lambda x: 1 if x >= 6 else 0)
    df["Condition14"] = df.mRecDel.apply(lambda x: 1 if x <= 60 else 0)
    df["Condition15"] = df.Inq24m.apply(lambda x: 1 if x == 7 else 0)

    df["Level"] = df.apply(f_model_G_level, axis=1)

    df["Reasons"] = df.apply(f_model_G_Reasons, axis=1)

    df["PFMScore"] = ""

    retain_cols = ["TRAN_ID", "TimeStamp", "CallingAppName", "GuidewireID", "GuidewireAccountNumber",
                   "PolicyNumber", "PolicySuffix", "GeneratedNumber",
                   "WritingCo", "PolEffDt", "PolAppDt", "ProviderStartDateTs",
                   "Model", "Level", "Reasons", "PFMScore"]
    df = df[retain_cols]
    return df
