##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Prakash Ranjan, Prabakar Subramani
# Creation Date          : 08FEB2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_model_m.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Model M
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################

# ------------------------------------------------------------------------

import numpy as np


def rlev(row):
    if row['rlimit'] == 0:
        return -1
    elif ((row['rbal'] > 0) & (row['rbal'] / row['rlimit'] < 0.01)):
        return 0.01
    else:
        return int((row['rbal'] / row['rlimit']) * 100) / 100


def fix_calculation(df):
    df['mrecdpr'] = df['mrecdpr'].replace(np.nan, 999)
    df['moldaop'] = df['moldaop'].replace(np.nan, -1)
    df['rlev'] = df.apply(rlev, axis=1)
    return df


def derogs(df):
    df['bankrupt_IN'] = np.where(df['State'] == "IN", 0, df['nbankrupt'])
    df['ndpr_IN'] = df.apply(lambda x: max(0, (x['ndpr']-x['nbankrupt'])) if x['State'] == 'IN' else x['ndpr'], axis=1)
    df['bankrupt60'] = np.where(df['mrecdpr'] < 60, df['bankrupt_IN'], 0)
    df['ndpr60'] = np.where(df['mrecdpr'] < 60, df['ndpr_IN'], 0)
    df['ntaxlien60'] = np.where(df['mrecdpr'] < 60, df['ntaxlien'], 0)
    df['dprflag'] = np.where(df['ndpr60'] > 0, 1, 0)
    df['collflag'] = np.where(df['colldoll'] > 0, 1, 0)
    df['mophiflag'] = np.where(df['mophi'] > 0, 1, 0)
    df['apdflag'] = np.where(df['apd'] >= 130, 1, 0)
    series = df['dprflag'] + df['collflag'] + df['mophiflag'] + df['apdflag']
    cond1 = series == 0
    df['derogs'] = np.where(cond1, np.where(df['apd'] > 0, 0.5, 0),
                            (df['dprflag'] +
                             df['collflag'] +
                             df['mophiflag'] +
                             df['apdflag']))
    return df


def aopFact(x):
    if x < 1:
        return 0.879
    elif x == 1:
        return 0.912
    elif x == 2:
        return 0.971
    elif x == 3:
        return 0.999
    elif x == 4:
        return 1.042
    elif x == 5:
        return 1.080
    elif x == 6:
        return 1.094
    elif x == 7:
        return 1.130
    elif x == 8:
        return 1.164
    elif x == 9:
        return 1.196
    elif x == 10:
        return 1.232
    else:
        return 1.257


def delFact(x):
    if x < 1:
        return 0.968
    elif x == 1:
        return 1.045
    elif x == 2:
        return 1.055
    elif x == 3:
        return 1.066
    elif x == 4:
        return 1.080
    elif x == 5:
        return 1.091
    elif x == 6:
        return 1.094
    elif x == 7:
        return 1.098
    elif x == 8:
        return 1.102
    elif x == 9:
        return 1.106
    elif x == 10:
        return 1.110
    elif x < 15:
        return 1.119
    elif x < 25:
        return 1.141
    elif x < 40:
        return 1.161
    else:
        return 1.182


def moldFact(x):
    if x < 0:
        return 1.177
    elif x < 12:
        return 1.384
    elif x < 24:
        return 1.261
    elif x < 36:
        return 1.169
    elif x < 60:
        return 1.149
    else:
        return 0.984


def nopaFact(x):
    if x < 1:
        return 1.196
    elif x == 1:
        return 1.092
    elif x == 2:
        return 1.072
    elif x == 3:
        return 1.058
    elif x == 4:
        return 1.037
    elif x == 5:
        return 1.013
    elif x == 6:
        return 0.997
    elif x == 7:
        return 0.978
    elif x == 8:
        return 0.969
    elif x == 9:
        return 0.972
    elif x == 10:
        return 0.973
    elif x == 11:
        return 0.974
    elif x == 12:
        return 0.975
    elif x == 13:
        return 0.978
    elif x == 14:
        return 0.979
    elif x == 15:
        return 0.981
    elif x == 16:
        return 0.982
    elif x == 17:
        return 0.984
    else:
        return 0.993


def rlevFact(x):
    if x < 0:
        return 1.081
    elif x == 0:
        return 1.008
    elif x < 0.05:
        return 0.941
    elif x < 0.18:
        return 0.962
    elif x < 0.25:
        return 0.983
    elif x < 0.35:
        return 0.998
    elif x < 0.50:
        return 1.019
    elif x < 0.75:
        return 1.048
    elif x < 1.00:
        return 1.078
    else:
        return 1.124


def score_factor(df):

    df['aopFact'] = df.aop24m.apply(aopFact)
    df['delFact'] = df.del30pd24m.apply(delFact)

    df['derogFact'] = np.where(df['derogs'] == 0, 0.952,
                               np.where(df['derogs'] == 0.5, 1.028,
                                        np.where(df['derogs'] == 1,
                                                 1.096, 1.148)))
    df['moldFact'] = df.moldaop.apply(moldFact)
    df['nopaFact'] = df.nopa.apply(nopaFact)
    df['rlevFact'] = df.rlev.apply(rlevFact)

    return df


def aopRR(x):
    if x < 1:
        return 999
    elif x == 1:
        return 119
    elif x == 2:
        return 113
    elif x == 3:
        return 109
    elif x == 4:
        return 103
    elif x == 5:
        return 98
    elif x == 6:
        return 94
    elif x == 7:
        return 87
    elif x == 8:
        return 81
    elif x == 9:
        return 73
    elif x == 10:
        return 62
    else:
        return 54


def delRR(x):
    if x < 1:
        return 999
    elif x == 1:
        return 100
    elif x == 2:
        return 96
    elif x == 3:
        return 91
    elif x == 4:
        return 86
    elif x == 5:
        return 84
    elif x == 6:
        return 83
    elif x == 7:
        return 74
    elif x == 8:
        return 71
    elif x == 9:
        return 64
    elif x == 10:
        return 55
    elif x < 15:
        return 44
    elif x < 25:
        return 24
    elif x < 40:
        return 2
    else:
        return 1


def moldRR(x):
    if x < 0:
        return 52
    elif x < 12:
        return 20
    elif x < 24:
        return 40
    elif x < 36:
        return 60
    elif x < 60:
        return 77
    else:
        return 999


def nopaRR(x):
    if x < 1:
        return 23
    elif x == 1:
        return 63
    elif x == 2:
        return 82
    elif x == 3:
        return 89
    elif x == 4:
        return 95
    elif x == 5:
        return 97
    elif x == 6:
        return 101
    elif x == 7:
        return 114
    elif x == 8:
        return 999
    elif x == 9:
        return 121
    elif x == 10:
        return 120
    elif x == 11:
        return 118
    elif x == 12:
        return 116
    elif x == 13:
        return 114
    elif x == 14:
        return 112
    elif x == 15:
        return 110
    elif x == 16:
        return 107
    elif x == 17:
        return 106
    else:
        return 105


def rlevRR(x):
    if x < 0:
        return 79
    elif x == 0:
        return 104
    elif x < 0.05:
        return 999
    elif x < 0.18:
        return 117
    elif x < 0.25:
        return 111
    elif x < 0.35:
        return 108
    elif x < 0.50:
        return 102
    elif x < 0.75:
        return 99
    elif x < 1.00:
        return 92
    else:
        return 41


def apdRR(x):
    if x >= 1300:
        return 3
    elif x >= 1200:
        return 4
    elif x >= 1100:
        return 5
    elif x >= 1000:
        return 6
    elif x >= 900:
        return 25
    elif x >= 800:
        return 26
    elif x >= 700:
        return 27
    elif x >= 600:
        return 28
    elif x >= 500:
        return 45
    elif x >= 400:
        return 46
    elif x >= 300:
        return 56
    elif x >= 200:
        return 65
    elif x >= 1:
        return 75
    else:
        return 999


def collRR(x):
    if x >= 3900:
        return 7
    elif x >= 3800:
        return 8
    elif x >= 3700:
        return 9
    elif x >= 3600:
        return 10
    elif x >= 3500:
        return 11
    elif x >= 3400:
        return 12
    elif x >= 3300:
        return 13
    elif x >= 3200:
        return 14
    elif x >= 3100:
        return 15
    elif x >= 3000:
        return 16
    elif x >= 2900:
        return 17
    elif x >= 2800:
        return 18
    elif x >= 2700:
        return 19
    elif x >= 2600:
        return 29
    elif x >= 2500:
        return 30
    elif x >= 2400:
        return 31
    elif x >= 2300:
        return 32
    elif x >= 2200:
        return 33
    elif x >= 2100:
        return 34
    elif x >= 2000:
        return 35
    elif x >= 1900:
        return 36
    elif x >= 1800:
        return 37
    elif x >= 1700:
        return 38
    elif x >= 1600:
        return 39
    elif x >= 1500:
        return 47
    elif x >= 1400:
        return 48
    elif x >= 1300:
        return 49
    elif x >= 1200:
        return 50
    elif x >= 1100:
        return 51
    elif x >= 1000:
        return 57
    elif x >= 900:
        return 58
    elif x >= 800:
        return 59
    elif x >= 700:
        return 66
    elif x >= 600:
        return 67
    elif x >= 500:
        return 72
    elif x >= 400:
        return 76
    elif x >= 300:
        return 78
    elif x >= 200:
        return 85
    elif x >= 100:
        return 88
    elif x >= 1:
        return 93
    else:
        return 999


def mophiRR(x):
    if x > 7:
        return 21
    elif x == 1:
        return 90
    elif x == 2:
        return 80
    elif x == 3:
        return 69
    elif x == 4:
        return 61
    elif x == 5:
        return 43
    elif x == 6:
        return 42
    elif x == 7:
        return 22
    else:
        return 999


def RR(row, x):
    existing_columns = [
        'apdRR',
        'collRR',
        'forecjRR',
        'moldRR',
        'rlevRR',
        'mophiRR',
        'bankruptRR',
        'taxlienRR',
        'aopRR',
        'nopaRR',
        'delRR']
    existing_columns.remove(x)
    c = 0
    for i in range(0, len(existing_columns)):
        if row[x] > row[existing_columns[i]]:
            c = c + 1
    return c + 1


def RC(row, x):
    if row['Level'] == "BD":
        return ""
    elif (row['RRA'] == x) & (row['apdRR'] < 999):
        return "A"
    elif (row['RRB'] == x) & (row['collRR'] < 999):
        return "B"
    elif (row['RRC'] == x) & (row['forecjRR'] < 999):
        return "C"
    elif (row['RRE'] == x) & (row['moldRR'] < 999):
        return "E"
    elif (row['RRF'] == x) & (row['rlevRR'] < 999):
        return "F"
    elif (row['RRH'] == x) & (row['mophiRR'] < 999):
        return "H"
    elif (row['RRK'] == x) & (row['bankruptRR'] < 999):
        return "K"
    elif (row['RRM'] == x) & (row['taxlienRR'] < 999):
        return "M"
    elif (row['RRU'] == x) & (row['aopRR'] < 999):
        return "U"
    elif (row['RR2'] == x) & (row['nopaRR'] < 999):
        return "2"
    elif (row['RR3'] == x) & (row['delRR'] < 999):
        return "3"
    else:
        return ""


def Reason_rank(df):

    df['aopRR'] = df.aop24m.apply(aopRR)
    df['delRR'] = df.del30pd24m.apply(delRR)
    df['moldRR'] = df.moldaop.apply(moldRR)
    df['nopaRR'] = df.nopa.apply(nopaRR)
    df['rlevRR'] = df.rlev.apply(rlevRR)
    df['apdRR'] = df.apd.apply(apdRR)
    df['collRR'] = df.colldoll.apply(collRR)
    df['mophiRR'] = df.mophi.apply(mophiRR)
    df['bankruptRR'] = np.where(df['bankrupt60'] > 0, 70, 999)
    df['taxlienRR'] = np.where(df['ntaxlien60'] > 0, 53, 999)
    cond1 = df['bankrupt60'] + df['ntaxlien60'] > 0
    df['forecjRR'] = np.where(cond1, 999, np.where(df['ndpr60'] > 0, 68, 999))
    existing_columns = [
        'apdRR',
        'collRR',
        'forecjRR',
        'moldRR',
        'rlevRR',
        'mophiRR',
        'bankruptRR',
        'taxlienRR',
        'aopRR',
        'nopaRR',
        'delRR']
    new_columns = [
        'RRA',
        'RRB',
        "RRC",
        "RRE",
        "RRF",
        "RRH",
        "RRK",
        "RRM",
        "RRU",
        "RR2",
        "RR3"]
    for i in range(0, len(existing_columns)):
        df[new_columns[i]] = df.apply(RR, x=existing_columns[i], axis=1)

    df['RC1'] = df.apply(RC, x=1, axis=1)
    df['RC2'] = df.apply(RC, x=2, axis=1)
    df['RC3'] = df.apply(RC, x=3, axis=1)
    df['RC4'] = df.apply(RC, x=4, axis=1)
    df['RC5'] = df.apply(RC, x=5, axis=1)
    df['Reasons'] = df['RC1'] + df['RC2'] + df['RC3'] + df['RC4'] + df['RC5']

    return df


def score(row):
    return max(10, min(999, round((705.99 * row['aopFact'] * row['delFact'] *
                                   row['derogFact'] * row['moldFact'] * row['nopaFact'] * row['rlevFact']) - 508)))


def Level(x):
    if (x >= 10) & (x < 26):
        return "BD"
    elif (x >= 26) & (x < 37):
        return "BH"
    elif (x >= 37) & (x < 49):
        return "BL"
    elif (x >= 49) & (x < 62):
        return "BP"
    elif (x >= 62) & (x < 68):
        return "BT"
    elif (x >= 68) & (x < 76):
        return "BW"
    elif (x >= 76) & (x < 84):
        return "CD"
    elif (x >= 84) & (x < 92):
        return "CH"
    elif (x >= 92) & (x < 102):
        return "CL"
    elif (x >= 102) & (x < 109):
        return "CP"
    elif (x >= 109) & (x < 118):
        return "CT"
    elif (x >= 118) & (x < 127):
        return "CW"
    elif (x >= 127) & (x < 130):
        return "DD"
    elif (x >= 130) & (x < 139):
        return "DG"
    elif (x >= 139) & (x < 146):
        return "DJ"
    elif (x >= 146) & (x < 154):
        return "DN"
    elif (x >= 154) & (x < 163):
        return "DQ"
    elif (x >= 163) & (x < 174):
        return "DT"
    elif (x >= 174) & (x < 184):
        return "DW"
    elif (x >= 184) & (x < 195):
        return "ED"
    elif (x >= 195) & (x < 206):
        return "EG"
    elif (x >= 206) & (x < 218):
        return "EJ"
    elif (x >= 218) & (x < 230):
        return "EN"
    elif (x >= 230) & (x < 244):
        return "EQ"
    elif (x >= 244) & (x < 259):
        return "ET"
    elif (x >= 259) & (x < 264):
        return "EW"
    elif (x >= 264) & (x < 283):
        return "FD"
    elif (x >= 283) & (x < 304):
        return "FG"
    elif (x >= 304) & (x < 325):
        return "FJ"
    elif (x >= 325) & (x < 341):
        return "FN"
    elif (x >= 341) & (x < 357):
        return "FQ"
    elif (x >= 357) & (x < 371):
        return "FT"
    elif (x >= 371) & (x < 389):
        return "FW"
    elif (x >= 389) & (x < 411):
        return "GD"
    elif (x >= 411) & (x < 425):
        return "GH"
    elif (x >= 425) & (x < 439):
        return "GL"
    elif (x >= 439) & (x < 454):
        return "GP"
    elif (x >= 454) & (x < 466):
        return "GT"
    elif (x >= 466) & (x < 485):
        return "HD"
    elif (x >= 485) & (x < 501):
        return "HH"
    elif (x >= 501) & (x < 529):
        return "HL"
    elif (x >= 529) & (x < 566):
        return "HP"
    elif (x >= 566) & (x < 636):
        return "HT"
    elif (x >= 636) & (x <= 999):
        return "HW"


def pfm_model_m(df):
    df = df[df['Model'] == 'M']
    df = fix_calculation(df)
    df = derogs(df)
    df = score_factor(df)
    df['score'] = df.apply(score, axis=1)
    df['Level'] = df.score.apply(Level)
    df = Reason_rank(df)
    df = df.rename(columns={'score': 'PFMScore'})

    return df
