##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Sreedhar Muthukrishnan Viswanathan,
#                          Prabakar Subramani
# Creation Date          : 08FEB2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_model_k.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Model K
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################

# ------------------------------------------------------------------------

import re
import math

import numpy as np
import pandas as pd


from ds_functions import load_pickle
from gw_pfm_539_ds_functions import cat_encoding_scoring
from gw_pfm_539_read_model_data import read_model_data


def f_model_K_deliveryVars_dprflag(x):
    if (x["State"] == "IN") & (x["nbankrupt"] >= x["ndpr"]):
        return 0
    elif (x["ndpr"] > 0) & (x["mrecdpr"] >= 0) & (x["mrecdpr"] < 84):
        return 1
    else:
        return 0


def f_model_K_deliveryVars_Rlev_calc(x):

    if (x["rlimit"] <= 0):
        return -1
    elif (x["rbal"] > 0) & (x["rbal"] / x["rlimit"] < 0.01):
        return 0.01
    else:
        return int((x["rbal"] / x["rlimit"]) * 100) / 100


def f_model_K_deliveryVars_submodel(x):

    if x["nopa"] < 4:
        if (x["age"] < 65) or (np.isnan(x["age"])):
            return "D"
        else:
            return "C"
    elif (((x["age"] >= 35) & (x["age"] < 65)) or (np.isnan(x["age"]))):
        return "A"
    elif x["age"] < 35:
        return "B"
    elif x["age"] >= 65:
        return "C"
    else:
        return "Z"


def f_model_K_deliveryVars(df):

    fill_blanks_zero_cols = ["aop06m", "aop24m", "rlimit", "rbal",
                             "del30d84m", "del60d84m", "del90d84m",
                             "del30pd24m", "del60pd24m", "del90pd24m",
                             "apd", "ndpr", "nbankrupt", "inq24m",
                             "inq06m", "nopa", "nopra", "mophi", "dpramt",
                             "colldoll", "ntaxlien"]

    df[fill_blanks_zero_cols] = df[fill_blanks_zero_cols].fillna(0, axis=1)

    fill_blanks_nulls_cols = ["moldaop", "mrecdel", "moldraop", "mrecdpr"]
    df[fill_blanks_nulls_cols] = df[fill_blanks_nulls_cols].fillna(
        -1, axis=1).replace('', -1)

    df["del30d24m"] = df["del30pd24m"] - df["del60pd24m"]
    df["del60d24m"] = df["del60pd24m"] - df["del90pd24m"]
    df["delw24_123"] = (df["del30d24m"] * 1) + \
        (df["del60d24m"] * 2) + (df["del90pd24m"] * 3)
    df["delw24_111"] = df["del30d24m"] + df["del60d24m"] + df["del90pd24m"]
    df["delw84_123"] = (df["del30d84m"] * 1) + \
        (df["del60d84m"] * 2) + (df["del90d84m"] * 3)
    df["delw84_111"] = df["del30d84m"] + df["del60d84m"] + df["del90d84m"]
    df["delwdif_123"] = df["delw84_123"] - df["delw24_123"]
    df["delwdif_111"] = df["delw84_111"] - df["delw24_111"]
    df["inqdif"] = df["inq24m"] - df["inq06m"]
    df["nopdif"] = df["nopa"] - df["nopra"]
    df["aopdif"] = df["aop24m"] - df["aop06m"]
    df["iadif"] = df["inq24m"] - df["aop24m"]
    df["aopratio"] = df.apply(lambda x: x["aop24m"] / x["nopa"] if x["nopa"] > 0 else -1, axis=1)
    df["dprflag"] = df.apply(f_model_K_deliveryVars_dprflag, axis=1)
    # if State="IN" and nbankrupt>=ndpr: return 0 elif ndpr > 0 and mrecdpr >=
    # 0 and mrecdpr < 84: return 1 else 0 endif endif
    # if colldoll > 0: return 1 else 0 endif
    df["collflag"] = df.colldoll.apply(lambda x: 1 if x > 0 else 0)
    df["mopflag"] = df.mophi.apply(lambda x: 1 if x > 0 else 0)
    df["apdflag"] = df.apd.apply(lambda x: 1 if x >= 130 else 0)
    df["derogs"] = df.apply(lambda x: 0.5 if (x["dprflag"] + x["collflag"] + x["mopflag"] + x["apdflag"] == 0) & (x["apd"] > 0) else (x["dprflag"] + x["collflag"] + x["mopflag"] + x["apdflag"]), axis=1)
    df["Rlev_calc"] = df.apply(f_model_K_deliveryVars_Rlev_calc, axis=1)
    df["arlim"] = df.apply(lambda x: x["rlimit"] / x["nopra"] if x["nopra"] > 0 else -1, axis=1)
    df["submodel"] = df.apply(f_model_K_deliveryVars_submodel, axis=1)

    return df


def f_model_K_pfmstorebins_aopratio(row):
    if row < 0:
        return 1
    elif row < 0.1:
        return 2
    elif row < 0.2:
        return 3
    elif row < 0.3:
        return 4
    elif row < 0.4:
        return 5
    elif row < 0.5:
        return 6
    elif row < 0.6:
        return 7
    elif row < 0.7:
        return 8
    elif row < 0.8:
        return 9
    elif row < 0.9:
        return 10
    elif row < 1:
        return 11
    else:
        return 12


def f_model_K_pfmstorebins_del_group(row):
    if row < 1:
        return 0
    elif row < 5:
        return row
    elif row < 8:
        return 5
    elif row < 10:
        return 8
    elif row < 11:
        return 10
    elif row < 15:
        return 11
    elif row < 25:
        return 15
    elif row < 40:
        return 25
    else:
        return 40


def f_model_K_pfmstorebins_derog_group(row, colname):
    if row["derogs"] >= 1:
        return 1
    elif row[colname] > 0:
        return 0
    else:
        return row["derogs"]


def f_model_K_pfmstorebins_del_derog123_group(row):
    if row["del123_group"] >= 10:
        return str(row["derog123_group"])[:3] + "_" + str(row["del123_group"])
    else:
        return str(row["derog123_group"])[:3] + "_0" + str(row["del123_group"])


def f_model_K_pfmstorebins_del_derog111_group(row):
    if row["del111_group"] >= 10:
        return str(row["derog111_group"])[:3] + "_" + str(row["del111_group"])
    else:
        return str(row["derog111_group"])[:3] + "_0" + str(row["del111_group"])


def f_model_K_pfmstorebins_del_derog_b(x):
    if x == "0.0_00":
        return 1
    if x == "0.0_01":
        return 3
    if x == "0.0_02":
        return 4
    if x == "0.0_03":
        return 5
    if x == "0.0_04":
        return 6
    if (x == "0.0_05") or (x == "0.0_08"):
        return 7
    if (x == "0.0_10") or (x == "0.0_11") or (
            x == "0.0_15") or (x == "0.0_25") or (x == "0.0_40"):
        return 8
    if x == "0.5_00":
        return 2
    if x == "1.0_00":
        return 9
    if x == "1.0_01":
        return 10
    if x == "1.0_02":
        return 11
    if x == "1.0_03":
        return 12
    if x == "1.0_04":
        return 13
    if x == "1.0_05":
        return 14
    if (x == "1.0_08") or (x == "1.0_10"):
        return 15
    if x == "1.0_11":
        return 16
    if x == "1.0_15":
        return 17
    if x == "1.0_25":
        return 18
    if x == "1.0_40":
        return 19


def f_model_K_pfmstorebins_delw_b(x):
    if x < 1:
        return 1
    elif x < 4:
        return 2
    elif x < 7:
        return 3
    elif x < 10:
        return 4
    elif x < 15:
        return 5
    elif x < 20:
        return 6
    elif x < 30:
        return 7
    elif x < 40:
        return 8
    elif x < 60:
        return 9
    elif x < 80:
        return 10
    elif x < 100:
        return 11
    elif x < 125:
        return 12
    else:
        return 13


def f_model_K_pfmstorebins_delwdif_b(x):
    if x < 1:
        return 1
    elif x < 10:
        return x + 1
    elif x < 12:
        return 11
    elif x < 15:
        return 12
    elif x < 18:
        return 13
    elif x < 21:
        return 14
    elif x < 25:
        return 15
    elif x < 30:
        return 16
    elif x < 50:
        return 17
    elif x < 70:
        return 18
    else:
        return 19


def f_model_K_pfmstorebins_derogflags_b(x):
    if x == 0:
        return 1
    elif x < 1:
        return 2
    elif x < 2:
        return 3
    else:
        return 4


def f_model_K_pfmstorebins_ia24diff_b(x):
    if x < 0:
        return 1
    elif x < 10:
        return x + 2
    elif x < 12:
        return 12
    elif x < 15:
        return 13
    else:
        return 14


def f_model_K_pfmstorebins_inq6m2_b(x):
    if x < 1:
        return 1
    elif x < 10:
        return x + 1
    else:
        return 11


def f_model_K_pfmstorebins_inq24m2_b(x):
    if x < 1:
        return 1
    elif x < 11:
        return x + 1
    elif x < 13:
        return 12
    elif x < 15:
        return 13
    elif x < 17:
        return 14
    elif x < 20:
        return 15
    elif x < 25:
        return 16
    else:
        return 17


def f_model_K_pfmstorebins_inqdiff2_b(x):
    if x < 1:
        return 1
    elif x < 8:
        return x + 1
    elif x < 10:
        return 9
    elif x < 12:
        return 10
    elif x < 15:
        return 11
    else:
        return 12


def f_model_K_pfmstorebins_moldaop2_b(x):
    if x < 0:
        return 1
    elif x < 12:
        return 2
    elif x < 24:
        return 3
    elif x < 36:
        return 4
    elif x < 60:
        return 5
    elif x < 96:
        return 6
    elif x < 120:
        return 7
    elif x < 144:
        return 8
    elif x < 156:
        return 9
    elif x < 192:
        return 10
    elif x < 300:
        return 11
    elif x < 360:
        return 12
    else:
        return 13


def f_model_K_pfmstorebins_moldraop2_b(x):
    if x < 0:
        return 1
    elif x < 24:
        return 2
    elif x < 60:
        return 3
    elif x < 108:
        return 4
    elif x < 132:
        return 5
    elif x < 168:
        return 6
    elif x < 216:
        return 7
    elif x < 300:
        return 8
    else:
        return 9


def f_model_K_pfmstorebins_nopracct2_b(x):
    if x < 1:
        return 1
    elif x < 18:
        return x + 1
    else:
        return 19


def f_model_K_pfmstorebins_nopdiff2_b(x):
    if x < 1:
        return 1
    elif x < 3:
        return x + 1
    else:
        return 4


def f_model_K_pfmstorebins_rlev_group(row):
    if row["Rlev_calc"] < 0:
        return -1
    elif row["rbal"] == 0:
        return 0
    elif row["Rlev_calc"] < 0.05:
        return 1
    elif row["Rlev_calc"] < 0.18:
        return 2
    elif row["Rlev_calc"] < 1:
        return 3
    else:
        return 4


def f_model_K_pfmstorebins_arlim_group(x):
    if x < 1:
        return "-1"
    elif x == 0:
        return "00000"
    elif x < 100:
        return "00001"
    elif x < 1250:
        return "00100"
    elif x < 2250:
        return "01250"
    elif x < 3250:
        return "02250"
    elif x < 6000:
        return "03250"
    elif x < 10000:
        return "06000"
    else:
        return "10000"


def f_model_K_pfmstorebins_rlev_arlim_b(x):
    if x == "-1_-1":
        return 1
    elif x == "-1_00000":
        return 1
    elif x == "-1_00001":
        return 1
    elif x == "-1_00100":
        return 1
    elif x == "-1_01250":
        return 1
    elif x == "-1_02250":
        return 1
    elif x == "-1_03250":
        return 1
    elif x == "-1_06000":
        return 1
    elif x == "-1_10000":
        return 1
    elif x == "0_-1":
        return 1
    elif x == "0_00000":
        return 1
    elif x == "0_00001":
        return 2
    elif x == "0_00100":
        return 3
    elif x == "0_01250":
        return 3
    elif x == "0_02250":
        return 3
    elif x == "0_03250":
        return 3
    elif x == "0_06000":
        return 3
    elif x == "0_10000":
        return 3
    elif x == "1_-1":
        return 1
    elif x == "1_00000":
        return 1
    elif x == "1_00001":
        return 2
    elif x == "1_00100":
        return 4
    elif x == "1_01250":
        return 5
    elif x == "1_02250":
        return 6
    elif x == "1_03250":
        return 7
    elif x == "1_06000":
        return 8
    elif x == "1_10000":
        return 9
    elif x == "2_-1":
        return 1
    elif x == "2_00000":
        return 1
    elif x == "2_00001":
        return 2
    elif x == "2_00100":
        return 4
    elif x == "2_01250":
        return 5
    elif x == "2_02250":
        return 10
    elif x == "2_03250":
        return 11
    elif x == "2_06000":
        return 12
    elif x == "2_10000":
        return 13
    elif x == "3_-1":
        return 1
    elif x == "3_00000":
        return 1
    elif x == "3_00001":
        return 2
    elif x == "3_00100":
        return 14
    elif x == "3_01250":
        return 15
    elif x == "3_02250":
        return 16
    elif x == "3_03250":
        return 17
    elif x == "3_06000":
        return 18
    elif x == "3_10000":
        return 19
    elif x == "4_-1":
        return 1
    elif x == "4_00000":
        return 1
    elif x == "4_00001":
        return 2
    elif x == "4_00100":
        return 20
    elif x == "4_01250":
        return 20
    elif x == "4_02250":
        return 20
    elif x == "4_03250":
        return 20
    elif x == "4_06000":
        return 20
    elif x == "4_10000":
        return 20
    else:
        return 0


def f_model_K_pfmstorebins_rlev_b(row):
    if row["Rlev_calc"] < 0:
        return 1
    elif row["rbal"] == 0:
        return 2
    elif row["Rlev_calc"] < 0.05:
        return 3
    elif row["Rlev_calc"] < 0.18:
        return 4
    elif row["Rlev_calc"] < 0.25:
        return 5
    elif row["Rlev_calc"] < 0.35:
        return 6
    elif row["Rlev_calc"] < 0.50:
        return 7
    elif row["Rlev_calc"] < 0.75:
        return 8
    elif row["Rlev_calc"] < 1:
        return 9
    elif row["Rlev_calc"] == 1:
        return 10
    else:
        return 11


def f_model_K_pfmstorebins(df):
    df["aop24m2_b"] = df["aop24m"].apply(lambda x: 12 if x > 10 else x + 1)
    df["aopdiff2_b"] = df["aopdif"].apply(lambda x: 4 if x > 2 else x + 1)
    df["aopratio_b"] = df["aopratio"].apply(f_model_K_pfmstorebins_aopratio)
    df["del123_group"] = df["delw24_123"].apply(
        f_model_K_pfmstorebins_del_group)
    df["del111_group"] = df["delw24_111"].apply(
        f_model_K_pfmstorebins_del_group)
    df["derog123_group"] = df.apply(
        lambda x: f_model_K_pfmstorebins_derog_group(
            x, "delw24_123"), axis=1)
    df["derog111_group"] = df.apply(
        lambda x: f_model_K_pfmstorebins_derog_group(
            x, "delw24_111"), axis=1)
    #######################################################################
    df["derog123_group"] = df["derog123_group"].astype(float)
    #######################################################################

    df["del_derog123_group"] = df.apply(
        lambda x: f_model_K_pfmstorebins_del_derog123_group(x), axis=1)
    #######################################################################
    df["derog111_group"] = df["derog111_group"].astype(float)
    #######################################################################

    df["del_derog111_group"] = df.apply(
        lambda x: f_model_K_pfmstorebins_del_derog111_group(x), axis=1)
    df["del123_derog_b"] = df["del_derog123_group"].apply(
        f_model_K_pfmstorebins_del_derog_b)
    df["del111_derog_b"] = df["del_derog111_group"].apply(
        f_model_K_pfmstorebins_del_derog_b)
    df["delw84_123_b"] = df["delw84_123"].apply(f_model_K_pfmstorebins_delw_b)
    df["delw84_111_b"] = df["delw84_111"].apply(f_model_K_pfmstorebins_delw_b)
    df["delw24_123_b"] = df["delw24_123"].apply(f_model_K_pfmstorebins_delw_b)
    df["delw24_111_b"] = df["delw24_111"].apply(f_model_K_pfmstorebins_delw_b)
    df["delwdif123_b"] = df["delwdif_123"].apply(
        f_model_K_pfmstorebins_delwdif_b)
    df["delwdif111_b"] = df["delwdif_111"].apply(
        f_model_K_pfmstorebins_delwdif_b)
    df["derogflags_b"] = df["derogs"].apply(
        f_model_K_pfmstorebins_derogflags_b)
    df["ia24diff_b"] = df["iadif"].apply(f_model_K_pfmstorebins_ia24diff_b)
    df["inq6m2_b"] = df["inq06m"].apply(f_model_K_pfmstorebins_inq6m2_b)
    df["inq24m2_b"] = df["inq24m"].apply(f_model_K_pfmstorebins_inq24m2_b)
    df["inqdiff2_b"] = df["inqdif"].apply(f_model_K_pfmstorebins_inqdiff2_b)
    df["moldaop2_b"] = df["moldaop"].apply(f_model_K_pfmstorebins_moldaop2_b)
    df["moldraop2_b"] = df["moldraop"].apply(
        f_model_K_pfmstorebins_moldraop2_b)
    df["nopacct2_b"] = df["nopa"].apply(lambda x: x+1 if x < 18 else 19)
    df["nopracct2_b"] = df["nopra"].apply(f_model_K_pfmstorebins_nopracct2_b)
    df["nopdiff2_b"] = df["nopdif"].apply(f_model_K_pfmstorebins_nopdiff2_b)
    df["rlev_group"] = df.apply(
        lambda x: f_model_K_pfmstorebins_rlev_group(x), axis=1)
    df["arlim_group"] = df["arlim"].apply(f_model_K_pfmstorebins_arlim_group)
    df["rlev_arlim_group"] = df["rlev_group"].astype(
        str) + "_" + df["arlim_group"]
    df["rlev_arlim_b"] = df["rlev_arlim_group"].apply(
        f_model_K_pfmstorebins_rlev_arlim_b)
    df["rlev_b"] = df.apply(lambda x: f_model_K_pfmstorebins_rlev_b(x), axis=1)
    df["del123_derog_b_integer"] = df["del123_derog_b"].astype(int)
    df["del111_derog_b_integer"] = df["del111_derog_b"].astype(int)
    df["rlev_arlim_b_integer"] = df["rlev_arlim_b"].astype(int)
    df = df.drop(
        labels=[
            "del123_derog_b",
            "del111_derog_b",
            "rlev_arlim_b"],
        axis=1)
    rename_cols_dict = {"del123_derog_b_integer": "del123_derog_b", "del111_derog_b_integer": "del111_derog_b",
                        "rlev_arlim_b_integer": "rlev_arlim_b"}
    df.rename(columns=rename_cols_dict, inplace=True)

    return df


def f_model_K_preptoscore(df):
    rename_cols_dict = {"delw84_123": "del84m2", "aop24m2_b": "aop24_b", "aopdiff2_b": "aopdif_b",
                        "aopratio_b": "aoprat_b", "delw84_123_b": "delw84_b", "delwdif123_b": "delwdif_b",
                        "derogflags_b": "derogs_b", "ia24diff_b": "iadif_b", "inq6m2_b": "inq06_b",
                        "inq24m2_b": "inq24_b", "inqdiff2_b": "inqdif_b", "moldaop2_b": "molda_b",
                        "moldraop2_b": "moldra_b", "nopacct2_b": "nopa_b", "nopracct2_b": "nopra_b",
                        "nopdiff2_b": "nopdif_b", "del123_derog_b": "del_derog_b"}

    df.rename(columns=rename_cols_dict, inplace=True)

    dummy_vars_dict = {"aop24_b": np.arange(1, 13), "aopdif_b": np.arange(1, 5), "aoprat_b": np.arange(1, 13),
                       "del_derog_b": np.arange(1, 20), "delw84_b": np.arange(1, 14), "delwdif_b": np.arange(1, 20),
                       "derogs_b": np.arange(1, 5), "iadif_b": np.arange(1, 15), "inq06_b": np.arange(1, 12),
                       "inq24_b": np.arange(1, 18), "inqdif_b": np.arange(1, 13), "molda_b": np.arange(1, 14),
                       "moldra_b": np.arange(1, 10), "nopa_b": np.arange(1, 20), "nopdif_b": np.arange(1, 5),
                       "nopra_b": np.arange(1, 20), "rlev_arlim_b": np.arange(1, 21)}

    appended_df, dummy_cols_list = cat_encoding_scoring(
        dummy_vars_dict, df, drop_first=False)

    cols_to_drop = ["mrecdel", "aop06m", "aop24m", "rlimit", "moldaop", "del30pd24m", "nopa", "rbal", "del90pd24m",
                    "del30d84m", "moldraop", "nopra", "inq06m", "del60pd24m", "inq24m", "del60d84m", "del90d84m",
                    "del30d24m", "del60d24m", "delw24_123", "delw24_111", "del84m2", "delw84_111", "delwdif_123",
                    "delwdif_111", "inqdif", "nopdif", "aopdif", "iadif", "aopratio", "dprflag", "collflag", "mopflag",
                    "apdflag", "derogs", "Rlev_calc", "arlim", "aop24_b", "aopdif_b", "aoprat_b", "del123_group",
                    "del111_group", "derog123_group", "derog111_group", "del_derog123_group", "del_derog111_group",
                    "delw84_b", "delw84_111_b", "delw24_123_b", "delw24_111_b", "delwdif_b", "delwdif111_b", "derogs_b",
                    "iadif_b", "inq06_b", "inq24_b", "inqdif_b", "molda_b", "moldra_b", "nopa_b", "nopra_b", "nopdif_b",
                    "rlev_group", "arlim_group", "rlev_arlim_group", "rlev_b", "del_derog_b", "del111_derog_b", "rlev_arlim_b"]
    appended_df = appended_df.drop(labels=cols_to_drop, axis=1)

    return appended_df


def f_model_K(df):

    df = df[df["Model"] == "K"]
    df_model_K_deliveryVars = f_model_K_deliveryVars(df)
    df_model_K_pfmstorebins = f_model_K_pfmstorebins(df_model_K_deliveryVars)
    df_model_K_preptoscore = f_model_K_preptoscore(df_model_K_pfmstorebins)

    return df_model_K_preptoscore


def df_model_K_submodel_Kscore(row):
    return min(max(
        int(((math.exp(row["LnScore"]) * row["Constant"] * 600) - 175) + 0.5), 10), 999)


def df_model_K_submodel_Level(row):
    if row["Kscore"] < 10:
        return ''
    elif row["Kscore"] < 56:
        return 'BD'
    elif row["Kscore"] < 75:
        return 'BH'
    elif row["Kscore"] < 88:
        return 'BL'
    elif row["Kscore"] < 99:
        return 'BP'
    elif row["Kscore"] < 109:
        return 'BT'
    elif row["Kscore"] < 117:
        return 'BW'
    elif row["Kscore"] < 124:
        return 'CD'
    elif row["Kscore"] < 131:
        return 'CH'
    elif row["Kscore"] < 138:
        return 'CL'
    elif row["Kscore"] < 144:
        return 'CP'
    elif row["Kscore"] < 150:
        return 'CT'
    elif row["Kscore"] < 156:
        return 'CW'
    elif row["Kscore"] < 158:
        return 'DD'
    elif row["Kscore"] < 163:
        return 'DG'
    elif row["Kscore"] < 169:
        return 'DJ'
    elif row["Kscore"] < 175:
        return 'DN'
    elif row["Kscore"] < 181:
        return 'DQ'
    elif row["Kscore"] < 188:
        return 'DT'
    elif row["Kscore"] < 195:
        return 'DW'
    elif row["Kscore"] < 201:
        return 'ED'
    elif row["Kscore"] < 208:
        return 'EG'
    elif row["Kscore"] < 216:
        return 'EJ'
    elif row["Kscore"] < 225:
        return 'EN'
    elif row["Kscore"] < 234:
        return 'EQ'
    elif row["Kscore"] < 243:
        return 'ET'
    elif row["Kscore"] < 247:
        return 'EW'
    elif row["Kscore"] < 260:
        return 'FD'
    elif row["Kscore"] < 275:
        return 'FG'
    elif row["Kscore"] < 291:
        return 'FJ'
    elif row["Kscore"] < 303:
        return 'FN'
    elif row["Kscore"] < 316:
        return 'FQ'
    elif row["Kscore"] < 331:
        return 'FT'
    elif row["Kscore"] < 348:
        return 'FW'
    elif row["Kscore"] < 369:
        return 'GD'
    elif row["Kscore"] < 382:
        return 'GH'
    elif row["Kscore"] < 396:
        return 'GL'
    elif row["Kscore"] < 410:
        return 'GP'
    elif row["Kscore"] < 426:
        return 'GT'
    elif row["Kscore"] < 446:
        return 'HD'
    elif row["Kscore"] < 470:
        return 'HH'
    elif row["Kscore"] < 503:
        return 'HL'
    elif row["Kscore"] < 549:
        return 'HP'
    elif row["Kscore"] < 641:
        return 'HT'
    elif row["Kscore"] <= 999:
        return 'HW'
    else:
        return ''


def df_model_K_submodel_APD_bin(x):
    if x == 0:
        return 0
    elif x < 200:
        return 1
    elif x >= 1300:
        return 13
    else:
        return int(x / 100)


def df_model_K_submodel_Coll_bin(x):
    if x == 0:
        return 0
    elif x < 100:
        return 1
    elif x >= 3900:
        return 40
    else:
        return int(x / 100) + 1


def get_linear_score(data, target, model_name, nugg_id, model_coeff_dict):
    """
    Function to calculate the score from linear regression model. Model
    coefficients are read from the pickle object present in the pickle file
    path passed via argument.

    Arguments:
    data -------> Pandas DataFrame containing the columns which will chosen
                  as features (Predictors (or) Inputs).
    target -------> Column name where the predicted score will be saved
                    (Target (or) Output).
    model_name -------> Name of the model for which the model coefficients
                        are stored in the pickle object.
    nugg_id -------> Nugget ID of the node of the Regression model.
    pkl_file_path -------> File path of the pickle object.

    Return:
    data -------> Pandas DataFrame containing the orginal columns and also
                  the predicted linear score in the target column.
    """
    model_data = read_model_data(model_name, nugg_id, pkl_obj_dict=model_coeff_dict)

    model_data["weights"] = pd.to_numeric(model_data["beta"])

    constant = 0
    constant_index = []
    for index, row in model_data.iterrows():
        if re.search(r"constant", row["parameterName"], re.I):
            constant_index.append(index)
            constant = float(row["weights"])
            break
    model_data.drop(constant_index, axis=0, inplace=True)

    model_data.drop(["df", "targetCategory"], axis=1, inplace=True)
    model_data.set_index("parameterName", inplace=True)

    param_names = model_data.index.values

    data[target] = np.dot(data[param_names].values, model_data["weights"].values) + constant

    return data


def submodel_scoring(model_K_prep_df, params_dict, model_coeff_dict, id_vars):
    submodel_val = params_dict['submodel_val']
    model_name = params_dict['model_name']
    nugget_id = params_dict['nugget_id']
    constant_val = params_dict['constant_val']

    df_model_K_submodel = model_K_prep_df[model_K_prep_df["submodel"] == submodel_val]
    if not df_model_K_submodel.empty:
        scored_df = get_linear_score(df_model_K_submodel, "LnScore", model_name, nugget_id, model_coeff_dict)
        scored_df["Constant"] = constant_val
        scored_df["Kscore"] = scored_df.apply(lambda x: df_model_K_submodel_Kscore(x), axis=1)
        scored_df["Level"] = scored_df.apply(df_model_K_submodel_Level, axis=1)
        scored_df["APD_bin"] = scored_df["apd"].apply(df_model_K_submodel_APD_bin)
        scored_df["Coll_bin"] = scored_df["colldoll"].apply(df_model_K_submodel_Coll_bin)
        scored_df["MOPhi_bin"] = scored_df["mophi"].apply(lambda x: 9 if x >= 8 else x + 1)
        scored_df["Bankrupt_flag"] = scored_df["nbankrupt"].apply(lambda x: 1 if x > 0 else 0)
        scored_df["Taxlien_flag"] = scored_df["ntaxlien"].apply(lambda x: 1 if x > 0 else 0)
        scored_df["DPRother_flag"] = scored_df.apply(lambda x: 1 if (x["ndpr"] - x["nbankrupt"] - x["ntaxlien"]) > 0 else 0, axis=1)
        return scored_df
    else:
        return df_model_K_submodel


def SubA_RC_zero_out_low_prob(x, pred_var1):

    for i in range(len(pred_var1)):
        x[pred_var1[i]] = np.where(x[pred_var1[i]] < 0.01, 0, x[pred_var1[i]])
        # if (x[i] < 0.01):
        #     x[i] = 0
        # else:
        #     x[i] = x[i]
    return x


def SubA_RC_PredRC_C(row):
    if row["nbankrupt"] + row["ntaxlien"] > 0:
        val = 0
    elif row["ndpr"] > 0:
        val = 0.99
    else:
        val = 0
    return val


def func_PredRC(row, target_cat, target):
    if row[target_cat] == 0:
        val = 1 - row[target]
    else:
        val = row[target]
    return val


def get_logistic_score(data, target, target_cat, model_name, nugg_id, model_coeff_dict):
    model_data = read_model_data(model_name, nugg_id, pkl_obj_dict=model_coeff_dict)

    model_data["weights"] = pd.to_numeric(model_data["beta"])

    constant = 0
    constant_index = []
    for index, row in model_data.iterrows():
        if (re.search(r"P0000001", row["predictorName"], re.I)):
            if (row["weights"] != 0) & (constant_index == []):
                constant = float(row["weights"])
                constant_index.append(index)
            else:
                constant_index.append(index)

    model_data.drop(constant_index, axis=0, inplace=True)

    model_data.drop(["df", "targetCategory"], axis=1, inplace=True)
    model_data.set_index("predictorName", inplace=True)

    param_names = model_data.index.values.tolist()

    data[target] = (np.dot(data[param_names].values, model_data["weights"].values) + constant)
    data[target] = 1 / (1 + (1 / np.exp(data[target])))
    data[target_cat] = data[target].apply(lambda x: 0 if x >= 0.5 else 1)

    return data


def model_K_Sub_RC(data, logit_list, logit_nugg_id, model_coeff_dict):
    target_list = ["$LP-RC_A", "$LP-RC_H", "$LP-RC_B", "$LP-RC_K", "$LP-RC_M",
                   "$LP-RC_3", "$LP-RC_G", "$LP-RC_U", "$LP-RC_Blank",
                   "$LP-RC_2", "$LP-RC_E", "$LP-RC_4"]

    target_cat_list = ["$L-RC_A", "$L-RC_H", "$L-RC_B", "$L-RC_K", "$L-RC_M",
                       "$L-RC_3", "$L-RC_G", "$L-RC_U",
                       "$L-RC_Blank", "$L-RC_2", "$L-RC_E", "$L-RC_4"]

    pred_var = ["PredRC_A", "PredRC_H", "PredRC_B", "PredRC_K", "PredRC_M",
                "PredRC_3", "PredRC_G", "PredRC_U", "PredRC_Blank", "PredRC_2",
                "PredRC_E", "PredRC_4"]

    # l = len(model_name_list)

    for i in range(len(logit_list)):
        model_name = logit_list[i]
        nugg_id = logit_nugg_id[i]
        target = target_list[i]
        target_cat = target_cat_list[i]
        data = get_logistic_score(data, target, target_cat,
                                  model_name, nugg_id, model_coeff_dict)
        data[target_cat] = 1 - data[target_cat]
        data[pred_var[i]] = 1 - data[target]

    data["PredRC_C"] = data.apply(SubA_RC_PredRC_C, axis=1)

    data = SubA_RC_zero_out_low_prob(data, pred_var)

    drop_cols_list = ["$L-RC_A", "$LP-RC_A", "$L-RC_H", "$LP-RC_H", "$L-RC_B",
                      "$LP-RC_B", "$L-RC_K", "$LP-RC_K", "$L-RC_M", "$LP-RC_M",
                      "$L-RC_3", "$LP-RC_3", "$L-RC_G", "$LP-RC_G", "$L-RC_U",
                      "$LP-RC_U", "$L-RC_Blank", "$LP-RC_Blank", "$L-RC_2",
                      "$LP-RC_2", "$L-RC_E", "$LP-RC_E", "$L-RC_4",
                      "$LP-RC_4"]
    data.drop(labels=drop_cols_list, axis=1, inplace=True)

    return data


def df_model_K_submodel_sub_RC_sortorders(val, col, colslist, row):
    a = val
    for colname in colslist:
        if row[col] > row[colname]:
            a = a + 1
        else:
            a = a
    return a


def df_model_K_submodel_sub_RC_Sort_Rank(val, col, colslist, row):
    a = val
    for colname in colslist:
        if row[col] < row[colname]:
            a = a + 1
        else:
            a = a
    return a


def df_model_K_submodel_sub_RC_Rank_RC(row, rank):
    if row["Level"] == "BD":
        return ''
    elif (row["PRC2_sort_rank"] == rank) & (row["PredRC_2"] > 0):
        return '2'
    elif (row["PRC3_sort_rank"] == rank) & (row["PredRC_3"] > 0):
        return '3'
    elif (row["PRC4_sort_rank"] == rank) & (row["PredRC_4"] > 0):
        return '4'
    elif (row["PRCA_sort_rank"] == rank) & (row["PredRC_A"] > 0):
        return 'A'
    elif (row["PRCB_sort_rank"] == rank) & (row["PredRC_B"] > 0):
        return 'B'
    elif (row["PRCC_sort_rank"] == rank) & (row["PredRC_C"] > 0):
        return 'C'
    elif (row["PRCE_sort_rank"] == rank) & (row["PredRC_E"] > 0):
        return 'E'
    elif (row["PRCG_sort_rank"] == rank) & (row["PredRC_G"] > 0):
        return 'G'
    elif (row["PRCH_sort_rank"] == rank) & (row["PredRC_H"] > 0):
        return 'H'
    elif (row["PRCK_sort_rank"] == rank) & (row["PredRC_K"] > 0):
        return 'K'
    elif (row["PRCM_sort_rank"] == rank) & (row["PredRC_M"] > 0):
        return 'M'
    elif (row["PRCU_sort_rank"] == rank) & (row["PredRC_U"] > 0):
        return 'U'
    else:
        return ''


def df_model_K_submodel_sub_RC_Rank(df, sort_columnslist, rank_columnslist):
    df["PredRC_A"] = np.where(df["apd"] <= 0, 0, df["PredRC_A"])
    df["PredRC_B"] = np.where(df["colldoll"] <= 0, 0, df["PredRC_B"])
    df["PredRC_H"] = np.where(df["mophi"] <= 0, 0, df["PredRC_H"])
    df["PredRC_K"] = np.where(df["nbankrupt"] <= 0, 0, df["PredRC_K"])
    df["PredRC_M"] = np.where(df["ntaxlien"] <= 0, 0, df["PredRC_M"])

    df["PRC2_sort"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_sortorders(
            1.00012, "PredRC_2", sort_columnslist, x), axis=1)
    df["PRC3_sort"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_sortorders(
            1.00011, "PredRC_3", sort_columnslist, x), axis=1)
    df["PRC4_sort"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_sortorders(
            1.00010, "PredRC_4", sort_columnslist, x), axis=1)
    df["PRCA_sort"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_sortorders(
            1.00009, "PredRC_A", sort_columnslist, x), axis=1)
    df["PRCB_sort"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_sortorders(
            1.00008, "PredRC_B", sort_columnslist, x), axis=1)
    df["PRCC_sort"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_sortorders(
            1.00007, "PredRC_C", sort_columnslist, x), axis=1)
    df["PRCE_sort"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_sortorders(
            1.00006, "PredRC_E", sort_columnslist, x), axis=1)
    df["PRCG_sort"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_sortorders(
            1.00005, "PredRC_G", sort_columnslist, x), axis=1)
    df["PRCH_sort"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_sortorders(
            1.00004, "PredRC_H", sort_columnslist, x), axis=1)
    df["PRCK_sort"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_sortorders(
            1.00003, "PredRC_K", sort_columnslist, x), axis=1)
    df["PRCM_sort"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_sortorders(
            1.00002, "PredRC_M", sort_columnslist, x), axis=1)
    df["PRCU_sort"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_sortorders(
            1.00001, "PredRC_U", sort_columnslist, x), axis=1)
    df["PRCBlank_sort"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_sortorders(
            1.00000, "PredRC_Blank", sort_columnslist, x), axis=1)
    df["PRC2_sort_rank"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Sort_Rank(
            1, "PRC2_sort", rank_columnslist, x), axis=1)
    df["PRC3_sort_rank"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Sort_Rank(
            1, "PRC3_sort", rank_columnslist, x), axis=1)
    df["PRC4_sort_rank"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Sort_Rank(
            1, "PRC4_sort", rank_columnslist, x), axis=1)
    df["PRCA_sort_rank"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Sort_Rank(
            1, "PRCA_sort", rank_columnslist, x), axis=1)
    df["PRCB_sort_rank"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Sort_Rank(
            1, "PRCB_sort", rank_columnslist, x), axis=1)
    df["PRCC_sort_rank"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Sort_Rank(
            1, "PRCC_sort", rank_columnslist, x), axis=1)
    df["PRCE_sort_rank"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Sort_Rank(
            1, "PRCE_sort", rank_columnslist, x), axis=1)
    df["PRCG_sort_rank"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Sort_Rank(
            1, "PRCG_sort", rank_columnslist, x), axis=1)
    df["PRCH_sort_rank"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Sort_Rank(
            1, "PRCH_sort", rank_columnslist, x), axis=1)
    df["PRCK_sort_rank"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Sort_Rank(
            1, "PRCK_sort", rank_columnslist, x), axis=1)
    df["PRCM_sort_rank"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Sort_Rank(
            1, "PRCM_sort", rank_columnslist, x), axis=1)
    df["PRCU_sort_rank"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Sort_Rank(
            1, "PRCU_sort", rank_columnslist, x), axis=1)
    df["PRCBlank_sort_rank"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Sort_Rank(
            1, "PRCBlank_sort", rank_columnslist, x), axis=1)
    df["RC1st"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Rank_RC(
            x, 1), axis=1)
    df["RC2nd"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Rank_RC(
            x, 2), axis=1)
    df["RC3rd"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Rank_RC(
            x, 3), axis=1)
    df["RC4th"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Rank_RC(
            x, 4), axis=1)
    df["RC5th"] = df.apply(
        lambda x: df_model_K_submodel_sub_RC_Rank_RC(
            x, 5), axis=1)
    df["Reasons"] = df["RC1st"] + df["RC2nd"] + \
        df["RC3rd"] + df["RC4th"] + df["RC5th"]

    return df


def pfm_model_k(model_G_V3_DF, pkl_path, pkl_file_name):

    model_K_prep_df = f_model_K(model_G_V3_DF)

    # Reading the model coefficient pickle file.
    model_coeff_dict = load_pickle(pkl_path, pkl_file_name)

    model_params_dict = dict()

    model_params_dict["A"] = {'submodel_val': "A", 'model_name': "Regression A", 'nugget_id': "id712PIF1L44K", 'constant_val': 0.612}
    model_params_dict["B"] = {'submodel_val': "B", 'model_name': "Regression B", 'nugget_id': "id13R3Y7FJYG", 'constant_val': 0.704}
    model_params_dict["C"] = {'submodel_val': "C", 'model_name': "Regression C", 'nugget_id': "idAHPX79JCFD", 'constant_val': 0.623}
    model_params_dict["D"] = {'submodel_val': "D", 'model_name': "Regression D", 'nugget_id': "id684PMVL4M2Y", 'constant_val': 0.812}

    id_vars = ["age", "colldoll", "PolicyNumber", "State", "mrecdpr",
               "PolicySuffix", "GuidewireAccountNumber", "PolEffDt",
               "WritingCo", "ndpr", "Leverage", "raop24m", "dpramt",
               "PolAppDt", "GuidewireID", "mophi", "DPR24m", "apd",
               "CallingAppName", "GeneratedNumber", "ProviderStartDateTs",
               "Model", "nbankrupt", "ntaxlien", "submodel"]

    submodel_scored_A = submodel_scoring(model_K_prep_df,
                                         model_params_dict["A"],
                                         model_coeff_dict,
                                         id_vars)
    submodel_scored_B = submodel_scoring(model_K_prep_df,
                                         model_params_dict["B"],
                                         model_coeff_dict,
                                         id_vars)
    submodel_scored_C = submodel_scoring(model_K_prep_df,
                                         model_params_dict["C"],
                                         model_coeff_dict,
                                         id_vars)
    submodel_scored_D = submodel_scoring(model_K_prep_df,
                                         model_params_dict["D"],
                                         model_coeff_dict,
                                         id_vars)

    logit_list_A = ["RC_A", "RC_H", "RC_B", "RC_K", "RC_M", "RC_3",
                    "RC_G", "RC_U", "RC_Blank", "RC_2", "RC_E",
                    "RC_4"]

    logit_nugg_id_A = ["id1WVPS3UUZDZ", "id7NEPLRYH3TQ", "id2XZQ7DG5NB4",
                       "id1HIQ57U5BAI", "id8BHQYXTW4NT", "id3GIQT3T98V8",
                       "id1Z7PIMWEG5H", "id3NLQR8CZ88A", "id6P8QG64C9VZ",
                       "id2EHQK8G66IR", "id5VBQVC1YFL7", "id5LKQATMMTRL"]

    logit_list_B = ["RC_A_subB", "RC_H_subB", "RC_B_subB", "RC_K_subB", "RC_M_subB", "RC_3_subB",
                                 "RC_G_subB", "RC_U_subB", "RC_Blank_subB", "RC_2_subB", "RC_E_subB",
                                 "RC_4_subB"]

    logit_nugg_id_B = ["idP7PPV19LAQ", "id4HPSSENDJL", "id19RPS6MAAMQ",
                       "id44QQCUYZF63", "id4LZQ58EA93H", "id351R2F69DNV",
                       "id72FQTYZJI2D", "id81BR11ESKYF", "id5Z8R3HNBV23",
                       "id1Z3PLR6BHBF", "idYNR2TBH1QC", "id3S6PW3NDBNG"]

    logit_list_C = ["RC_A_subC", "RC_H_subC", "RC_B_subC", "RC_K_subC", "RC_M_subC", "RC_3_subC",
                                 "RC_G_subC", "RC_U_subC", "RC_Blank_subC", "RC_2_subC", "RC_E_subC",
                                 "RC_4_subC"]

    logit_nugg_id_C = ["id5NYQ5T2CAI1", "id1XZQ3LFMN2X", "id4XIPDHKBZ9E",
                       "id7FLPWPHP8V2", "id3S5QMUJ6XCD", "id3NJPV2BUXT5",
                       "id2Q3QPVWQYHE", "id3ZUPXE3TPNB", "id6IAQTVL15UU",
                       "id61TQH4IXZZN", "id2BXPBEZHILI", "id8CFQT8VBG23"]

    logit_list_D = ["RC_A_subD", "RC_H_subD", "RC_B_subD", "RC_K_subD", "RC_M_subD", "RC_3_subD",
                                 "RC_G_subD", "RC_U_subD", "RC_Blank_subD", "RC_2_subD", "RC_E_subD",
                                 "RC_4_subD"]

    logit_nugg_id_D = ["id1HXQIQWHYZ6", "id3RYPMFERLEF", "id4BPR2CGGC75",
                       "id7SUPSUSX3K7", "id6WUQ4ALJKME", "id6D5QJZWB7IX",
                       "id5FXRZYXEKW5", "id3JYQRUZKXWJ", "id8E8QMLXLUTH",
                       "id298QF7J1F7I", "id4L2R1888CTP", "id6D3QGSMUEDX"]

    sort_columnslist = [
        "PredRC_2",
        "PredRC_3",
        "PredRC_4",
        "PredRC_A",
        "PredRC_B",
        "PredRC_Blank",
        "PredRC_C",
        "PredRC_E",
        "PredRC_G",
        "PredRC_H",
        "PredRC_K",
        "PredRC_M",
        "PredRC_U"]
    rank_columnslist = [
        "PRC2_sort",
        "PRC3_sort",
        "PRC4_sort",
        "PRCA_sort",
        "PRCB_sort",
        "PRCC_sort",
        "PRCE_sort",
        "PRCG_sort",
        "PRCH_sort",
        "PRCK_sort",
        "PRCM_sort",
        "PRCU_sort",
        "PRCBlank_sort"]

    submodel_scored_reasons = pd.DataFrame()

    if not submodel_scored_A.empty:
        submodel_scored_log_A = model_K_Sub_RC(
            submodel_scored_A,
            logit_list_A,
            logit_nugg_id_A,
            model_coeff_dict)
        submodel_scored_reasons_A = df_model_K_submodel_sub_RC_Rank(
                submodel_scored_log_A, sort_columnslist, rank_columnslist)
        submodel_scored_reasons = pd.concat([submodel_scored_reasons,
                                             submodel_scored_reasons_A],
                                            ignore_index=True)
    if not submodel_scored_B.empty:
        submodel_scored_log_B = model_K_Sub_RC(
                                               submodel_scored_B,
                                               logit_list_B,
                                               logit_nugg_id_B,
                                               model_coeff_dict)
        submodel_scored_reasons_B = df_model_K_submodel_sub_RC_Rank(
                submodel_scored_log_B, sort_columnslist, rank_columnslist)
        submodel_scored_reasons = pd.concat([submodel_scored_reasons,
                                             submodel_scored_reasons_B],
                                            ignore_index=True)
    if not submodel_scored_C.empty:
        submodel_scored_log_C = model_K_Sub_RC(
                                               submodel_scored_C,
                                               logit_list_C,
                                               logit_nugg_id_C,
                                               model_coeff_dict)
        submodel_scored_reasons_C = df_model_K_submodel_sub_RC_Rank(
                submodel_scored_log_C, sort_columnslist, rank_columnslist)
        submodel_scored_reasons = pd.concat([submodel_scored_reasons,
                                             submodel_scored_reasons_C],
                                            ignore_index=True)
    if not submodel_scored_D.empty:
        submodel_scored_log_D = model_K_Sub_RC(
                                               submodel_scored_D,
                                               logit_list_D,
                                               logit_nugg_id_D,
                                               model_coeff_dict)
        submodel_scored_reasons_D = df_model_K_submodel_sub_RC_Rank(
                submodel_scored_log_D, sort_columnslist, rank_columnslist)
        submodel_scored_reasons = pd.concat([submodel_scored_reasons,
                                             submodel_scored_reasons_D],
                                            ignore_index=True)

    submodel_scored_reasons.rename(columns={"Kscore": "PFMScore"}, inplace=True)

    return submodel_scored_reasons
