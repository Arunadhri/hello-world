##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Arunadhri Srinivasan, Prabakar Subramani
# Creation Date          : 08FEB2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : gw_pfm_539_model_u.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-GW-PFM
# Brief Description      : Model U
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################

# ------------------------------------------------------------------------

from math import sqrt
import pandas as pd
import numpy as np


def f_u1_factors_AVGMAO_FACT_U1(x):
    if x == "0_00":
        return 1.034
    elif x == "0_01":
        return 1.366
    elif x == "0_02":
        return 1.167
    elif x == "0_03":
        return 1.051
    elif x == "4_00":
        return 0.954
    elif x == "4_01":
        return 1.179
    elif x == "4_02":
        return 1.136
    elif x == "4_03":
        return 1.082
    elif x == "4_04":
        return 1.010
    elif x == "A_05":
        return 0.954
    else:
        return np.nan


def f_u1_factors_AWOAO_FACT_U1(x):
    if x <= 0:
        return 1.221
    elif x > 0 and x < 18:
        return 0.941
    elif x == 18:
        return 0.848
    elif x == 19:
        return 0.881
    elif x == 20:
        return 0.892
    elif x == 21:
        return 0.906
    elif x == 22:
        return 0.920
    elif x == 23:
        return 0.934
    elif x == 24:
        return 0.949
    elif x == 25:
        return 0.964
    elif x == 26:
        return 0.980
    elif x == 27:
        return 0.996
    elif x == 28:
        return 1.012
    elif x == 29:
        return 1.029
    elif x == 30:
        return 1.033
    elif x == 31:
        return 1.037
    elif x == 32:
        return 1.041
    elif x == 33:
        return 1.045
    elif x == 34:
        return 1.050
    elif x == 35:
        return 1.055
    elif x == 36:
        return 1.059
    elif x == 37:
        return 1.069
    elif x == 38:
        return 1.078
    elif x == 39:
        return 1.086
    elif x == 40:
        return 1.094
    elif x == 41:
        return 1.104
    elif x == 42:
        return 1.112
    elif x == 43:
        return 1.121
    elif x == 44:
        return 1.132
    elif x >= 45:
        return 1.221
    else:
        return np.nan


def f_u1_factors_DEL84_FACT_U1(x):
    if x == "0_2":
        return 1.096
    elif x == "OTH":
        return 0.995
    else:
        return np.nan


def f_u1_factors_DDC_FACT_U1(x):
    if x == 1:
        return 0.904
    elif x == 2:
        return 0.998
    elif x == 3:
        return 1.021
    elif x == 4:
        return 1.091
    elif x == 5:
        return 1.114
    elif x == 6:
        return 1.218
    elif x == 7:
        return 1.233
    elif x == 8:
        return 1.297
    else:
        return np.nan


def f_u1_factors_IADIF_FACT_U1(x):
    if x == "0_E-1":
        return 0.955
    elif x == "0_P_0":
        return 0.892
    elif x == "0_P_1":
        return 0.936
    elif x == "0_P_2":
        return 1.035
    elif x == "0_P_3":
        return 1.058
    elif x == "0_P_4":
        return 1.133
    elif x == "4_A-5":
        return 1.043
    elif x == "4_B-4":
        return 1.034
    elif x == "4_C-3":
        return 1.009
    elif x == "4_D-2":
        return 0.986
    elif x == "4_E-1":
        return 0.964
    elif x == "4_P_0":
        return 0.993
    elif x == "4_P_1":
        return 0.999
    elif x == "4_P_2":
        return 1.008
    elif x == "4_P_3":
        return 1.017
    else:
        return np.nan


def f_u1_factors_INQ06_FACT_U1(x):
    if x == "0_5":
        return 1.167
    elif x == "OTH":
        return 0.998
    else:
        return np.nan


def f_u1_factors_INQ24_FACT_U1(x):
    if x == "0ALL":
        return 0.928
    elif x == "4_00":
        return 0.912
    elif x == "4_01":
        return 0.957
    elif x == "4_02":
        return 0.992
    elif x == "4_03":
        return 1.003
    elif x == "4_04":
        return 1.008
    elif x == "4_05":
        return 1.014
    elif x == "4_06":
        return 1.024
    elif x == "4_07":
        return 1.073
    elif x == "4_08":
        return 1.084
    elif x == "4_09":
        return 1.094
    elif x == "4_10":
        return 1.105
    elif x == "4_11":
        return 1.165
    elif x == "4_12":
        return 1.180
    elif x == "4_13":
        return 1.194
    elif x == "4_14":
        return 1.209
    elif x == "4_15":
        return 1.235
    elif x == "4_16":
        return 1.258
    elif x == "4_17":
        return 1.276
    elif x == "4_18":
        return 1.291
    elif x == "4_19":
        return 1.306
    elif x == "4_20":
        return 1.333
    else:
        return np.nan


def f_u1_factors_NOPA_FACT_U1(x):
    if x >= 0 and x < 10:
        return 0.984
    elif x == 10:
        return 0.997
    elif x == 11:
        return 1.065
    elif x == 12:
        return 1.075
    elif x == 13:
        return 1.067
    elif x == 14:
        return 1.029
    elif x == 15:
        return 1.017
    elif x == 16:
        return 1.007
    elif x >= 17:
        return 0.979
    else:
        return np.nan


def f_u1_factors_NOPRA_FACT_U1(x):
    if x == "0_P0":
        return 1.061
    elif x == "0_P1":
        return 0.924
    elif x == "0_P2":
        return 0.981
    elif x == "4_00":
        return 0.981
    elif x == "4_01":
        return 0.981
    elif x == "4_02":
        return 0.981
    elif x == "4_03":
        return 0.901
    elif x == "4_04":
        return 0.950
    elif x == "4_05":
        return 0.960
    elif x == "4_06":
        return 0.971
    elif x == "4_07":
        return 0.984
    elif x == "4_08":
        return 1.012
    elif x == "4_09":
        return 1.020
    elif x == "4_10":
        return 1.023
    elif x == "4_11":
        return 1.026
    elif x == "4_12":
        return 1.030
    elif x == "4_13":
        return 1.034
    elif x == "4_14":
        return 1.038
    elif x == "4_15":
        return 1.045
    elif x == "4_16":
        return 1.058
    elif x == "4_17":
        return 1.101
    elif x == "4_18":
        return 1.115
    elif x == "4_19":
        return 1.120
    elif x == "4_20":
        return 1.124
    elif x == "4_21":
        return 1.127
    elif x == "4_22":
        return 1.130
    elif x == "4_23":
        return 1.134
    elif x == "4_24":
        return 1.138
    elif x == "4_25":
        return 1.151
    else:
        return np.nan


def f_u1_factors_PORAL50_FACT_U1(x):
    if x == "0_N_-1":
        return 0.935
    elif x == "0_P000":
        return 0.935
    elif x == "0_P100":
        return 1.048
    elif x == "4_N_-1":
        return 0.964
    elif x == "4_P000":
        return 0.964
    elif x == "4_P001":
        return 0.968
    elif x == "4_P015":
        return 1.005
    elif x == "4_P025":
        return 1.051
    elif x == "4_P067":
        return 1.076
    else:
        return np.nan


def f_u1_factors_RLEV_FACT_U1(x):
    if x == "0_-1":
        return 1.159
    elif x == "0_00":
        return 1.000
    elif x == "4_-1":
        return 1.116
    elif x == "4_00":
        return 1.000
    else:
        return np.nan


def f_u1_factors(df):

    df.loc[:, "AVGMAO_FACT_U1"] = df["NOPA_AVGMAO"]\
        .apply(lambda x: f_u1_factors_AVGMAO_FACT_U1(x))
    df.loc[:, "AWOAO_FACT_U1"] = df["AWOAO_BIN"]\
        .apply(lambda x: f_u1_factors_AWOAO_FACT_U1(x))
    df.loc[:, "DEL84_FACT_U1"] = df["NOPA_DEL84"]\
        .apply(lambda x: f_u1_factors_DEL84_FACT_U1(x))
    df.loc[:, "DDC_FACT_U1"] = df["DDC_COMBO"]\
        .apply(lambda x: f_u1_factors_DDC_FACT_U1(x))
    df.loc[:, "IADIF_FACT_U1"] = df["NOPA_IADIF"]\
        .apply(lambda x: f_u1_factors_IADIF_FACT_U1(x))
    df.loc[:, "INQ06_FACT_U1"] = df["NOPA_INQ06"]\
        .apply(lambda x: f_u1_factors_INQ06_FACT_U1(x))
    df.loc[:, "INQ24_FACT_U1"] = df["NOPA_INQ24"]\
        .apply(lambda x: f_u1_factors_INQ24_FACT_U1(x))
    df.loc[:, "NOPA_FACT_U1"] = df["NOPA_CAP"]\
        .apply(lambda x: f_u1_factors_NOPA_FACT_U1(x))
    df.loc[:, "NOPRA_FACT_U1"] = df["NOPA_NOPRA"]\
        .apply(lambda x: f_u1_factors_NOPRA_FACT_U1(x))
    df.loc[:, "PORAL50_FACT_U1"] = df["NOPA_PORAL50"]\
        .apply(lambda x: f_u1_factors_PORAL50_FACT_U1(x))
    df.loc[:, "RLEV_FACT_U1"] = df["NOPA_RLEVTYPE"]\
        .apply(lambda x: f_u1_factors_RLEV_FACT_U1(x))

    return df


def f_u2_factors_ACD_FACT_U2(x):
    if x == "0_1":
        return 0.972
    elif x == "0_2":
        return 1.027
    elif x == "0_3":
        return 1.055
    elif x == "0_4":
        return 1.056
    elif x == "0_5":
        return 1.058
    elif x == "4_1":
        return 0.992
    elif x == "4_2":
        return 1.010
    elif x == "4_3":
        return 1.021
    elif x == "4_4":
        return 1.038
    elif x == "4_5":
        return 1.058
    else:
        return np.nan


def f_u2_factors_AOP24_FACT_U2(x):
    if x == 0:
        return 1.023
    elif x == 1:
        return 1.009
    elif x == 2:
        return 1.004
    elif x == 3:
        return 0.996
    elif x == 6:
        return 0.980
    else:
        return np.nan


def f_u2_factors_AVGMAO_FACT_U2(x):
    if x == 1:
        return 1.176
    elif x == 2:
        return 1.102
    elif x == 3:
        return 1.055
    elif x == 4:
        return 1.039
    elif x == 5:
        return 1.022
    elif x == 6:
        return 1.003
    elif x == 7:
        return 0.990
    elif x == 8:
        return 0.984
    elif x == 9:
        return 0.976
    elif x == 10:
        return 0.967
    elif x == 11:
        return 0.954
    elif x == 12:
        return 0.946
    elif x == 13:
        return 0.928
    elif x == 14:
        return 0.877
    else:
        return np.nan


def f_u2_factors_DEL24_FACT_U2(x):
    if x == 0:
        return 0.995
    elif x == 1:
        return 1.008
    elif x == 2:
        return 1.016
    elif x == 3:
        return 1.021
    else:
        return np.nan


def f_u2_factors_INQ24_FACT_U2(x):
    if x == "0_0":
        return 0.931
    elif x == "0_1":
        return 0.945
    elif x == "1_0":
        return 0.967
    elif x == "1_1":
        return 1.047
    elif x == "2_0":
        return 0.981
    elif x == "2_1":
        return 1.035
    elif x == "3_0":
        return 0.983
    elif x == "3_1":
        return 1.024
    elif x == "4_0":
        return 0.980
    elif x == "4_1":
        return 1.002
    else:
        return np.nan


def f_u2_factors_MOP_FACT_U2(x):
    if x == "0_1":
        return 0.992
    elif x == "0_2":
        return 1.032
    elif x == "0_3":
        return 1.055
    elif x == "0_4":
        return 1.056
    elif x == "0_5":
        return 1.075
    elif x == "0_6":
        return 1.088
    elif x == "0_7":
        return 1.105
    elif x == "4_1":
        return 0.971
    elif x == "4_2":
        return 0.994
    elif x == "4_3":
        return 1.020
    elif x == "4_4":
        return 1.037
    elif x == "4_5":
        return 1.049
    elif x == "4_6":
        return 1.078
    elif x == "4_7":
        return 1.105
    else:
        return np.nan


def f_u2_factors_NMORTHEL_FACT_U2(x):
    if x == "0_0":
        return 1.152
    elif x == "0_1":
        return 0.938
    elif x == "0_2":
        return 0.908
    elif x == "4_0":
        return 1.178
    elif x == "4_1":
        return 0.956
    elif x == "4_2":
        return 0.908
    else:
        return np.nan


def f_u2_factors_NOMORT_FACT_U2(x):
    if x == 0:
        return 1.051
    elif x == 1:
        return 0.944
    else:
        return np.nan


def f_u2_factors_PORAL50_FACT_U2(x):
    if x == -1:
        return 0.983
    elif x == 0:
        return 0.991
    elif x == 1:
        return 1.002
    elif x == 15:
        return 1.001
    elif x == 25:
        return 1.009
    elif x == 40:
        return 1.017
    elif x == 67:
        return 1.025
    elif x == 100:
        return 1.023
    else:
        return np.nan


def f_u2_factors_RLEV_FACT_U2(x):
    if x == "0_0":
        return 1.033
    elif x == "0_1":
        return 0.985
    elif x == "0_6":
        return 1.002
    elif x == "4_0":
        return 1.037
    elif x == "4_1":
        return 1.011
    elif x == "4_2":
        return 0.994
    elif x == "4_3":
        return 0.988
    elif x == "4_4":
        return 0.982
    elif x == "4_5":
        return 0.992
    elif x == "4_6":
        return 1.002
    else:
        return np.nan


def f_u2_factors(df):

    df.loc[:, "ACD_FACT_U2"] = df["NOPA_ACD"]\
        .apply(lambda x: f_u2_factors_ACD_FACT_U2(x))
    df.loc[:, "AOP24_FACT_U2"] = df["AOP24_BIN"]\
        .apply(lambda x: f_u2_factors_AOP24_FACT_U2(x))
    df.loc[:, "AVGMAO_FACT_U2"] = df["AVGMAO_BIN"]\
        .apply(lambda x: f_u2_factors_AVGMAO_FACT_U2(x))
    df.loc[:, "DEL24_FACT_U2"] = df["DEL24_CAP"]\
        .apply(lambda x: f_u2_factors_DEL24_FACT_U2(x))
    df.loc[:, "INQ24_FACT_U2"] = df["NOPA_INQ24B"]\
        .apply(lambda x: f_u2_factors_INQ24_FACT_U2(x))
    df.loc[:, "MOP_FACT_U2"] = df["NOPA_MOP"]\
        .apply(lambda x: f_u2_factors_MOP_FACT_U2(x))
    df.loc[:, "NMORTHEL_FACT_U2"] = df["NOPA_NMORTHEL"]\
        .apply(lambda x: f_u2_factors_NMORTHEL_FACT_U2(x))
    df.loc[:, "NOMORT_FACT_U2"] = df["NOMORT_CAP"]\
        .apply(lambda x: f_u2_factors_NOMORT_FACT_U2(x))
    df.loc[:, "PORAL50_FACT_U2"] = df["PORAL50_BIN"]\
        .apply(lambda x: f_u2_factors_PORAL50_FACT_U2(x))
    df.loc[:, "RLEV_FACT_U2"] = df["NOPA_RLEV"]\
        .apply(lambda x: f_u2_factors_RLEV_FACT_U2(x))

    return df


def f_calc_raw_scores(df):

    df.loc[:, "PFMU_LRSCORE"] = round(0.434 * df["AVGMAO_FACT_U1"] *
                                      df["AWOAO_FACT_U1"] *
                                      df["DDC_FACT_U1"] *
                                      df["DEL84_FACT_U1"] *
                                      df["IADIF_FACT_U1"] *
                                      df["INQ06_FACT_U1"] *
                                      df["INQ24_FACT_U1"] *
                                      df["NOPA_FACT_U1"] *
                                      df["NOPRA_FACT_U1"] *
                                      df["PORAL50_FACT_U1"] *
                                      df["RLEV_FACT_U1"] *
                                      100000) / 100000
    df.loc[:, "PFMU_MOSCORE"] = round(0.400 * df["ACD_FACT_U2"] *
                                      df["AOP24_FACT_U2"] *
                                      df["AVGMAO_FACT_U2"] *
                                      df["DEL24_FACT_U2"] *
                                      df["INQ24_FACT_U2"] *
                                      df["MOP_FACT_U2"] *
                                      df["NMORTHEL_FACT_U2"] *
                                      df["NOMORT_FACT_U2"] *
                                      df["PORAL50_FACT_U2"] *
                                      df["RLEV_FACT_U2"] * 100000) / 100000
    df = df.rename(
        columns={"PFMU_LRSCORE": "LRSCORE", "PFMU_MOSCORE": "MOSCORE"})

    return df


def f_score_adjust_LRSCORE_BIN(x):
    if x["LRSCORE"] < 0.29145:
        return "BDA"
    if x["LRSCORE"] >= 0.29145 and x["LRSCORE"] < 0.30215:
        return "L01"
    if x["LRSCORE"] >= 0.30215 and x["LRSCORE"] < 0.32005:
        return "L02"
    if x["LRSCORE"] >= 0.32005 and x["LRSCORE"] < 0.34545:
        return "L03"
    if x["LRSCORE"] >= 0.34545 and x["LRSCORE"] < 0.36655:
        return "L04"
    if x["LRSCORE"] >= 0.36655 and x["LRSCORE"] < 0.38745:
        return "L05"
    if x["LRSCORE"] >= 0.38745 and x["LRSCORE"] < 0.40975:
        return "L06"
    if x["LRSCORE"] >= 0.40975 and x["LRSCORE"] < 0.43595:
        return "L07"
    if x["LRSCORE"] >= 0.43595 and x["LRSCORE"] < 0.46935:
        return "L08"
    if x["LRSCORE"] >= 0.46935 and x["LRSCORE"] < 0.51595:
        return "L09"
    if x["LRSCORE"] >= 0.51595 and x["LRSCORE"] < 0.59285:
        return "L10"
    if x["LRSCORE"] >= 0.59285 and x["LRSCORE"] < 0.66215:
        return "L11"
    if x["LRSCORE"] >= 0.66215:
        return "L12"
    else:
        return np.nan


def f_score_adjust_MOSCORE_BIN(x):
    if x["MOSCORE"] < 0.31635:
        return "M01"
    if x["MOSCORE"] >= 0.31635 and x["MOSCORE"] < 0.32585:
        return "M02"
    if x["MOSCORE"] >= 0.32585 and x["MOSCORE"] < 0.33685:
        return "M03"
    if x["MOSCORE"] >= 0.33685 and x["MOSCORE"] < 0.35065:
        return "M04"
    if x["MOSCORE"] >= 0.35065 and x["MOSCORE"] < 0.36725:
        return "M05"
    if x["MOSCORE"] >= 0.36725 and x["MOSCORE"] < 0.39745:
        return "M06"
    if x["MOSCORE"] >= 0.39745 and x["MOSCORE"] < 0.44985:
        return "M07"
    if x["MOSCORE"] >= 0.44985 and x["MOSCORE"] < 0.49275:
        return "M08"
    if x["MOSCORE"] >= 0.49275 and x["MOSCORE"] < 0.54665:
        return "M09"
    if x["MOSCORE"] >= 0.54665:
        return "M10"
    else:
        return np.nan


def f_score_adjust_CA(x):
    if x["LRSCORE"] < 0.29145:
        return 0
    elif x["LRSCORE"] < 0.30215:
        return 0.29145
    elif x["LRSCORE"] < 0.66215:
        return 0.30215
    elif x["LRSCORE"] < 1.3:
        return 0.66215
    else:
        return 1.3


def f_score_adjust_CB(x):
    if x["LRSCORE"] < 0.29145:
        return 0.29145
    elif x["LRSCORE"] < 0.30215:
        return 0.30215
    elif x["LRSCORE"] < 0.66215:
        return 0.66215
    elif x["LRSCORE"] < 1.3:
        return 1.3
    else:
        return 2


def f_score_adjust_CC(x):
    if x["LRSCORE"] < 0.29145:
        return 1
    elif x["LRSCORE"] < 0.30215:
        return 0.94000
    elif x["LRSCORE"] < 0.66215:
        return 0.34408
    elif x["LRSCORE"] < 1.3:
        return 0.10000
    else:
        return 0.10000


def f_score_adjust_CD(x):
    if x["LRSCORE"] < 0.29145:
        return 1
    elif x["LRSCORE"] < 0.30215:
        return 0.93778
    elif x["LRSCORE"] < 0.66215:
        return 0.31635
    elif x["LRSCORE"] < 1.3:
        return 0.10000
    else:
        return 0.10000


def f_score_adjust_CE(x):
    if x["LRSCORE"] < 0.29145:
        return 1
    elif x["LRSCORE"] < 0.30215:
        return 1
    elif x["LRSCORE"] < 0.66215:
        return 0.36725
    elif x["LRSCORE"] < 1.3:
        return 0.10100
    else:
        return 0.10100


def f_score_adjust_CF(x):
    if x["LRSCORE"] < 0.29145:
        return 1.0302
    elif x["LRSCORE"] < 0.30215:
        return 1
    elif x["LRSCORE"] < 0.66215:
        return 0.36725
    elif x["LRSCORE"] < 1.3:
        return 0.10100
    else:
        return 0.10100


def f_score_adjust_CG(x):
    if x["LRSCORE"] < 0.29145:
        return 1.1
    elif x["LRSCORE"] < 0.30215:
        return 1.1
    elif x["LRSCORE"] < 0.66215:
        return 0.44920
    elif x["LRSCORE"] < 1.3:
        return 0.12000
    else:
        return 0.12000


def f_score_adjust_CH(x):
    if x["LRSCORE"] < 0.29145:
        return 1.1
    elif x["LRSCORE"] < 0.30215:
        return 1.1
    elif x["LRSCORE"] < 0.66215:
        return 0.54665
    elif x["LRSCORE"] < 1.3:
        return 0.13830
    else:
        return 0.13020


def f_score_adjust_CI(x):
    if x["LRSCORE"] < 0.29145:
        return 0.96500
    elif x["LRSCORE"] < 0.30215:
        return 0.34000
    elif x["LRSCORE"] < 0.66215:
        return 0.65100
    elif x["LRSCORE"] < 1.3:
        return 1.74200
    else:
        return 1.74200


def f_score_adjust_CJ(x):
    if x["LRSCORE"] < 0.29145:
        return 0.96500
    elif x["LRSCORE"] < 0.30215:
        return 0.34000
    elif x["LRSCORE"] < 0.66215:
        return 0.65100
    elif x["LRSCORE"] < 1.3:
        return 1.74200
    else:
        return 1.74200


def f_score_adjust_CK(x):
    if x["LRSCORE"] < 0.29145:
        return 1
    elif x["LRSCORE"] < 0.30215:
        return 1
    elif x["LRSCORE"] < 0.66215:
        return 0.18450
    elif x["LRSCORE"] < 1.3:
        return 1.74200
    else:
        return 3.42000


def f_score_adjust_CL(x):
    if x["LRSCORE"] < 0.29145:
        return 1
    elif x["LRSCORE"] < 0.30215:
        return 1
    elif x["LRSCORE"] < 0.66215:
        return 0.18450
    elif x["LRSCORE"] < 1.3:
        return 1.74200
    else:
        return 3.42000


def f_score_adjust_CMO(x):
    if x["MOSCORE"] < x["MMP"]:
        if x["MOSCORE"] > x["MLC"]:
            return x["MOSCORE"]
        else:
            return x["MLC"]
    elif x["MOSCORE"] < x["MRC"]:
        return x["MOSCORE"]
    else:
        return x["MRC"]


def f_score_adjust_Slope(x):
    if x["MOSCORE"] < x["MMP"]:
        return ((x["CI"] * (1 - x["YPct"])) +
                (x["CJ"] * x["YPct"])) * 100000
    else:
        return ((x["CK"] * (1 - x["YPct"])) +
                (x["CL"] * x["YPct"])) * 100000


def f_score_adjust_ADJ_SCORE(x):
    if x["MOSCORE"] < x["MMP"]:
        return (x["LRSCORE"] - ((x["MMP"] -
                x["CMO"]) * x["Slope"])) * 100000
    else:
        return (x["LRSCORE"] + ((x["CMO"] -
                x["MMP"]) * x["Slope"])) * 100000


def f_score_adjust(df):

    df["LRSCORE_BIN"] = df.apply(f_score_adjust_LRSCORE_BIN, axis=1)
    df["MOSCORE_BIN"] = df.apply(f_score_adjust_MOSCORE_BIN, axis=1)
    df["CA"] = df.apply(f_score_adjust_CA, axis=1)
    df["CB"] = df.apply(f_score_adjust_CB, axis=1)
    df["CC"] = df.apply(f_score_adjust_CC, axis=1)
    df["CD"] = df.apply(f_score_adjust_CD, axis=1)
    df["CE"] = df.apply(f_score_adjust_CE, axis=1)
    df["CF"] = df.apply(f_score_adjust_CF, axis=1)
    df["CG"] = df.apply(f_score_adjust_CG, axis=1)
    df["CH"] = df.apply(f_score_adjust_CH, axis=1)
    df["CI"] = df.apply(f_score_adjust_CI, axis=1)
    df["CJ"] = df.apply(f_score_adjust_CJ, axis=1)
    df["CK"] = df.apply(f_score_adjust_CK, axis=1)
    df["CL"] = df.apply(f_score_adjust_CL, axis=1)
    df["YPct"] = round(((df["LRSCORE"] - df["CA"]) /
                       (df["CB"] - df["CA"])) * 100000) / 100000
    df["MMP"] = round((df["CE"] + ((df["CF"] -
                       df["CE"]) * df["YPct"])) * 100000) / 100000
    df["MLC"] = round((df["CC"] + ((df["CD"] -
                       df["CC"]) * df["YPct"])) * 100000) / 100000
    df["MRC"] = round((df["CG"] + ((df["CH"] - df["CG"]) *
                       df["YPct"])) * 100000) / 100000
    df["CMO"] = df.apply(f_score_adjust_CMO, axis=1)
    df["Slope"] = df.apply(f_score_adjust_Slope, axis=1)
    df["Slope"] = df["Slope"].round() / 100000
    df["ADJ_SCORE"] = df.apply(f_score_adjust_ADJ_SCORE, axis=1)
    df["ADJ_SCORE"] = df["ADJ_SCORE"].round() / 100000
    df["ADJ_FACTOR"] = df["ADJ_SCORE"] / df["LRSCORE"]

    return df


def f_scale_score_SCALED_SCORE(x):
    if x["SCALED_SCORE_PRE"] < 10:
        return 10
    elif x["SCALED_SCORE_PRE"] > 999:
        return 999
    else:
        return x["SCALED_SCORE_PRE"]


def f_scale_score(df):

    df["ADJ_SCORE"] = round(df["ADJ_SCORE"] * 100000.0000)/100000
    df["SCALED_SCORE_PRE"] = round((df["ADJ_SCORE"] * 1310) - 285)
    df["SCALED_SCORE"] = df.apply(f_scale_score_SCALED_SCORE, axis=1)
    df = df.drop(["LRSCORE_BIN", "MOSCORE_BIN", "CA", "CB",
                  "CC", "CD", "CE", "CF", "CG", "CH", "CI",
                  "CJ", "CK", "CL", "YPct", "MMP", "MLC", "MRC",
                  "CMO", "Slope", "ADJ_FACTOR",
                  "SCALED_SCORE_PRE"], axis=1)
    df = df.rename(
        columns={"LRSCORE": "PFMU_LRSCORE",
                 "MOSCORE": "PFMU_MOSCORE",
                 "ADJ_SCORE": "PFMU_ADJSCORE",
                 "SCALED_SCORE": "PFMU_SCORE"})
    return df


def f_PFMU_LEVEL(x):
    if x["PFMU_SCORE"] >= 10 and x["PFMU_SCORE"] < 92:
        return "BD"
    if x["PFMU_SCORE"] >= 92 and x["PFMU_SCORE"] < 123:
        return "BH"
    if x["PFMU_SCORE"] >= 123 and x["PFMU_SCORE"] < 141:
        return "BL"
    if x["PFMU_SCORE"] >= 141 and x["PFMU_SCORE"] < 155:
        return "BP"
    if x["PFMU_SCORE"] >= 155 and x["PFMU_SCORE"] < 169:
        return "BT"
    if x["PFMU_SCORE"] >= 169 and x["PFMU_SCORE"] < 180:
        return "BW"
    if x["PFMU_SCORE"] >= 180 and x["PFMU_SCORE"] < 191:
        return "CD"
    if x["PFMU_SCORE"] >= 191 and x["PFMU_SCORE"] < 202:
        return "CH"
    if x["PFMU_SCORE"] >= 202 and x["PFMU_SCORE"] < 212:
        return "CL"
    if x["PFMU_SCORE"] >= 212 and x["PFMU_SCORE"] < 220:
        return "CP"
    if x["PFMU_SCORE"] >= 220 and x["PFMU_SCORE"] < 230:
        return "CT"
    if x["PFMU_SCORE"] >= 230 and x["PFMU_SCORE"] < 239:
        return "CW"
    if x["PFMU_SCORE"] >= 239 and x["PFMU_SCORE"] < 242:
        return "DD"
    if x["PFMU_SCORE"] >= 242 and x["PFMU_SCORE"] < 249:
        return "DG"
    if x["PFMU_SCORE"] >= 249 and x["PFMU_SCORE"] < 258:
        return "DJ"
    if x["PFMU_SCORE"] >= 258 and x["PFMU_SCORE"] < 267:
        return "DN"
    if x["PFMU_SCORE"] >= 267 and x["PFMU_SCORE"] < 276:
        return "DQ"
    if x["PFMU_SCORE"] >= 276 and x["PFMU_SCORE"] < 287:
        return "DT"
    if x["PFMU_SCORE"] >= 287 and x["PFMU_SCORE"] < 297:
        return "DW"
    if x["PFMU_SCORE"] >= 297 and x["PFMU_SCORE"] < 306:
        return "ED"
    if x["PFMU_SCORE"] >= 306 and x["PFMU_SCORE"] < 317:
        return "EG"
    if x["PFMU_SCORE"] >= 317 and x["PFMU_SCORE"] < 329:
        return "EJ"
    if x["PFMU_SCORE"] >= 329 and x["PFMU_SCORE"] < 343:
        return "EN"
    if x["PFMU_SCORE"] >= 343 and x["PFMU_SCORE"] < 357:
        return "EQ"
    if x["PFMU_SCORE"] >= 357 and x["PFMU_SCORE"] < 370:
        return "ET"
    if x["PFMU_SCORE"] >= 370 and x["PFMU_SCORE"] < 376:
        return "EW"
    if x["PFMU_SCORE"] >= 376 and x["PFMU_SCORE"] < 392:
        return "FD"
    if x["PFMU_SCORE"] >= 392 and x["PFMU_SCORE"] < 415:
        return "FG"
    if x["PFMU_SCORE"] >= 415 and x["PFMU_SCORE"] < 440:
        return "FJ"
    if x["PFMU_SCORE"] >= 440 and x["PFMU_SCORE"] < 456:
        return "FN"
    if x["PFMU_SCORE"] >= 456 and x["PFMU_SCORE"] < 479:
        return "FQ"
    if x["PFMU_SCORE"] >= 479 and x["PFMU_SCORE"] < 502:
        return "FT"
    if x["PFMU_SCORE"] >= 502 and x["PFMU_SCORE"] < 528:
        return "FW"
    if x["PFMU_SCORE"] >= 528 and x["PFMU_SCORE"] < 569:
        return "GD"
    if x["PFMU_SCORE"] >= 569 and x["PFMU_SCORE"] < 592:
        return "GH"
    if x["PFMU_SCORE"] >= 592 and x["PFMU_SCORE"] < 612:
        return "GL"
    if x["PFMU_SCORE"] >= 612 and x["PFMU_SCORE"] < 644:
        return "GP"
    if x["PFMU_SCORE"] >= 644 and x["PFMU_SCORE"] < 674:
        return "GT"
    if x["PFMU_SCORE"] >= 674 and x["PFMU_SCORE"] < 706:
        return "HD"
    if x["PFMU_SCORE"] >= 706 and x["PFMU_SCORE"] < 729:
        return "HH"
    if x["PFMU_SCORE"] >= 729 and x["PFMU_SCORE"] < 795:
        return "HL"
    if x["PFMU_SCORE"] >= 795 and x["PFMU_SCORE"] < 831:
        return "HP"
    if x["PFMU_SCORE"] >= 831 and x["PFMU_SCORE"] < 943:
        return "HT"
    if x["PFMU_SCORE"] >= 943 and x["PFMU_SCORE"] <= 999:
        return "HW"
    else:
        return "ZZ"


def f_reason_percentiles_RPCT_A(x):
    if x["APD"] < 1:
        return 100
    elif x["APD"] < 100:
        return 5.89
    elif x["APD"] < 200:
        return 4.55
    elif x["APD"] < 300:
        return 4.01
    elif x["APD"] < 400:
        return 3.59
    elif x["APD"] < 500:
        return 3.21
    elif x["APD"] < 600:
        return 2.91
    elif x["APD"] < 700:
        return 2.67
    elif x["APD"] < 800:
        return 2.47
    elif x["APD"] < 900:
        return 2.27
    elif x["APD"] < 1000:
        return 2.11
    elif x["APD"] < 1100:
        return 1.96
    elif x["APD"] < 1200:
        return 1.84
    elif x["APD"] < 1300:
        return 1.73
    elif x["APD"] < 1400:
        return 1.63
    elif x["APD"] < 1500:
        return 1.53
    elif x["APD"] < 1600:
        return 1.46
    elif x["APD"] < 1700:
        return 1.39
    elif x["APD"] < 1800:
        return 1.32
    elif x["APD"] < 1900:
        return 1.26
    elif x["APD"] < 2000:
        return 1.20
    elif x["APD"] < 2100:
        return 1.15
    elif x["APD"] < 2200:
        return 1.11
    elif x["APD"] < 2300:
        return 1.05
    elif x["APD"] < 2400:
        return 1.01
    elif x["APD"] < 2500:
        return 0.97
    else:
        return 0.94


def f_reason_percentiles_RPCT_B(x):
    if x["COLL"] < 1:
        return 100.00
    elif x["COLL"] < 100:
        return 18.08
    elif x["COLL"] < 200:
        return 16.29
    elif x["COLL"] < 300:
        return 13.81
    elif x["COLL"] < 400:
        return 12.15
    elif x["COLL"] < 500:
        return 10.91
    elif x["COLL"] < 600:
        return 9.92
    elif x["COLL"] < 700:
        return 9.15
    elif x["COLL"] < 800:
        return 8.48
    elif x["COLL"] < 900:
        return 7.91
    elif x["COLL"] < 1000:
        return 7.43
    elif x["COLL"] < 1100:
        return 6.98
    elif x["COLL"] < 1200:
        return 6.57
    elif x["COLL"] < 1300:
        return 6.22
    elif x["COLL"] < 1400:
        return 5.92
    elif x["COLL"] < 1500:
        return 5.63
    elif x["COLL"] < 1600:
        return 5.37
    elif x["COLL"] < 1700:
        return 5.14
    elif x["COLL"] < 1800:
        return 4.91
    elif x["COLL"] < 1900:
        return 4.71
    elif x["COLL"] < 2000:
        return 4.51
    elif x["COLL"] < 2100:
        return 4.33
    elif x["COLL"] < 2200:
        return 4.15
    elif x["COLL"] < 2300:
        return 4.00
    elif x["COLL"] < 2400:
        return 3.86
    elif x["COLL"] < 2500:
        return 3.71
    elif x["COLL"] < 2600:
        return 3.57
    elif x["COLL"] < 2700:
        return 3.45
    elif x["COLL"] < 2800:
        return 3.34
    elif x["COLL"] < 2900:
        return 3.23
    elif x["COLL"] < 3000:
        return 3.13
    elif x["COLL"] < 3200:
        return 3.02
    elif x["COLL"] < 3400:
        return 2.84
    elif x["COLL"] < 3600:
        return 2.66
    elif x["COLL"] < 3800:
        return 2.51
    elif x["COLL"] < 4000:
        return 2.36
    elif x["COLL"] < 4200:
        return 2.22
    elif x["COLL"] < 4400:
        return 2.10
    elif x["COLL"] < 4600:
        return 1.99
    elif x["COLL"] < 4800:
        return 1.89
    elif x["COLL"] < 5000:
        return 1.79
    elif x["COLL"] < 5500:
        return 1.71
    elif x["COLL"] < 6000:
        return 1.51
    elif x["COLL"] < 6500:
        return 1.34
    elif x["COLL"] < 7000:
        return 1.18
    elif x["COLL"] < 7500:
        return 1.06
    elif x["COLL"] < 8000:
        return 0.95
    else:
        return 0.87


def f_reason_percentiles_RPCT_C(x):
    if (x["DPR"] - x["NBANKRUPT"] - x["NTAXLIEN"]) < 1:
        return 100.00
    else:
        return 5.00


def f_reason_percentiles_RPCT_F(x):
    if x["NOPA"] < 4:
        if x["RRF_FACT"] < 1.1590:
            return 100.00
        else:
            return 32.00
    elif x["RRF_FACT"] < 1.1160:
        return 100.00
    else:
        return 1.00


def f_reason_percentiles_RPCT_G(x):
    if x["NOPA"] < 4:
        if x["RRG_FACT"] < 0.8960:
            return 100.00
        elif x["RRG_FACT"] < 0.9050:
            return 74.00
        elif x["RRG_FACT"] < 0.9420:
            return 60.00
        elif x["RRG_FACT"] < 0.9530:
            return 44.00
        elif x["RRG_FACT"] < 0.9860:
            return 35.00
        elif x["RRG_FACT"] < 1.0230:
            return 28.00
        else:
            return 8.00
    elif x["RRG_FACT"] < 0.9038:
        return 100.00
    elif x["RRG_FACT"] < 0.9070:
        return 96.00
    elif x["RRG_FACT"] < 0.9143:
        return 92.00
    elif x["RRG_FACT"] < 0.9255:
        return 88.00
    elif x["RRG_FACT"] < 0.9295:
        return 86.00
    elif x["RRG_FACT"] < 0.9377:
        return 85.00
    elif x["RRG_FACT"] < 0.9484:
        return 84.00
    elif x["RRG_FACT"] < 0.9517:
        return 80.00
    elif x["RRG_FACT"] < 0.9546:
        return 78.00
    elif x["RRG_FACT"] < 0.9594:
        return 74.00
    elif x["RRG_FACT"] < 0.9712:
        return 72.00
    elif x["RRG_FACT"] < 0.9720:
        return 71.00
    elif x["RRG_FACT"] < 0.9754:
        return 70.00
    elif x["RRG_FACT"] < 0.9828:
        return 67.00
    elif x["RRG_FACT"] < 0.9831:
        return 66.00
    elif x["RRG_FACT"] < 0.9865:
        return 64.00
    elif x["RRG_FACT"] < 0.9877:
        return 62.00
    elif x["RRG_FACT"] < 0.9895:
        return 59.00
    elif x["RRG_FACT"] < 0.9936:
        return 58.00
    elif x["RRG_FACT"] < 0.9940:
        return 56.00
    elif x["RRG_FACT"] < 0.9945:
        return 55.00
    elif x["RRG_FACT"] < 0.9975:
        return 53.00
    elif x["RRG_FACT"] < 0.9989:
        return 52.00
    elif x["RRG_FACT"] < 1.0005:
        return 50.00
    elif x["RRG_FACT"] < 1.0025:
        return 49.00
    elif x["RRG_FACT"] < 1.0034:
        return 47.00
    elif x["RRG_FACT"] < 1.0050:
        return 45.00
    elif x["RRG_FACT"] < 1.0055:
        return 44.00
    elif x["RRG_FACT"] < 1.0067:
        return 43.00
    elif x["RRG_FACT"] < 1.0084:
        return 40.00
    elif x["RRG_FACT"] < 1.0095:
        return 39.00
    elif x["RRG_FACT"] < 1.0105:
        return 38.00
    elif x["RRG_FACT"] < 1.0111:
        return 37.00
    elif x["RRG_FACT"] < 1.0115:
        return 36.00
    elif x["RRG_FACT"] < 1.0145:
        return 35.00
    elif x["RRG_FACT"] < 1.0148:
        return 34.00
    elif x["RRG_FACT"] < 1.0160:
        return 33.00
    elif x["RRG_FACT"] < 1.0165:
        return 32.00
    elif x["RRG_FACT"] < 1.0184:
        return 31.00
    elif x["RRG_FACT"] < 1.0214:
        return 30.00
    elif x["RRG_FACT"] < 1.0223:
        return 28.00
    elif x["RRG_FACT"] < 1.0229:
        return 27.00
    elif x["RRG_FACT"] < 1.0265:
        return 26.00
    elif x["RRG_FACT"] < 1.0290:
        return 25.00
    elif x["RRG_FACT"] < 1.0335:
        return 24.00
    elif x["RRG_FACT"] < 1.0622:
        return 22.00
    elif x["RRG_FACT"] < 1.0720:
        return 21.00
    elif x["RRG_FACT"] < 1.0757:
        return 20.00
    elif x["RRG_FACT"] < 1.0813:
        return 19.00
    elif x["RRG_FACT"] < 1.0828:
        return 17.00
    elif x["RRG_FACT"] < 1.0913:
        return 16.00
    elif x["RRG_FACT"] < 1.0936:
        return 14.00
    elif x["RRG_FACT"] < 1.1022:
        return 13.00
    elif x["RRG_FACT"] < 1.1150:
        return 11.00
    elif x["RRG_FACT"] < 1.1735:
        return 9.00
    elif x["RRG_FACT"] < 1.1910:
        return 7.00
    elif x["RRG_FACT"] < 1.2024:
        return 6.00
    elif x["RRG_FACT"] < 1.2170:
        return 5.00
    elif x["RRG_FACT"] < 1.2467:
        return 4.00
    elif x["RRG_FACT"] < 1.2878:
        return 3.00
    elif x["RRG_FACT"] < 1.3528:
        return 2.00
    else:
        return 0.00


def f_reason_percentiles_RPCT_H(x):
    if x["MOPHI"] < 1:
        return 100.00
    elif x["MOPHI"] < 2:
        return 17.29
    elif x["MOPHI"] < 3:
        return 11.15
    elif x["MOPHI"] < 4:
        return 8.38
    elif x["MOPHI"] < 5:
        return 6.44
    elif x["MOPHI"] < 6:
        return 4.91
    elif x["MOPHI"] < 7:
        return 3.73
    elif x["MOPHI"] < 8:
        return 2.80
    elif x["MOPHI"] < 9:
        return 2.10
    else:
        return 1.56


def f_reason_percentiles_RPCT_K(x):
    if x["NBANKRUPT"] < 1:
        return 100.00
    else:
        return 5.00


def f_reason_percentiles_RPCT_M(x):
    if x["NTAXLIEN"] < 1:
        return 100.00
    else:
        return 3.00


def f_reason_percentiles_RPCT_U(x):
    if x["NOPA"] < 4:
        if x["RRU_FACT"] < 0.9675:
            return 100.00
        elif x["RRU_FACT"] < 0.9772:
            return 74.00
        elif x["RRU_FACT"] < 1.0173:
            return 60.00
        elif x["RRU_FACT"] < 1.0286:
            return 44.00
        elif x["RRU_FACT"] < 1.0644:
            return 35.00
        else:
            return 28.00
    elif x["RRU_FACT"] < 0.9930:
        return 100.00
    elif x["RRU_FACT"] < 0.9965:
        return 84.00
    elif x["RRU_FACT"] < 0.9995:
        return 73.00
    elif x["RRU_FACT"] < 1.0040:
        return 56.00
    elif x["RRU_FACT"] < 1.0045:
        return 45.00
    elif x["RRU_FACT"] < 1.0085:
        return 38.00
    elif x["RRU_FACT"] < 1.0169:
        return 30.00
    elif x["RRU_FACT"] < 1.0213:
        return 10.00
    else:
        return 6.00


def f_reason_percentiles_RPCT_2(x):
    if x["RR2_FACT"] < 0.8983:
        return 100.00
    elif x["RR2_FACT"] < 0.9163:
        return 94.00
    elif x["RR2_FACT"] < 0.9398:
        return 88.00
    elif x["RR2_FACT"] < 0.9472:
        return 80.00
    elif x["RR2_FACT"] < 0.9567:
        return 72.00
    elif x["RR2_FACT"] < 0.9596:
        return 66.00
    elif x["RR2_FACT"] < 0.9662:
        return 65.00
    elif x["RR2_FACT"] < 0.9683:
        return 58.00
    elif x["RR2_FACT"] < 0.9686:
        return 57.00
    elif x["RR2_FACT"] < 0.9763:
        return 53.00
    elif x["RR2_FACT"] < 0.9875:
        return 52.00
    elif x["RR2_FACT"] < 0.9977:
        return 51.00
    elif x["RR2_FACT"] < 1.0045:
        return 48.00
    elif x["RR2_FACT"] < 1.0094:
        return 47.00
    elif x["RR2_FACT"] < 1.0125:
        return 45.00
    elif x["RR2_FACT"] < 1.0169:
        return 44.00
    elif x["RR2_FACT"] < 1.0191:
        return 43.00
    elif x["RR2_FACT"] < 1.0213:
        return 42.00
    elif x["RR2_FACT"] < 1.0243:
        return 41.00
    elif x["RR2_FACT"] < 1.0271:
        return 40.00
    elif x["RR2_FACT"] < 1.0361:
        return 39.00
    elif x["RR2_FACT"] < 1.0412:
        return 37.00
    elif x["RR2_FACT"] < 1.0438:
        return 36.00
    elif x["RR2_FACT"] < 1.0448:
        return 35.00
    elif x["RR2_FACT"] < 1.0480:
        return 27.00
    elif x["RR2_FACT"] < 1.0496:
        return 26.00
    elif x["RR2_FACT"] < 1.0523:
        return 25.00
    elif x["RR2_FACT"] < 1.0546:
        return 24.00
    elif x["RR2_FACT"] < 1.0578:
        return 23.00
    elif x["RR2_FACT"] < 1.0628:
        return 22.00
    elif x["RR2_FACT"] < 1.0654:
        return 21.00
    elif x["RR2_FACT"] < 1.0778:
        return 20.00
    elif x["RR2_FACT"] < 1.0779:
        return 19.00
    elif x["RR2_FACT"] < 1.0798:
        return 18.00
    elif x["RR2_FACT"] < 1.0879:
        return 17.00
    elif x["RR2_FACT"] < 1.0895:
        return 15.00
    elif x["RR2_FACT"] < 1.0915:
        return 14.00
    elif x["RR2_FACT"] < 1.0916:
        return 13.00
    elif x["RR2_FACT"] < 1.0927:
        return 12.00
    elif x["RR2_FACT"] < 1.0965:
        return 11.00
    elif x["RR2_FACT"] < 1.0990:
        return 9.00
    elif x["RR2_FACT"] < 1.0997:
        return 8.00
    elif x["RR2_FACT"] < 1.1004:
        return 7.00
    elif x["RR2_FACT"] < 1.1030:
        return 6.00
    elif x["RR2_FACT"] < 1.1033:
        return 5.00
    elif x["RR2_FACT"] < 1.1063:
        return 4.00
    elif x["RR2_FACT"] < 1.1073:
        return 3.00
    elif x["RR2_FACT"] < 1.1268:
        return 2.00
    else:
        return 1.00


def f_reason_percentiles_RPCT_3(x):
    if x["NOPA"] < 4:
        if x["RR3_FACT"] < 0.9940:
            return 100.00
        elif x["RR3_FACT"] < 1.0054:
            return 57.00
        elif x["RR3_FACT"] < 1.0393:
            return 53.00
        elif x["RR3_FACT"] < 1.0502:
            return 49.00
        elif x["RR3_FACT"] < 1.1049:
            return 44.00
        elif x["RR3_FACT"] < 1.1074:
            return 37.00
        elif x["RR3_FACT"] < 1.1332:
            return 35.00
        elif x["RR3_FACT"] < 1.1448:
            return 30.00
        elif x["RR3_FACT"] < 1.1568:
            return 28.00
        elif x["RR3_FACT"] < 1.2096:
            return 27.00
        elif x["RR3_FACT"] < 1.2170:
            return 25.00
        elif x["RR3_FACT"] < 1.2482:
            return 15.00
        else:
            return 7.00
    elif x["RR3_FACT"] < 0.9940:
        return 100.00
    elif x["RR3_FACT"] < 1.0054:
        return 46.00
    elif x["RR3_FACT"] < 1.0393:
        return 44.00
    elif x["RR3_FACT"] < 1.0502:
        return 19.00
    elif x["RR3_FACT"] < 1.0981:
        return 15.00
    elif x["RR3_FACT"] < 1.1049:
        return 13.00
    elif x["RR3_FACT"] < 1.1332:
        return 4.00
    else:
        return 1.00


def f_reason_percentiles_RPCT_5(x):
    if x["NOPA"] < 1:
        return 100.00
    elif x["RR5_FACT"] < 0.8810:
        return 100.00
    elif x["RR5_FACT"] < 0.8920:
        return 92.00
    elif x["RR5_FACT"] < 0.9060:
        return 87.00
    elif x["RR5_FACT"] < 0.9200:
        return 82.00
    elif x["RR5_FACT"] < 0.9340:
        return 76.00
    elif x["RR5_FACT"] < 0.9410:
        return 71.00
    elif x["RR5_FACT"] < 0.9490:
        return 66.00
    elif x["RR5_FACT"] < 0.9640:
        return 62.00
    elif x["RR5_FACT"] < 0.9800:
        return 58.00
    elif x["RR5_FACT"] < 0.9960:
        return 53.00
    elif x["RR5_FACT"] < 1.0120:
        return 49.00
    elif x["RR5_FACT"] < 1.0290:
        return 46.00
    elif x["RR5_FACT"] < 1.0330:
        return 42.00
    elif x["RR5_FACT"] < 1.0370:
        return 39.00
    elif x["RR5_FACT"] < 1.0410:
        return 36.00
    elif x["RR5_FACT"] < 1.0450:
        return 33.00
    elif x["RR5_FACT"] < 1.0500:
        return 30.00
    elif x["RR5_FACT"] < 1.0550:
        return 28.00
    elif x["RR5_FACT"] < 1.0590:
        return 26.00
    elif x["RR5_FACT"] < 1.0690:
        return 24.00
    elif x["RR5_FACT"] < 1.0780:
        return 22.00
    elif x["RR5_FACT"] < 1.0860:
        return 20.00
    elif x["RR5_FACT"] < 1.0940:
        return 18.00
    elif x["RR5_FACT"] < 1.1040:
        return 17.00
    elif x["RR5_FACT"] < 1.1120:
        return 15.00
    elif x["RR5_FACT"] < 1.1210:
        return 14.00
    elif x["RR5_FACT"] < 1.1320:
        return 13.00
    elif x["RR5_FACT"] < 1.2210:
        return 12.00
    else:
        return 11.00


def f_reason_percentiles_RPCT_7(x):
    if x["NOPA"] < 4:
        if x["RR7_FACT"] < 1.0340:
            return 100.00
        elif x["RR7_FACT"] < 1.0510:
            return 61.00
        elif x["RR7_FACT"] < 1.1670:
            return 48.00
        elif x["RR7_FACT"] < 1.3660:
            return 21.00
        else:
            return 12.00
    elif x["RR7_FACT"] < 1.0100:
        return 100.00
    elif x["RR7_FACT"] < 1.0820:
        return 36.00
    elif x["RR7_FACT"] < 1.1360:
        return 16.00
    elif x["RR7_FACT"] < 1.1790:
        return 7.00
    else:
        return 1.00


def f_reason_percentiles_RPCT_8(x):
    if x["NOPA"] < 4:
        if x["RR8_FACT"] < 1.0480:
            return 100.00
        else:
            return 15.00
    elif x["RR8_FACT"] < 0.9680:
        return 100.00
    elif x["RR8_FACT"] < 1.0050:
        return 53.00
    elif x["RR8_FACT"] < 1.0510:
        return 42.00
    elif x["RR8_FACT"] < 1.0760:
        return 33.00
    else:
        return 10.00


def f_reason_percentiles(df):

    df["RRF_FACT"] = round(df["RLEV_FACT_U1"] * 10000)/10000
    df["RRG_FACT"] = round(df["INQ06_FACT_U1"] * df["INQ24_FACT_U1"] *
                           np.sqrt(df["IADIF_FACT_U1"]) * 10000)/10000
    df["RRU_FACT"] = round(np.sqrt(df["IADIF_FACT_U1"]) * 10000)/10000
    df["RR2_FACT"] = round(df["NOPA_FACT_U1"] *
                           df["NOPRA_FACT_U1"] * 10000)/10000
    df["RR3_FACT"] = round(df["DEL84_FACT_U1"] *
                           np.sqrt(df["DDC_FACT_U1"]) * 10000)/10000
    df["RR5_FACT"] = round(df["AWOAO_FACT_U1"] * 10000)/10000
    df["RR7_FACT"] = round(df["AVGMAO_FACT_U1"] * 10000)/10000
    df["RR8_FACT"] = round(df["PORAL50_FACT_U1"] * 10000)/10000
    df["RPCT_A"] = df.apply(f_reason_percentiles_RPCT_A, axis=1)
    df["RPCT_B"] = df.apply(f_reason_percentiles_RPCT_B, axis=1)
    df["RPCT_C"] = df.apply(f_reason_percentiles_RPCT_C, axis=1)
    df["RPCT_F"] = df.apply(f_reason_percentiles_RPCT_F, axis=1)
    df["RPCT_G"] = df.apply(f_reason_percentiles_RPCT_G, axis=1)
    df["RPCT_H"] = df.apply(f_reason_percentiles_RPCT_H, axis=1)
    df["RPCT_K"] = df.apply(f_reason_percentiles_RPCT_K, axis=1)
    df["RPCT_M"] = df.apply(f_reason_percentiles_RPCT_M, axis=1)
    df["RPCT_U"] = df.apply(f_reason_percentiles_RPCT_U, axis=1)
    df["RPCT_2"] = df.apply(f_reason_percentiles_RPCT_2, axis=1)
    df["RPCT_3"] = df.apply(f_reason_percentiles_RPCT_3, axis=1)
    df["RPCT_5"] = df.apply(f_reason_percentiles_RPCT_5, axis=1)
    df["RPCT_7"] = df.apply(f_reason_percentiles_RPCT_7, axis=1)
    df["RPCT_8"] = df.apply(f_reason_percentiles_RPCT_8, axis=1)

    return df


def f_reason_ranks_RRA(x):
    a = 0
    if x["RPCT_A"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_C"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_F"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_A"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    a += 1
    return a


def f_reason_ranks_RRB(x):
    a = 0
    if x["RPCT_B"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_C"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_F"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_B"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    a += 1
    return a


def f_reason_ranks_RRC(x):
    a = 0
    if x["RPCT_C"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_C"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_F"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_C"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    a += 1
    return a


def f_reason_ranks_RRF(x):
    a = 0
    if x["RPCT_F"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_C"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_F"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_F"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    a += 1
    return a


def f_reason_ranks_RRG(x):
    a = 0
    if x["RPCT_G"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_C"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_F"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_G"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    a += 1
    return a


def f_reason_ranks_RRH(x):
    a = 0
    if x["RPCT_H"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_C"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_F"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_H"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    a += 1
    return a


def f_reason_ranks_RRK(x):
    a = 0
    if x["RPCT_K"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_C"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_F"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_K"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    a += 1
    return a


def f_reason_ranks_RRM(x):
    a = 0
    if x["RPCT_M"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_C"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_F"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_M"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    a += 1
    return a


def f_reason_ranks_RRU(x):
    a = 0
    if x["RPCT_U"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_C"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_F"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_U"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    a += 1
    return a


def f_reason_ranks_RR2(x):
    a = 0
    if x["RPCT_2"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_C"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_F"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_2"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    a += 1
    return a


def f_reason_ranks_RR3(x):
    a = 0
    if x["RPCT_3"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_C"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_F"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_3"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    a += 1
    return a


def f_reason_ranks_RR5(x):
    a = 0
    if x["RPCT_5"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_C"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_F"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_5"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    a += 1
    return a


def f_reason_ranks_RR7(x):
    a = 0
    if x["RPCT_7"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_C"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_F"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_7"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    a += 1
    return a


def f_reason_ranks_RR8(x):
    a = 0
    if x["RPCT_8"] > x["RPCT_A"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_B"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_C"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_F"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_G"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_H"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_K"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_M"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_U"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_2"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_3"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_5"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_7"]:
        a += 1
    else:
        a += 0
    if x["RPCT_8"] > x["RPCT_8"]:
        a += 1
    else:
        a += 0
    a += 1
    return a


def f_reason_ranks_RC1(x):
    if x["PFMU_LEVEL"] == "BD":
        return ""
    elif x["RRA"] == 1 and x["RPCT_A"] < 100:
        return "A"
    elif x["RRB"] == 1 and x["RPCT_B"] < 100:
        return "B"
    elif x["RRC"] == 1 and x["RPCT_C"] < 100:
        return "C"
    elif x["RRF"] == 1 and x["RPCT_F"] < 100:
        return "F"
    elif x["RRG"] == 1 and x["RPCT_G"] < 100:
        return "G"
    elif x["RRH"] == 1 and x["RPCT_H"] < 100:
        return "H"
    elif x["RRK"] == 1 and x["RPCT_K"] < 100:
        return "K"
    elif x["RRM"] == 1 and x["RPCT_M"] < 100:
        return "M"
    elif x["RRU"] == 1 and x["RPCT_U"] < 100:
        return "U"
    elif x["RR2"] == 1 and x["RPCT_2"] < 100:
        return "2"
    elif x["RR3"] == 1 and x["RPCT_3"] < 100:
        return "3"
    elif x["RR5"] == 1 and x["RPCT_5"] < 100:
        return "5"
    elif x["RR7"] == 1 and x["RPCT_7"] < 100:
        return "7"
    elif x["RR8"] == 1 and x["RPCT_8"] < 100:
        return "8"
    else:
        return ""


def f_reason_ranks_RC2(x):
    if x["PFMU_LEVEL"] == "BD":
        return ""
    elif x["RRA"] == 2 and x["RPCT_A"] < 100:
        return "A"
    elif x["RRB"] == 2 and x["RPCT_B"] < 100:
        return "B"
    elif x["RRC"] == 2 and x["RPCT_C"] < 100:
        return "C"
    elif x["RRF"] == 2 and x["RPCT_F"] < 100:
        return "F"
    elif x["RRG"] == 2 and x["RPCT_G"] < 100:
        return "G"
    elif x["RRH"] == 2 and x["RPCT_H"] < 100:
        return "H"
    elif x["RRK"] == 2 and x["RPCT_K"] < 100:
        return "K"
    elif x["RRM"] == 2 and x["RPCT_M"] < 100:
        return "M"
    elif x["RRU"] == 2 and x["RPCT_U"] < 100:
        return "U"
    elif x["RR2"] == 2 and x["RPCT_2"] < 100:
        return "2"
    elif x["RR3"] == 2 and x["RPCT_3"] < 100:
        return "3"
    elif x["RR5"] == 2 and x["RPCT_5"] < 100:
        return "5"
    elif x["RR7"] == 2 and x["RPCT_7"] < 100:
        return "7"
    elif x["RR8"] == 2 and x["RPCT_8"] < 100:
        return "8"
    else:
        return ""


def f_reason_ranks_RC3(x):
    if x["PFMU_LEVEL"] == "BD":
        return ""
    elif x["RRA"] == 3 and x["RPCT_A"] < 100:
        return "A"
    elif x["RRB"] == 3 and x["RPCT_B"] < 100:
        return "B"
    elif x["RRC"] == 3 and x["RPCT_C"] < 100:
        return "C"
    elif x["RRF"] == 3 and x["RPCT_F"] < 100:
        return "F"
    elif x["RRG"] == 3 and x["RPCT_G"] < 100:
        return "G"
    elif x["RRH"] == 3 and x["RPCT_H"] < 100:
        return "H"
    elif x["RRK"] == 3 and x["RPCT_K"] < 100:
        return "K"
    elif x["RRM"] == 3 and x["RPCT_M"] < 100:
        return "M"
    elif x["RRU"] == 3 and x["RPCT_U"] < 100:
        return "U"
    elif x["RR2"] == 3 and x["RPCT_2"] < 100:
        return "2"
    elif x["RR3"] == 3 and x["RPCT_3"] < 100:
        return "3"
    elif x["RR5"] == 3 and x["RPCT_5"] < 100:
        return "5"
    elif x["RR7"] == 3 and x["RPCT_7"] < 100:
        return "7"
    elif x["RR8"] == 3 and x["RPCT_8"] < 100:
        return "8"
    else:
        return ""


def f_reason_ranks_RC4(x):
    if x["PFMU_LEVEL"] == "BD":
        return ""
    elif x["RRA"] == 4 and x["RPCT_A"] < 100:
        return "A"
    elif x["RRB"] == 4 and x["RPCT_B"] < 100:
        return "B"
    elif x["RRC"] == 4 and x["RPCT_C"] < 100:
        return "C"
    elif x["RRF"] == 4 and x["RPCT_F"] < 100:
        return "F"
    elif x["RRG"] == 4 and x["RPCT_G"] < 100:
        return "G"
    elif x["RRH"] == 4 and x["RPCT_H"] < 100:
        return "H"
    elif x["RRK"] == 4 and x["RPCT_K"] < 100:
        return "K"
    elif x["RRM"] == 4 and x["RPCT_M"] < 100:
        return "M"
    elif x["RRU"] == 4 and x["RPCT_U"] < 100:
        return "U"
    elif x["RR2"] == 4 and x["RPCT_2"] < 100:
        return "2"
    elif x["RR3"] == 4 and x["RPCT_3"] < 100:
        return "3"
    elif x["RR5"] == 4 and x["RPCT_5"] < 100:
        return "5"
    elif x["RR7"] == 4 and x["RPCT_7"] < 100:
        return "7"
    elif x["RR8"] == 4 and x["RPCT_8"] < 100:
        return "8"
    else:
        return ""


def f_reason_ranks_RC5(x):
    if x["PFMU_LEVEL"] == "BD":
        return ""
    elif x["RRA"] == 5 and x["RPCT_A"] < 100:
        return "A"
    elif x["RRB"] == 5 and x["RPCT_B"] < 100:
        return "B"
    elif x["RRC"] == 5 and x["RPCT_C"] < 100:
        return "C"
    elif x["RRF"] == 5 and x["RPCT_F"] < 100:
        return "F"
    elif x["RRG"] == 5 and x["RPCT_G"] < 100:
        return "G"
    elif x["RRH"] == 5 and x["RPCT_H"] < 100:
        return "H"
    elif x["RRK"] == 5 and x["RPCT_K"] < 100:
        return "K"
    elif x["RRM"] == 5 and x["RPCT_M"] < 100:
        return "M"
    elif x["RRU"] == 5 and x["RPCT_U"] < 100:
        return "U"
    elif x["RR2"] == 5 and x["RPCT_2"] < 100:
        return "2"
    elif x["RR3"] == 5 and x["RPCT_3"] < 100:
        return "3"
    elif x["RR5"] == 5 and x["RPCT_5"] < 100:
        return "5"
    elif x["RR7"] == 5 and x["RPCT_7"] < 100:
        return "7"
    elif x["RR8"] == 5 and x["RPCT_8"] < 100:
        return "8"
    else:
        return ""


def f_reason_ranks(df):

    df["RPCT_A"] = df["RPCT_A"] + 0.0001
    df["RPCT_B"] = df["RPCT_B"] + 0.0002
    df["RPCT_C"] = df["RPCT_C"] + 0.0003
    df["RPCT_F"] = df["RPCT_F"] + 0.0004
    df["RPCT_G"] = df["RPCT_G"] + 0.0005
    df["RPCT_H"] = df["RPCT_H"] + 0.0006
    df["RPCT_K"] = df["RPCT_K"] + 0.0007
    df["RPCT_M"] = df["RPCT_M"] + 0.0008
    df["RPCT_U"] = df["RPCT_U"] + 0.0009
    df["RPCT_2"] = df["RPCT_2"] + 0.0010
    df["RPCT_3"] = df["RPCT_3"] + 0.0011
    df["RPCT_5"] = df["RPCT_5"] + 0.0012
    df["RPCT_7"] = df["RPCT_7"] + 0.0013
    df["RPCT_8"] = df["RPCT_8"] + 0.0014
    df["RRA"] = df.apply(f_reason_ranks_RRA, axis=1)
    df["RRB"] = df.apply(f_reason_ranks_RRB, axis=1)
    df["RRC"] = df.apply(f_reason_ranks_RRC, axis=1)
    df["RRF"] = df.apply(f_reason_ranks_RRF, axis=1)
    df["RRG"] = df.apply(f_reason_ranks_RRG, axis=1)
    df["RRH"] = df.apply(f_reason_ranks_RRH, axis=1)
    df["RRK"] = df.apply(f_reason_ranks_RRK, axis=1)
    df["RRM"] = df.apply(f_reason_ranks_RRM, axis=1)
    df["RRU"] = df.apply(f_reason_ranks_RRU, axis=1)
    df["RR2"] = df.apply(f_reason_ranks_RR2, axis=1)
    df["RR3"] = df.apply(f_reason_ranks_RR3, axis=1)
    df["RR5"] = df.apply(f_reason_ranks_RR5, axis=1)
    df["RR7"] = df.apply(f_reason_ranks_RR7, axis=1)
    df["RR8"] = df.apply(f_reason_ranks_RR8, axis=1)
    df["RC1"] = df.apply(f_reason_ranks_RC1, axis=1)
    df["RC2"] = df.apply(f_reason_ranks_RC2, axis=1)
    df["RC3"] = df.apply(f_reason_ranks_RC3, axis=1)
    df["RC4"] = df.apply(f_reason_ranks_RC4, axis=1)
    df["RC5"] = df.apply(f_reason_ranks_RC5, axis=1)
    df["Reasons"] = (df["RC1"].astype(str) + df["RC2"].astype(str) +
                     df["RC3"].astype(str) + df["RC4"].astype(str) +
                     df["RC5"].astype(str))

    return df


def pfm_model_u(df):

    df = f_u1_factors(df)
    df = f_u2_factors(df)
    df = f_calc_raw_scores(df)
    df = f_score_adjust(df)
    df = f_scale_score(df)
    df["PFMU_LEVEL"] = df.apply(f_PFMU_LEVEL, axis=1)
    df = f_reason_percentiles(df)
    df = f_reason_ranks(df)
    df = df.drop(["State", "AVGMAO", "MOLDAOP", "INQ06",
                  "MRECDPR", "NOPA", "AOP24", "AOP06",
                  "MRECDEL", "MOLDRAOP", "RLIM", "RBAL",
                  "NOPRA", "HIMOPEVER", "PH_AGE", "PORAL50",
                  "PORAL75", "DEL84", "DEL24", "DPRAMT", "NMORT",
                  "NHELOAN", "INQ24", "NOMORT", "AGE_IN_MONTHS",
                  "AWOAO", "IADIF", "NMORTHEL", "RLEV", "APD_FLAG",
                  "COLL_FLAG", "DPR_FLAG", "DDC_COMBO2"], axis=1)
    df = df.rename(columns={"PFMU_LEVEL": "Level"})
    df = df.drop(["APD", "Leverage", "DPR", "DPR24m", "MOPHI",
                  "COLL", "NBANKRUPT", "NTAXLIEN", "ACD_COMBO",
                  "MOP_COMBO", "DDC_COMBO", "NOPA_GRP", "AWOAO_BIN",
                  "NOPA_AVGMAO", "NOPA_CAP", "NOPA_DEL84", "NOPA_IADIF",
                  "NOPA_INQ06", "NOPA_INQ24", "NOPA_NOPRA", "NOPA_PORAL50",
                  "NOPA_RLEVTYPE", "DEL24_CAP", "NOMORT_CAP", "PORAL50_BIN",
                  "AOP24_BIN", "AVGMAO_BIN", "NOPA_INQ24B", "NOPA_NMORTHEL",
                  "NOPA_RLEV", "NOPA_ACD", "NOPA_MOP", "AVGMAO_FACT_U1",
                  "AWOAO_FACT_U1", "DEL84_FACT_U1", "DDC_FACT_U1",
                  "IADIF_FACT_U1",
                  "INQ06_FACT_U1", "INQ24_FACT_U1", "NOPA_FACT_U1",
                  "NOPRA_FACT_U1", "PORAL50_FACT_U1", "RLEV_FACT_U1",
                  "ACD_FACT_U2", "AOP24_FACT_U2",
                  "AVGMAO_FACT_U2", "DEL24_FACT_U2",
                  "INQ24_FACT_U2", "MOP_FACT_U2",
                  "NMORTHEL_FACT_U2", "NOMORT_FACT_U2", "PORAL50_FACT_U2",
                  "RLEV_FACT_U2", "PFMU_LRSCORE", "PFMU_MOSCORE",
                  "PFMU_ADJSCORE", "RRF_FACT", "RRG_FACT",
                  "RRU_FACT", "RR2_FACT", "RR3_FACT",
                  "RR5_FACT", "RR7_FACT", "RR8_FACT",
                  "RPCT_A", "RPCT_B", "RPCT_C", "RPCT_F", "RPCT_G",
                  "RPCT_H", "RPCT_K", "RPCT_M", "RPCT_U", "RPCT_2",
                  "RPCT_3", "RPCT_5", "RPCT_7", "RPCT_8", "RRA", "RRB",
                  "RRC", "RRF", "RRG", "RRH", "RRK", "RRM", "RRU",
                  "RR2", "RR3", "RR5", "RR7", "RR8", "RC1", "RC2",
                  "RC3", "RC4"], axis=1)
    df["PFMScore"] = df["PFMU_SCORE"].astype(str)
    df = df.drop(["PFMU_SCORE", "RC5"], axis=1)

    return df
