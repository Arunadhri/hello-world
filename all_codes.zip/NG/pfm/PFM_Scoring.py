##############################################################################
# ----------------------------------------------------------------------------
#                            Program Information
# ----------------------------------------------------------------------------
# Author                 : Sushant Kulkarni
# Creation Date          : 08FEB2019
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#                             Script Information
# ---------------------------------------------------------------------------
# Script Name            :
# Bitbucket Project/Repo :
# Brief Description      :
# Data used              :
#
# Output Files           :
#
# Notes / Assumptions    :
# ---------------------------------------------------------------------------
#                            Environment Information
# ---------------------------------------------------------------------------
# Python Version         : 3.6.3
# Anaconda Version       : 5.0.1
# Spark Version          : 2.3.0
# Operating System       : Red Hat Linux 7.4
# ---------------------------------------------------------------------------
#                           Change Control Information
# ---------------------------------------------------------------------------
# Developer Name/Date   : Change and Reason
# ###########################################################################

# ----------------------------------------------------------------------------
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("PFM_scoring").enableHiveSupport().getOrCreate()

import pandas as pd
import datetime
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# --------------define-PFM-specific-reusable-functions-here-------------------
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
def to_upper_and_trim(x):
	''' Converts string to upper case and strips whitespace

	'''
	x = str(x).upper()
	x = x.trim()
	return (x)
# ----------------------------------------------------------------------------

# Load file 

# ----------------------------------------------------------------------------
# Nodes disabled
""""
initialDF["LOBSubCd"] = "AUTO"
initialDF["NewRenewInd"] = ""
initialDF["State"] = "MD"
"""
# ----------------------------------------------------------------------------


# ----------------------------------------------------------------------------
# Default value supernode: Nugget ID - id472URHZAWYQ
def f_default_value(df):

	value_92 = ["CRATE2", "INQEVLI", "LOCINQS_30", "LP30P", "LP30P24", 
			    "LP60P", "LP60P24", "LP90P", "LP90P24", "PRDEROG",
			    "PRDEROG24_EX", "TOPEN", "TOPEN24", "TOPEN6", "TOPENR_REP",
			    "TOPENR24", "TROPENB50", "TROPENB75", "TRR29"]
	for col in value_92:
		df.loc[df[i] > 92, col] = 0

	value_992 = ["CRDPTH", "CRDPTHREV", "PRAGE", "PRAGE_BKP", "TMINAGE_REP"]
	for col in value_992:
		df.loc[df[i] > 9992, col] = 0

	value_9999992 = ["AMTPD", "COLLSAMT", "PRAMT", "TSBALR", "TSHICR"]
	for col in value_9999992:
		df.loc[df[i] > 9999992, col] = 0

	df.loc[df['BRHICRAT'] > 9.9992, 'BRHICRAT'] = 0

	df.loc[df['AVGMOS'] > 992, 'AVGMOS'] = 0

	df.loc[df['WRRATE_MER'] > 9, 'WRRATE_MER'] = 0

	df.loc[df['WRRATE_MER'] = 6, 'WRRATE_MER'] = 8

	return df

DefaultDF = f_default_value(initialDF)
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# Nugget iD: id5NUUHEB7TAH
up_trim_cols = ["LOBCd", "CreditInquiryStatus", "State", "NewRenewInd", "LOBSubCd"]
for col in up_trim_cols:
	DefaultDF[col] = DefaultDF[col].apply(to_upper_and_trim)
	DefaultDF[col] = DefaultDF[col].apply(to_upper_and_trim)
# ----------------------------------------------------------------------------


# ----------------------------------------------------------------------------
# Disabled Node
"""
# Nugget iD: id6Y7U6UC1YVT
def LOBCd_replace(x):

	if (x == "AUTO") | (x == "A") | (x == "AUTO"):
		lobcd = "AUTO"
	elif (x == "HOME") | (x == "H") | (x == "AUTO"):
		lobcd = "HOME"
	elif (x == "UMBRL") | (x == "U") | (x == "UMBRELLA"):
		lobcd = "UMB"
	else:
		lobcd = x

	return lobcd

DefaultDF["x["LOBCd"]"] = DefaultDF.x["LOBCd"].apply(LOBCd_replace)
"""
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
DefaultDF["ProviderStartDateTs"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
DefaultDF["ProviderStartDateTs"] = pd.to_datetime(DefaultDF["ProviderStartDateTs"])
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# TO BE UPDATED
"""" 
trim(GuidewireID)='' or trim(GuidewireAccountNumber)='' 
or trim(State)='' or trim(WritingCo)='' 
or PolEffDt=undef or PolAppDt=undef or (x["LOBCd"]  /= 'HOME'  and x["LOBCd"]  /= 'AUTO'  )  
or (CreditInquiryStatus  /=  'CREDIT BUREAU NO-HIT' and CreditInquiryStatus  /='UNSCORED'   and CreditInquiryStatus  /='COMPLETE, NO REPORT (CREDIT BUREAU MANUAL REPORT)'　　and CreditInquiryStatus  /=　'COMPLETE' )  
or (AMTPD=undef or AVGMOS=undef or BRHICRAT=undef or CRATE2=undef or CRDPTH=undef or INQEVLI=undef or LOCINQS_30=undef or PRAGE=undef or PRAGE_BKP=undef or PRDEROG=undef or PRDEROG24_EX=undef or TOPEN=undef or TOPEN24=undef or TOPEN6=undef or TRR29=undef or TMINAGE_REP=undef or CRDPTHREV=undef or TSHICR=undef or TSBALR=undef or TOPENR_REP=undef or WRRATE_MER=undef or COLLSAMT=undef or AGE_REP=undef or TROPENB50=undef or TROPENB75=undef or LP30P=undef or LP30P24=undef or LP60P=undef or LP60P24=undef or LP90P=undef or LP90P24=undef or PRAMT=undef or TOPENR24=undef or MTGOPN=undef or MTGREV=undef )  or  ( ( LOBSubCd  /= 'HOMEOWNERS'  and LOBSubCd  /= 'AUTO' and LOBSubCd  /= 'RENTERS' and LOBSubCd  /= 'CONDO')  or LOBSubCd=undef ) or ( NewRenewInd =undef or (NewRenewInd  /= 'NEW'  and NewRenewInd  /= 'RENEW' ) ) 
"""
# ----------------------------------------------------------------------------


# ----------------------------------------------------------------------------
subset1["Renewal_flag"] = ""
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# Supernode - update model used for State/WRC/product-nugget id: id6BYTKNFC549
def f_LOBCd_State(x):
	home_model_U = ["AL", "AR", "AZ", "CO", "DE", "IA", "ID", "IL", "IN", "KS", 
	                "KY", "LA", "MA", "ME", "MI", "MN", "MO", "MS", "ND", "NE", 
	                "NH", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "UT", 
	                "VA",  "VT", "WI", "WV", "WY"]
	auto_model_U = ["AL", "AR", "AZ", "CO", "DE", "IA", "ID", "IL", "IN", "KS", 
	                "KY", "LA", "ME", "MI", "MN", "MO", "MS", "ND", "NE", 
	                "NH", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "UT", 
	                "VA",  "VT", "WI", "WV", "WY"]

	if (x["LOBCd"]="HOME"):
		if (x["State"] in home_model_U):
			Model = "U"
		elif (x["State"] in ["CT", "NM", "WA"]):
			Model = "N"
		elif (x["State"] in ["DC", "FL"]):
			Model = "G"
		elif (x["State"] in ["NC", "NJ", "TX"]):
			Model = "L"
		elif (x["State"]="GA"):
			Model = "P"
		elif (x["State"]="MT"):
			Model = "O"
		elif (x["State"]="NV"):
			Model = "V"
		elif (x["State"]="NY"):
			Model = "K"
		elif (x["State"] in ["HI", "AK", "CA", "MD"]): 
			Model = "z"
	elif (x["LOBCd"]="AUTO"):
		if (x["State"] in auto_model_U):
			Model = "U"
		elif (x["State"] in ["CT", "NM", "WA"]):
			Model = "N"
		elif (x["State"] = "DC"): 
			Model = "G"
		elif (x["State"] in ["FL", "NV"]):
			Model = "V"
		elif (x["State"] = "GA"):
			Model = "P"
		elif (x["State"] in ["NC", "NJ", "TX"]):
			Model = "L"
		elif (x["State"]="MT"):
			Model = "O"
		elif (x["State"]="NY"):
			Model = "K"
		elif (x["State"]="MD"):
			Model = "M"
		elif (x["State"] in ["HI", "AK", "CA", "MA"]):
			Model = "z"
	else:
		Model = "z"

	return Model

subset1["Model"] = subset1.apply(f_LOBCd_State, axis=1)

subset1["G960"] = subset1["INQEVLI"]
subset1["MT02"] = subset1["MTGOPN"]

# Filter node
# 5 filtered, 31 renamed - best way to do??
dropcols = ["MOSOPEN_AK", "TOPEN24_WA", "TR29P24_BKP", "COLLSBOB_54B", "HELOANS"]
subset1.drop(dropcols, axis=1, inplace=True)

subset1.rename(columns = {"AMTPD" : "G091",
						  "AVGMOS" : "S004",
						  "BRHICRAT" : "Leverage",
						  "CRATE2" : "G001",
						  "CRDPTH" : "AT20",
						  "INQEVLI" : "G096",
						  "LOCINQS_30" : "G098",
						  "PRAGE" : "G095",
						  "PRDEROG" : "G093",
						  "TOPEN" : "S011",
						  "TOPEN24" : "AT09",
						  "TOPEN6" : "AT06",
						  "TRR29" : "S060",
						  "TMINAGE_REP" : "AT36",
						  "CRDPTHREV" : "RE20",
						  "TSHICR" : "RE28",
						  "TSBALR" : "RE33",
						  "TOPENR_REP" : "S012",
						  "WRRATE_MER" : "G089",
						  "COLLSAMT" : "S064",
						  "AGE_REP" : "PH_AGE",
						  "TROPENB50" : "RE30",
						  "TROPENB75" : "RE31",
						  "LP30P" : "G007",
						  "LP30P24" : "G061",
						  "LP60P24" : "G066",
						  "LP90P24" : "G071",
						  "PRAMT" : "DPRAMT",
						  "TOPENR24" : "RE09",
						  "MTGOPN" : "MT01",
						  "MTGREV" : "IHI01"}, inplace=True)

subset1["G002"] = subset1["G007"] - subset1["LP60P"]
subset1["G003"] = subset1["LP60P"] - subset1["LP90P"]
subset1["G094"] = subset1["G093"] - subset1["PRAGE_BKP"]
subset1["G004"] = subset1["LP60P"] - subset1["LP90P"]
subset1["ntaxlien"] = 0
subset1["AGE_IN_MONTHS"] = subset1["PH_AGE"]*12
# End of Supernode
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# Nugget id: id4NJU9V8YGIL
subset1["CreditInquiryStatus"] = subset1["CreditInquiryStatus"].apply(to_upper_and_trim)

# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------

def f_hub1_operations_level(x):

	if x["Model"] >= "A" and x["Model"] <= "J":
		Level = "2B"
	elif x["Model"] = "z":
		Level = ""
	else:
		if x["PH_AGE"] >= 16 and x["PH_AGE"] < 30:
			Level = "NQ"
		elif x["PH_AGE"] >= 30 and x["PH_AGE"] < 65:
			Level = "NK"
		elif x["PH_AGE"] >= 65 and x["PH_AGE"] < 130:
			Level = "NF"
		else:
			Level = "NN"
	return Level


def f_hub1_operations(subsetDF):
	'''
	from nugget id: id6XHRBIFQIYS to nugget id: id8ZTPY4B2RMR
 	also returns data from nugget id: id7ILQU9GU84Y
	'''

	subsetDF.rename(columns={"PRDEROG24_EX": "DPR24m"}, inplace=True)

	# Hub - COMPLETE NUGGETS
	# ------------------------------------------------------------------------
	hub_cis_complete = subset1[subset1["CreditInquiryStatus"] == "COMPLETE"]

	cond1 = hub_cis_complete["AT06"] == ""
	cond2 = hub_cis_complete["AT20"] == ""
	cond3 = ((hub_cis_complete["G096"] == 0) & (hub_cis_complete["S011"] == 0) & \
			 (hub_cis_complete["G093"] == 0) & (hub_cis_complete["S060"] == 0) & \
			 (hub_cis_complete["S064"] == 0) & (hub_cis_complete["G091"] == 0))

	# Select "No Hits"
	cis_no_hits = hub_cis_complete[cond1 | cond2 | cond3]
	cis_no_hits["Resons"] = "IJ"
	cis_no_hits["Level"] = cis_no_hits.apply(f_hub_level, axis=1)

	retain_cols = ["CallingAppName", "GuidewireID", "GuidewireAccountNumber",
                   "PolicyNumber", "PolicySuffix", "GeneratedNumber",
                   "NewRenewInd", "State", "WritingCo", "PolEffDt", "PolAppDt",
                   "PH_AGE", "ProviderStartDateTs" "Model", "Reasons", "Level"]
	cis_no_hits = cis_no_hits[retain_cols]

	# Select "Hits"
	cis_hits = hub_cis_complete[~(cond1 | cond2 | cond3)]
	# Select no credit state
	cis_hits_copy = cis_hits.copy()
	cis_hits = cis_hits[(cis_hits["Model"] >= "z") | (cis_hits["Model"] == "") | \
						(cis_hits["Model"] < "A") | (cis_hits["Model"] > "W")]
	cis_hits["Reasons"] = "IJ"
	cis_hits["Level"] = ""
	cis_hits = cis_hits[retain_cols]

	# Hub - SELECT NO HITS - STATUS CHECK
	# ------------------------------------------------------------------------
	cond1 = subset1["CreditInquiryStatus"] == "CREDIT BUREAU NO-HIT"
	cond2 = subset1["CreditInquiryStatus"] == "COMPLETE, NO REPORT (CREDIT BUREAU MANUAL REPORT)"
	cond3 = subset1["CreditInquiryStatus"] == "UNSCORED"
	cis_nohits_statuscheck = subset1[cond1 | cond2 | cond3]
	cis_nohits_statuscheck["Reasons"] = "IJ"
	cis_nohits_statuscheck["Level"] = cis_nohits_statuscheck.apply(f_hub_level, axis=1)
	cis_nohits_statuscheck = cis_nohits_statuscheck[retain_cols]

	cis_append = cis_nohits_statuscheck.append([cis_hits, cis_no_hits], ignore_index = True)

	return cis_append, cis_hits_copy

CIS_AppendedDF, CIS_Hits = f_hub1_operations(subset1) 
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# Nugget ID: idN3QAGYU55B
retain_cols = ["CallingAppName", "GuidewireID", "GuidewireAccountNumber",
			   "PolicyNumber", "PolicySuffix", "GeneratedNumber", "State",
			   "WritingCo", "PolEffDt", "PolAppDt", "G091", "S004", "Leverage",
			   "G001", "AT20", "G096", "G098", "G095", "G093", "DPR24m", "S011",
			   "AT09", "AT06", "S060", "AT36", "RE20", "RE28", "RE33", "S012",
			   "G089", "S064", "PH_AGE", "RE30", "RE31", "G007", "G061", "G066",
			   "G071", "DPRAMT", "RE09", "MT01", "IHI01", "ProviderStartDateTs",
			   "Model", "G960", "MT02", "G002", "G003", "G094", "G004", 
			   "ntaxlien", "AGE_IN_MONTHS" ]
CIS_Hits = CIS_Hits[retain_cols]

# Disabled
# CIS_Hits["Model"] = CIS_Hits["Model"].fillna("V")
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------

def f_model_G_Strike(x):
	'''
	Supernode ID: id59UTVBU9I13 
	Nugget ID: id4J2SJZQD7XI
	''' 
	Strike = 0

	if x["DPR84m"] > 0:
		Strike = Strike + 1
	if x["MOPhi"] > 0:
		Strike = Strike + 1
	if x["CollDoll"] > 0:
		Strike = Strike + 1
	if APD > 100:
		Strike = Strike + 1
	if x["Inq24m"] >= 8:
		Strike = Strike + 1
	if x["Leverage"] >= 0.80:
		Strike = Strike + 1
	if ["AOTL"] < 7.0:
		Strike = Strike + 1

	return Strike 

def f_model_G_RC7(x):
	'''
	Supernode ID: id59UTVBU9I13
	Nugget ID: id2K8TCHM99GV
	'''
	if (x["DPR84m"] > 0) & (x["nbankrupt"]>0):
		RC7 = "K"
	elif (x["DPR84m"] > 0) & (x["ntaxlien"]>0):
		RC7 = "M"
	else:
		RC7 = ""
	return RC7

def f_model_G_level(x):
	'''
	Nugget ID: id85SPP9R7JEI
	'''

	if x["Strike"] = 7:
		Level = "4B"
	elif x["Strike"] = 6:
		Level = "4B"
	elif x["Strike"] = 5:
		Level = "4B"
	elif x["Strike"] = 4:
		Level = "4B"
	elif x["Strike"] = 3:
		Level = "4A"
	elif x["Strike"] = 2:
		Level = "3B"
	elif (x["Strike"] = 1) & (x["Condition2"] = 1):
		Level = "3B"
	elif (x["Strike"] = 1) & (x["Condition15"] = 1):
		Level = "3B"
	elif (x["Strike"] = 1) & (x["Condition3"] = 1):
		Level = "3B"
	elif (x["Strike"] = 1) & (x["Condition4"] = 1):
		Level = "3A"
	elif (x["Strike"] = 1) & (x["Condition5"] = 1):
		Level = "3A"
	elif ((x["Strike"] = 1) | (x["Strike"] = 0)) & (x["Condition6"] = 1):
		Level = "3A"
	elif ((x["Strike"] = 1) | (x["Strike"] = 0)) & ((x["Condition7"] = 1) & \
		  (x["Condition8"] = 1) & (x["Condition9"] = 1)):
		Level = "3A"
	elif ((x["Strike"] = 1) | (x["Strike"] = 0)) & \
	     ((x["Condition10"] = 1) & (x["Condition11"] = 1)):
		Level = "3A"
	elif x["Strike"] = 1:
		Level = "2A"
	elif (x["Strike"] = 0) & (x["Condition7"] = 1) & (x["Condition8"] = 1):
		Level = "2A"
	elif (x["Strike"] = 0) & (x["Condition7"] = 1) & (x["Condition12"] = 1):
		Level = "2A"
	elif (x["Strike"] = 0) & (x["Condition8"] = 1) & (x["Condition11"] = 1):
		Level = "2A"
	elif (x["Strike"] = 0) & (x["Condition12"] = 1) & (x["Condition13"] = 1):
		Level = "2A"
	elif (x["Strike"] = 0) & (x["Condition7"] = 1) & \
	     (x["Condition9"] = 1) & (x["Condition14"] = 1):
		Level = "2A"
	elif (x["Strike"] = 0) & (x["Condition8"] = 1) & \
	     (x["Condition9"] = 1) & (x["Condition14"] = 1):
		Level = "2A"
	elif (x["Strike"] = 0) & (x["Condition11"] = 1) & (x["Condition14"] = 1):
		Level = "2A"
	elif (x["Strike"] = 0) & (x["Condition7"] = 1):
		Level = "1B"
	elif (x["Strike"] = 0) & (x["Condition8"] = 1):
		Level = "1B"
	elif (x["Strike"] = 0) & (x["Condition9"] = 1):
		Level = "1B"
	elif x["Strike"] = 0:
		Level = "1A"
	else:
		Level = ""

	return Level

def f_model_G_Reasons(x):
	''''
	Nugget ID: id2DNQL3QPVQS
	'''

	if (x["Strike"] >= 2) & (x["Strike"] <= 7):
		Reasons = str.strip(str(x["RC1"]) + str(x["RC2"]) + str(x["RC3"]) + \
			                str(x["RC4"]) + str(x["RC5"]) + str(x["RC6"]) + str(x["RC7"]))
	elif (x["Strike"] = 1) & (x["Condition2"] = 1):
		Reasons = str.strip(str(x["RC1"]) + str(x["RC2"]) + str(x["RC3"]) + \
			                str(x["RC4"]) + str(x["RC5"]) + str(x["RC6"]) + \
			                str(x["RC7"]) + "U")
	elif (x["Strike"] = 1) & (x["Condition15"] = 1):
		Reasons = str.strip(str(x["RC1"]) + str(x["RC2"]) + str(x["RC3"]) + \
			                str(x["RC4"]) + str(x["RC5"]) + str(x["RC6"]) + \
			                str(x["RC7"]) + "G")
	elif (x["Strike"] = 1) & (x["Condition3"] = 1):
		Reasons = "G"
	elif (x["Strike"] = 1) & (x["Condition4"] = 1):
		Reasons = str.strip(str(x["RC1"]) + str(x["RC2"]) + str(x["RC3"]) + \
			                str(x["RC4"]) + str(x["RC5"]) + str(x["RC6"]) + str(x["RC7"]))
	elif (x["Strike"] = 1) & (x["Condition5"] = 1):
		Reasons = "H"
	elif ((x["Strike"] = 1) | (x["Strike"] = 0)) & (x["Condition6"] = 1):
		Reasons = "A"
	elif ((x["Strike"] = 1) | (x["Strike"] = 0)) & ((x["Condition7"] = 1) & (x["Condition8"] = 1) & (x["Condition9"] = 1)):
		Reasons = "FGU"
	elif ((x["Strike"] = 1) | (x["Strike"] = 0)) & ((x["Condition10"] = 1) & (x["Condition11"] = 1)):
		Reasons = "EV"
	elif x["Strike"] = 1: 
		Reasons = str.strip(str(x["RC1"]) + str(x["RC2"]) + str(x["RC3"]) + \
						    str(x["RC4"]) + str(x["RC5"]) + str(x["RC6"]) + str(x["RC7"])) 
	elif (x["Strike"] = 0) & (x["Condition7"] = 1 ) & (x["Condition8"] = 1):
		Reasons = "FG"
	elif (x["Strike"] = 0) & (x["Condition7"] = 1) & (x["Condition12"] = 1):
		Reasons = "FU"
	elif (x["Strike"] = 0) & (x["Condition8"] = 1) & (x["Condition11"] = 1):
		Reasons = "EG"
	elif (x["Strike"] = 0) & (x["Condition12"] = 1) & (x["Condition13"] = 1):
		Reasons = "GU"
	elif (x["Strike"] = 0) & (x["Condition7"] = 1 ) & \
	     (x["Condition9"] = 1) & (x["Condition14"] = 1):
		Reasons = "FUV"
	elif (x["Strike"] = 0) & (x["Condition8"] = 1) & \
		 (x["Condition9"] = 1) & (x["Condition14"] = 1):
		Reasons = "GUV"
	elif (x["Strike"] = 0) & (x["Condition11"] = 1) & (x["Condition14"] = 1):
		Reasons = "EV"
	elif (x["Strike"] = 0) & (x["Condition7"] = 1):
		Reasons = "F"
	elif (x["Strike"] = 0) & (x["Condition8"] = 1):
		Reasons = "G"
	elif (x["Strike"] = 0) & (x["Condition9"] = 1):
		Reasons = "U"
	elif x["Strike"] = 0:
		Reasons = ""
	else:
		Reasons = ""


# Update model used for State/WRC/product
def f_model_G(df):
	''''
	Start Nugget ID: id5SZQ8XDIMTV
	End Nugget ID: id5H7RCUSRNJQ
	'''

	df  = df[((df["Model"] >= "A") & (df["Model"] <= "J")) | \
			 ((df["Model"] >= "Q") & (df["Model"] <= "T"))]

	df.drop(columns=["S004", "G096", "G089", "RE30", "RE31", "G007", "RE09", 
				     "MT01", "IHI01", "MT02", "AGE_IN_MONTHS"], axis=1,
				     inplace=True)
	
	df.rename(columns={"G091" : "apd",
					   "G001" : "del30d84m",
					   "AT20" : "AOTL",
					   "G098" : "inq06m",
					   "G095" : "mrecdpr",
					   "G093" : "ndpr",
					   "S011" : "nopa",
					   "AT09" : "aop24m",
					   "AT06" : "aop06m",
					   "S060" : "mophi",
					   "AT36" : "mrecdel",
					   "RE20" : "moldraop",
					   "RE28" : "rlimit",
					   "RE33" : "rbal",
					   "S012" : "nopra",
					   "S064" : "colldoll",
					   "PH_AGE" : "age",
					   "G061" : "del30pd24m",
					   "G066" : "del60pd24m",
					   "G071" : "del90pd24m",
					   "G960" : "inq24m",
					   "G002" : "del60d84m",
					   "G003" : "del90d84m",
					   "G094" : "nbankrupt",
					   "S004" : "avgmao"}, inplace=True)

	df.drop(columns=["del30d84m", "del30pd24m", "del60pd24m", "del90pd24m",
					 "del60d84m", "del90d84m", "del120d84m"], axis=1, inplace=True)

	df.rename(columns={"apd" : "APD",
					   "ndpr" : "DPR84m",
					   "aop24m" : "AOP24m",
					   "mophi" : "MOPhi", 
					   "mrecdel" : "mRecDel",
					   "colldoll" : "CollDoll",
					   "inq24m" : "Inq24m"}, inplace=True)

	df["Strike"] = df.apply(f_model_G_Strike, axis=1)
	df["RC7"] = df.apply(f_model_G_RC7, axis=1)
	df["RC6"] = df.MOPhi.apply(lambda x: if x > 0 "H" else "")
	df["RC2"] = df.CollDoll.apply(lambda x: if x > 0 "B" else "")
	df["RC1"] = df.APD.apply(lambda x: if x > 100 "A" else "")
	df["RC5"] = df.Inq24m.apply(lambda x: if x >= 8 "G" else "")
	df["RC4"] = df.Leverage.apply(lambda x: if >= 0.80 "F" else "")
	df["RC3"] = df.AOTL.apply(lambda x: if x < 7.0 "E" else "")
	df["Condition2"] = df.AOP24m.apply(lambda x: if x >= 8 1 else 0)
	df["Condition3"] = df.Inq24m.apply(lambda x: if x >= 10 1 else 0)
	df["Condition4"] = df.DPR24m.apply(lambda x: if x > 0 else 0)
	df["Condition5"] = df.MOPhi.apply(lambda x: if x > 0 1 else 0)
	df["Condition6"] = df.APD.apply(lambda x: if x > 0 1 else 0)
	df["Condition7"] = df.Leverage.apply(lambda x: if x >= 0.2 1 else 0)
	df["Condition8"] = df.Inq24m.apply(lambda x: if x >= 4 1 else 0)
	df["Condition9"] = df.AOP24m.apply(lambda x: if x >= 3 1 else 0)
	df["Condition10"] = df.mRecDel.apply(lambda x: if x <= 24 1 else 0)
	df["Condition11"] = df.AOTL.apply(lambda x: if x < 15 1 else 0)
	df["Condition12"] = df.AOP24m.apply(lambda x: if x >= 5 1 else 0)
	df["Condition13"] = df.Inq24m.apply(lambda x: if x >= 6 1 else 0)
	df["Condition14"] = df.mRecDel.apply(lambda x: if x <= 60 1 else 0)
	df["Condition15"] = df.Inq24m.apply(lambda x: if x == 7 1 else 0)

	df["Level"] = df.apply(f_model_G_level, axis = 1)

	df["Reasons"] = df.apply(f_model_G_Reasons, axis = 1)

	df["PFMScore"] = ""

	retain_cols = ["CallingAppName", "GuidewireID", "GuidewireAccountNumber",
	               "PolicyNumber", "PolicySuffix", "GeneratedNumber",
	               "WritingCo", "PolEffDt", "PolAppDt", "ProviderStartDateTs",
	               "Model", "Level", "Reasons", "PFMScore"]
	df = df[retain_cols]
	
	return df

model_G_DF = f_model_G(CIS_Hits)
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------