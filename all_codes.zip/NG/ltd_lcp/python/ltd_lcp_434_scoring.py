##############################################################################
# ----------------------------------------------------------------------------
#                            Program Information
# ----------------------------------------------------------------------------
# Author                 : Sushant Kulkarni
# Creation Date          : 29NOV2018
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#                             Script Information
# ---------------------------------------------------------------------------
# Script Name            : ltd_lcp_434_scoring.py
# Bitbucket Project/Repo : DnAAnalytics-US-Group/US-GRP-MO-LTD-LCP
# Brief Description      : Script for scoring a optimal LCP
# Data used              : /hadoop/met_scripts/datascience/dnaanalytics_us_group/us_grp_mo_ltd_lcp/pickles/ltd_lcp_434_ctg_dict.pkl,
#                          /hadoop/met_scripts/datascience/dnaanalytics_us_group/us_grp_mo_ltd_lcp/pickles/ltd_lcp_434_model.pkl,
#                          analytics.ltd_lcp_scoring_set
# Output Files           : Data/datascience/dnaanalytics_us_group/us_grp_mo_ltd_lcp/outputs/ltd_lcp_results_set_yyyy_mm_dd-hh_mm_ss
#
# Notes / Assumptions    : ds_functions.py from utils folder needed to import global functions
#                          For config and logging - following files required
#                          config.py, yaml_wrappers.py from utils folder on server
#                          base.yml, development.yml  from use case config folder
# ---------------------------------------------------------------------------
#                            Environment Information
# ---------------------------------------------------------------------------
# Python Version         : 3.6.3
# Anaconda Version       : 5.0.1
# Spark Version          : 2.3.0
# Operating System       : Red Hat Linux 7.4
# ---------------------------------------------------------------------------
#
# ###########################################################################

#############################################################################
#
# Packages & Modules
#
#############################################################################

# For spark-submit run
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("ltd_lcp_434_scoring").enableHiveSupport().getOrCreate()


import os
import sys
sys.path.append("./utils")
import time
import pandas as pd
import numpy as np
import logging
from datetime import datetime, timedelta

try:
    from config import Config
except IOError:
    logging.error("Cannot import Config class.")
except Exception:
    logging.exception("Failed to import Config class.")

try:
    from ds_functions import load_pickle, cat_encoding_scoring, write_scoring_file
except IOError:
    logging.error("Cannot import ds_functions")
except Exception:
    logging.exception("Failed to import ds_functions.")

# ---------------------------------------------------------------------------

#############################################################################
#
# Data Import
#
#############################################################################


def data_import():
    log.info("Data Import method has started running.")
    # Get data from hive table
    try:
        spark_lcp_df = spark.sql(scoring_sql)
    except IOError:
        log.error("Could not import data from Hive table")
    except Exception:
        log.error("Data import from Hive table has failed")
    # Convert to pandas df
    lcp_scoring = spark_lcp_df.toPandas()
    log.info("Data import is now complete")
    return lcp_scoring, spark_lcp_df

#############################################################################
#
# Data Preparation
#
#############################################################################


def data_prep(lcp_scoring, spark_lcp_df):
    log.info("Data preparation has started")
    # Strip white spaces from all string/object columns
    for col, dtype in spark_lcp_df.dtypes:
        if dtype == "string":
            lcp_scoring[col] = lcp_scoring[col].str.strip()
    # Convert spark dataframe dates to datetime type in pandas
    for col, dtype in spark_lcp_df.dtypes:
        if dtype == "date":
            lcp_scoring[col] = lcp_scoring[col].astype("datetime64[ns]")
    log.info("Data preparation is now complete")
    return lcp_scoring


#############################################################################
#
# Feature Engineering
#
#############################################################################
def f_days_lstwk_dabl_bin(x):
    if x == 1:
        days_lstwk_dabl_bin = "1_1day"
    elif x <= 3:
        days_lstwk_dabl_bin = "2_2-3days"
    elif x <= 7:
        days_lstwk_dabl_bin = "3_4-7days"
    elif x > 7:
        days_lstwk_dabl_bin = "4_7days+"
    else:
        days_lstwk_dabl_bin = "0_UN"
    return days_lstwk_dabl_bin


def f_ssstat_bin(x):
    if x.endswith("P"):
        ssstat_bin = "PE"
    elif x.endswith("A"):
        ssstat_bin = "ZA"
    elif x.endswith("D"):
        ssstat_bin = "DEN"
    else:
        ssstat_bin = "OTH"
    return ssstat_bin


def f_gender(x):
    if x == "F":
        gender = "F"
    elif x == "M":
        gender = "M"
    else:
        gender = "M"
    return gender


def f_job_class(x):
    if x.startswith("S"):
        job_class = "Z_S"
    elif (x.startswith("L")) | (x.startswith("M")):
        job_class = "L_M"
    elif (x.startswith("H")) | (x.startswith("V")):
        job_class = "H_V"
    elif (x.startswith("U")) | (x == ""):
        job_class = "UN"
    return job_class


def f_sal_pct_bin(x):
    if x <= 0.4:
        sal_pct_bin = "LT40"
    elif x <= 0.55:
        sal_pct_bin = "40TO55"
    elif x <= 0.667:
        sal_pct_bin = "Z55TO67"
    elif x > 0.667:
        sal_pct_bin = "GT67"
    else:
        sal_pct_bin = "UN"
    return sal_pct_bin


def f_mkt_seg_bin(x):
    if x == "004":
        mkt_seg_bin = "SBC"
    elif x == "005":
        mkt_seg_bin = "NSC"
    elif x == "006":
        mkt_seg_bin = "NA"
    else:
        mkt_seg_bin = "OTHER"
    return mkt_seg_bin


def f_srv_yr_group(x):
    if x > 27:
        srv_yr_group = "27+"
    elif (x > 14) & (x <= 27):
        srv_yr_group = "14_27"
    elif (x > 8) & (x <= 14):
        srv_yr_group = "8_14"
    elif (x > 4) & (x <= 8):
        srv_yr_group = "4_8"
    elif (x > 2) & (x <= 4):
        srv_yr_group = "2_4"
    elif (x >= 1) & (x <= 2):
        srv_yr_group = "1_2"
    else:
        srv_yr_group = "0"
    return srv_yr_group


def f_age_group(x):
    if x <= 40:
        age_group = "under40"
    elif (x <= 55):
        age_group = "40-55"
    elif (x <= 65):
        age_group = "55-65"
    elif x > 65:
        age_group = "65+"
    else:
        age_group = ""
    return age_group


def f_tot_cpt_surgery(x):
    if x == 0:
        total_cpt_surgery = 0
    elif x == 1:
        total_cpt_surgery = 1
    elif x > 1:
        total_cpt_surgery = 2
    else:
        total_cpt_surgery = 0
    return total_cpt_surgery


def f_sal_freq_cd_v2(x):
    if (x["sal_amt"] > 10000) & (x["sal_freq_cd"] == "H"):
        sal_freq_cd_v2 = "Y"
    elif (x["sal_amt"] > 1000) & (x["sal_freq_cd"] == "H"):
        sal_freq_cd_v2 = "M"
    elif (x["sal_amt"] > 100000) & (x["sal_freq_cd"] == "M"):
        sal_freq_cd_v2 = "Y"
    else:
        sal_freq_cd_v2 = x["sal_freq_cd"]
    return sal_freq_cd_v2


def f_sal_amt_yr(x):
    if x["sal_freq_cd_v2"] == "M":
        sal_amt_yr = x["sal_amt"]*12
    elif x["sal_freq_cd_v2"] == "H":
        sal_amt_yr = x["sal_amt"]*2080
    elif x["sal_freq_cd_v2"] == "B":
        sal_amt_yr = x["sal_amt"]*26
    elif x["sal_freq_cd_v2"] == "W":
        sal_amt_yr = x["sal_amt"]*52
    else:
        sal_amt_yr = x["sal_amt"]
    return sal_amt_yr


def f_sal_amt_grp(x):
    if (x["sal_amt"] == 9999) | (x["sal_amt"] == 0) | (x["sal_amt"] == 1):
        sal_amt_group = "unknown"
    elif (x["sal_amt_yr"] <= 18550):
        sal_amt_group = "zgroup1"
    elif (x["sal_amt_yr"] <= 37650):
        sal_amt_group = "group2"
    elif (x["sal_amt_yr"] <= 75300):
        sal_amt_group = "group3"
    elif (x["sal_amt_yr"] <= 151900):
        sal_amt_group = "group4"
    elif (x["sal_amt_yr"] <= 466950):
        sal_amt_group = "group5"
    else:
        sal_amt_group = "unknown"
    return sal_amt_group


def f_at_risk_bin(x):
    if (max(x["at_risk_prmry"], x["at_risk_sec"]) >= 0) & \
       (max(x["at_risk_prmry"], x["at_risk_sec"]) < 60):
        at_risk_bin = "Z1"
    elif (max(x["at_risk_prmry"], x["at_risk_sec"]) >= 60) & \
         (max(x["at_risk_prmry"], x["at_risk_sec"]) < 120):
        at_risk_bin = "A2"
    elif (max(x["at_risk_prmry"], x["at_risk_sec"]) >= 120) & \
         (max(x["at_risk_prmry"], x["at_risk_sec"]) < 180):
        at_risk_bin = "A3"
    elif (max(x["at_risk_prmry"], x["at_risk_sec"]) >= 180) & \
         (max(x["at_risk_prmry"], x["at_risk_sec"]) < 240):
        at_risk_bin = "A4"
    elif (max(x["at_risk_prmry"], x["at_risk_sec"]) >= 240) & \
         (max(x["at_risk_prmry"], x["at_risk_sec"]) < 300):
        at_risk_bin = "A5"
    elif (max(x["at_risk_prmry"], x["at_risk_sec"]) >= 300):
        at_risk_bin = "A6"
    else:
        at_risk_bin = 0
    return at_risk_bin


def f_sic_bin_wiki(x):
    x = int(x)
    if x >= 9900:
        sic_bin_wiki = "Nonclassifiable"
    elif x >= 9100:
        sic_bin_wiki = "Public Administration"
    elif x >= 7000:
        sic_bin_wiki = "Services"
    elif x >= 6000:
        sic_bin_wiki = "Finance"
    elif x >= 5200:
        sic_bin_wiki = "Retail Trade"
    elif x >= 5000:
        sic_bin_wiki = "Wholesale Trade"
    elif x >= 4000:
        sic_bin_wiki = "Trans Commu Elec Gas Sanitary"
    elif x >= 2000:
        sic_bin_wiki = "Manufacturing"
    elif x >= 1500:
        sic_bin_wiki = "Construction"
    elif x >= 1000:
        sic_bin_wiki = "Mining"
    elif x >= 100:
        sic_bin_wiki = "Agriculture Forestry Fishing"
    else:
        sic_bin_wiki = "UN"
    return sic_bin_wiki


def f_sic_regroup(x):
    if (x == "Agriculture Forestry Fishing") | (x == "Mining"):
        sic_regroup = "AGRI_MINING"
    elif x == "Construction":
        sic_regroup = "ZCONSTRUC_TRANS"
    elif x == "Manufacturing":
        sic_regroup = "MANUFACTURING"
    elif (x == "Nonclassifiable") | (x == "UN"):
        sic_regroup = "UN"
    elif (x == "Public Administration") | (x == "Retail Trade"):
        sic_regroup = "TRADE_ADMIN_FINANCE"
    elif (x == "Services") | (x == "Trans Commu Elec Gas Sanitary"):
        sic_regroup = "CONSTRUC_TRANS"
    elif (x == "Wholesale Trade") | (x == "Finance"):
        sic_regroup = "TRADE_ADMIN_FINANCE"
    else:
        sic_regroup = "UN"
    return sic_regroup


def f_mdc_group(x):
    if x == "CIRCULATORY SYSTEM":
        mdc_group = "CIRCULATORY SYSTEM"
    elif x == "INJURY & POISONING":
        mdc_group = "INJURY & POISONING"
    elif (x == "MENTAL RETARDATION") | (x == "NERVOUS SYSTEM") | \
         (x == "NON-PSYCHOTIC MENTAL DISORDERS") | (x == "PSYCHOSES"):
        mdc_group = "MENTAL"
    elif x == "MUSCULOSKELETAL SYSTEM":
        mdc_group = "MUSCULOSKELETAL SYSTEM"
    elif x == "NEOPLASMS":
        mdc_group = "NEOPLASMS"
    else:
        mdc_group = "OTHER"
    return mdc_group


def f_bridge_type(x):
    if x == "T":
        bridge_type = "STD_LTD"
    elif (x == ""):
        bridge_type = "STANDALONE"
    else:
        bridge_type = "default"
    return bridge_type


def feature_engineering(df):
    log.info("Feature engineering has started")
    # Filter
    df.drop(["prmry_icd9_cd", "sec_icd9_cd", "data_xtrct_dt"], axis=1, inplace=True)
    # ----------------------------------------------------------------------------
    # DAYS_LSTWK_DABL_BIN
    df["days_lstwk_dabl"] = (pd.to_datetime(df.dabl_dt) -
                             pd.to_datetime(df.lst_wrk_dt)).dt.days
    # DAYS_LSTWK_DABL_BIN
    df["days_lstwk_dabl_bin"] = df.days_lstwk_dabl.apply(f_days_lstwk_dabl_bin)
    # WK_PHY_IND
    df["wk_phy_ind"] = np.where(df.occ_dabl_phys_ind == "Y", 1, 0)
    # SSSTAT_BIN
    df["ssstat_bin"] = df.ss_stts_cd.apply(f_ssstat_bin)
    # GENDER
    df["gender"] = df.sex_cd.apply(f_gender)
    # JOB_CLASS
    df["job_class"] = df.job_class_cd.apply(f_job_class)
    # SAL_PCT_BIN
    df["sal_pct"] = df.sal_pct.astype(float)
    df["sal_pct_bin"] = df.sal_pct.apply(f_sal_pct_bin)
    # MKT_SEG_BIN
    df["mkt_seg_bin"] = df.admn_zn_cd.apply(f_mkt_seg_bin)
    # SRV_YR_GROUP
    df["srv_yr_group"] = df.lnth_of_srv_yr.apply(f_srv_yr_group)
    # AGE_GROUP
    df["age_group"] = df.age.apply(f_age_group)
    # TOTAL_CPT_SURGERY_BIN
    df["total_cpt_surgery_bin"] = df.total_cpt_surgery.apply(f_tot_cpt_surgery)
    # SAL_FREQ_CD_V2
    df["sal_amt"] = df.sal_amt.astype(float)
    df["sal_freq_cd_v2"] = df.apply(f_sal_freq_cd_v2, axis=1)
    # SAL_AMT_YR
    df["sal_amt_yr"] = df.apply(f_sal_amt_yr, axis=1)
    # SAL_AMT_GROUP
    df["sal_amt_group"] = df.apply(f_sal_amt_grp, axis=1)
    # Filler
    df.at_risk_prmry.fillna(0, inplace=True)
    df.at_risk_sec.fillna(0, inplace=True)
    # At_Risk_BIN
    df["at_risk_bin"] = df.apply(f_at_risk_bin, axis=1)
    # SIC_BIN_WIKI
    df["sic_bin_wiki"] = df.sic_cd.apply(f_sic_bin_wiki)
    # SIC_REGROUP
    df["sic_regroup"] = df.sic_bin_wiki.apply(f_sic_regroup)
    # MDC_GROUP
    df["mdc_group"] = df.mjr_dx_ctgy_dscr.apply(f_mdc_group)
    # BRIDGE_TYPE
    df["brdg_typ"] = df.brdg_cd.apply(f_bridge_type)
    # Encode categorical variables in the dataframe
    scoringdf, predictor_cols = cat_encoding_scoring(categories_dict, df.copy())
    # All model variables are categorical variables.
    # Hence, dummy variable list is itself model/predictor variables
    log.info("Data preparation is now complete")
    return scoringdf, predictor_cols

#####################################################################
#
# Modeling
#
#####################################################################


def modeling(modeldata, predictor_cols):
    log.info("Modeling scoring started")
    try:
        # Score using model object
        modeldata["predicted_lcp"] = lr_model.predict(modeldata[predictor_cols])
    except IOError:
        log.error("Cannot extract the scoring dataframe with features")
    except Exception:
        log.Exception("Failed to extract scoring dataframe with features")
    # Append Probabilities
    prob_cols = ["probability_hp", "probability_pr", "probability_oo",
                 "probability_pa", "probability_vr", "probability_ed"]
    df_proba = pd.DataFrame(lr_model.predict_proba(modeldata[predictor_cols]),
                            columns=prob_cols)
    modeldata = pd.concat([modeldata.reset_index(drop=True), df_proba], axis=1)
    # Dropping dummies
    modeldata.drop(predictor_cols, axis=1, inplace=True)
    log.info("Modeling scoring completed")
    return modeldata

#####################################################################
#
# Post Processing
#
#####################################################################


def f_predicted_lcp(x):
    if x == "1_HP":
        predicted_lcp = "HP"
    elif x == "2_PR":
        predicted_lcp = "PR"
    elif x == "3_OO":
        predicted_lcp = "OO"
    elif x == "4_PA":
        predicted_lcp = "PA"
    elif x == "5_VR":
        predicted_lcp = "VR"
    elif x == "6_ED":
        predicted_lcp = "ED"
    else:
        predicted_lcp = x
    return predicted_lcp


def f_exprtw_ind(x):
    if not pd.isnull(x):
        days_dif = (pd.to_datetime(x) - pd.to_datetime("now"))
        if (days_dif < timedelta(days=90)):
            return 1
        else:
            return 0
    else:
        return 0


def f_pred_lcp(x):
    if x["expected_rtw_ind"] == 1:
        model_predicted_lcp = "HP"
    elif (not pd.isnull(x["expected_rtw_dt"])) & \
         (not pd.isnull(x["max_dur_dt"])) & \
         (x["expected_rtw_ind"] == x["max_dur_dt"]):
        model_predicted_lcp = "ED"
    else:
        model_predicted_lcp = x["predicted_lcp"]
    return model_predicted_lcp


def post_processing(df):
    log.info("Post processing has started")
    df["model_process_ts"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    df["model_process_ts"] = pd.to_datetime(df["model_process_ts"])
    df["predicted_lcp"] = df.predicted_lcp.apply(f_predicted_lcp)
    df.drop(["brdg_cd", "lst_wrk_dt", "dabl_dt", "sal_amt", "sal_freq_cd",
             "sal_freq_cd_v2", "sic_bin_wiki"], axis=1, inplace=True)
    # Renaming columns as per required format
    df.rename(columns={"sev_cond_cd": "severity_cond_cd",
                       "days_lstwk_dabl": "dlw_to_dod_days",
                       "days_lstwk_dabl_bin": "model_days_lstwk_dabl_bin",
                       "wk_phy_ind": "model_wk_phy_ind",
                       "ssstat_bin": "model_ssstat_bin",
                       "gender": "model_gender_bin",
                       "job_class": "model_job_class",
                       "sal_pct_bin": "model_sal_pct_bin",
                       "mkt_seg_bin": "model_mkt_seg_bin",
                       "srv_yr_group": "model_srv_yr_bin",
                       "age_group": "model_age_group_bin",
                       "total_cpt_surgery_bin": "model_total_cpt_surgery_bin",
                       "sal_amt_yr": "annl_sal_amt",
                       "sal_amt_group": "model_sal_amt_bin",
                       "at_risk_bin": "model_at_risk_bin",
                       "mdc_group": "model_mdc_bin",
                       "sic_regroup": "model_sic_bin",
                       "clm_recd_dt": "clm_rcvd_dt",
                       "diagnosis": "model_diagnosis"}, inplace=True)
    # -------------------------------------------------------------------------
    df.expected_rtw_dt = pd.to_datetime(df.expected_rtw_dt, errors="coerce")
    df["expected_rtw_ind"] = df.expected_rtw_dt.apply(f_exprtw_ind)
    # -------------------------------------------------------------------------
    df["model_predicted_lcp"] = df.apply(f_pred_lcp, axis=1)
    # -------------------------------------------------------------------------
    var_order = ["clm_num_cd", "clm_rcvd_dt", "brdg_typ", "clm_ofc_cd",
                 "model_process_ts", "probability_hp", "probability_pr",
                 "probability_oo", "probability_pa", "probability_vr",
                 "probability_ed", "model_total_cpt_surgery_bin",
                 "model_diagnosis", "model_mdc_bin", "model_at_risk_bin",
                 "model_sal_pct_bin", "model_ssstat_bin",
                 "model_days_lstwk_dabl_bin", "model_sic_bin",
                 "model_mkt_seg_bin", "model_age_group_bin",
                 "model_gender_bin", "model_sal_amt_bin", "model_wk_phy_ind",
                 "model_srv_yr_bin", "total_cpt_surgery", "co_morbid_yn",
                 "prmry_icd_dscr", "sec_icd_dscr", "mjr_dx_ctgy_dscr",
                 "at_risk_prmry", "at_risk_sec", "sal_pct", "ss_stts_cd",
                 "dlw_to_dod_days", "sic_cd", "admn_zn_cd", "job_class_cd",
                 "age", "sex_cd", "annl_sal_amt", "occ_dabl_phys_ind",
                 "lnth_of_srv_yr", "severity_cond_cd", "expected_rtw_dt",
                 "cust_nm", "clm_ownr_nm", "team_cd", "team_nm", "max_dur_dt",
                 "expected_rtw_ind", "model_predicted_lcp"]
    df = df[var_order]
    df["clm_rcvd_dt"] = pd.to_datetime(df["clm_rcvd_dt"])
    # Need to replace Nan in the category column types with empty strings.
    for col in df.columns.tolist():
        if df[col].dtype is pd.api.types.CategoricalDtype():
            df[col] = df[col].cat.add_categories("").fillna("")
    log.info("Post processing is now complete")
    return df

###############################################################################
#
# Export Output
#
###############################################################################


def export_scored(df):
    log.info("Export scored method has started")
    # Convert back to spark df
    spark_scored_df = spark.createDataFrame(df)
    # Write out to hdfs
    log.debug("Exporting the results to file: " + hdfs_export_file_path + " " + export_file_name)
    write_scoring_file(hdfs_export_file_path, export_file_name, spark_scored_df)
    log.info("Exporting scored df is now complete")

#####################################################################
#
# Main function
#
#####################################################################


if __name__ == "__main__":
    start_time = time.time()
    # fetch config params and load required data
    env = os.environ.get("ENV")
    app_path = os.getcwd()
    config = Config(env, app_path)
    log = config.get_logger()
    log.info("Scoring has started")
    pkl_path = config.getConfigValueFor("pkl_path")
    pkl_ct_dict = config.getConfigValueFor("pkl_file_name_ct_dict")
    pkl_lr_model = config.getConfigValueFor("pkl_file_name_model")
    hdfs_export_file_path = config.getConfigValueFor("hdfs_export_file_path")
    export_file_name = config.getConfigValueFor("export_file_name")
    scoring_sql = config.getConfigValueFor("scoring_sql")
    log.debug("Found the export file path as {}".format(hdfs_export_file_path))
    try:
        categories_dict = load_pickle(pkl_path, pkl_ct_dict)
    except IOError:
        log.error("Could not load categories dictionary pickle file.", pkl_path+pkl_ct_dict)
    except Exception:
        log.exception("Failed to load categories dictionary pickle file.")
    try:
        lr_model = load_pickle(pkl_path, pkl_lr_model)
    except IOError:
        log.error("Could not load model pickle file", pkl_path+pkl_lr_model)
    except Exception:
        log.exception("Failed to load model pickle file")
    # Start scoring process
    # Import data from hive table
    lcp_scoring, spark_lcp_df = data_import()
    # Data Preparation - ensuring correct datatypes
    lcp_scoring = data_prep(lcp_scoring, spark_lcp_df)
    # Create features as required for scoring
    scoringdf, predictor_cols = feature_engineering(lcp_scoring)
    # Score using the loaded model
    modelDF = modeling(scoringdf, predictor_cols)
    # Process model output and apply business rules
    final_df = post_processing(modelDF)
    # export data onto predefined HDFS location
    export_scored(final_df)
    # Log and end scoring process
    log.info("Scoring is complete")
    log.warning("The scoring is completed in: [ %s ] Seconds ---" % (time.time() - start_time))
