##############################################################################
# ----------------------------------------------------------------------------
#                            Program Information
# ----------------------------------------------------------------------------
# Author                 : Sushant Kulkarni
# Creation Date          : 26NOV2018
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
#                             Script Information
# ----------------------------------------------------------------------------
# Script Name            : ltd_lcp_434_training.py
# Bitbucket Project/Repo : DnAAnalytics-US-Group/US-GRP-MO-LTD-LCP
# Brief Description      : Script trains a model to predict the Optimal LCP
# Data used              : hdfs:///Data/datascience/dnaanalytics_us_group/us_grp_mo_ltd_lcp/inputs/ltd_lcp_434_model_input_data.txt
# Output Files           : /hadoop/met_scripts/datascience/dnaanalytics_us_group/us_grp_mo_ltd_lcp/pickles/ltd_lcp_434_ctg_dict.pkl,
#                          /hadoop/met_scripts/datascience/dnaanalytics_us_group/us_grp_mo_ltd_lcp/pickles/ltd_lcp_434_model.pkl,
# Notes / Assumptions    : ds_functions.py from utils folder needed to import global functions
#                          For config and logging - following files required
#                          config.py, yaml_wrappers.py from utils folder on server
#                          base.yml, development.yml  from use case config folder
# ----------------------------------------------------------------------------
#                            Environment Information
# ----------------------------------------------------------------------------
# Python Version         : 3.6.3
# Anaconda Version       : 5.0.1
# Spark Version          : 2.3.0
# Operating System       : Red Hat Linux 7.4
# ----------------------------------------------------------------------------
#
# #############################################################################

# For spark-submit run
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("ltd_lcp_434_training").enableHiveSupport().getOrCreate()

# #############################################################################
#
# Loading input data
#
# #############################################################################

import os
import sys
sys.path.append("./utils")
import time
import pandas as pd
import logging
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.model_selection import ParameterGrid

try:
    from config import Config
except IOError:
    logging.error("Cannot import Config class")
except Exception:
    logging.exception("Failed to import Config class")

try:
    from ds_functions import (make_categorical_dict, cat_encoding_train,
                              cat_encoding_scoring, save_pickle,
                              classifier_metrics)
except IOError:
    logging.error("Cannot import ds_functions")
except Exception:
    logging.exception("Failed to import ds_functions")

# #############################################################################
#
# Loading input data
#
# #############################################################################


def data_import(path, file_name):
    # Read the file exported from SPSS stream after filter reorder
    log.info("Data import process has started running")
    # Import data
    try:
        spark_df = spark.read.csv(path + file_name,
                                  header=True,
                                  inferSchema=True,
                                  sep=",",
                                  mode="DROPMALFORMED",
                                  nullValue="$null$")
    except IOError:
        log.error("Importing data failed")
    except Exception:
        log.exception("Data not found")
    # Convert spark df to pandas df
    df = spark_df.toPandas()
    print("Input file size is: " + str(df.shape))
    log.info("Data import process is now complete")
    return df


# #############################################################################
#
# Data preparation
#
# #############################################################################


def data_prep(df):
    log.info("Data preparation process has started running")
    # Convert pandas df column names to lower case & replacing blanks
    df.columns = [col.replace(" ", "_").lower() for col in df.columns]
    # Split training & testing sets
    train = df[df.partition == "1_Training"].copy()
    test = df[df.partition == "2_Testing"].copy()
    validation = df[df.partition == "3_Validation"].copy()
    # Subset only for predictors and target
    model_vars = ["lcp", "mkt_seg_bin", "ssstat_bin", "total_cpt_surgery_bin",
                  "gender", "age_group", "job_class", "at_risk_bin",
                  "mdc_group", "srv_yr_group", "sal_pct_bin",
                  "days_lstwk_dabl_bin", "sal_amt_group",
                  "co_morbid_yn", "wk_phy_ind", "diagnosis", "sic_regroup"]
    train = train[model_vars]
    test = test[model_vars]
    validation = validation[model_vars]
    y_train = train.lcp.values
    y_test = test.lcp.values
    y_validat = validation.lcp.values
    log.info("Data preparation process has finished running")
    return train, test, validation, y_train, y_test, y_validat


# #############################################################################
#
# Feature Engineering
#
# #############################################################################
def feature_eng(training_set, test_set, validation_set):
    log.info("Feature engineering process has started running")
    # Assemble string variables to be used in the model so we can encode
    catg_vars = ["mkt_seg_bin", "ssstat_bin", "total_cpt_surgery_bin",
                 "gender", "age_group", "job_class", "at_risk_bin",
                 "mdc_group", "srv_yr_group", "sal_pct_bin",
                 "days_lstwk_dabl_bin", "sal_amt_group", "co_morbid_yn",
                 "wk_phy_ind", "diagnosis", "sic_regroup"]
    # Encode the categorical values in train dataset
    try:
        catg_dict = make_categorical_dict(string_vars=catg_vars,
                                          train_df=training_set,
                                          save_path=pkl_path+pkl_ct_dict)
    except IOError:
        log.error("Writing categorical dictionary pickle failed.")
    except Exception:
        log.exception("Failed to write categorical dictionary pickle")
    log.info("Catergorical Dictionary is created")
    # Transform encodings in train and test dataset
    trainx, testx, pred_cols = cat_encoding_train(categories_dict=catg_dict,
                                                  train_df=training_set.copy(),
                                                  test_df=test_set.copy())
    # Transfrom encodings in validation dataset
    validx, pred_cols = cat_encoding_scoring(categories_dict=catg_dict,
                                             scoring_df=validation_set.copy())
    log.info("Feature engineering process is now complete")
    return trainx, testx, validx, pred_cols


###############################################################################
#
# Training and evaluating the model
#
###############################################################################

def modeling(trainx, testx, y_train, y_test, predict_cols):
    log.info("Model training process has started running")
    # Initialize the classifier
    lr = LogisticRegression(solver="saga", max_iter=500)
    # hyper parameters set to tune over
    parameters = {"penalty": ("l1", "l2"),
                  "C": [0.5, 1, 10, 25, 50, 100],
                  "multi_class": ["multinomial"]}
    # Evaluating all combinations of hyper parameters using test datasset
    best_score = 0
    for g in ParameterGrid(parameters):
        lr.set_params(**g)
        lr.fit(trainx[predictor_cols], y_train)
        acc_score = accuracy_score(testx.lcp, lr.predict(testx[predict_cols]))
        print(g, acc_score)
        # save if best
        if acc_score > best_score:
            best_score = acc_score
            best_grid = g
    print("Best Test Accuracy: %0.5f" % best_score)
    print("Optimal Hyper-parametes: ", best_grid)
    """
        Best Test Score:
        56.438%
        Optimal Hyper-parameters:
        {"C": 1, "multi_class": "multinomial", "penalty": "l1"}
    """
    # Training for best hyper-parameter
    LogReg = LogisticRegression(solver="saga", max_iter=500)
    LogReg.set_params(**best_grid)
    LogReg.fit(trainx[predict_cols], y_train)
    log.info("Modeling training process is now complete")
    # Save the model
    try:
        save_pickle(LogReg, pkl_path, pkl_lr_model)
    except IOError:
        log.error("Could not save Logistic Regression model pickle")
    except Exception:
        log.exception("Failed to save Logistic Regression model pickle")
    return LogReg


def append_proba(lr, pred_cols, df):
    # Append Predictions
    df["predicted_lcp"] = lr.predict(df[pred_cols])
    # Append Probabilities
    prob_cols = ["Probability_hp", "Probability_pr", "probability_oo",
                 "Probability_pa", "Probability_vr", "probability_ed"]
    df_proba = pd.DataFrame(lr.predict_proba(df[pred_cols]), columns=prob_cols)
    df = pd.concat([df.reset_index(drop=True), df_proba], axis=1)
    # Dropping dummies
    df.drop(pred_cols, axis=1, inplace=True)
    return df


def evaluation(LogReg, trainx, testx, validx, y_train, y_test, y_validat):
    # Evaluating performance on hold out (validation) dataset
    log.info("Model evaluation process has started")
    print("\nValidation Metrics for Logistic Regression are:")
    classifier_metrics(y_validat, LogReg.predict(validx[predictor_cols]))
    # Metrics for train dataset
    print("\nTrain Metrics for Logistic Regression are:")
    classifier_metrics(y_train, LogReg.predict(trainx[predictor_cols]))
    # Metrics for test dataset
    print("\nTest Metrics for Logistic Regression are:")
    classifier_metrics(y_test, LogReg.predict(testx[predictor_cols]))
    # Appending results for all three datasets
    trainf = append_proba(LogReg, predictor_cols, trainx)
    testf = append_proba(LogReg, predictor_cols, testx)
    validf = append_proba(LogReg, predictor_cols, validx)
    log.info("Model evaluation process is now complete")
    return trainf, testf, validf


if __name__ == "__main__":
    start_time = time.time()
    # fetch config params and load required data
    env = os.environ.get("ENV")
    app_path = os.getcwd()
    config = Config(env, app_path)
    log = config.get_logger()
    log.info("Training script has now started")
    pkl_path = config.getConfigValueFor("pkl_path")
    pkl_ct_dict = config.getConfigValueFor("pkl_file_name_ct_dict")
    pkl_lr_model = config.getConfigValueFor("pkl_file_name_model")
    hdfs_import_file_path = config.getConfigValueFor("hdfs_in_path")
    import_file_name = config.getConfigValueFor("train_file_name")
    # Start training process
    # Import training data
    ltd_lcp = data_import(hdfs_import_file_path, import_file_name)
    # Data preprocessing
    trainDF, testDF, validDF, act_train, act_test, act_valid = data_prep(ltd_lcp)
    # Encode categorical variables
    trainDF, testDF, validDF, predictor_cols = feature_eng(trainDF, testDF, validDF)
    # Tune hyper-parameters and build optimal model
    model = modeling(trainDF, testDF, act_train, act_test, predictor_cols)
    # evalute metrics
    train_final, test_final, valid_final = evaluation(model, trainDF, testDF, validDF, act_train, act_test, act_valid)
    log.info("Training script is now complete")
    log.warning("The training is completed in: [ %s ] Seconds ---" % (time.time() - start_time))
