string = 'abaaab'
substr = 'ab'
N = 1
def substr_count(string,substr,N):
    count = 0
    if len(re.findall('(?='+substr+')',string)) >= N:
        for i in range(len(string)):
            if string[i:i+len(substr)] == substr:
                count+=1
            if count == N:
                return(i+1)
    else:
        return 0
a = substr_count(string,substr,N)
print(a)