##############################################################################
# ----------------------------------------------------------------------------
#                            Program Information
# ----------------------------------------------------------------------------
# Author                 : Shanmugaraja Dakshinamoorthy, Arunadhri Srinivasan, 
#                          Sreedhar Muthukrishnan Viswanathan
# Creation Date          : 19FEB2019
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#                             Script Information
# ---------------------------------------------------------------------------
# Script Name            : Modelling_Univariate_Tool.py
# Bitbucket Project/Repo :
# Brief Description      :
# Data used              : Univariate_Auto_Defection_input.txt
#
# Output Files           : Auto_Mid_A.txt, ChiValue_Ret_GrpAu_Base.txt,
#                          Univar_Ret_GrpAu_Base_Sorted.txt
#
# Notes / Assumptions    :
# ---------------------------------------------------------------------------
#                            Environment Information
# ---------------------------------------------------------------------------
# Python Version         : 3.6.3
# Anaconda Version       : 5.0.1
# Spark Version          : 2.3.0
# Operating System       : Red Hat Linux 7.4
# ---------------------------------------------------------------------------
#                           Change Control Information
# ---------------------------------------------------------------------------
# Developer Name/Date   : Change and Reason
# ###########################################################################

# ----------------------------------------------------------------------------

import pandas as pd
import configparser
import sys
import ast
from copy import deepcopy
import csv
import warnings
warnings.filterwarnings('ignore')




def read_config():
    config = configparser.ConfigParser()
    config.read("config.ini")
    return config

def read_data(config):
    """Reads a dataframe from a flatfile at the location specified in the
       config file. If some other source is provided it throws error.
    """
    cat_columns = ast.literal_eval(config['DataInput']['Categorical_columns'])

    cat_column_dict = {}
    for cat_col in cat_columns:
        cat_column_dict[cat_col] = object
    
    delimiter = ast.literal_eval(config['DataInput']['Delimiter'])
    if config['DataInput']['Data_Source'] == 'FLATFILE':
        df = pd.read_csv(config['DataInput']['Path_To_File'], dtype = cat_column_dict, sep=delimiter)
    else:
        print('Input value is wrong. Please check config file and run again')
        sys.exit(1)
    return df


def condition_builder(condition):
    """Returns a condition based on the one that is provided in the
    config file using which the RESPONSE flag is generateddf["WP_LIAB_VEH"].dtype
Out[31]: dtype('float64')

    Parameters:
        condition: Condition to create RESPONSE flag.

    Returns:
        condition: The updated training DataFrame.

    """
    condition = condition.split(' ')
    condition = 'df["RESPONSE"] = df["' + condition[0] + '"].apply(lambda x: 1 if x'+' '\
    + condition[1] + ' ' + condition[2]+' else 0)'
    return condition



def response_variable_creation(df, config):
    """Creates a new column called "RESPONSE" in the dataframe using which
       many aggregations are done. If it is created in advance, it can be
       specified in the config file which will be handled here

       Parameters:
        df (dataframe): The source DataFrame.
        config: input config file with user input

       Returns:
        df (dataframe): The updated training DataFrame.

    """
    if config['DataInput']['Response_Field'] == 'CREATE':
        condition = condition_builder(config['DataInput']['Condition'])
        exec(condition)
    elif config['DataInput']['Response_Field'] == 'CREATED':
        pass
    else:
        print('Input value is wrong. Please check config file and run again')
        sys.exit(1)
    return df



def fill_values(df, config):
    """Fills the nan values in the dataframe with the specified character
       or number. A list of columns for which the values to be filled must
       be provided in the config file to replace the values

    Parameters:
        fill_value: Value that needs to be filled in place of nan values.
        config: input config file with user input

    Returns:
        df (dataframe): The updated training DataFrame.

    """
    if config['DataInput']['Filler_Value_Type'] == 'INT':
        fill_value = int(config['DataInput']['Filler_Value'])
    elif config['DataInput']['Filler_Value_Type'] == 'STR':
        fill_value = config['DataInput']['Filler_Value']
    else:
        print('Input value is wrong. Please check config file and run again')
        sys.exit(1)
    #Getting the columns for which the nan values should be treated
    cols_to_fill = ast.literal_eval(config['DataInput']['Columns_To_Fill'])
    #Filling nan in the columns
    df.loc[:, cols_to_fill].fillna(fill_value, inplace=True)
    return df


def drop_columns(df, config):
    """Drops the columns that needs to be before processing the data.
    Gets the date columns and adds it to the list of columns that
    needs to be dropped

    Parameters:
        df: source dataframe
        config: input config file with user input

    Variables:
        cols_to_drop: Known columns that needs to be dropped.
        ID_cols: Known ID columns provided in the config file.
        Date_cols: Known date columns provided in the config file.
        Datetime_columns: Columns that are of dtype 'datetime64[ns]'.

    Returns:
        df (dataframe): The updated training DataFrame.

    """
    #Getting Columns to drop
    cols_to_drop = ast.literal_eval(config['DataInput']['Columns_To_Drop'])
    #Getting ID columns
    ID_cols = ast.literal_eval(config['DataInput']['ID_Columns'])
    #Getting Date Columns
    Date_cols = ast.literal_eval(config['DataInput']['Date_Columns'])
    #Deriving the columns that are of type datetime and left in previous list
    Datetime_columns = [i for i in df.columns if df[i].dtype == 'datetime64[ns]']
    #consolidating the list of columns that needs to be dropped
    cols_to_drop = cols_to_drop + ID_cols + Date_cols + Datetime_columns
    #Dropping columns
    df = df.drop(cols_to_drop, axis=1)
    
#    cat_columns = config['DataInput']['Categorical_cols']
#    cat_columns = [i for i in cat_columns if i in df.columns]
#    for i in df.drop(cat_columns, axis=1).columns:
#        try:
#            df[i] = df[i].fillna('').astype(int)
#        except Exception as e:
#            print(i)
#            if i == 'VEH_COL_DED_AMT3':
#                print(e)
#                sys.exit()
#                break
#            df[i] = df[i].astype(str) 
        
    return df


def categorical_variables_data_processing(df):

    """Returns a dataframe where all categorical variables
    are consolidated at variable level and the weighted
    response,weights are calculated

    Parameters:
        df (dataframe): source dataframe.

    Returns:
        cat_melt: Aggregated dataframe for the categorical columns.

    """
    #getting categorical columns in df
    cat_columns = [i for i in df.columns if df[i].dtype == 'object']
    #Filling nan's with empty space for all categorical columns
    df[cat_columns] = df[cat_columns].fillna(' ')
    #Melting dataframe before grouping it
    cat_melt = df.melt(id_vars=['RESPONSE', 'WEIGHT'], value_vars=cat_columns,
                      var_name='colname', value_name='value')
    #Groupby on melted df
    cat_melt = cat_melt.groupby(['colname', 'value'])['RESPONSE', 'WEIGHT'].agg(sum).reset_index()
    #cat_melt.columns = ['_'.join(i) for i in cat_melt.columns]
    
    #Renaming variables in the dataframe
    cat_melt.rename(columns={"colname": "colname",
                             "value": "value",
                             "RESPONSE": "sum_value",
                             "WEIGHT": "count_value"}, inplace=True)
    cat_melt["dtype"] = "CATEGORICAL"
    cols = ["dtype", "colname", "value", "sum_value", "count_value"]
    #Rearranging data 
    cat_melt = cat_melt[cols]
    return cat_melt


def continuous_variables_data_processing(df,config):
    

    """Returns a dataframe where all continuous variables
    are consolidated at variable level and the weighted
    response,weights are calculated

    Parameters:
        df (dataframe): source dataframe.
        config: input config file with user input

    Returns:
        cont_melt: Aggregated dataframe for the categorical columns.

    """  
    
    bins = int(config['DataInput']['Bins'])
    
    #cat_columns = [i for i in df.columns if df[i].dtype == 'object']
    #cont_columns = [i for i in df.columns if i not in cat_columns and i not in ["RESPONSE", "WEIGHT"]]
    cont_columns = [i for i in df.columns if df[i].dtype != 'object']
    cont_columns.remove("RESPONSE")
    cont_columns.remove("WEIGHT")

    
    df["VAL_ORDER"] = df.index+1
    df_melt = df.melt(id_vars=['RESPONSE', 'WEIGHT', 'VAL_ORDER'], value_vars=cont_columns, var_name='colname', value_name='value')
    df_temp = df_melt.sort_values(by=['colname', 'value', "VAL_ORDER"]).reset_index(drop=True)
    df_temp["WEIGHTSOFAR"] = df_temp.groupby(['colname'])['WEIGHT'].cumsum()
    df_temp["WEIGHTSOFAR_BIN"] = pd.cut(df_temp["WEIGHTSOFAR"], bins, labels=range(1, bins+1))
    #df_temp["WEIGHTSOFAR_BIN"] = pd.cut(df_temp["VAL_ORDER"], bins, labels=range(1, bins+1))
    cont_melt_df = df_temp.groupby(['colname','WEIGHTSOFAR_BIN'])['WEIGHT', 'RESPONSE', 'value'].sum().reset_index()
    cont_melt_df["dtype"] = "CONTINUOUS"
    cont_melt_df["VALUE"] = cont_melt_df["value"]/cont_melt_df["WEIGHT"]
    cont_melt_df = cont_melt_df.drop(["value"], axis=1)

    cont_melt_df.rename(columns={"VALUE": "value",
                            "RESPONSE": "sum_value",
                            "WEIGHT": "count_value"}, inplace=True)
    cols = ["dtype", "colname", "value", "sum_value", "count_value"]
    cont_melt_df = cont_melt_df[cols]
    return cont_melt_df

def flat_file(df):

    """Returns a dataframe where weighted sum of response and 
    weighted sum of weights are calculated at the level of
    SRC_OF_BUS_CD in the source dataframe.


    Parameters:
        df (dataframe): source dataframe.
        
    Returns:
        df_agg: Aggregated dataframe .

    """
    #Aggregates data at the variable level
    df_agg = df.groupby('SRC_OF_BUS_CD')['WEIGHT', 'RESPONSE'].sum().reset_index().rename(columns={'WEIGHT': 'WEIGHT_Sum', 'RESPONSE': 'RESPONSE_Sum'})

    df_agg["INPUT"] = "sample"
    #Renaming columns in the dataframe
    df_agg.rename(columns={"RESPONSE_Sum": "RESPONSE",
                           "WEIGHT_Sum": "WEIGHT"}, inplace=True)

    df_agg["INPUT_TYPE"] = "SAMPLE"

    #Rearranging the columns
    lis = list(df_agg)
    cols = ["INPUT_TYPE", "INPUT"]
    cols2 = ["RESPONSE", "WEIGHT"]
    temp = {"INPUT_TYPE", "INPUT", "RESPONSE", "WEIGHT"}
    lis = [i for i in lis if i not in temp]
    cols = cols+lis
    cols = cols+cols2
    df_agg = df_agg[cols]
    df_agg.rename(columns={"INPUT_TYPE": "dtype",
                           "INPUT": "colname",
                           "SRC_OF_BUS_CD": "value",
                           "RESPONSE": "sum_value",
                           "WEIGHT": "count_value"}, inplace=True)

    return df_agg


def chivalue_calculation(input_df):

    """Returns a dataframe where chivalue and adjusted chivalue
    are calculated for the variables that are present in the provided
    dataframe.


    Parameters:
        input_df (dataframe): source dataframe which will be output of
        supernode_data_processing function .

    Returns:
        chivalue: Cumulative dataframe .

    """
    #Aggregating dataframe at specified level
    chivalue = input_df.groupby(["VARIABLE"]).agg({"RESPONSE": "sum",
                                                   "WEIGHT": "sum"})\
    .reset_index().rename(columns={"RESPONSE": "RESPONSE_Sum",
                                   "WEIGHT": "WEIGHT_Sum"})

    #Creating new variables
    RESPONSE_Sum_Max = chivalue["RESPONSE_Sum"].max()
    WEIGHT_Sum_Max = chivalue["WEIGHT_Sum"].max()
    chivalue = deepcopy(input_df)
    chivalue["TOTAL_RESPONSE"] = RESPONSE_Sum_Max
    chivalue["TOTAL_WEIGHT"] = WEIGHT_Sum_Max
    
    #Creating new variables
    chivalue["TARGET_REL"] = (chivalue["RESPONSE"] / chivalue["WEIGHT"]) / (chivalue["TOTAL_RESPONSE"] / chivalue["TOTAL_WEIGHT"])
    chivalue["PCT_TOTAL_WEIGHT"] = chivalue["WEIGHT"] / chivalue["TOTAL_WEIGHT"]

    chivalue["CHI_VALUE"] = (chivalue["TARGET_REL"] - 1) ** 2 * chivalue["PCT_TOTAL_WEIGHT"] * 1000
    #Aggregating dataframe at specified level
    chivalue = chivalue.groupby(["VARIABLE", "CATEGORY"])["CHI_VALUE"].agg(["sum", "count"])\
    .reset_index().rename(columns={"sum": "CHI_VALUE_Sum", "count": "VALUES"})
    #Creating new variables
    chivalue["ADJ_CHI_VALUE"] = chivalue["CHI_VALUE_Sum"] / (chivalue["VALUES"])
    #Renaming variables
    chivalue = chivalue.rename(columns={"CHI_VALUE_Sum": "CHI_VALUE"})

    cols = ["VARIABLE", "CATEGORY", "VALUES", "CHI_VALUE", "ADJ_CHI_VALUE"]
    #Rearranging variables in the dataframe
    chivalue = chivalue[cols]
    #Field Reorder

    chivalue = chivalue.sort_values(by=["ADJ_CHI_VALUE", "CHI_VALUE", "VALUES"], ascending=[False, False, True]).reset_index(drop=True)
    return chivalue


def consolidated_output_creation(df_output, chivalue):

    """Returns a sorted dataframe


    Parameters:
        df (dataframe): source dataframe which will be output of
        "supernode_data_processing" function.
        chivalue (dataframe): source dataframe which will be output of
        "chivalue_file" function.

    Returns:
        data: Cumulative dataframe .

    """
    #Creating index
    chivalue["VAR_RANK"] = chivalue.index+1
    #Dropping Variables
    chivalue.drop(labels=["CATEGORY"], axis=1, inplace=True)


    # -----------------Univar_Ret_GrpAu_Base_Sorted.txt-----------
    # -----------------Continuous---------------------------------
    #Filtering dataframe for continuous variables
    set_continuous = df_output.loc[df_output["CATEGORY"] == "CONTINUOUS"]
    #Creating variables
    set_continuous['VAL_INT'] = pd.to_numeric(set_continuous['VALUE'], errors='coerce')
    #set_continuous["VAL_INT"] = (set_continuous["VALUE"]).astype(int)
    #Sorting dataframe based on variables
    set_continuous = set_continuous.sort_values(by=["VARIABLE", "VAL_INT"]).reset_index(drop=True)
    #Creating variables
    set_continuous["VAL_ORDER"] = set_continuous.index+1
    #Dropping variables
    set_continuous.drop(labels=["VAL_INT"], axis=1, inplace=True)

    # -----------------Categorical---------------------------------
    #Filtering dataframe for Categorical variables
    set_categorical = df_output.loc[df_output["CATEGORY"] == "CATEGORICAL"]
    #Sorting dataframe based on variables
    set_categorical = set_categorical.sort_values(by=["VARIABLE", "VALUE"]).reset_index(drop=True)
    #Creating index
    set_categorical["VAL_ORDER"] = set_categorical.index+1
    #Appending newly created dataframes into one
    data = set_categorical.append(set_continuous, ignore_index=True)
    #Merging data with chivalue dataframe
    data = data.merge(chivalue, on="VARIABLE")
    #Sorting resultant dataframe
    data = data.sort_values(by=["VAR_RANK", "VARIABLE", "VAL_ORDER"])
    #Dropping certain columns
    data.drop(["VAL_ORDER", "VALUES", "CHI_VALUE",
                       "ADJ_CHI_VALUE", "VAR_RANK"], axis=1, inplace=True)
    #Reordering variables in the dataframe in a predefined way
    lis = list(data)
    temp = ["CATEGORY", "VARIABLE", "VALUE", "RESPONSE", "WEIGHT"]
    lis = [i for i in lis if i not in temp]
    cols = temp + lis
    data = data[cols]
    return data


def logistic_univariate(df, config):
    #Getting value for WEIGHT column
    df["WEIGHT"] = int(config['DataInput']['WEIGHT'])

    #Reading location and filename for the output files from the config file
    processed_input_data_filepath = config['DataInput']['processed_input_data']
    ChiValue_filepath = config['DataInput']['ChiValue_File']
    consolidated_output_filepath = config['DataInput']['consolidated_output']


    #---------------------------Supernode data processing------------------------
    df2_categorical = categorical_variables_data_processing(df)
    df2_continuous = continuous_variables_data_processing(df, config)
    df2 = df2_continuous.append(df2_categorical, ignore_index=True)

    Univar_Ret_GrpAu_Base = flat_file(df)

    processed_input_data = Univar_Ret_GrpAu_Base.append(df2, ignore_index=True)
    processed_input_data.to_csv(processed_input_data_filepath, sep=",", index=False, header=False)


    #---------------------Chi Value and Auto_Mid_A_sorted file --------------------
    #---------------------Data Prep --------------------


    df_output = df2.copy()
    df_output = df_output.rename(columns={"dtype": "CATEGORY",
                                          "colname": "VARIABLE",
                                          "value": "VALUE",
                                          "sum_value": "RESPONSE",
                                          "count_value": "WEIGHT"})

    # -----------------------ChiValue File-----------------
    df2_chi_input = deepcopy(df_output)
    chivalue = chivalue_calculation(df2_chi_input)

    chivalue.to_csv(ChiValue_filepath, header=True, index=False, sep="\t", quoting=csv.QUOTE_NONNUMERIC )


    # -----------------------Auto_Mid_A_sorted File-----------------

    data = consolidated_output_creation(df_output, chivalue)

    data.to_csv(consolidated_output_filepath, header=True, index=False, sep=",")


def main():

    config = read_config()
    df = read_data(config)
    df = response_variable_creation(df, config)
    df = fill_values(df,config)
    df = drop_columns(df,config)
    logistic_univariate(df,config)
    

if __name__ == '__main__':
    main()