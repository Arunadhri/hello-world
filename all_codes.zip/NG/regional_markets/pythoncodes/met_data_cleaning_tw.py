def labels_customize(size_cut):
    cuts_label = ['100-'+size_cut[0]]
    for i in range(1, len(size_cut)+1):
        if i<len(size_cut):
            label = size_cut[i] + '-' + size_cut[i+1]
        else:
            label = size_cut[i] + '+'
        cuts_label.append(label)
    return cuts_label

# function to reconcile broker name between MetLife database and f5500 filing 
def met_broker_standardization(dt=dt, map=brokerMappingFile):

    #map_brokers = pd.read_pickle('metlife_brokers_standardized_all_yrs.pkl')
    map_brokers = map_brokers.drop_duplicates()

    if 'LKUP_BRKR_ID' in dt.columns:
        dt['BRKR_FIRM_ID'] = dt['LKUP_BRKR_ID']
    if 'LKUP_BRKR_FIRM_NM' in dt.columns:
        dt['BRKR_FIRM_NM'] = dt['LKUP_BRKR_FIRM_NM']

    dt = dt.merge(map_brokers[['BrokerProper', 'BRKR_FIRM_ID']],
                  on='BRKR_FIRM_ID', how='left')
    dt = dt.rename(columns={'BrokerProper': 'BROKER_NAME_GRIP'})
    np.where((dt['BROKER_NAME_GRIP'].isnull()) or (dt['BROKER_NAME_GRIP'] == ''),
             dt['BRKR_FIRM_NM'], dt['BROKER_NAME_GRIP'])

    dt.replace({'BROKER_NAME_GRIP': {'Northwestern Mutual': 'Northwestern'}}, inplace=True)
    return dt

# get profitability and persistency metrics
def Profitabilty_Calc(dt, inscope_products=met_inscope_products,
                      inscope_state=met_inscope_state,
                      sizecut=size_cut, suffix=suffix, metvar=metvar):

    #dt = pd.read_excel('McKinsey Update - Inforce - Phase Up - v2.xlsx', sheetname='Inforce Data')
    dt = dt[(dt['RPT_SIZE_TXT'] == '100-5000') & (dt['REC_YR'].isin(range(2016, 2019)))]
    dt['CVR_GRP_SCOR_CARD_CD'] = dt['CVR_GRP_SCOR_CARD_CD'].apply(lambda x: x.toupper())
    dt = met_broker_standardization(dt)
    dt['BRKR_FIRM_ZIP_CD'] = dt['BRKR_FIRM_ZIP_CD'].apply(lambda x: x[:5])
    dt = met_add_market(dt, zipvar=["BRKR_FIRM_ZIP_CD"], Statevar="BRKR_FIRM_ST_CD", brokervar="BROKER_NAME_GRIP")
    dt['SalesOffice'].fillna('', inplace=True)
    dt = dt[(dt['CVR_GRP_SCOR_CARD_CD'].isin(inscope_products))]

    labels_customized = labels_customize(sizecut)[:-1]

    def elgbl_lif_cnt(x):
        if x['ELGBL_LIF_CNT'] == '(null)':
            if x['SUBSEGMENT'] == 'A_100-499':
                return 101
            else:
                if x['SUBSEGMENT'] == 'C_1000-4999':
                    return 1001
                else:
                    return 501
        else:
            return x['ELGBL_LIF_CNT']


    dt['ELGBL_LIF_CNT'] = dt.apply(elgbl_lif_cnt, axis=1)
    dt['ELGBL_LIF_CNT'] = pd.to_numeric(dt['ELGBL_LIF_CNT'])
    bins = [-1] + sizecut[:-1] + [dt['ELGBL_LIF_CNT'].max()]
    dt['SUBSEGMENT'] = pd.cut(dt['ELGBL_LIF_CNT'], bins=bins, labels=labels_customized)
    # aggregate by state, sales office, size segment, product, broker
    ag = dt.groupby(metvar)['TOT_PREM_AND_FEE_AMT', 'P_TAX_ERN_AMT'].sum().reset_index()
    ag.to_pickle('Profit_Calculation'+suffix+'.pkl')


def Persistency_Calc(inscope_products=met_inscope_products,
                     inscope_state=met_inscope_state,
                     sizecut=size_cut, suffix=suffix, metvar=metvar):
    dt = pd.read_excel('McKinsey Update - Persistency - Phase Up - v2.xlsx', sheetname='Persistency_Data')
    dt = dt[(dt['RPT_SIZE_TXT'] == '100-5000') & (dt['REC_YR'].isin(range(2016, 2019)))]
    dt['CVR_GRP_SCOR_CARD_CD'] = dt['CVR_GRP_SCOR_CARD_CD'].apply(lambda x: x.toupper())
    dt = met_broker_standardization(dt)

    dt['BRKR_FIRM_ZIP_CD'] = dt['BRKR_FIRM_ZIP_CD'].apply(lambda x: x[:5])
    dt = met_add_market(dt, zipvar=["BRKR_FIRM_ZIP_CD"],Statevar="BRKR_FIRM_ST_CD", brokervar="BROKER_NAME_GRIP")
    dt['SalesOffice'].fillna('', inplace=True)
    dt = dt[(dt['CVR_GRP_SCOR_CARD_CD'].isin(inscope_products))]
    labels_customized = labels_customize(sizecut)[:-1]

    def elgbl_lif_cnt(x):
        if x['ELGBL_LIF_CNT'] == '(null)':
            if x['SUBSEGMENT'] == 'A_100-499':
                return 101
            else:
                if x['SUBSEGMENT'] == 'C_1000-4999':
                    return 1001
                else:
                    return 501
        else:
            return x['ELGBL_LIF_CNT']


    dt['ELGBL_LIF_CNT'] = dt.apply(elgbl_lif_cnt, axis=1)
    dt['ELGBL_LIF_CNT'] = pd.to_numeric(dt['ELGBL_LIF_CNT'])
    bins = [-1] + sizecut[:-1] + [dt['ELGBL_LIF_CNT'].max()]
    dt['SUBSEGMENT'] = pd.cut(dt['ELGBL_LIF_CNT'], bins=bins, labels=labels_customized)
    # aggregate by state, sales office, size segment, product, broker
    ag = dt.groupby(metvar)['PRST_PREM_BASE_AMT', 'PRST_TRM_PREM_AMT'].sum().reset_index()
    ag.to_pickle('Persistency_Calculation'+suffix+'.pkl')

def import_sales_data():
    data2019 = pd.read_excel('McKinsey Update - Sales & Quotes - 2019 - All - v2.xlsx')
    data2018 = pd.read_excel('McKinsey Update - Sales & Quotes - 2018 - All - v2.xlsx')
    data2017 = pd.read_excel('McKinsey Update - Sales & Quotes - 2017 - All - v2.xlsx')
    data2016 = pd.read_excel('McKinsey Update - Sales & Quotes - 2016 - All - v2.xlsx')
    all_ = pd.DataFrame()
    for y in range(2016, 2020):
        sub = locals()['data'+y]
        sub['ETL_CYC_DT'] = pd.to_datetime(sub['ETL_CYC_DT'])
        sub['cycleyear'] = sub['ETL_CYC_DT'].dt.year
        sub = sub[sub['cycleyear'] == sub['EFF_YR']]
        for v in ["ELGBL_LIF_CNT",'QT_PCT','CVR_CNT',"PREMIUM"]:
            sub[v] = pd.to_numeric(sub[v])
        all_ = all_.append(sub)
    all_ = all_[(all_['CUST_NM'] != '(null)') & ~(all_['CUST_NM'].isna())]
    met_mapping = pd.read_pickle('broker_mapping_felix.pkl')
    met_mapping = met_mapping.drop_duplicates()

    all_ = all_.merge(met_mapping["BRKR_FIRM_ID","BRKR_FIRM_PRNT_NM","BRKR_FIRM_ZIP_CD"],
              left_on="LKUP_BRKR_ID", right_on="BRKR_FIRM_ID", how='left')
    all_['BRKR_FIRM_PRNT_NM'] = np.where(all_['BRKR_FIRM_PRNT_NM'].isnull(),all_['LKUP_BRKR_FIRM_NM'], all_['BRKR_FIRM_PRNT_NM'])
    all_['BRKR_FIRM_ZIP_CD'] = np.where(all_['BRKR_FIRM_ZIP_CD'].isnull(), '', all_['BRKR_FIRM_ZIP_CD'])
    all_['BRKR_FIRM_ZIP_CD'] = all_['BRKR_FIRM_ZIP_CD'].apply(lambda x: x[:5])
    all_.to_pickle('AllSalesQuote.pkl')

def clean_sales_quote_data():
    df = pd.read_pickle('AllSalesQuote.pkl')
    df = met_broker_standardization(df)
    df = df.sort_values('CUST_NM')
    df['CUST_NM'] = df['CUST_NM'].apply(lambda x: x.toupper())

    quotes = df[df['COMP_CD'] == 'Quoted']
    sales = df[df['COMP_CD'] == 'Sales$']

    customer = sales[sales['CUST_NUM'] != '(null)'].groupby(['CUST_NUM', 'CUST_NM'])['COMP_CD'].count().reset_index(name='Freq')
    customer['NAMECT'] = customer.groupby(['CUST_NM'])['CUST_NM'].transform('size')
    customer['NAMELEN'] = customer['CUST_NM'].apply(lambda x: len(x))
    badCUST_NUM = list(customer[customer['NAMECT'] > 12]['CUST_NUM'].unique())
    badCUST_NUM += ['5347643','0163845','5343412','5347558','9999814','0000000', '0000224']
    customer = customer[~customer['CUST_NUM'].isin(badCUST_NUM)]

    customer = customer.sort_values(['CUST_NUM', 'Freq', 'NAMELEN'], ascending=[True, False,True])
    customer['IND'] = customer.groupby('CUST_NUM').cumcount(1).add(1)


    customer_unique = customer[['CUST_NUM','CUST_NM']].drop_duplicates(subset='CUST_NUM')
    customer_unique.rename(columns={'CUST_NM': 'CUST_NM_STD'})
    customer = customer.merge(customer_unique, how='inner', on='CUST_NUM')
    customer = customer[['CUST_NUM','CUST_NM','CUST_NM_STD']].drop_duplicates()
    sales = sales.merge(customer, on=['CUST_NUM','CUST_NM'], how='left')
    
    prospect = quotes[quotes['PRSP_NUM'] != '(null)'].groupby(['CUST_NM','PRSP_NUM'])['CUST_NM'].count().reset_index(name='Freq')
    prospect['NAMECT'] = prospect.groupby(['PRSP_NUM', 'CUST_NM'])['CUST_NM'].transform('size')
    prospect['NAMELEN'] = prospect['CUST_NM'].apply(lambda x: len(x))
    badPRSP_NUM = list(prospect[prospect['NAMECT'] > 8]['PRSP_NUM'].unique())
    badPRSP_NUM += ['na','n/a','N/A','Unknown','P1000000','P1122334','0']
    prospect = prospect[~prospect['PRSP_NUM'].isin(badPRSP_NUM)]
    prospect = prospect.sort_values(['PRSP_NUM', 'Freq', 'NAMELEN'], ascending=[True, False,True])
    prospect_unique = prospect[['PRSP_NUM','CUST_NM']].drop_duplicates(subset='PRSP_NUM')
    prospect_unique.rename(columns={'CUST_NM': 'CUST_NM_STD'})
    prospect = prospect.merge(prospect_unique, how='inner', on='PRSP_NUM')
    prospect = prospect[['PRSP_NUM','CUST_NM','CUST_NM_STD']].drop_duplicates()
    quotes = quotes.merge(customer, on=['PRSP_NUM','CUST_NM'], how='left')
    
    dt = sales.append(quotes)
    dt['CUST_NM_STD'] = np.where(dt['CUST_NM_STD'].isnull(), dt['CUST_NM'], dt['CUST_NM_STD'])
    dt.to_pickle('AllSalesQuote_clean.pkl')


def Closing_ratio_calc(inscope_products=met_inscope_products,
                       inscope_state=met_inscope_state,
                       sizecut=size_cut,
                       suffix=suffix,
                       metvar=metvar):
    dt = pd.read_pickle('AllSalesQuote_clean.pkl')
    dt = dt[(dt['CVR_GRP_SCOR_CARD_CD'].isin(inscope_products)) &
           (dt['MKT_CD_WITH_SORT_TXT'] == 'B_100-5000') & (dt['EFF_YR'].isin(range(2016, 2019)))]

    labels_customized = labels_customize(sizecut)[:-1]

    def elgbl_lif_cnt(x):
        if x['ELGBL_LIF_CNT'] == '(null)':
            if x['SUBSEGMENT'] == 'A_100-499':
                return 101
            else:
                if x['SUBSEGMENT'] == 'C_1000-4999':
                    return 1001
                else:
                    return 501
        else:
            return x['ELGBL_LIF_CNT']


    dt['ELGBL_LIF_CNT'] = dt.apply(elgbl_lif_cnt, axis=1)
    dt['ELGBL_LIF_CNT'].fillna(0, inplace=True)
    dt['ELGBL_LIF_CNT'] = pd.to_numeric(dt['ELGBL_LIF_CNT'])
    bins = [-1] + sizecut[:-1] + [dt['ELGBL_LIF_CNT'].max()]
    dt['SUBSEGMENT'] = pd.cut(dt['ELGBL_LIF_CNT'], bins=bins, labels=labels_customized)

    dt = dt.merge(zip_st_mapping, how='left', left_on='BRKR_FIRM_ZIP_CD', right_on='Zip')
    dt['ST'] = dt['ST'].fillna('')
    dt['FL'] = np.where((dt['BRKR_FIRM_ST_CD'] != dt['ST']) & (dt['BRKR_FIRM_ST_CD'] != '')
                        & (dt['ST'] != ''), 1, 0)
    dt['BRKR_FIRM_ST_CD'] = np.where(dt['FL'] == 1, dt['ST'], dt['BRKR_FIRM_ST_CD'])
    dt = dt.drop(['ST', 'FL'], axis=1)

    dt = met_add_market(dt, zipvar=["BRKR_FIRM_ZIP_CD"], Statevar="BRKR_FIRM_ST_CD", brokervar="BROKER_NAME_GRIP")
    dt[['SalesOffice', 'Region']] = dt[['SalesOffice', 'Region']].fillna('')

    
    
    quotes = dt[dt['COMP_CD'] == 'Quoted']
    sales = dt[dt['COMP_CD'] == 'Sales$']
    bylist = metvar.copy()
    ag_s = sales.groupby(bylist)['PREMIUM', 'CVR_CNT'].sum().reset_index().rename(columns={'PREMIUM': 'AvgSales',
                                                                                                'CVR_CNT': 'AvgSoldCvg'})
    ag_s['AvgSales'] = ag_s['AvgSales']/3
    ag_s['AvgSoldCvg'] = ag_s['AvgSoldCvg']/3

    ag_quotes = quotes.groupby(bylist)['QT_PCT'].sum().reset_index(name='AvgQuotes')
    ag_quotes['QT_PCT'] = ag_quotes['QT_PCT']/3

    ag = ag_s.merge(ag_quotes, how='outer', on=bylist)
    ag[['AvgSales', 'AvgSoldCvg', 'AvgQuotes']].fillna(0, inplace=True)
    ag.to_pickle('Sales_Calculation' + suffix + '.pkl')

def met_combine(inscope_products=met_inscope_products, outdir=met_datawd):
    profit = pd.read_pickle('Profit_Calculation'+ suffix + '.pkl')
    persistency = pd.read_pickle('Persistency_Calculation'+suffix+'.RDS')
    salesquote = pd.read_pickle('Sales_Calculation'+suffix+'.RDS')
    bylist = metvar.copy()
    all_ = profit.merge(persistency, by=bylist, how='outer')
    all_ = all_.merge(salesquote, by=bylist, how='outer')
    all_ = all_.rename()
    all_ = all_.rename({'CVR_GRP_SCOR_CARD_CD': {'DENTAL': 'Dental',
                                           'HL': 'Legal',
                                           'TERM LIFE': 'Life',
                                           'VISION': 'Vision'}})

    
    all_ = all_.rename(columns={'BROKER_NAME_GRIP': 'Broker'})
    all_.to_pickle('Met_Metrics' + suffix + '.RDS')
    all_.to_excel('Met_Metrics' + suffix + '.xlsx')