def BrokerByAddr(dt = groupdt, y = 2017, broker_num = 50):
    dt = dt[dt["year"] == y]
    # Get primary broker address
    dt = EditBrokerCarrier(dt,state_var = "BrokPrimarySTATE",brokervar = "BrokPrimary", EDIT_BROKER = T,broker_num = broker_num)
    BROKER = dt.groupby(["RegionPrimary","BrokPrimarySTATE","SalesOfficePrimary","BrokPrimary","BrokPrimaryZIP","BrokPrimaryAddr"])["STATE_EIN"].nunique().reset_index()
    BROKER = BROKER[BROKER["SalesOfficePrimary"] != "" & BROKER["BrokPrimary"] != "Other" & BROKER["BrokPrimaryAddr"] != "MISSING BROKER LOCATION"]
    BROKER = BROKER.sort_order(by = ["BrokPrimarySTATE","SalesOfficePrimary","BrokPrimary", "TotalGroups"], ascending=[True,True,True,False]).reset_index(drop=true)
    
    BROKER[,AddrRank := seq_along(TotalGroups), by = c("RegionPrimary","BrokPrimarySTATE","SalesOfficePrimary","BrokPrimary")]

    BROKER["TOT"] = BROKER["TotalGroups"].groupby(["RegionPrimary","BrokPrimarySTATE","SalesOfficePrimary","BrokPrimary"]).transform("sum")
    BROKER["AddrPct"] = BROKER["TotalGroups"] / BROKER["TOT"]
    BROKER = BROKER[BROKER["AddrRank"]==1 |(BROKER["AddrPct"]>0.1 & BROKER["TotalGroups"]>=3)]
    zipuq = met_office_map["County", "Zip"].drop_duplicates()
    BROKER = BROKER.merge(zipuq["Zip","County"], how="left", left_on="BrokPrimaryZIP", right_on=Zip)
    BROKER.rename({"RegionPrimary": "Region",
                   "BrokPrimarySTATE": "State",
                   "SalesOfficePrimary": "SalesOffice",
                   "BrokPrimary": "Broker",
                   "BrokPrimaryZIP": "BrokerZip",
                   "BrokPrimaryAddr": "BrokerAddress"
                   ,"County": "COUNTY_NAME"}, axis=1, inplace=True)
    keepvars = ["Region","State","SalesOffice", "Broker","BrokerZip","BrokerAddress","COUNTY_NAME"]
    BROKER = BROKER[keepvars].drop_duplicated()
    BROKER = BROKER[BROKER["State"] in met_inscope_state]
    return BROKER


def BrokerbyIndustry(dt, byvars2):

  vars_ = ["STATE_EIN","EIN_FTE","Size_Band", "Medical_Car1","Medical_Car2","Industry"]
  def groupby1(x):
      d={}
      d["GBWallet"] = x["EstProd_Prem_Carrier"].sum()
      d["OfferVBLegal"] = (1 if x["product"] in ["CI", "Accident","Hospital","Legal"] else 0).max()
      return pd.Series(d, index=["MetLifeStatePenetrationAllProd"])
  EIN_base = broker_metrics.groupby(vars_).apply(groupby1)  
  # Get primary broker on EIN level 
  EIN_BROKER = dt.groupby(["STATE_EIN"] + byvars2)agg({"EstProd_Prem_Carrier": "sum"}).reset_index()
  EIN_BROKER = EIN_BROKER.sort_order(by=["GBWallet"], ascending=False).reset_index(drop=True)  

  EIN_BROKER[,BROKERIND := seq_along(GBWallet), by = c("STATE_EIN")]

  EIN_BROKER = EIN_BROKER[EIN_BROKER["BROKERIND"] == 1]
  EIN_base = EIN_base.merge(EIN_BROKER[set("STATE_EIN")+set(byvars2)], on="STATE_EIN")
  ind = EIN_base.copy()
  ind["TotalGroups"] = ind["STATE_EIN"].groupby(set(byvars2) + set(["Industry"])).transform("sum")
  if("RegionPrimary" in byvars2):  
    ind = ind[ind["RegionPrimary"] != ""]
    ind.rename({"RegionPrimary": "Region"})
  
  if("BrokPrimarySTATE" in byvars2): 
    ind = ind[ind["BrokPrimarySTATE"] != ""]
    ind.rename({"BrokPrimarySTATE": "State"})
  
  if("SalesOfficePrimary" %in% byvars2):
    ind = ind[ind["SalesOfficePrimary"] != ""]
    ind.rename({"SalesOfficePrimary": "SalesOffice"})
  
  if("BrokPrimary" in byvars2):  
    ind = ind[ind["BrokPrimary"] not in ["Other",""]]
    ind.rename({"BrokPrimary": "Broker"})
      
  return ind 
