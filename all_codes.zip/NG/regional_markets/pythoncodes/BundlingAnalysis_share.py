def BundlingTrend(dt, Baseproduct, mod = "Bundling_trend_by_year", byvars = "year"):
  mod = mod + " for " + Baseproduct
  coreprod = ["Medical", "Life", "LTD", "STD","Vision","Dental"]
  coreVB = [ "CI", "Accident", "Hospital", "Legal"]
  def groupby1(x):
      d={}
      d["OfferMedical"] = (1 if x["product"] == "Medical" else 0).max()
      d["OfferLife"] = (1 if x["product"] == "Life" else 0).max()
      d["OfferVision"] = (1 if x["product"] == "Vision" else 0).max()
      d["OfferLTD"] = (1 if x["product"] == "LTD" else 0).max()
      d["OfferSTD"] = (1 if x["product"] == "STD" else 0).max()
      d["OfferDental"] = (1 if x["product"] == "Dental" else 0).max()
      d["OfferCI"] = (1 if x["product"] == "CI" else 0).max()
      d["OfferAccident"] = (1 if x["product"] == "Accident" else 0).max()
      d["OfferHospital"] = (1 if x["product"] == "Hospital" else 0).max()
      d["OfferLegal"] = (1 if x["product"] == "Legal" else 0).max()
      
      return pd.Series(d, index=["OfferMedical", "OfferLife", "OfferVision", "OfferLTD",
                                 "OfferSTD", "OfferDental", "OfferCI", "OfferAccident", "OfferHospital", "OfferLegal"])
  map = dt.groupby(["State_HQ","STATE_EIN","year"]).apply(groupby1)
  def groupby2(x):
      d={}
      d["Medical"] = (1 if x["product"] == "Medical" else 0).max()
      d["Life"] = (1 if x["product"] == "Life" else 0).max()
      d["Vision"] = (1 if x["product"] == "Vision" else 0).max()
      d["LTD"] = (1 if x["product"] == "LTD" else 0).max()
      d["STD"] = (1 if x["product"] == "STD" else 0).max()
      d["Dental"] = (1 if x["product"] == "Dental" else 0).max()
      d["CI"] = (1 if x["product"] == "CI" else 0).max()
      d["Accident"] = (1 if x["product"] == "Accident" else 0).max()
      d["Hospital"] = (1 if x["product"] == "Hospital" else 0).max()
      d["Legal"] = (1 if x["product"] == "Legal" else 0).max()
      
      return pd.Series(d, index=["Medical", "Life", "Vision", "LTD", "STD", "Dental", "CI", "Accident", "Hospital", "Legal"])
  prodXgroup = dt.groupby(["State_HQ","STATE_EIN","Carrier","year"]).apply(groupby2)
  dt = map.merge(prodXgroup, on=["State_HQ","STATE_EIN", "year"])
  df = dt.copy()
  na = df.columns[df.isnull().any() == False].tolist()
  if len(na) > 0:
    stopped = df
  df = df[df["OfferMedical"==1]]
  df = df[df["Carrier"] in ["", "Not Provided"]]
  prods = set(coreprod + coreVB) - set(Baseproduct)
  for in in range(1,len(prods),1):
    v = prods[i]
    sample = df[df["Offer" + Baseproduct]==1 & df["Offer" + v]==1]
    sample[v+"Bundle_w"+Baseproduct] = (1 if Baseproduct == 1 & v == 1 else 0)
    bundleEIN = sample.groupby(set["STATE_EIN"] + byvars).[v + "Bundle_w"+Baseproduct].max().reset_index()
    bundleEIN = bundleEIN.set_axis(["STATE_EIN", byvars, (v + "Bundle_w" + Baseproduct)], axis=1,inplace=True)
    summary = bundleEIN.groupby(byvars).agg({(v + "Bundle_w"+Baseproduct): "mean",
                                             (v + "Bundle_w"+Baseproduct): "sum",
                                             (v + "Bundle_w"+Baseproduct): "size"}).rename().reset_index()
    summary = summary.set_axis([byvars, (v+"CarrierBundle_w"+Baseproduct), (v+"Bundle_w"+Baseproduct+"N"),
                                ("OffersByCarr"+v+"and_"+Baseproduct+"N")], axis=1,inplace=True) 
    if(i==1):
      bundles = summary
    else:
      bundles = bundles.merge(summary, on = byvars, how ="left")

  vars = [byvars, (prods+"CarrierBundle_w"+Baseproduct), (prods+"Bundle_w"+Baseproduct+"N"),
           ("OffersByCarr"+prods+"and_"+Baseproduct+"N")]
  bundles = bundles[vars]
  return bundles
