import pandas as pd

def add_size_band(dt, size_cut=[500, 1000, 5000], mod="add_size_band"):
	cuts_label = ['100-' + str(size_cut[0])]
	for i in range(len(size_cut)):
		if i < len(size_cut):
			label = [str(size_cut[i]) + '-' + str(size_cut[i+1])]
		if i == len(size_cut):
			label = [str(size_cut[i]) + '+']
		cuts_label = cuts_label + label

	if max(dt['EIN_FTE']) > max(dt['size_cut']):
		bins = [0] + size_cut + [dt['EIN_FTE'].max()]
		dt['Size_Band'] = pd.cut(dt['EIN_FTE'], bins=bins, labels=cuts_label)
	else:
		bins = [0] + size_cut + [(dt['EIN_FTE'].max()) + 1]
		dt['Size_Band'] = pd.cut(dt['EIN_FTE'], bins=bins, labels=cuts_label)

	return dt

def met_add_market(dt, zipvar="BROKER_ZIP", Statevar="State",
                          outputvar="SalesOffice",
                          outputvarRegion="Region"):
	met_office_map = pd.read_excel('RM Zip Matrix - 2019.xlsx')
	map_ = met_office_map.copy()
	map_['Sales.Office'] = map_['Sales.Office'].apply(lambda x: x.strip())
	map_ = map_.rename(columns={'Region': 'RegionMap'})
	vars_ = ["Zip","Sales.Office","RegionMap","ST"]
	map_ = map_[vars_].drop_duplicates()
	dt = dt.merge(map_, left_on=zipvar, right_on='Zip', how='left')
	dt['ST'] = dt['ST'].fillna('')\
	dt[Statevar] = np.where(((Statevar != dt['ST']) & (dt['ST'] != '')), dt['ST'], Statevar)
	dt = dt.drop('ST', axis=1)
	nyczips = pd.read_excel('NYC LI ONLY zip codes.xlsx')
	dt['Sales.Office'] = np.where(((Statevar == 'NY') & (zipvar in nyczips['Zip'])), 'NYCLI', dt['Sales.Office'])
	dt['Sales.Office'] = np.where(((Statevar == 'NY') & (zipvar not in nyczips['Zip'])), 'NY State', dt['Sales.Office'])
	dt['RegionMap'] = np.where(Statevar == 'NY', 'Northeast Region', dt['RegionMap'])
	dt = dt.rename(columns={'Sales.Office': outputvar, 'RegionMap': outputvarRegion})
	return dt
