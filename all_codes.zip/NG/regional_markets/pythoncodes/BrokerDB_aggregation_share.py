import pandas as pd
import numpy as np
import re


def broker_metrics_overall_pit(dt=groupdt, broker_num=50, client="Metlife",
                               byvars2=["RegionPrimary","BrokPrimarySTATE", "SalesOfficePrimary","BrokPrimary"]):
   
   vars_ = ["STATE_EIN","EIN_FTE","Size_Band", "Medical_Car1","Medical_Car2","Industry"]

   def groupby1(x):
      d={}
      d["GBWallet"] = x["EstProd_Prem_Carrier"].sum()
      d["OfferVBLegal"] = (x['product'].isin(["CI", "Accident","Hospital","Legal"])).any().sum()
      return pd.Series(d, index=["GBWallet", "OfferVBLegal"])

   EIN_base = dt.groupby(vars_).apply(groupby1)
   EIN_BROKER = dt.groupby([("STATE_EIN", "RegionPrimary",
                             "BrokerCrossProductSTATE", "SalesOfficePrimary",
                             "BrokerCrossProduct")])['EstProd_Prem_Carrier'].sum().reset_index(name='GBWallet')
   EIN_BROKER = EIN_BROKER.sort_values(by=[GBWallet], ascending=False).reset_index(drop=True)
   EIN_BROKER['BROKERIND'] = EIN_BROKER.groupby('STATE_EIN').cumcount(1).add(1)
   EIN_BROKER = EIN_BROKER[EIN_BROKER["BROKERIND"] == 1]
   EIN_base = EIN_base.merge(EIN_BROKER[["STATE_EIN","RegionPrimary","BrokerCrossProductSTATE","SalesOfficePrimary",
                                         "BrokerCrossProduct"]], on="STATE_EIN", how='inner')

   def groupby2(x):
      d={}
      d["GBWallet_Carrier"] = x["EstProd_Prem_Carrier"].sum()
      d["Dental"] = (x['product'] == 'Dental').any().sum()
      d["Life"] = (x['product'] == 'Life').any().sum()
      d["LTD"] = (x['product'] == 'LTD').any().sum()
      d["STD"] = (x['product'] == 'STD').any().sum()
      d["Vision"] = (x['product'] == 'Vision').any().sum()
      d["Dis"] = (x['product'].isin(['LTD', 'STD'])).any().sum()
      return pd.Series(d, index=["GBWallet_Carrier", "Dental", "Life", "LTD", "STD", "Vision", "Dis"])

   EIN_carrier = dt[~dt['Carrier'].isin(['Not Provided'])].groupby("STATE_EIN","Carrier","Medical_Car1","Medical_Car2").apply(groupby2)
   table2 = EIN_carrier.groupby("STATE_EIN")["GBWallet_Carrier"].sum().rename({"GBWallet_Carrier": "GBWallet"})
   EIN_carrier = EIN_carrier.merge(table2, on="STATE_EIN", how="inner")
   EIN_carrier['GBWalletShare'] = EIN_carrier["GBWallet_Carrier"] / np.maximum(EIN_carrier["GBWallet"], [1]*len(EIN_carrier))
   EIN_carrier["BundleProdCT"] = EIN_carrier["Dental"] + EIN_carrier["Life"] +
                                 EIN_carrier["Vision"] + EIN_carrier["LTD"] +
                                 EIN_carrier["LTD"]
   table3 = EIN_carrier.groupby("STATE_EIN")["BundleProdCT"].sum().rename({"BundleProdCT": "ReportedProdCT"})
   EIN_carrier = EIN_carrier.merge(table3, on="STATE_EIN", how="inner")  
   EIN_carrier["ProdShare"] = EIN_carrier["BundleProdCT"] / np.maximum(EIN_carrier["ReportedProdCT"], [1]*len(EIN_carrier))
   EIN_carrier["DDLBundle"] = np.where((EIN_carrier["Dental"]+EIN_carrier["Life"]+EIN_carrier["Dis"] == 3), 1, 0)


   def groupby3(x):
      d={}
      d["AvgCarrierWallet"] = x["GBWalletShare"].mean()
      d["AvgCarrierWalletProduct"] = x["ProdShare"].mean()
      d["AvgMedicalCarrierGBWallet"] = x[x['Carrier'].isin([x['Medical_Car1'], x['Medical_Car2']])]['GBWalletShare'].mean()
      d["AvgMedicalCarrierGBProduct"] = x[x['Carrier'].isin([x['Medical_Car1'], x['Medical_Car2']])]['ProdShare'].mean()
      d["IsClient"] = (x['Carrier'] == x['client']).any().sum()
      d["ClientShareOfWallet"] =  x[x['Carrier'] == x['client']]['GBWalletShare'].sum()
      d["ClientShareOfWalletProduct"] = x[x['Carrier'] == x['client']]['ProdShare'].sum()
      d["DDLBundle"] = x["DDLBundle"].max()
      d["DDLReported"] = np.where((x["Dental"].max() + x["Life"].max() + x["Dis"].max() == 3), 1, 0)
      return pd.Series(d, index=["AvgCarrierWallet", "AvgCarrierWalletProduct", "AvgMedicalCarrierGBWallet", "AvgMedicalCarrierGBProduct",
                                 "IsClient", "ClientShareOfWallet", "ClientShareOfWalletProduct","DDLBundle", "DDLReported"])

   EIN_base_add = EIN_carrier.groupby("STATE_EIN").apply(groupby3)
   EIN_base_add['AvgMedicalCarrierGBWallet'] = EIN_base_add["AvgMedicalCarrierGBWallet"].fillna(0)
   EIN_base = EIN_base.merge(EIN_base_add, on="STATE_EIN", how="left")

   EIN_base["AvgCarrierWallet"].fillna(EIN_base["AvgCarrierWallet"].mean())
   EIN_base["AvgCarrierWalletProduct"].fillna(EIN_base["AvgCarrierWalletProduct"].mean())
   EIN_base["AvgMedicalCarrierGBWallet"].fillna(0)
   EIN_base["AvgMedicalCarrierGBProduct"].fillna(0)
   EIN_base["IsClient"].fillna(0)
   EIN_base["ClientShareOfWallet"].fillna(0)
   EIN_base["ClientShareOfWalletProduct"].fillna(0)
   EIN_base["DDLBundle"].fillna(0)
   EIN_base["DDLReported"].fillna(0)
 
   EIN_base = EditBrokerCarrier(dt=EIN_base, LONGITUDINAL=F,EDIT_BROKER=T, 
                               broker_num=broker_num, state_var="BrokerCrossProductSTATE",
                               brokervar="BrokerCrossProduct", Carriervar="Carrier")
   def groupby4(x):
      d={}
      d["TotalGroups"] = x["STATE_EIN"].nunique()
      d["Pct_100_200"] = x[x['Size_Band'] == '100-200']['EIN_FTE'].sum() / x["EIN_FTE"].sum()
      d["Pct_200_500"] = x[x['Size_Band'] == '200-500']['EIN_FTE'].sum() / x["EIN_FTE"].sum()
      d["Pct_100_500"] = x[x['Size_Band'] == '100-500']['EIN_FTE'].sum() / x["EIN_FTE"].sum()
      d["Pct_500_1000"] = x[x['Size_Band'] == '500-1000']['EIN_FTE'].sum() / x["EIN_FTE"].sum()
      d["Pct_1000_5000"] = x[x['Size_Band'] == '1000-5000']['EIN_FTE'].sum() / x["EIN_FTE"].sum()

      d["Lives_100_200"] = x[x['Size_Band'] == '100-200']['EIN_FTE'].sum()
      d["Lives_200_500"] = x[x['Size_Band'] == '200-500']['EIN_FTE'].sum()
      d["Lives_100_500"] = x[x['Size_Band'] == '100-500']['EIN_FTE'].sum()
      d["Lives_500_1000"] = x[x['Size_Band'] == '500-1000']['EIN_FTE'].sum()
      d["Lives_1000_5000"] = x[x['Size_Band'] == '1000-5000']['EIN_FTE'].sum()

      d["PropConsolidate"] = x["AvgCarrierWallet"].mean()
      d["PropConsolidateProd"] = x["AvgCarrierWalletProduct"].mean()
      d["PropMedicalBundle"] = x["AvgMedicalCarrierGBWallet"].mean()
      d["PropMedicalBundleProd"] = x["AvgMedicalCarrierGBProduct"].mean()
      d["PctDDLBundle"] = x["DDLBundle"].sum() / np.maximum(1, x["DDLReported"].sum())
      d["MetLifeCoverage"] = x["IsClient"].mean()
      d["MetLifeShareofWallet"] = x[x['IsClient'] == 1]['ClientShareOfWallet'].mean()
      d["MetLifeShareofWalletProd"] = x[x['IsClient'] == 1]['ClientShareOfWalletProduct'].mean()
      d["GroupsVBLegal"] = x["OfferVBLegal"].mean()
      d["TotalHealthGroupOver1000"] = ((x['Size_Band'] == '1000-5000') & (x['Industry'] == 'Health Care and Social Assistance')).any().sum()
      return pd.Series(d, index=["AvgCarrierWallet", "AvgCarrierWalletProduct", "AvgMedicalCarrierGBWallet", "AvgMedicalCarrierGBProduct",
                                 "IsClient", "ClientShareOfWallet", "ClientShareOfWalletProduct","ViDDLBundlesion", "DDLReported"])
   broker_metrics = EIN_base.groupby(byvars2).apply(groupby4)
   broker_metrics["MetLifeShareofWallet"].fillna(None)
   broker_metrics["MetLifeShareofWalletProd"].fillna(None)

   return broker_metrics



def broker_metrics_prod_pit(dt, client="Metlife", broker_num, multiyearBaseOppPIT=False,
                                   byvars=["Region","Broker_State", "SalesOffice","Broker","product"]):


   corebyvar = ["Region", "Broker_State", "SalesOffice", "Broker", "product"]
  if multiyearBaseOppPIT:
    corebyvar = ["Region", "Broker_State", "SalesOffice", "Broker", "year"]


   dt = EditBrokerCarrier(dt=dt , LONGITUDINA=False, EDIT_BROKER=True, 
                          broker_num=broker_num, state_var="Broker_State",
                          brokervar="Broker", Carriervar="Carrier")
   def groupby1(x):
      d={}
      d["EstProd_Prem"] = x["EstProd_Prem_Carrier"].sum()
      d["EstProd_PremReported"] = x[x['Carrier'] != 'Not Provided']['EstProd_Prem_Carrier'].sum()
      d["EstProd_Grps_Reported"] = np.where(x['Carrier'] != 'Not Provided', 1, 0).sum()
      d["DummyASOUnder1KPrem"] = x[(x['Carrier'] != 'Not Provided')
                                   & (x['Funding'] == 'SI')
                                   & (x['EIN_FTE'] < 1000)]['EstProd_Prem_Carrier'].sum()
      d["DummyASOUnder1KGroup"] = np.where((x['Carrier'] != 'Not Provided')
                                   & (x['Funding'] == 'SI')
                                   & (x['EIN_FTE'] < 1000), 1, 0).sum()
      d["EstProd_Prem_Client"] = x[x['Carrier'] == client]['EstProd_Prem_Carrier'].sum()
      d["IsClient"] = np.where(x['Carrier'] == client, 1, 0).max()
      d["BundwMed"] = np.where((x['Carrier'] == client)
                               | (x['Carrier'] == Medical_Car2), 1, 0).max()
      d["FI_Members"] = x[x['Funding'] == 'FI']['Memb'].sum()
      d["SI_Members"] = x[x['Funding'] == 'SI']['Memb'].sum()
      return pd.Series(d, index=["EstProd_Prem", "EstProd_PremReported", "EstProd_Grps_Reported", "DummyASOUnder1KPrem",
                                 "EstProd_Prem_Client", "IsClient", "BundwMed", "FI_Members", "SI_Members"])

   EIN_prod = dt.groupby(corebyvar + ["Size_Band","STATE_EIN"]).apply(groupby1)

   def groupby2(x):
      d={}
      d["TotalBrokerOpportunity"] = x["EstProd_Prem"].sum()
      d["EstProd_Prem_Client"] = x["EstProd_Prem_Client"].sum()
      d["EstProd_Prem_Reported"] = x["EstProd_Prem_Client"].sum()
      d["EstProd_Grps_Reported"] = x["EstProd_Grps_Reported"].sum()
      d["DummyASOUnder1KPrem"] = x["DummyASOUnder1KPrem"].sum()
      d["DummyASOUnder1KGroup"] = x["DummyASOUnder1KGroup"].sum()
      d["TotalGroups"] = x["STATE_EIN"].len()
      d["ClientGroups_Reported"] = x["IsClient"].sum()
      d["BundwMed"] = x["BundwMed"].mean()
      d["FI_Penetration"] = 1 - x["SI_Memb"].sum()/np.maximum(([1] * len(x), x["SI_Memb"] + x["FI_Memb"]), axis=0)
      return pd.Series(d, index=["TotalBrokerOpportunity", "EstProd_Prem_Client", "EstProd_Prem_Reported", "EstProd_Grps_Reported",
                                 "DummyASOUnder1KPrem", "DummyASOUnder1KGroup", "TotalGroups", "ClientGroups_Reported", "BundwMed", "FI_Penetration"])
   broker_metrics_product = EIN_prod.groupby(byvars + ["Size_Band","STATE_EIN"]).apply(groupby2)
   broker_metrics_product["MetLifepenetration_prem_raw"] = broker_metrics_product["EstProd_Prem_Client"]/np.maximum(([1] * len(broker_metrics_product),broker_metrics_product["EstProd_Prem_Reported"]), axis=0)
   broker_metrics_product["EstimatedMetBook_K"] = broker_metrics_product["EstProd_Prem_Client"] + 
                                                  broker_metrics_product["MetLifepenetration_prem_raw"] *
                                                  (broker_metrics_product["TotalBrokerOpportunity"] - broker_metrics_product["EstProd_Prem_Reported"] - broker_metrics_product["DummyASOUnder1KPrem"])
   broker_metrics_product["MetLifepenetration_grps_raw"] = broker_metrics_product["EstProd_Prem_Client"]/np.maximum(([1] * len(broker_metrics_product),broker_metrics_product["EstProd_Prem_Reported"]),axis=0) 
   broker_metrics_product["ClientGroups"] = broker_metrics_product["ClientGroups_Reported"] + 
                                            broker_metrics_product["MetLifepenetration_grps_raw"] *
                                            (broker_metrics_product["TotalGroups"] - broker_metrics_product["EstProd_Grps_Reported"] - broker_metrics_product["DummyASOUnder1KGroup"])                                              
   keepvars = byvars + ["TotalBrokerOpportunity","EstimatedMetBook_K","TotalGroups","ClientGroups", "BundwMed","FI_Penetration"]             
   broker_metrics_product = broker_metrics_product[keepvars]
   return broker_metrics_product


def broker_metrics_overall_met(client_metrics):

   def groupby2(x):
      d={}
      d["AvgQuotes"] = x["AvgQuotes"].sum()
      d["AvgSoldCvg"] = x["AvgSoldCvg"].sum()
      d["ClosingRatio"] = x["AvgSoldCvg"].sum() / np.maximum((1, x["AvgQuotes"].sum()), axis=0)
      d["Churn"] = x["PRST_TRM_PREM_AMT"].sum() / np.maximum((1, x["PRST_PREM_BASE_AMT"].sum()), axis=0)
      d["TotChurnPrem"] = x["PRST_TRM_PREM_AMT"].sum()
      d["TotBasePrem"] = x["PRST_PREM_BASE_AMT"].sum()
      return pd.Series(d, index=["AvgQuotes", "AvgSoldCvg", "ClosingRatio", "Churn",
                                 "TotChurnPrem", "TotBasePrem"])
   CM = client_metrics.groupby(["BRKR_FIRM_ST_CD","SalesOffice","Broker"]).apply(groupby2)
   CM["ClosingRatio"] = CM["ClosingRatio"].apply(lambda x: 1 if x > 1 else x)
   CM["Churn"] = CM["Churn"].apply(lambda x: 1 if x > 1 else x)

   return CM


def broker_metrics_prod_met(client_metrics, PubPct,broker_num, byvar = metvar, suffix_met = suffix):

   statevar = (if suffix_met == "","BRKR_FIRM_ST_CD","Region")
   client_metrics =  EditBrokerCarrier(dt =client_metrics, LONGITUDINAL = F,EDIT_BROKER=T,
                                      broker_num = broker_num,brokervar = "Broker",
                                      state_var = statevar)
   Quotes = client_metrics.groupby((set(metvar) - set(["SUBSEGMENT" , "BROKER_NAME_GRIP"])) + ["Broker"]).agg({"AvgQuotes": "sum"})
   Quotes_Accident = Quotes[Quotes["CVR_GRP_SCOR_CARD_CD" == "AH"]]
   Quotes_Accident["CVR_GRP_SCOR_CARD_CD"] = Quotes_Accident["CVR_GRP_SCOR_CARD_CD"].apply(lambda x: if "AH" in x then x.replace("AH","Accident") else x)
   Quotes_Hospital = Quotes[Quotes["CVR_GRP_SCOR_CARD_CD"] == "AH"]
   Quotes_Hospital["CVR_GRP_SCOR_CARD_CD"] = Quotes_Hospital["CVR_GRP_SCOR_CARD_CD"].apply(lambda x: if "AH" in x then x.replace("AH","Accident") else x)
   Quotes = Quotes[Quotes["CVR_GRP_SCOR_CARD_CD"] != "AH"].append(Quotes_Accident, ignore_index=True)
   Quotes = Quotes.append(Quotes_Hospital)
   Quotes["AvgQuotesNonPub"] = Quotes["AvgQuotes"] * (1- Quotes["PubPct"])
   Quotes.drop(['AvgQuotes'], inplace=True, axis=1)
   return Quotes


def broker_metrics_prod_prospect(ProspectByProd, namingmatching_margin = 0.2, broker_num = broker_num, byvars = prosepctvar):

   ProspectByProd["ASObelow1K"] = ProspectByProd.apply(lambda x: 1 if (x["Funding"] != "FI" & x["EIN_FTE"] < 1000) else 0)
   ProspectByProd  = EditBrokerCarrier(dt =  ProspectByProd , LONGITUDINAL = F,EDIT_BROKER=T, 
                                       broker_num = broker_num, state_var = ifelse("Broker_State_Product" %in% prosepctvar,"Broker_State_Product","Region"),#"Broker_State_Product",
                                       brokervar = "Broker_Product", Carriervar = "Carrier")
   def groupby2(x):
      d={}
      d["ASObelow1K"] = x["ASObelow1K"].max()
      d["LeaveScore"] = x["LeaveScore"].mean()
      d["ConvertScore"] = x["ConvertScore"].mean()
      d["GroupQuoted"] = x["GroupQuoted"].max()
      return pd.Series(d, index=["ASObelow1K", "LeaveScore", "ConvertScore", "GroupQuoted"])
   EIN_prod = ProspectByProd.groupby(byvars + ["State_HQ","EIN"]).apply(groupby2)


   def groupby3(x):
      d={}
      d["LeaveScore"] = x["LeaveScore"].mean()
      d["ConvertScore"] = x["ConvertScore"].mean()
      d["Groups"] = x["LeaveScore"].count()
      d["MetQuoted"] = np.minimum(round(x["GroupQuoted"].sum()*(1+x["namingmatching_margin"])),x["LeaveScore"].count())
      d["UnQuotedASOBelow1K"] = ((1-x["GroupQuoted"])*x["ASObelow1K"]).sum()
      return pd.Series(d, index=["ASObelow1K", "LeaveScore", "ConvertScore", "GroupQuoted"])
   broker_prospect_product = EIN_prod.groupby(byvars ).apply(groupby3)

   broker_prospect_product = broker_prospect_product.merge(met_finance_asmp["Product", "RenewFreq"], how='inner',left_on=["product"], right_on=["Product"])
   broker_prospect_product["NetNewProductUpforBid"] = np.maximum([0]*len(broker_prospect_product), ((broker_prospect_product["Groups"]- broker_prospect_product["MetQuoted"]- broker_prospect_product["MetQuoted-UnQuotedASOBelow1K"])/broker_prospect_product["RenewFreq"]))
   broker_prospect_product["NetNewProductUpforBid"] = round(broker_prospect_product["NetNewProductUpforBid"])
   broker_prospect_product = broker_prospect_product[keepvars]
   return broker_prospect_product


def broker_prioritization_matrix(broker_metrics,client_metrics):

   broker_metrics["BrokerOpportunityScore"] = broker_metrics["ProspectBrokerOpportunity_K"]/1000 + broker_metrics["inFlowPremEst"]/1000
   broker_metrics = broker_metrics.join(broker_metrics.groupby(["BrokPrimarySTATE"])["LeaveScore"].mean().rename({"LeaveScore": "StateLeaveBM"}), "BrokPrimarySTATE")
   broker_metrics = broker_metrics.join(broker_metrics.groupby(["BrokPrimarySTATE"])["ConvertScore"].mean().rename({"ConvertScore": "StateConvertBM"}), "BrokPrimarySTATE")
   broker_metrics["StateLeaveBM"].fillna(5)
   broker_metrics["StateConvertBM"].fillna(5)
   broker_metrics["LeaveIndex"] = broker_metrics["LeaveScore"] / broker_metrics["StateLeaveBM"]
   broker_metrics["ConvertIndex"] = broker_metrics["ConvertScore"] / broker_metrics["StateConvertBM"]
   broker_metrics["BrokerOpportunityScore"] = broker_metrics["BrokerOpportunityScore"] +
                                              broker_metrics["LeaveIndex"] +
                                              broker_metrics["ConvertIndex"]
   broker_metrics["BrokerOpportunityScore"] = broker_metrics.apply(lambda x:"NA" if x["BrokPrimary"] == "Other" else x["BrokerOpportunityScore"])


   def groupby3(x):
      d={}
      d["BrokerOpportunityScoreUpperBound"] = x["BrokerOpportunityScore"].mean() + 2.5 + x["BrokerOpportunityScore"].std()
      return pd.Series(d)
   BrokerOpportunityScoreUpperBound_val = broker_metrics.groupby(["BrokPrimarySTATE"]).apply(groupby3)
   broker_metrics = broker_metrics.join(BrokerOpportunityScoreUpperBound_val, "BrokPrimarySTATE")
   broker_metrics["BrokerOpportunityScore"] = broker_metrics.apply(lambda x: x["BrokerOpportunityScoreUpperBound"] if x["BrokerOpportunityScore"] > x["BrokerOpportunityScoreUpperBound"] else x["BrokerOpportunityScore"])


   CM = broker_metrics_overall_met(client_metrics = client_metrics)
   broker_metrics = broker_metrics.merge(CM, how='left', left_on = ["BrokPrimarySTATE" ,"SalesOfficePrimary" ,"BrokPrimary"],
                                         right_on = ["BRKR_FIRM_ST_CD","SalesOffice","Broker"])
   

   def groupby4(x):
      d={}
      d["StateClosingRatio"] = x["AvgSoldCvg"].sum() / x["AvgQuotes"].sum()
      return pd.Series(d)
   StateClosingRatio_val = broker_metrics.groupby(["BrokPrimarySTATE"]).apply(groupby4)
   broker_metrics = broker_metrics.join(StateClosingRatio_val, "BrokPrimarySTATE")


   def groupby5(x):
      d={}
      d["StateChurnRate"] = x["TotChurnPrem"].sum() / x["TotBasePrem"].sum()
      return pd.Series(d)
   StateChurnRate_val = broker_metrics.groupby(["BrokPrimarySTATE"]).apply(groupby5 )
   broker_metrics = broker_metrics.join(StateChurnRate_val, "BrokPrimarySTATE")
   broker_metrics["StateClosingRatio"].fillna(0)
   broker_metrics["StateChurnRate"].fillna(0)
   broker_metrics["ClosingRatio"].fillna(broker_metrics["StateClosingRatio"]) 
   broker_metrics["Churn"].fillna(broker_metrics["StateChurnRate"]) 
   broker_metrics["BrokerComplexityScore"] = broker_metrics["Pct_1000_5000"] +
                                             (broker_metrics["Churn"] - broker_metrics["StateChurnRate"]) +
                                             (1 - broker_metrics["PctQuoted"]) +
                                             (broker_metrics["StateClosingRatio"]-broker_metrics["ClosingRatio"])
   broker_metrics[broker_metrics["TotalGroups"] < 5]["BrokerComplexityScore"] = broker_metrics["BrokerComplexityScore"].median()
   return broker_metrics


def Broker_aggregate_all(dt,client = "Metlife",current_year = 2017, 
                         client_metrics =  clientdata,
                         ProspectByProd = ProspectByProd,
                         ProspectByEIN = ProspectByEIN,
                         brokerlong = brokerlong, 
                         BS,
                         CoreProducts = c("Medical","Dental","Life", "LTD","STD","Vision"),
                         allprods = c("Medical","Dental","Life", "LTD","STD","Vision","CI", "Accident","Hospital","Legal"),
                         EDIT_BROKER=T, broker_num = 50,
                         PubPct = 0.1,  outdir = paste0(met_export_dir,""),
                         overallbyvar = overallbyvar,
                         prodbyvar = prodbyvar):
   broker_metrics =  broker_metrics_overall_pit(dt = dt[year==current_year],
                                                client = "Metlife", broker_num = broker_num, byvars2 = overallbyvar)
   broker_metrics_prod = broker_metrics_prod_pit(dt = dt[year==current_year],
                                                 broker_num=broker_num,
                                                 byvars = prodbyvar)
   def groupby1(x):
      d={}
      d["ProspectBrokerOpportunity_K"] = x["TotalBrokerOpportunity"].sum() - x["EstimatedMetBook_K"].sum()
      d["TotalBrokerOpportunity"] = x["TotalBrokerOpportunity"].sum()
      d["EstimatedMetBook_K"] = x["EstimatedMetBook_K"].sum()

      return pd.Series(d, index=["ProspectBrokerOpportunity_K", "TotalBrokerOpportunity", "EstimatedMetBook_K"])
   broker_opportunity = broker_metrics_prod.groupby(list(set(prodbyvar) - list(set(["product"])))).apply(groupby1)
   broker_metrics = broker_metrics.merge(broker_opportunity, how='left', left_on = overallbyvar,
                                         right_on = list(set(prodbyvar) - list(set(["product"]))))
   broker_metrics = broker_metrics[broker_metrics["BrokPrimary"] != "Child Health Corp"]
   broker_metrics["ProspectBrokerOpportunity_K"].fillna(0)
   broker_metrics["OtherIND"] = broker_metrics.apply(lambda x: 1 if x["BrokPrimary"] =="Other" else 0)
   broker_metrics = broker_metrics.sort_values(by=["RegionPrimary", "OtherIND", "ProspectBrokerOpportunity_K"], ascending=[True, True, False]).reset_index(drop=true)
   #need change in below step
   broker_metrics[,Rank := seq_along(ProspectBrokerOpportunity_K), by = setdiff(overallbyvar,"BrokPrimary")]
 
   broker_metrics.drop(["OtherIND"], axis=1)
   broker_metrics["MetLifePenetrationAllProd"] =broker_metrics["EstimatedMetBook_K"] / broker_metrics["TotalBrokerOpportunity"]
   

   def groupby2(x):
      d={}
      d["MetLifeStatePenetrationAllProd"] = x["EstimatedMetBook_K"].sum() / x["TotalBrokerOpportunity"].sum()
      return pd.Series(d, index=["MetLifeStatePenetrationAllProd"])
   table1 = broker_metrics.groupby(list(set(overallbyvar) - list(set(["SalesOfficePrimary","BrokPrimary"])))).apply(groupby2)
   broker_metrics = broker_metrics.merge(table1, how='left', on=list(set(overallbyvar) - list(set(["SalesOfficePrimary","BrokPrimary"]))) )

   brokerBaseOppPIT = broker_metrics_prod_pit(dt = dt[dt["year"] in range(2014,2017+1)],broker_num=broker_num,
                                             byvars = list(set(prodbyvar + year) - list(set(["product"]))))
   yearweight = brokerBaseOppPIT["year"]
   yearweight = yearweight.sort_values(by=["year"], ascending=True).reset_index(drop=True)
   yearweight["Weight"] = yearweight["year"].rank()
   yearweight["sumWeight"] = yearweight["Weight"].sum()
   yearweight["Weight"] = yearweight["Weight"] / yearweight["sumWeight"]
   yearweight = yearweight.drop(["sumWeight"], axis=1)
   brokerBaseOppPIT = brokerBaseOppPIT.merge(yearweight, how="left", on="year")
   def groupby3(x):
      d={}
      d["BaseAvgBrokOpp"] = (x["TotalBrokerOpportunity"] + x["Weight"]).sum()
      return pd.Series(d, index=["MetLifeStatePenetrationAllProd"])
   brokerBaseOppPITAvg = brokerBaseOppPIT.groupby(list(set(prodbyvar) - list(set(["product"])))).apply(groupby3)  
   brokerflow = brokerFlowsProductAgnostic(brokerlong = brokerlong, 
                                           RM = T, years= range(2014,2017+1),
                                           broker_num = broker_num,
                                           byvars = overallbyvar)

   brokerBaseOppPITAvg = brokerBaseOppPITAvg.merge(brokerflow[overallbyvar+["inFlowRtMemb","outFlowRtMemb"]], how="left",
                                                   left_on=list(set(prodbyvar) - list(set(["product"]))),
                                                   right_on=overallbyvar)
   brokerBaseOppPITAvg["inFlowRtMemb"].fillna(0)
   brokerBaseOppPITAvg["outFlowRtMemb"].fillna(0)
   brokerBaseOppPITAvg["inFlowPremEst"] = brokerBaseOppPITAvg["BaseAvgBrokOpp"] * brokerBaseOppPITAvg["inFlowRtMemb"]
   brokerBaseOppPITAvg["outFlowPremEst"] = brokerBaseOppPITAvg["BaseAvgBrokOpp"] * brokerBaseOppPITAvg["outFlowRtMemb"]
   broker_metrics = broker_metrics.merge(brokerBaseOppPITAvg[list(set(prodbyvar) - list(set(["product"]))) + ["inFlowPremEst","outFlowPremEst"]]
                                         how="left",
                                         left_on=overallbyvar,
                                         right_on=list(set(prodbyvar) - list(set(["product"]))))
   ProspectByEIN = EditBrokerCarrier(dt =   ProspectByEIN, LONGITUDINAL = F,EDIT_BROKER=T, 
                                    broker_num = broker_num, state_var = if "BrokPrimarySTATE" in overallbyvar + ["BrokPrimarySTATE", "RegionPrimary"],
                                    brokervar = "BrokPrimary")


   def groupby4(x):
      d={}
      d["LeaveScore"] = x["LeaveScore"].mean()
      d["ConvertScore"] = x["ConvertScore"].mean()
      return pd.Series(d, index=["LeaveScore", "ConvertScore"])
   prospect_likehood = ProspectByEIN.groupby(overallbyvar).apply(groupby4)
   broker_metrics = broker_metrics.merge(prospect_likehood, how="left",
                         left_on=overallbyvar,
                         right_on=overallbyvar)
   NewProspect = broker_metrics_prod_prospect(ProspectByProd = ProspectByProd,
                                              namingmatching_margin = 0.2,
                                              broker_num = broker_num,
                                              byvars = prosepctvar)
   NewProspect = NewProspect.groupby(list(set(prosepctvar) - list(set(["product"])))).agg({"NetNewProductUpforBid": "sum"}).reset_index()
   broker_metrics = broker_metrics.merge(NewProspect, how="left",
                                         left_on=overallbyvar,
                                         right_on=list(set(prosepctvar) - list(set(["product"]))))
   broker_metrics["NetNewProductUpforBid"].fillna(0)
   NonPubQuotes = broker_metrics_prod_met(client_metrics = client_metrics,broker_num=broker_num, PubPct = 0.1, byvar = metvar).agg({"AvgQuotesNonPub": "sum"}).reset_index()
   NonPubQuotes = NonPubQuotes.groupby(list(set(metvar + ["SUBSEGMENT" , "CVR_GRP_SCOR_CARD_CD","BROKER_NAME_GRIP"]) - list(set(["Broker"]))))
   broker_metrics = broker_metrics.merge(NonPubQuotes, how="left",
                                         left_on=overallbyvar,
                                         right_on=list(set(metvar + ["SUBSEGMENT" , "CVR_GRP_SCOR_CARD_CD","BROKER_NAME_GRIP"]) - list(set(["Broker"]))))
   broker_metrics["AvgQuotesNonPub"].fillna(0)
   broker_metrics["PctQuoted"] = broker_metrics["AvgQuotesNonPub"] / np.maximum([0]*len(broker_metrics, broker_metrics["NetNewProductUpforBid"] + broker_metrics["AvgQuotesNonPub"]))


   if("SalesOfficePrimary" in overallbyvar):
      BS =  BS.groupby(["Region","Office","BROKER_NAME"])["OverallScore"].mean().rename({"OverallScore": "OverallSatisfactionScore"})
      broker_metrics = broker_metrics.merge(BS, how="left",
                                            left_on=["RegionPrimary","SalesOfficePrimary","BrokPrimary"],
                                            right_on=["Region","Office","BROKER_NAME"])
   else:
      BS =  BS.groupby(["Region","BROKER_NAME"])["OverallScore"].mean().rename({"OverallScore": "OverallSatisfactionScore"})
      broker_metrics = broker_metrics.merge(BS, how="left",
                                            left_on=["RegionPrimary","BrokPrimary"],
                                            right_on=["Region","BROKER_NAME"])
   if("RegionPrimary" in broker_metrics.columns):
      broker_metrics.rename({"RegionPrimary": "Region"})
   if("BrokPrimarySTATE" in broker_metrics.columns):
      broker_metrics.rename({"BrokPrimarySTATE": "State"})
   if("SalesOfficePrimary" in broker_metrics.columns):
      broker_metrics.rename({"SalesOfficePrimary": "SalesOffice"})
   if("BrokPrimary" in broker_metrics.columns):
      broker_metrics.rename({"BrokPrimary": "Broker"})

   if (set(sizebands) - set(["100-500","500-1000","1000-5000"])):
      dashboardmetrics1 = ["Region","State","SalesOffice", "Broker","ProspectBrokerOpportunity_K",   
                           "TotalGroups" ,"Pct_100_500", "Pct_500_1000" , "Pct_1000_5000" ,
                           "Lives_100_500" ,"Lives_500_1000"  ,"Lives_1000_5000" ,
                           "PropConsolidate" ,   "PropMedicalBundle" ,  "PctDDLBundle" ,      
                           "MetLifeCoverage", "MetLifeShareofWallet" ,   "TotalHealthGroupOver1000" , 
                           "inFlowPremEst","outFlowPremEst","LeaveScore","ConvertScore",
                           "PctQuoted","BrokerOpportunityScore","BrokerComplexityScore","OverallSatisfactionScore",
                           "MetLifePenetrationAllProd","MetLifeStatePenetrationAllProd"]
   if (set(sizebands) - set(["100-200"])):
      dashboardmetrics1 = ["Region","State","SalesOffice", "Broker","ProspectBrokerOpportunity_K",   
                           "TotalGroups" ,"Pct_100_200",
                           "Lives_100_200",
                           "PropConsolidate" ,   "PropMedicalBundle" ,  "PctDDLBundle" ,      
                           "MetLifeCoverage", "MetLifeShareofWallet" ,   "TotalHealthGroupOver1000" , 
                           "inFlowPremEst","outFlowPremEst","LeaveScore","ConvertScore",
                           "PctQuoted","BrokerOpportunityScore","BrokerComplexityScore","OverallSatisfactionScore",
                           "MetLifePenetrationAllProd","MetLifeStatePenetrationAllProd"]

   broker_metrics[broker_metrics.columns in dashboardmetrics1].to_excel(os.path.join(outdir,"/BrokerMetrics_allGB.xlsx"))
   broker_metrics[broker_metrics.columns in dashboardmetrics1].to_excel(os.path.join(outdir,"/archive/","BrokerMetrics_allGB.xlsx"))
   return broker_metrics


def Broker_aggregate_prod(dt = dt,client = "Metlife",current_year = 2017,
                          client_metrics =  clientdata,
                          ProspectByProd = ProspectByProd, 
                          CoreProducts = ["Medical","Dental","Life", "LTD","STD","Vision"],
                          allprods = ["Medical","Dental","Life", "LTD","STD","Vision","CI", "Accident","Hospital","Legal"],
                          EDIT_BROKER=T, EDIT_CARRIER=T, carrier_num=10, broker_num = 50,
                          PubPct = 0.1,  outdir = met_export_dir,
                          overallbyvar = overallbyvar,prodbyvar = prodbyvar):
   dt = dt[dt["year"] == current_year]
   broker_metrics_prod = broker_metrics_prod_pit(dt = dt, broker_num = broker_num,byvars = prodbyvar)
   prospect_agg = broker_metrics_prod_prospect(ProspectByProd = ProspectByProd,
                                               namingmatching_margin = 0.2,
                                               broker_num = broker_num,
                                               byvars = prosepctvar)
   broker_metrics_prod = broker_metrics_prod.merge(prospect_agg, how="left",
                                                   left_on=prodbyvar,
                                                   right_on=prosepctvar)
   broker_metrics_prod["LeaveScore"].fillna(NA)
   broker_metrics_prod["ConvertScore"].fillna(NA)
   broker_metrics_prod["NetNewProductUpforBid"].fillna(0)
   Quotes = broker_metrics_prod_met(client_metrics = client_metrics,broker_num=broker_num, PubPct = 0.1, byvar = metvar)
   broker_metrics_prod = broker_metrics_prod.merge(Quotes, how="left",
                                                   left_on=prodbyvar,
                                                   right_on=list(set(metvar) - list(set( ["SUBSEGMENT" , "CVR_GRP_SCOR_CARD_CD","BROKER_NAME_GRIP"]))) + ["Broker", "CVR_GRP_SCOR_CARD_CD"])
   broker_metrics_prod["AvgQuotesNonPub"].fillna(0)
   broker_metrics_prod = broker_metrics_prod[broker_metrics_prod["Broker"] != "Child Health Corp"]


   def groupby1(x):
      d={}
      d["MetLifePenetrationAllProd"] = x["EstimatedMetBook_K"].sum() / x["TotalBrokerOpportunity"]
      return pd.Series(d, index=["MetLifePenetrationAllProd"])


   table1 = broker_metrics_prod.groupby(list(set(prodbyvar) - list(set( ["product"])))).apply(groupby1)
   broker_metrics_prod = broker_metrics_prod.merge(table1, how="left", on=(list(set(prodbyvar) - list(set( ["product"])))))
  
   def groupby2(x):
      d={}
      d["MetLifeStatePenetrationAllProd"] = x["EstimatedMetBook_K"].sum() / x["TotalBrokerOpportunity"]
      return pd.Series(d, index=["MetLifePenetrationAllProd"])


   table2 = broker_metrics_prod.groupby(if "Broker_State" in prodbyvar:  "Broker_State" else "Region").apply(groupby2)
   broker_metrics_prod = broker_metrics_prod.merge(table2, how="left", on=(if "Broker_State" in prodbyvar:  "Broker_State" else "Region"))
  
   if("Broker_State" in broker_metrics_prod.columns):
      broker_metrics_prod.rename({"Broker_State": "State"})

   dashboardmetrics2 = ["Region","State","SalesOffice", "Broker","product", "TotalBrokerOpportunity", "EstimatedMetBook_K",
                        "TotalGroups","ClientGroups", "BundwMed", "NetNewProductUpforBid","AvgQuotesNonPub","FI_Penetration",  "LeaveScore" ,"ConvertScore",
                        "MetLifePenetrationAllProd","MetLifeStatePenetrationAllProd"]
   broker_metrics_prod[broker_metrics_prod.columns in dashboardmetrics2].to_excel(os.path.join(outdir,"/BrokerMetrics_product.xlsx"))
   broker_metrics_prod[broker_metrics_prod.columns in dashboardmetrics2].to_excel(os.path.join(outdir,"/archive/", "BrokerMetrics_product.xlsx"))
   return broker_metrics_prod

