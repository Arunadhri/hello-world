import pandas as pd
import numpy as np
from met_helper_function_share import met_add_market
from top_broker_carrier_per_state import EditBrokerCarrier

def brokerFlowsProductAgnostic(brokerlong, years= list(range(2014:2018)),
							   broker_num = 50, RM = False, byvars = overallbyvar):
	dt = brokerlong[brokerlong['Base_Yr'].isin([i-1 for i in years])]
	dt = dt.rename(columns={'St1_Post': 'State'})
    dt  = met_add_market(dt, zipvar="Zip1_Post", outputvar="SalesOfficePrimary",
                         Statevar="State", outputvarRegion="RegionPrimary")
 
    dt['SalesOfficePrimary'].fillna('', inplace=True)
    dt['RegionPrimary'].fillna('', inplace=True)

    if RM == True:
    	dt = dt[dt['EIN_FTE'] <= 5000]
    dt = dt[~(dt['Br1_Base'].isna()) & ~(dt['Br1_Post'].isna())]
    dt = EditBrokerCarrier(dt=dt, BROKERFLOW=True, EDIT_BROKER=True,
    					   EDIT_CARRIER=False, broker_num=broker_num)

    yearweight = pd.DataFrame(data=dt['Base_Yr'].unique(), columns='Base_Yr')
    yearweight = yearweight.sort_values()
    yearweight['Weight'] = list(range(1, len(yearweight)+1))
    yearweight['sumWeight'] = yearweight['Weight'].sum()
    yearweight['Weight'] = yearweight['Weight'] / yearweight['sumWeight']
    yearweight = yearweight.drop('sumWeight', axis=1)
    dt = dt.merge(dt, yearweight, how='left', on='Base_Yr')

    dt = dt.rename(columns={'State': 'BrokPrimarySTATE'})
    sub = dt.copy()
    sub = sub.rename(columns={'State': 'BrokPrimary'})
    sub['EOYWeight'] = sub['EOY'] * sub['Weight']
    base = sub.groupby(byvars).agg({'Weight': 'sum', 'EOYWeight': 'sum',
    	    						'Part_EOY': 'count'})\
    	   .rename(columns={'Weight': 'Cases', 'EOYWeight': 'Part',
    	   	'Part_EOY': 'CasesOrig'}).reset_index()\
           .round({'Cases': 0})
    sub = sub.rename(columns={'Br1_Post': 'BrokPrimary'})

    post = sub.groupby(byvars).agg({'Weight': 'sum', 'EOYWeight': 'sum',
    	    						'Part_EOY': 'count'})\
    	   .rename(columns={'Weight': 'Cases', 'EOYWeight': 'Part',
    	   	'Part_EOY': 'CasesOrig'}).reset_index()\
           .round({'Cases': 0})
    sub = sub.drop('EOYWeight', axis=1)
    baseDt = base.append(post)
    def groupby_func(data):
    	d={}
    	d['Cases'] = round((data['Cases']/2).sum())
    	d['Part'] = round((data['Part']/2).sum())
    	d['CasesOrig'] = round((data['CasesOrig']/2).sum())
    	return pd.Series(d)
    baseDt = baseDt.groupby(byvars).apply(groupby_func)
    baseDt = baseDt[~baseDt['BrokPrimary'].isin(['Other', ''])]

    flows = dt[(dt['Br1_Post'] != dt['Br1_Base']) &
    		   (dt['Br1_Base'] != 'Other') &
    		   (dt['Br1_Post'] != 'Other')]

    inFlows = flows.copy()
    inFlows = inFlows.rename(columns={'Br1_Post': 'BrokPrimary'})
    inflows['EOYWeight'] = inFlows['Part_EOY'] * inFlows['Weight']
    inflows = inFlows.groupby(byvars).agg({'Weight': 'sum', 'EOYWeight': 'sum'})\
    		  .rename(columns={'Weight': 'inCases', 'EOYWeight': 'inMembers'}).reset_index()
    inFlows = inFlows.drop('EOYWeight', axis=1)
    outFlows = inFlows.copy()
    outFlows = outFlows.rename(columns={'Br1_Base': 'BrokPrimary'})
    outFlows['EOYWeight'] = outFlows['Part_EOY'] * outFlows['Weight']
    outFlows = outFlows.groupby(byvars).agg({'Weight': 'sum', 'EOYWeight': 'sum'})\
    		  .rename(columns={'Weight': 'outCases', 'EOYWeight': 'outMembers'}).reset_index()
    outFlows = outFlows.drop('EOYWeight', axis=1)
    flows = inFlows.merge(outFlows, on=byvars, how='outer')
    flows.fillna(0, inplace=True)
    flows = flows.merge(baseDt, on=byvars, how='outer')
    flows.fillna(0, inplace=True)

    flows['inFlowRtGrp'] = np.min([[1] * len(flows), round(flows['inCases'] /
    	np.max([[1] * len(flows), flows['Cases']]), 3)], axis=0)
    flows['inFlowRtMemb'] = np.min([[1] * len(flows), round(flows['inMembers'] /
    	np.max([[1] * len(flows), flows['Part']]), 3)], axis=0)
    flows['outFlowRtGrp'] = np.min([[1] * len(flows), round(flows['outCases'] /
    	np.max([[1] * len(flows), flows['Cases']]), 3)], axis=0)
    flows['outFlowRtMemb'] = np.min([[1] * len(flows), round(flows['outMembers'] /
    	np.max([[1] * len(flows), flows['Part']]), 3)], axis=0)

    columns_to_get = byvars + ["Cases", "CasesOrig", "Part", "outFlowRtGrp",
    						   "outFlowRtMemb", "inFlowRtGrp", "inFlowRtMemb",
    						   "inCases", "inMembers", "outCases", "outMembers"]
    if 'BrokPrimarySTATE' in flows.columns:
    	#########################################################################################################
    	flows= flows[(flows['CasesOrig'] > 4) & (flows['BrokPrimarySTATE'].isin(state.abb))][columns_to_get]
    else:
    	flows = flows[flows['CasesOrig'] > 4][columns_to_get]

    threshold = np.mean([np.quantile(flows['outFlowRtGrp'], q=0.99),
    					 np.quantile(flows['inFlowRtGrp'], q=0.99),
    					 np.quantile(flows['outFlowRtMemb'], q=0.99),
    					 np.quantile(flows['inFlowRtMemb'], q=0.99)])
    print('\nCap flow rate at: ', threshold)
    flows['inFlowRtMemb'] = np.where(flows['inFlowRtMemb'] > threshold,
    								 threshold, flows['inFlowRtMemb'])
    flows['outFlowRtMemb'] = np.where(flows['outFlowRtMemb'] > threshold,
    								 threshold, flows['outFlowRtMemb'])
    return flows
