import sys

def met_add_field(dt, RM=True,
                         size_cut=[500,1000,5000],
                         allprods=["Medical", "Dental", "Life", "LTD", "STD", "Vision", "CI", "Accident", "Hospital", "Legal"],
                         mod="met_add_field"):

    beginvar = list(dt.columns)
    beginobs = len(dt)
    
    dt = dt.merge(zip_st_mapping, left_on='Broker_Zip', right_on='Zip', how='left')
    dt['ST'] = dt['ST'].fillna('')
    dt['FL'] = np.where((dt['Broker_State'] != dt['ST']) & (dt['Broker_State'] != '') & (dt['ST'] != ''), 1, 0)
    dt['Broker_State'] = np.where(dt['FL'] == 1, dt['ST'], dt['Broker_State'])
    dt = dt.drop(['ST', 'FL'], axis=1)

    dt = dt.merge(zip_st_mapping, left_on='BrokerCrossProductZIP', right_on='Zip', how='left')
    dt['ST'] = dt['ST'].fillna('')
    dt['FL'] = np.where((dt['BrokerCrossProductSTATE'] != dt['ST']) & (dt['BrokerCrossProductSTATE'] != '') & (dt['ST'] != ''), 1, 0)
    dt['BrokerCrossProductSTATE'] = np.where(dt['FL'] == 1, dt['ST'], dt['BrokerCrossProductSTATE'])
    dt = dt.drop(['ST'], axis=1)

    dt['STATE_EIN'] = dt['STATE_EIN'].astype(str) + dt['EIN'].astype(str)
    dt = dt.sort_values(['STATE_EIN', 'year', 'product', 'Members', 'Carrier'], ascending=[True, True, True, False, True])
    dt['CarrierIND'] = customer.groupby(["STATE_EIN","year","product"])['Carrier'].cumcount(1).add(1)
    map_ = dt[dt['product'] == 'Medical'][['STATE_EIN', 'Carrier', 'CarrierIND', 'year', 'PN', "Members"]]
    map_['CT'] = dt.groupby(["STATE_EIN","CarrierIND","year"])['Members'].count()
    for i in range(1, 3):
        sub = map_[map_['CarrierIND'] == i]
        sub = sub.drop('CarrierIND', axis=1)
        carVar = 'Medical_Car' + str(i)
        sub = sub.rename(columns={'Carrier': carVar})
        dt = dt.merge(sub[['STATE_EIN', 'year', carVar]], on=['STATE_EIN', 'year'], how='left')
        del(sub)
        dt[carVar] = dt[carVar].fillna('')
    dt = dt[dt['product'] != 'Medical']
    dt = dt.merge(met_finance_asmp[['Product', 'PMPM', 'RenewFreq']], left_on='product', right_on='Product', how='inner')
    dt['EstProd_Prem_Carrier'] = 12 * dt['Members'] * dt['PMPM'] / 1000
    dt = add_size_band(dt=dt, size_cut=size_cut)
    if RM:
        dt =dt[dt['Size_Band'] != '5000+']
        for p in allprods:
            t1 = dt[(dt['Carrier'] == 'Metlife') & (dt['product'] == p)]['EstProd_Prem_Carrier'].sum()
            t2 = dt[(dt['Carrier'] == 'Not Provided') & (dt['product'] == p)]['EstProd_Prem_Carrier'].sum()
            ms = t1/t2

    dt = met_add_market(dt, zipvar="Broker_Zip", outputvar="SalesOffice", Statevar="Broker_State",
                      outputvarRegion="Region", brokervar="Broker")
    dt[['SalesOffice', 'Region']] = dt[['SalesOffice', 'Region']].fillna('')
    dt = met_add_market(dt, zipvar="BrokerCrossProductZIP", outputvar="SalesOfficePrimary",
                      outputvarRegion="RegionPrimary", Statevar="BrokerCrossProductSTATE", brokervar="BrokerCrossProduct")
    dt[['SalesOfficePrimary', 'RegionPrimary']] = dt[['SalesOfficePrimary', 'RegionPrimary']].fillna('')
    na = df.isnull().any().any().sum()
    if na > 0:
        print(mod, 'has NAs')
        sys.exit()
    byvars = ["year","STATE_EIN","PN","Carrier","product","Funding"]
    dt['CT'] = dt.groupby(byvars)['Members'].count()
    if dt[dt['CT'] > 1]['CT'].sum() > 0:
        print('not unique at ', byvars)
        sys.exit()
    return dt