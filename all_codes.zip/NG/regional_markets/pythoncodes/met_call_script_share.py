import pandas as pd
import os
import numpy as np


YG=T
SI = F


if(YG):
	box_base = "C:/Users/Ying Guo/Box Sync/"
if(SI):
	box_base = "C:/Users/Sumedha Iramani/Box Sync/"
#Shared File Path
box_base = "//ns-sisci01/APP_11469_GAIN_Analytics/DataSharing_MetLife - Granularity of Growth/Scaleup Phase/Data/"

broker_number = 50
the_current_year = 2017
carrier_number = 10

#parameters
Abhishek = F
RegionalView = T
DefaultBrokerDashboard = F

if(Abhishek):
  size_cut = [200,500,1000,5000]
  sizebands = ["100-200"]
  overallbyvar = ["RegionPrimary","BrokPrimarySTATE","SalesOfficePrimary","BrokPrimary"]
  prodbyvar = ["Region","Broker_State", "SalesOffice","Broker","product"]
  metvar = ["Region" ,"BRKR_FIRM_ST_CD" ,"SalesOffice" ,"SUBSEGMENT" , "CVR_GRP_SCOR_CARD_CD","BROKER_NAME_GRIP"]
  prosepctvar = ["Region","Broker_State_Product","SalesOffice","Broker_Product","product"]
  suffix = "_100_200"


if(RegionalView):
  size_cut = [500,1000,5000]
  sizebands = ["100-500","500-1000","1000-5000"]
  overallbyvar = ["RegionPrimary","BrokPrimary"]
  prodbyvar = ["Region","Broker","product"]
  metvar = ["Region" ,"SUBSEGMENT", "CVR_GRP_SCOR_CARD_CD","BROKER_NAME_GRIP"]
  prosepctvar = ["Region","Broker_Product","product"]
  suffix = "_regional"
 

if(DefaultBrokerDashboard){
  size_cut = [500,1000,5000]
  sizebands = ["100-500","500-1000","1000-5000"]
  overallbyvar = ["RegionPrimary","BrokPrimarySTATE","SalesOfficePrimary","BrokPrimary"]
  prodbyvar = ["Region","Broker_State", "SalesOffice","Broker","product"]
  metvar = ["Region" ,"BRKR_FIRM_ST_CD" ,"SalesOffice" ,"SUBSEGMENT" , "CVR_GRP_SCOR_CARD_CD","BROKER_NAME_GRIP"]
  prosepctvar = ["Region","Broker_State_Product","SalesOffice","Broker_Product","product"]
  suffix = ""
}


from met_config_share import *


def Met_metrics():
  Persistency_Calc(sizecut = size_cut, suffix = suffix, metvar = metvar)
  Profitabilty_Calc(sizecut = size_cut, suffix = suffix, metvar = metvar)
  Closing_ratio_calc(sizecut = size_cut, suffix = suffix, metvar = metvar)
  met_combine()
  clientdata = pd.read_pickle(os.path.join(met_datawd,"/Met_Metrics",suffix,".pkl"))

  # View(unique(clientdata[,c("Region" ,"BRKR_FIRM_ST_CD","SalesOffice")]))
  
Met_metrics()

group_product_carrier_ally = pd.read_pickle(os.path.join(final_wd, "/EINXProdXCarrier_mapped.pkl"))
groupdt = met_add_field(dt = group_product_carrier_ally, size_cut = size_cut)


clientdata = pd.read_pickle(os.path.join(met_datawd,"/Met_Metrics",suffix,".pkl"))
BrokerScore = pd.read_excel(os.path.join(met_datawd,"/BrokerSatisfactionScore.xlsx"))
ProspectByProd = pd.read_pickle(os.path.join(met_export_dir, "/ProspectlistProduct.pkl"))
ProspectByEIN = pd.read_pickle(os.path.join(met_export_dir, "/ProspectlistGroup.pkl"))
brokerlongdata = pd.read_pickle(os.path.join(datawd, "/brokerLongitudinal_clean_190604.pkl"))


groupdt_broker = groupdt[groupdt["Size_Band"] in sizebands]

ProspectByProd = add_size_band(ProspectByProd, size_cut = size_cut)
ProspectByEIN = add_size_band(ProspectByEIN, size_cut = size_cut)
brokerlongdata = add_size_band(brokerlongdata, size_cut = size_cut)

ProspectByProd2 = ProspectByProd[ProspectByProd["Size_Band"] in sizebands ]
ProspectByEIN2 = ProspectByEIN[ProspectByEIN["Size_Band"] in sizebands ]
client_metrics2 = clientdata[clientdata["SUBSEGMENT"] in sizebands ]
brokerlong2 = brokerlongdata[brokerlongdata["Size_Band"] in sizebands ]

BrokerDB = Broker_aggregate_all(dt =  groupdt_broker , 
                                ProspectByProd = ProspectByProd2 ,
                                ProspectByEIN = ProspectByEIN2,
                                client_metrics = client_metrics2,  
                                brokerlong = brokerlong2,
                                BS =  copy(BrokerScore),
                                current_year = the_current_year, broker_num = broker_number, 
                                outdir = met_export_dir,
                                overallbyvar = overallbyvar,
                                prodbyvar = prodbyvar)

# generate product-specific broker dashboard 
BrokerDBprod = Broker_aggregate_prod(dt =groupdt, 
                                     #prospect = copy(prospectlist) ,
                                     ProspectByProd = ProspectByProd2 ,
                                     client_metrics= client_metrics2,  
                                     current_year = the_current_year,
                                     carrier_num = carrier_number, broker_num = broker_number, 
                                     outdir = met_export_dir,
                                     overallbyvar = overallbyvar,
                                     prodbyvar = prodbyvar)

dt =  groupdt[groupdt["year"] == 2017]
dt = dt[dt["Size_Band"] in sizebands ]
IndustryDistribution = BrokerbyIndustry(dt = dt, byvars2 = overallbyvar)
IndustryDistribution.to_excel(os.path.join(datawd,"broker_byindustry",suffix,".xlsx"))
# Address & Zip
BrokerAddr = BrokerByAddr(dt = groupdt)



# broker by carrier
groupdt2 = groupdt.copy()
groupdt2["product"] = ("AH" if groupdt2["product"] in ["Accident","Hospital"] else groupdt2["product"])
groupdt2 = groupdt2[groupdt2["Size_Band"] in sizebands]
groupdt2 =  groupdt2[groupdt2["year"] == 2017]
Broker_Carrier_Prod = State_Carrier_aggregation(dt = groupdt2,broker_num = 50, 
                                                carrier_num = 15,limitStateToScope = T,
                                                CoreORALL = "All",EDIT_CARRIER = F, 
                                                byvars = prodbyvar)

if("Broker_State" in byvars):
  Broker_Carrier_Prod = Broker_Carrier_Prod.sort_order(by=["Broker_State","Broker","SalesOffice","product","CarrierPenetration_prem"], ascending=[True, True, True, True, False]).reset_index(drop=True)
  Broker_Carrier_Prod[,Rank:= seq_along(CarrierPenetration_prem), by = c("Broker_State","Broker","SalesOffice","product")]
  Broker_Carrier_Prod = Broker_Carrier_Prod[Broker_Carrier_Prod["Rank"] <= 5 |Broker_Carrier_Prod["CarrierPenetration_prem"] >= 0.01]
  Broker_Carrier_Prod = Broker_Carrier_Prod[Broker_Carrier_Prod["SalesOffice"] != "" & Broker_Carrier_Prod["Broker"] != "Other"]["Region","Broker_State","Broker","SalesOffice","product","Carrier","CarrierPenetration_prem","CarrierPenetration_grps","Rank"]
  setnames(Broker_Carrier_Prod.rename({"Broker_State": "State"})
else:
  Broker_Carrier_Prod = Broker_Carrier_Prod.sort_order(by=["Region","product","CarrierPenetration_prem"], ascending=[True, True, False]).reset_index(drop=True)
  Broker_Carrier_Prod[,Rank:= seq_along(CarrierPenetration_prem), by = c("Region","Broker","product")]
  Broker_Carrier_Prod = Broker_Carrier_Prod[Broker_Carrier_Prod["Rank"] <= 5 |Broker_Carrier_Prod["CarrierPenetration_prem"] >= 0.01]
  Broker_Carrier_Prod = Broker_Carrier_Prod[Broker_Carrier_Prod["Broker"] != "Other"]["Region","Broker","product","Carrier","CarrierPenetration_prem","CarrierPenetration_grps","Rank"]

groupdt3 =  groupdt2.copy()
groupdt3 =  groupdt3[groupdt3["year"] == 2017]
# create aggregation table to State Migration tab
State_Car_PIT = State_Carrier_aggregation(dt = groupdt3, carrier_num = 8,EDIT_CARRIER = T, byvars = ["year","Broker_State","product"])

dt = pd.read_pickle(os.path.join(final_wd, "EINXProdXCarrier_mapped.pkl"))

dt["STATE_EIN"] = dt["State_HQ"] + dt["EIN"]

#Carrier agnostic
Baseproduct = "Dental"
bundles = BundlingTrend(dt = dt, Baseproduct = Baseproduct , byvars = "year")
bundles.to_excel(os.path.join(datawd, "bundlingtrend_w",Baseproduct,"All.xlsx"))

#By Carrier
bundles = BundlingTrend(dt = dt,Baseproduct = Baseproduct, byvars = ["Carrier","year"])
bundles.to_excel(os.path.join(datawd, "bundlingtrend_w",Baseproduct,"CarrierByYear.xlsx"))

#By Carrier by State
bundles = BundlingTrend(dt = dt,Baseproduct = Baseproduct, byvars = ["State_HQ","Carrier","year"])
bundles.to_excel(os.path.join(datawd, "bundlingtrend_w",Baseproduct,"CarrierByYearByState.xlsx"))