def CarrierFlowsByProduct(brokState="All", carrier_num, lob, USE_BROKER_STATE, years, 
                          Target="Metlife", BrkSTvar, byvars):
	mod = 'CarrierFlows for ' + lob
	dt = globals()['long_trans_'+lob.lower()]
	dt = dt[dt['DROPDES'] == 0]

	if USE_BROKER_STATE:
		dt['State'] = BrkSTvar
	dt['Region'] = globals()['RegionPrimary']
	dt = dt[(dt['Carrier_Base'] != '') & (dt['Carrier_Post'] != '')]
	dt = EditBrokerCarrier(dt=dt, LONGITUDINAL=True, EDIT_BROKER=False, EDIT_CARRIER=True,
		lob=lob, carrier_num=carrier_num, Carriervar='Carrier', client=Target)

	dt = dt[dt['Base_Yr'].isin([i-1 for i in years])]
	yearweight = pd.DataFrame(sorted(dt['Base_Yr'].unique()), columns=['Base_Yr'])
	yearweight['Weight'] = list(range(1, len(yearweight)+1))
	yearweight['sumWeight'] = yearweight['Weight'].sum()
    yearweight['Weight'] = yearweight['Weight'] / yearweight['sumWeight']
    yearweight = yearweight.drop('sumWeight', axis=1)
    dt = dt.merge(dt, yearweight, how='left', on='Base_Yr')

    sub = dt.copy()
    sub = sub.rename(columns={'Carrier_Base': 'Carrier'})
    sub['MembersBase'] = sub['Members_Base'] * sub['Weight']
    base = sub.groupby(byvars).agg({'Weight': 'sum', 'MembersBase': 'sum'}).rename(
    	columns={'Weight': 'GroupsBase'}).reset_index().round({'GroupsBase': 0})
    sub = sub.rename(columns={'Carrier_Post': 'Carrier'})
    post = sub.groupby(byvars).agg({'Weight': 'sum', 'MembersBase': 'sum'}).rename(
    	columns={'Weight': 'GroupsBase'}).reset_index().round({'GroupsBase': 0})
    sub = sub.drop('MembersBase', axis=1)

    baseDt = base.append(post)
	baseDt = baseDt.groupby(byvars).agg({'GroupsBase': 'sum', 'MembersBase': 'sum'}).reset_index()
	baseDt['GroupsBase'] = round(baseDt['GroupsBase']/2)
	baseDt['MembersBase'] = round(baseDt['MembersBase']/2)
	baseDt = baseDt[(baseDt['Carrier'] != 'Other') & (baseDt['Carrier'] != '')]

	flows = dt[dt['Carrier_Post'] != dt['Carrier_Base']]
	inFlows = flows.copy()
	inFlows = inFlows.rename(columns={'Carrier_Post': 'Carrier'})
	inFlows['inMembers'] = inFlows['Members_Post'] * inFlows['Weight']
	inFlows['inGroupsTarget'] = np.where(inFlows['Carrier_Base'] == inFlows['Target'], inFlows['Weight'], 0)
	inFlows['inMembersTarget'] = np.where(inFlows['Carrier_Base'] == inFlows['Target'], inFlows['inMembers'], 0)
	inFlows = inFlows.groupby(byvars).agg({'Weight': 'sum',
										   'inMembers': 'sum',
										   'inGroupsTarget': 'sum',
										   'inMembersTarget': 'sum'}).rename(columns={'Weight': 'inGroups'}).reset_index()
	outFlows = flows.copy()
	outFlows = outFlows.rename(columns={'Carrier_Base': 'Carrier'})
	outFlows['outMembers'] = outFlows['Members_Base'] * outFlows['Weight']
	outFlows['outGroupsTarget'] = np.where(outFlows['Carrier_Post'] == outFlows['Target'], outFlows['Weight'], 0)
	outFlows['outMembersTarget'] = np.where(outFlows['Carrier_Post'] == outFlows['Target'], outFlows['inMembers'], 0)
	outFlows = outFlows.groupby(byvars).agg({'Weight': 'sum',
										   'outMembers': 'sum',
										   'outGroupsTarget': 'sum',
										   'outMembersTarget': 'sum'}).rename(columns={'Weight': 'outGroups'}).reset_index()

	flows = inFlows.merge(outFlows, on=byvars, how='outer')
	flows = flows.fillna(0)
	flows = flows.merge(baseDt, on=byvars, how='outer')
	flows = flows.fillna(0)
	flows = flows[(flows['Carrier'] != 'Other') & (flows['Carrier'] != '')]

	flows['inFlowRtGrp'] = round(flows['inGroups'] /
    	np.max([[1] * len(flows), flows['GroupsBase']]), 3)

    flows['inFlowRtMemb'] = round(flows['inMembers'] /
    	np.max([[1] * len(flows), flows['MembersBase']]), 3)

    flows['inFlowRtGrpTarget'] = round(flows['inGroupsTarget'] /
    	np.max([[1] * len(flows), flows['GroupsBase']]), 3)

    flows['inFlowRtMembTarget'] = round(flows['inMembersTarget'] /
    	np.max([[1] * len(flows), flows['MembersBase']]), 3)

    flows['outFlowRtGrp'] = round(flows['outGroups'] /
    	np.max([[1] * len(flows), flows['GroupsBase']]), 3)

    flows['outFlowRtMemb'] = round(flows['outMembers'] /
    	np.max([[1] * len(flows), flows['MembersBase']]), 3)

    flows['outFlowRtGrpTarget'] = round(flows['outGroupsTarget'] /
    	np.max([[1] * len(flows), flows['GroupsBase']]), 3)

    flows['outFlowRtMembTarget'] = round(flows['outMembersTarget'] /
    	np.max([[1] * len(flows), flows['MembersBase']]), 3)

    columns_to_get = byvars + ["outFlowRtGrp","outFlowRtMemb","inFlowRtGrp", "inFlowRtMemb",
                    "outFlowRtGrpTarget","outFlowRtMembTarget","inFlowRtGrpTarget", "inFlowRtMembTarget"]

    outDt = flows[columns_to_get]
    if brokState != 'All':
    	outDt = outDt[outDt['State'].isin(brokState)]
    return outDt
