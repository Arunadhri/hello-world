from bs4 import BeautifulSoup
import pandas as pd

soup = BeautifulSoup(open('Funnel_540/ROUND_LOSS.xml').read(),'xml')

d={}
names_type = pd.DataFrame()
for i in soup.findAll('DataField'):
    d['name'] = i['name']
    d['optype'] = i['optype']
    names_type = names_type.append(d,ignore_index=True)

d={}
param_name_value = pd.DataFrame()
for i in soup.findAll('PPCell'):
    d['parameterName'] = i['parameterName']
    d['name'] = i['predictorName']
    d['value'] = i['value']
    param_name_value = param_name_value.append(d,ignore_index=True)

d={}
beta_param = pd.DataFrame()
for i in soup.findAll('PCell'):
    d['beta'] = float(i['beta'])
    d['df'] = i['df']
    d['parameterName'] = i['parameterName']
    beta_param = beta_param.append(d,ignore_index=True)

beta_val = beta_param.merge(param_name_value.merge(names_type,how='left',on='name'),how='left',on='parameterName')
beta_val.loc[beta_val['parameterName'] == 'P0000001', 'name'] = 'INTERCEPT'
beta_val = beta_val[['name','value','optype','beta']].drop_duplicates()
beta_val.to_pickle('Funnel_540/beta.pkl')