def convert_spss_conditional_to_python(conditional_string,new_column,df_name,super_node):
    #All arguments are strings
    return conditional_string.strip().replace('elseif ','    elif x["')\
.replace('if  ','def f_'+super_node+'_'+new_column+'(x):\n\tif x["')\
.replace(' = ','"] == ').replace(' >= ','"] >= ').replace(' > ','"] > ')\
.replace(' < ','"] < ').replace(' <= ','"] <= ').replace(' then ',':\n\t\treturn ')\
.replace('else ','\telse:\n\t\treturn None\n'+df_name+'["'+new_column+'"] = '+df_name+'\
.apply(f_'+super_node+'_'+new_column+',axis=1)').replace('and ','and x["').replace(' endif','').replace('\t','    ')

#Example case:
#String to convert
#there should be 2 spaces after the first if
#whatever is returned after else is given at the end. so neet to copy that
#does not work for nested statements directly
a = '''if  NOPRA = 0 then -1
elseif PORAL50 >= 100 then 100
elseif PORAL50 >= 66.66 then 67
elseif PORAL50 >= 40 then 40
elseif PORAL50 >= 25 then 25
elseif PORAL50 >= 15 then 15
elseif PORAL50 >= 1 then 1
elseif PORAL50 > 0   then 0
elseif PORAL50 = 0 then 0
else undef endif'''

#Function to call
print(convert_spss_conditional_to_python(a,'RLEV_FACT_U2','df','u2_factors'))

# Will return
def f_u2_factors_RLEV_FACT_U2(x):
    if x["NOPRA"] == 0:
        return -1
    elif x["PORAL50"] >= 100:
        return 100
    elif x["PORAL50"] >= 66.66:
        return 67
    elif x["PORAL50"] >= 40:
        return 40
    elif x["PORAL50"] >= 25:
        return 25
    elif x["PORAL50"] >= 15:
        return 15
    elif x["PORAL50"] >= 1:
        return 1
    elif x["PORAL50"] > 0  :
        return 0
    elif x["PORAL50"] == 0:
        return 0
    else:
        return None
df["RLEV_FACT_U2"] = df.apply(f_u2_factors_RLEV_FACT_U2,axis=1)undef

#######################################################################################################
#Function2
a='''
if RPCT_A > RPCT_A then 1 else 0 endif +
if RPCT_A > RPCT_B then 1 else 0 endif +
if RPCT_A > RPCT_C then 1 else 0 endif +
if RPCT_A > RPCT_F then 1 else 0 endif +
if RPCT_A > RPCT_G then 1 else 0 endif +
if RPCT_A > RPCT_H then 1 else 0 endif +
if RPCT_A > RPCT_K then 1 else 0 endif +
if RPCT_A > RPCT_M then 1 else 0 endif +
if RPCT_A > RPCT_U then 1 else 0 endif +
if RPCT_A > RPCT_2 then 1 else 0 endif +
if RPCT_A > RPCT_3 then 1 else 0 endif +
if RPCT_A > RPCT_5 then 1 else 0 endif +
if RPCT_A > RPCT_7 then 1 else 0 endif +
if RPCT_A > RPCT_8 then 1 else 0 endif + 1
'''

super_node = 'rank_reasons'
new_column='RRA'
df_name = 'df'
def convert_spss_plus_python(convert_string,new_column,df_name,super_node):
    return 'def f_'+super_node+'_'+new_column+'(x):\n\ta=0\n'+convert_string.strip().replace(' endif +','')\
      .replace(' then ','"]:\n\t\ta+=').replace(' else ','\n\telse:\n\t\ta+=')\
     .replace('if ','if x["').replace(' > ','"] > x["').replace('if x','\tif x')\
      +'\n\treturn a+='\
      +'\n'+df_name+'["'+new_column+'"] = '+df_name+'.apply(f_'+super_node+'_'+new_column+',axis=1)'\
      .replace('\t','    ')
print(convert_spss_plus_python(a,new_column,df_name,super_node))

#returns
def f_rank_reasons_RRA(x):
    a=0
    if x["RPCT_A"] > x["RPCT_A"]:
        a+=1
    else:
        a+=0
    if x["RPCT_A"] > x["RPCT_B"]:
        a+=1
    else:
        a+=0
    if x["RPCT_A"] > x["RPCT_C"]:
        a+=1
    else:
        a+=0
    if x["RPCT_A"] > x["RPCT_F"]:
        a+=1
    else:
        a+=0
    if x["RPCT_A"] > x["RPCT_G"]:
        a+=1
    else:
        a+=0
    if x["RPCT_A"] > x["RPCT_H"]:
        a+=1
    else:
        a+=0
    if x["RPCT_A"] > x["RPCT_K"]:
        a+=1
    else:
        a+=0
    if x["RPCT_A"] > x["RPCT_M"]:
        a+=1
    else:
        a+=0
    if x["RPCT_A"] > x["RPCT_U"]:
        a+=1
    else:
        a+=0
    if x["RPCT_A"] > x["RPCT_2"]:
        a+=1
    else:
        a+=0
    if x["RPCT_A"] > x["RPCT_3"]:
        a+=1
    else:
        a+=0
    if x["RPCT_A"] > x["RPCT_5"]:
        a+=1
    else:
        a+=0
    if x["RPCT_A"] > x["RPCT_7"]:
        a+=1
    else:
        a+=0
    if x["RPCT_A"] > x["RPCT_8"]:
        a+=1
    else:
        a+=0 1
    return a+=
df["RRA"] = df.apply(f_rank_reasons_RRA,axis=1)

#######################################################################################################
#Function3
a='''
PFMU_SCORE >= 10 and PFMU_SCORE < 92    "BD"
PFMU_SCORE >= 92 and PFMU_SCORE < 123   "BH"
PFMU_SCORE >= 123 and PFMU_SCORE < 141  "BL"
PFMU_SCORE >= 141 and PFMU_SCORE < 155  "BP"
PFMU_SCORE >= 155 and PFMU_SCORE < 169  "BT"
PFMU_SCORE >= 169 and PFMU_SCORE < 180  "BW"
PFMU_SCORE >= 180 and PFMU_SCORE < 191  "CD"
PFMU_SCORE >= 191 and PFMU_SCORE < 202  "CH"
PFMU_SCORE >= 202 and PFMU_SCORE < 212  "CL"
PFMU_SCORE >= 212 and PFMU_SCORE < 220  "CP"
PFMU_SCORE >= 220 and PFMU_SCORE < 230  "CT"
PFMU_SCORE >= 230 and PFMU_SCORE < 239  "CW"
PFMU_SCORE >= 239 and PFMU_SCORE < 242  "DD"
PFMU_SCORE >= 242 and PFMU_SCORE < 249  "DG"
PFMU_SCORE >= 249 and PFMU_SCORE < 258  "DJ"
PFMU_SCORE >= 258 and PFMU_SCORE < 267  "DN"
PFMU_SCORE >= 267 and PFMU_SCORE < 276  "DQ"
PFMU_SCORE >= 276 and PFMU_SCORE < 287  "DT"
PFMU_SCORE >= 287 and PFMU_SCORE < 297  "DW"
PFMU_SCORE >= 297 and PFMU_SCORE < 306  "ED"
PFMU_SCORE >= 306 and PFMU_SCORE < 317  "EG"
PFMU_SCORE >= 317 and PFMU_SCORE < 329  "EJ"
PFMU_SCORE >= 329 and PFMU_SCORE < 343  "EN"
PFMU_SCORE >= 343 and PFMU_SCORE < 357  "EQ"
PFMU_SCORE >= 357 and PFMU_SCORE < 370  "ET"
PFMU_SCORE >= 370 and PFMU_SCORE < 376  "EW"
PFMU_SCORE >= 376 and PFMU_SCORE < 392  "FD"
PFMU_SCORE >= 392 and PFMU_SCORE < 415  "FG"
PFMU_SCORE >= 415 and PFMU_SCORE < 440  "FJ"
PFMU_SCORE >= 440 and PFMU_SCORE < 456  "FN"
PFMU_SCORE >= 456 and PFMU_SCORE < 479  "FQ"
PFMU_SCORE >= 479 and PFMU_SCORE < 502  "FT"
PFMU_SCORE >= 502 and PFMU_SCORE < 528  "FW"
PFMU_SCORE >= 528 and PFMU_SCORE < 569  "GD"
PFMU_SCORE >= 569 and PFMU_SCORE < 592  "GH"
PFMU_SCORE >= 592 and PFMU_SCORE < 612  "GL"
PFMU_SCORE >= 612 and PFMU_SCORE < 644  "GP"
PFMU_SCORE >= 644 and PFMU_SCORE < 674  "GT"
PFMU_SCORE >= 674 and PFMU_SCORE < 706  "HD"
PFMU_SCORE >= 706 and PFMU_SCORE < 729  "HH"
PFMU_SCORE >= 729 and PFMU_SCORE < 795  "HL"
PFMU_SCORE >= 795 and PFMU_SCORE < 831  "HP"
PFMU_SCORE >= 831 and PFMU_SCORE < 943  "HT"
PFMU_SCORE >= 943 and PFMU_SCORE <= 999 "HW"
'''

def convert_spss_ordinal_python(convert_string,new_column,df_name,super_node):
    convert_string = 'if x["' + a.strip()
    convert_string = convert_string.replace('\n','\nif x["').replace('\t',':\n\treturn ')\
    .replace(' <','"] <').replace('and ','and x["').replace(' >','"] >')
    convert_string = 'def f_'+super_node+'_'+new_column+'(x):\n\t\n'+convert_string
    convert_string = convert_string.replace('\n','\n\t')\
    +'\n'+df_name+'["'+new_column+'"] = '+df_name+'.apply(f_'+super_node+'_'+new_column+',axis=1)'
    return convert_string
print(convert_spss_ordinal_python(a,new_column,df_name,super_node))

#returns
def f_rank_reasons_RRA(x):
        
    if x["PFMU_SCORE"] >= 10 and x["PFMU_SCORE"] < 92:
        return "BD"
    if x["PFMU_SCORE"] >= 92 and x["PFMU_SCORE"] < 123:
        return "BH"
    if x["PFMU_SCORE"] >= 123 and x["PFMU_SCORE"] < 141:
        return "BL"
    if x["PFMU_SCORE"] >= 141 and x["PFMU_SCORE"] < 155:
        return "BP"
    if x["PFMU_SCORE"] >= 155 and x["PFMU_SCORE"] < 169:
        return "BT"
    if x["PFMU_SCORE"] >= 169 and x["PFMU_SCORE"] < 180:
        return "BW"
    if x["PFMU_SCORE"] >= 180 and x["PFMU_SCORE"] < 191:
        return "CD"
    if x["PFMU_SCORE"] >= 191 and x["PFMU_SCORE"] < 202:
        return "CH"
    if x["PFMU_SCORE"] >= 202 and x["PFMU_SCORE"] < 212:
        return "CL"
    if x["PFMU_SCORE"] >= 212 and x["PFMU_SCORE"] < 220:
        return "CP"
    if x["PFMU_SCORE"] >= 220 and x["PFMU_SCORE"] < 230:
        return "CT"
    if x["PFMU_SCORE"] >= 230 and x["PFMU_SCORE"] < 239:
        return "CW"
    if x["PFMU_SCORE"] >= 239 and x["PFMU_SCORE"] < 242:
        return "DD"
    if x["PFMU_SCORE"] >= 242 and x["PFMU_SCORE"] < 249:
        return "DG"
    if x["PFMU_SCORE"] >= 249 and x["PFMU_SCORE"] < 258:
        return "DJ"
    if x["PFMU_SCORE"] >= 258 and x["PFMU_SCORE"] < 267:
        return "DN"
    if x["PFMU_SCORE"] >= 267 and x["PFMU_SCORE"] < 276:
        return "DQ"
    if x["PFMU_SCORE"] >= 276 and x["PFMU_SCORE"] < 287:
        return "DT"
    if x["PFMU_SCORE"] >= 287 and x["PFMU_SCORE"] < 297:
        return "DW"
    if x["PFMU_SCORE"] >= 297 and x["PFMU_SCORE"] < 306:
        return "ED"
    if x["PFMU_SCORE"] >= 306 and x["PFMU_SCORE"] < 317:
        return "EG"
    if x["PFMU_SCORE"] >= 317 and x["PFMU_SCORE"] < 329:
        return "EJ"
    if x["PFMU_SCORE"] >= 329 and x["PFMU_SCORE"] < 343:
        return "EN"
    if x["PFMU_SCORE"] >= 343 and x["PFMU_SCORE"] < 357:
        return "EQ"
    if x["PFMU_SCORE"] >= 357 and x["PFMU_SCORE"] < 370:
        return "ET"
    if x["PFMU_SCORE"] >= 370 and x["PFMU_SCORE"] < 376:
        return "EW"
    if x["PFMU_SCORE"] >= 376 and x["PFMU_SCORE"] < 392:
        return "FD"
    if x["PFMU_SCORE"] >= 392 and x["PFMU_SCORE"] < 415:
        return "FG"
    if x["PFMU_SCORE"] >= 415 and x["PFMU_SCORE"] < 440:
        return "FJ"
    if x["PFMU_SCORE"] >= 440 and x["PFMU_SCORE"] < 456:
        return "FN"
    if x["PFMU_SCORE"] >= 456 and x["PFMU_SCORE"] < 479:
        return "FQ"
    if x["PFMU_SCORE"] >= 479 and x["PFMU_SCORE"] < 502:
        return "FT"
    if x["PFMU_SCORE"] >= 502 and x["PFMU_SCORE"] < 528:
        return "FW"
    if x["PFMU_SCORE"] >= 528 and x["PFMU_SCORE"] < 569:
        return "GD"
    if x["PFMU_SCORE"] >= 569 and x["PFMU_SCORE"] < 592:
        return "GH"
    if x["PFMU_SCORE"] >= 592 and x["PFMU_SCORE"] < 612:
        return "GL"
    if x["PFMU_SCORE"] >= 612 and x["PFMU_SCORE"] < 644:
        return "GP"
    if x["PFMU_SCORE"] >= 644 and x["PFMU_SCORE"] < 674:
        return "GT"
    if x["PFMU_SCORE"] >= 674 and x["PFMU_SCORE"] < 706:
        return "HD"
    if x["PFMU_SCORE"] >= 706 and x["PFMU_SCORE"] < 729:
        return "HH"
    if x["PFMU_SCORE"] >= 729 and x["PFMU_SCORE"] < 795:
        return "HL"
    if x["PFMU_SCORE"] >= 795 and x["PFMU_SCORE"] < 831:
        return "HP"
    if x["PFMU_SCORE"] >= 831 and x["PFMU_SCORE"] < 943:
        return "HT"
    if x["PFMU_SCORE"] >= 943 and x["PFMU_SCORE"] <= 999:
        return "HW"
df["RRA"] = df.apply(f_rank_reasons_RRA,axis=1)