import modeler.api

class AllNodeFilter(modeler.api.NodeFilter):
    """A node filter for all nodes."""

    def __init__(this, typename):
        this._typename = typename
	
    def accept(this, node):
        return node.getTypeName() == this._typename

stream = modeler.script.stream()
allFilter = AllNodeFilter("variablefile")#database, databaseexport, outputfile, table
allnodes = stream.findAll(allFilter, True)
print(allnodes)

allFilter = AllNodeFilter("outputfile")#database, databaseexport, outputfile, table
allnodes = stream.findAll(allFilter, True)
print(allnodes)

allFilter = AllNodeFilter("database")#database, databaseexport, outputfile, table
allnodes = stream.findAll(allFilter, True)
for i in list(allnodes):
    print(i.getPropertyValue("tablename"))

print('\n')

allFilter = AllNodeFilter("databaseexport")#database, databaseexport, outputfile, table
allnodes = stream.findAll(allFilter, True)
for i in list(allnodes):
    print(i.getPropertyValue("tablename"))