def f_variable_creation(df):
    condition1 = (df['Disability Date'] - df['Prognosis Date']).dt.days >= 1500
    condition2 = (df['Disability Date'] - df['Prognosis Date']).dt.days <= 0
    df.loc[(condition1 | condition2), 'Prognosis Date'] = None

    df['Diagnosis Type'] = 'Other'
    condition1 = df['Primary ICD Major Diagnosis Category Description'] ==\
        'NORMAL PREGNANCY & DELIVERY'
    condition2 = df['Primary ICD Major Diagnosis Category Description'] ==\
        'COMPLICATIONS OF PREGNANCY'
    df.loc[(condition1 | condition2), 'Diagnosis Type'] = 'Pregnancy'

    condition1 = df['Primary ICD Major Diagnosis Category Description'] ==\
        'NON-PSYCHOTIC MENTAL DISORDERS'
    condition2 = df['Primary ICD Major Diagnosis Category Description'] ==\
        'PSYCHOSES'
    df.loc[(condition1 | condition2), 'Diagnosis Type'] = 'Behavioral'

    df['Prognosis < 30'] = 0
    df['Prognosis < 15'] = 0
    df['Prognosis < 10'] = 0
    condition1 = (df['Disability Date'] - df['Prognosis Date']).dt.days <= 30
    df.loc[condition1, 'Prognosis < 30'] = 1
    condition1 = (df['Disability Date'] - df['Prognosis Date']).dt.days <= 15
    df.loc[condition1, 'Prognosis < 15'] = 1
    condition1 = (df['Disability Date'] - df['Prognosis Date']).dt.days <= 10
    df.loc[condition1, 'Prognosis < 10'] = 1

    df['Simple Surgery'] = 'Other Surgery'
    condition1 = df['CPT4_PROC1 Code'].str.strip() == ''
    condition2 = df['CPT4_PROC1 Code'].isnull()
    df.loc[(condition1 | condition2), 'Simple Surgery'] = 'No Surgery'
    condition1 = df['CPT4 Proc 1 Description'].str.contains('ECTOMY')
    condition2 = df['CPT4 Proc 1 Description'].str.contains('SCOPY')
    df.loc[(condition1 | condition2), 'Simple Surgery'] = 'Simple Surgery'

    df['Self-Reported'] = 0
    df.loc[df['CSTM_MDC_SORT_DESC'].str.strip() == 'SELF-REPORTED CONDITIONS',
           'Self-Reported'] = 1

    df.to_sql('table1')

    df['Prognosis < 42'] = 0
    condition1 = (df['Disability Date'] - df['Prognosis Date']).dt.days <= 42
    df.loc[condition1, 'Prognosis < 42'] = 1

    df['Prognosis < 20'] = 0
    condition1 = (df['Disability Date'] - df['Prognosis Date']).dt.days <= 20
    df.loc[condition1, 'Prognosis < 20'] = 1

    df.to_sql('table2')

    df['V2'] = df['Prognosis < 30']
    df['V3'] = df['Co-morbidity']

    df['Modified Original LCP'] = df['LCP']
    df1 = df.copy()
    df1['Change'] = 0
    condition1 = df['Modified Original LCP'] != df['LCP']
    df1.loc[condition1, 'Change'] = 1

    df1 = df1['Change'].value_counts().reset_index()
    df1 = df1.rename({'Change': 'Record_Count', 'index': 'Change'})

    df1.to_sql('table3')

    condition1 = df['Modified Original LCP'] == 'Variable RTW'
    condition2 = df['RTW in the past'] == 1
    df.loc[(condition1 & condition2),
           'Modified Original LCP'] = 'High Potential RTW'

    df1 = df.copy()
    df1['Change'] = 0
    condition1 = df['Modified Original LCP'] != df['LCP']
    df1.loc[condition1, 'Change'] = 1

    df1 = df1['Change'].value_counts().reset_index()
    df1 = df1.rename({'Change': 'Record_Count', 'index': 'Change'})

    df1.to_sql('table4')

    condition1 = df['Modified Original LCP'] == 'Variable RTW'
    condition2 = df['Prognosis < 30'] == 1
    df.loc[(condition1 & condition2),
           'Modified Original LCP'] = 'High Potential RTW'

    df1 = df.copy()
    df1['Change'] = 0
    condition1 = df['Modified Original LCP'] != df['LCP']
    df1.loc[condition1, 'Change'] = 1

    df1 = df1['Change'].value_counts().reset_index()
    df1 = df1.rename({'Change': 'Record_Count', 'index': 'Change'})

    df1.to_sql('table5')

    condition1 = df['Modified Original LCP'] == 'Complex RTW'
    condition2 = df['RTW in the past'] == 1
    df.loc[(condition1 & condition2),
           'Modified Original LCP'] = 'High Potential RTW'

    df1 = df1['Change'].value_counts().reset_index()
    df1 = df1.rename({'Change': 'Record_Count', 'index': 'Change'})

    df1.to_sql('table6')

    df['Presence of Estimated Delivery Date'] = 0
    df.loc[~df['Pregnacy Estimated Delivery Date'].isnull(),
           'Presence of Estimated Delivery Date'] = 1

    df['Delivered in the past'] = 0
    condition1 = df['Actual Pregnacy Termination Date'] < df['CMPLT_TS']
    df.loc[condition1, 'Delivered in the past'] = 1

    return df
