def f_microsegments_firstsegmentation(df):
    df = df.groupby(['Primary ICD9 Code',
                    'Primary ICD Major Diagnosis Category Description',
                     'RTW in the past', 'V2', 'V3']).size()

    df = df.rename(columns={0: 'Record_Count'})

    df = df.sort_values('Record_Count', ascending=False)

    df1 = df.copy()
    df1 = df1[df1['Record_Count'] >= 50]
    df1['Cluster Type'] = 'ICD, 123'
    df1.rename(columns={'Record_Count': 'Real Record Count'},
               inplace=True)

    df = df[df['Record_Count'] < 50]
    df = df.groupby(['Primary ICD9 Code',
                     'Primary ICD Major Diagnosis Category Description',
                     'RTW in the past',
                     'V2'])['Record_Count'].sum().reset_index()
    df.rename(columns={'Record_Count': 'Record_Count_Sum'}, inplace=True)
    df = df.groupby(['Primary ICD9 Code',
                     'Primary ICD Major Diagnosis Category Description',
                     'RTW in the past',
                     'V2', 'Record_Count_Sum']).size().reset_index()
    df.rename(columns={0: 'Record_Count'})

    df2 = df.copy()
    df2 = df2[df2['Record_Count_Sum'] >= 50]
    df2['Cluster Type'] = 'ICD, 12'
    df2.drop('Record_Count', axis=1, inplace=True)
    df2.rename(columns={'Record_Count_Sum': 'Real Record Count'},
               inplace=True)

    df = df[df['Record_Count_Sum'] < 50]
    df = df.groupby(['Primary ICD9 Code',
                     'Primary ICD Major Diagnosis Category Description',
                     'RTW in the past'])['Record_Count_Sum']\
        .sum().reset_index()
    df.rename(columns={'Record_Count_Sum': 'Record_Count_Sum_Sum'},
              inplace=True)
    df = df.groupby(['Primary ICD9 Code',
                     'Primary ICD Major Diagnosis Category Description',
                     'RTW in the past',
                     'Record_Count_Sum_Sum']).size().reset_index()
    df.rename(columns={0: 'Record_Count'})

    df3 = df.copy()
    df3 = df3[df3['Record_Count_Sum_Sum'] >= 50]
    df3['Cluster Type'] = 'ICD, 1'
    df3.drop('Record_Count', axis=1, inplace=True)
    df3.rename(columns={'Record_Count_Sum_Sum': 'Real Record Count'},
               inplace=True)

    df = df[df['Record_Count_Sum_Sum'] < 50]
    df.to_sql('table1')

    df = df.groupby(['Primary ICD9 Code',
                     'Primary ICD Major Diagnosis Category Description'])[
                         'Record_Count_Sum_Sum'].sum().reset_index()
    df.rename(columns={'Record_Count_Sum_Sum':
                       'Record_Count_Sum_Sum_Sum'},
              inplace=True)
    df = df.groupby(['Primary ICD9 Code',
                     'Primary ICD Major Diagnosis Category Description',
                     'Record_Count_Sum_Sum_Sum']).size().reset_index()
    df.rename(columns={0: 'Record_Count'})

    df4 = df.copy()
    df4 = df4[df4['Record_Count_Sum_Sum_Sum'] >= 50]
    df4['Cluster Type'] = 'ICD'
    df4.drop('Record_Count', axis=1, inplace=True)
    df4.rename(columns={'Record_Count_Sum_Sum_Sum': 'Real Record Count'},
               inplace=True)

    df = df[df['Record_Count_Sum_Sum_Sum'] < 50]
    df['Cluster Type'] = 'tmp'
    df.drop('Record_Count', axis=1, inplace=True)
    df.rename(columns={'Record_Count_Sum_Sum_Sum': 'Real Record Count'},
              inplace=True)

    final_df = df1.append([df2, df3, df4, df], sort=True)
    final_df.to_sql('table2')

    return final_df


def f_microsegments_secondsegmentation(df):
    df = df.groupby(['Primary ICD Major Diagnosis Category Description',
                     'RTW in the past', 'V2', 'V3']).size().reset_index()
    df.rename(columns={0: 'Record_Count'}, inplace=True)

    df.sort_values('Record_Count', ascending=False, inplace=True)

    df1 = df[df['Record_Count'] >= 50]
    df1['Cluster Type'] = 'MDC, 123'
    df1.rename(columns={'Record_Count': 'Real Record Count'}, inplace=True)

    df = df[df['Record_Count'] < 50]
    df = df.groupby(['Primary ICD Major Diagnosis Category Description',
                     'RTW in the past', 'V2'])['Record_Count']\
        .sum().reset_index()
    df.rename(columns={'Record_Count': 'Record_Count_Sum'}, inplace=True)

    df = df.groupby(['Primary ICD Major Diagnosis Category Description',
                     'RTW in the past', 'V2', 'Record_Count_Sum'])\
        .size().reset_index()
    df.rename(columns={0: 'Record_Count'}, inplace=True)

    df2 = df[df['Record_Count_Sum'] >= 50]
    df2['Cluster Type'] = 'MDC, 12'
    df2.rename(columns={'Record_Count_Sum': 'Real Record Count'},
               inplace=True)
    df2.drop('Record_Count', axis=1, inplace=True)

    df = df[df['Record_Count_Sum'] < 50]
    df = df.groupby(['Primary ICD Major Diagnosis Category Description',
                     'RTW in the past'])['Record_Count_Sum']\
        .sum().reset_index()
    df.rename(columns={'Record_Count_Sum': 'Record_Count_Sum_Sum'},
              inplace=True)

    df = df.groupby(['Primary ICD Major Diagnosis Category Description',
                     'RTW in the past', 'Record_Count_Sum_Sum'])\
        .size().reset_index()
    df.rename(columns={0: 'Record_Count'}, inplace=True)

    df3 = df[df['Record_Count_Sum_Sum'] >= 50]
    df3['Cluster Type'] = 'MDC, 1'
    df3.rename(columns={'Record_Count_Sum_Sum': 'Real Record Count'},
               inplace=True)
    df3.drop('Record_Count', axis=1, inplace=True)

    df = df[df['Record_Count_Sum_Sum'] < 50]
    df.to_sql('table1')
    df = df.groupby(['Primary ICD Major Diagnosis Category Description'])[
            'Record_Count_Sum_Sum'].sum().reset_index()
    df.rename(columns={'Record_Count_Sum_Sum': 'Record_Count_Sum_Sum_Sum'},
              inplace=True)

    df = df.groupby(['Primary ICD Major Diagnosis Category Description',
                     'Record_Count_Sum_Sum_Sum']).size().reset_index()
    df.rename(columns={0: 'Record_Count'}, inplace=True)

    df4 = df[df['Record_Count_Sum_Sum_Sum'] >= 50]
    df4['Cluster Type'] = 'MDC'
    df4.rename(columns={'Record_Count_Sum_Sum_Sum': 'Real Record Count'},
               inplace=True)
    df4.drop('Record_Count', axis=1, inplace=True)

    df = df[df['Record_Count_Sum_Sum_Sum'] < 50]
    df['Cluster Type'] = 'misc'
    df.rename(columns={'Record_Count_Sum_Sum_Sum': 'Real Record Count'},
              inplace=True)
    df.drop('Record_Count', axis=1, inplace=True)
    final_df = df1.append([df2, df3, df4, df], sort=True)

    final_df.to_sql('table2')
    return final_df


def f_microsegments(df):
    df = df[~df['Primary ICD Major Diagnosis Category Description'].isnull()]
    df.to_sql('table1')

    df1 = df.copy()

    df = f_microsegments_firstsegmentation(df)
    df = df.sort_values('Real Record Count', ascending=False)

    df_temp = df.groupby('Cluster Type')['Real Record Count'].sum()
    df_temp.rename(columns={'Real Record Count':
                            'Real Record Count_Sum'},
                   inplace=True)
    df_temp = df_temp.groupby(['Cluster Type', 'Real Record Count'])\
        .size().reset_index()
    df_temp.rename(columns={0: 'Record_Count'})
    df_temp.to_sql('table2')

    df_temp = df[df['Cluster Type'] == 'tmp']
    df_temp.to_sql('table3')

    df = df[df['Cluster Type'] != 'tmp']
    df['Microsegment'] = df.reset
    df.loc[df['Cluster Type'] == 'tmp', 'Microsegment'] = -1
    df = df[~df['Primary ICD Major Diagnosis Category Description'].isnull()]

    df.to_sql('table4')
    df.sort_values('Microsegment').to_sql('table5')
    df.to_sql('table6')

    df2 = df[df['Cluster Type'] == 'ICD, 123']
    df1 = df1.merge(df2, how='left', on=['V2',
                                         'V3', 'RTW in the past',
                                         'Primary ICD Major Diagnosis \
                                         Category Description',
                                         'Primary ICD9 Code'])
    df2 = df1[~df1['Cluster Type'].isnull()]
    df1 = df1[df['Cluster Type'].isnull()]
    df1.drop(['Real Record Count', 'Cluster Type', 'Microsegment'],
             inplace=True)
    df_temp = df[df['Cluster Type'] == 'ICD, 12']
    df_temp.drop('V3', inplace=True)
    df1 = df1.merge(df_temp, how='left', on=['RTW in the past',
                                             'Primary ICD Major Diagnosis \
                                             Category Description',
                                             'Primary ICD9 Code', 'V2'])

    df3 = df1[~df1['Cluster Type'].isnull()]

    df1 = df1[df1['Cluster Type'].isnull()]
    df1.drop(['Real Record Count', 'Cluster Type', 'Microsegment'],
             inplace=True)
    df_temp = df[df['Cluster Type'] == 'ICD, 1']
    df_temp.drop(['V2', 'V3'], inplace=True)

    df1 = df1.merge(df_temp, how='left', on=['RTW in the past',
                                             'Primary ICD Major Diagnosis \
                                             Category Description',
                                             'Primary ICD9 Code'])

    df4 = df1[~df1['Cluster Type'].isnull()]

    df1 = df1[df1['Cluster Type'].isnull()]
    df1.drop(['Real Record Count', 'Cluster Type', 'Microsegment'],
             inplace=True)

    df_temp = df[df['Cluster Type'] == 'ICD']
    df_temp.drop(['V2', 'V3', 'RTW in the past'], inplace=True)
    df1 = df1.merge(df_temp, how='left', on=[
              'Primary ICD Major Diagnosis Category Description',
              'Primary ICD9 Code'])
    df1['Cluster Type'].fillna('tmp', inplace=True)

    df5 = df1[df1['Cluster Type'] != 'tmp']

    df1 = df1[df1['Cluster Type'] == 'tmp']
    df1.to_sql('table7')

    df1.drop(['Real Record Count', 'Cluster Type', 'Microsegment'],
             inplace=True)

    df_second_seg = f_microsegments_secondsegmentation(df1)
    df_second_seg['Microsegment'] = (df_second_seg.index)+1000
    df_second_seg.loc[df_second_seg['Cluster Type'] == 'misc',
                      'Microsegment'] = -1000
    df_second_seg.to_sql('table8')
    df_second_seg = df_second_seg[~
                                  df_second_seg['Primary ICD Major Diagnosis \
                        Category Description'].isnull()]
    df_second_seg.to_sql('table9')
    df_temp = df_second_seg.groupby('Cluster Type').size().reset_index()
    df_temp.rename(columns={0: 'Record_Count'}, inplace=True)
    df_temp.to_sql('table10')

    df_second_seg = df_second_seg.groupby('Microsegment').agg({
        'Real Record Count': 'sum',
        'Cluster Type': 'min',
        'RTW in the past': 'min',
        'Primary ICD Major Diagnosis Category Description': 'min',
        'V2': 'min',
        'V3': 'min'
        }).reset_index()
    df_second_seg.rename(columns={
        'Real Record Count': 'Real Record Count_Sum',
        'Cluster Type': 'Cluster Type_Min',
        'RTW in the past': 'RTW in the past_Min',
        'Primary ICD Major Diagnosis Category Description':
        'Primary ICD Major Diagnosis Category Description_Min',
        'V2': 'V2_Min',
        'V3': 'V3_Min'
        }).sort_values('Microsegment').to_sql('table11')
    df_second_seg.to_sql('table12')

    df_mdc_123 = df_second_seg[df_second_seg['Cluster Type'] == 'MDC, 123']
    df1 = df1.merge(df_mdc_123, how='left', on=['RTW in the past',
                                                'Primary ICD Major Diagnosis \
                                                Category Description',
                                                'V2', 'V3'])
    df_ta1 = df1[~df1['Cluster Type'].isnull()]
    df1 = df1[df1['Cluster Type'].isnull()]
    df1.drop(['Real Record Count', 'Cluster Type', 'Microsegment'],
             inplace=True)
    df_mdc_12 = df1[df1['Cluster Type'] == 'MDC, 12']
    df_mdc_12.drop('V3', inplace=True)
    df1 = df1.merge(df_mdc_12, how='left', on=['RTW in the past',
                                               'Primary ICD Major Diagnosis \
                                               Category Description',
                                               'V2'])
    df_ta2 = df1[~df1['Cluster Type'].isnull()]
    df_ta2.to_sql('table13')
    df1 = df1[df1['Cluster Type'].isnull()]
    df1.drop(['Real Record Count', 'Cluster Type', 'Microsegment'],
             inplace=True)

    df_mdc_1 = df1[df1['Cluster Type'] == 'MDC, 1']
    df_mdc_1.drop(['V3', 'V2'], inplace=True)
    df1 = df1.merge(df_mdc_1, how='left', on=['RTW in the past',
                                              'Primary ICD Major Diagnosis \
                                              Category Description'])
    df_ta3 = df1[~df1['Cluster Type'].isnull()]

    df1 = df1[df1['Cluster Type'].isnull()]
    df1.drop(['Real Record Count', 'Cluster Type', 'Microsegment'],
             inplace=True)

    df_mdc = df1[df1['Cluster Type'] == 'MDC']
    df_mdc.drop(['V3', 'V2', 'RTW in the past'], inplace=True)
    df1 = df1.merge(df_mdc, how='left', on=[
              'Primary ICD Major Diagnosis Category Description'])
    df_ta4 = df1[~df1['Cluster Type'].isnull()]

    df1 = df1[df1['Cluster Type'].isnull()]
    df1['Cluster Type'].fillna('Miscellaneous', inplace=True)
    df1['Microsegment'].fillna(-10000, inplace=True)
    df1.to_sql('table14')

    final_append_2 = df_ta1.append([df_ta2, df_ta3, df_ta4, df1], sort=True)
    final_append_2.to_sql('table15')

    final_append = df2.append([df3, df4, df5, final_append_2])
    final_append.to_sql('table16')

    return final_append
