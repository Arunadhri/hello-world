def f_restructureMerge(df):
    df_temp = pd.get_dummies(df['Modified Original LCP'],
                             prefix='Modified Original LCP')
    df = df.drop('Modified Original LCP', axis=1).merge(df_temp,
                                                        left_index=True,
                                                        right_index=True,
                                                        how='inner')

    df.rename(columns={'Modified Original LCP_Complex RTW':
                       'Complex RTW',
                       'Modified Original LCP_Ext Dis Limited RTW':
                       'Ext Dis Limited RTW',
                       'Modified Original LCP_High Potential RTW':
                       'High Potential RTW',
                       'Modified Original LCP_Variable RTW':
                       'Variable RTW'},
              inplace=True)

    df.loc[df['Complex RTW'] == 1, 'Complex RTW'] = df['Record_Count']
    df.loc[df['Ext Dis Limited RTW'] == 1, 'Ext Dis Limited RTW'] = \
        df['Record_Count']
    df.loc[df['High Potential RTW'] == 1, 'High Potential RTW'] = \
        df['Record_Count']
    df.loc[df['Variable RTW'] == 1, 'Variable RTW'] = df['Record_Count']

    df[['Complex RTW',
        'Ext Dis Limited RTW',
        'High Potential RTW',
        'Variable RTW']].fillna(
            0, inplace=True)

    df = df.groupby('Microsegment')['Complex RTW',
                                    'Ext Dis Limited RTW',
                                    'High Potential RTW',
                                    'Variable RTW'].sum().reset_index()

    return df
