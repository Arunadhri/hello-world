def f_rankLCP1(df):
    df.sort_values('Record_Count', ascending=False, inplace=True)
    df['HP%'] = df['High Potential RTW'] / df['Record_Count']
    df['ED%'] = df['Ext Dis Limited RTW']
    df['VR%'] = df['Variable RTW']
    df['CR%'] = df['Complex RTW']
    df['Majority %'] = df[['HP%', 'ED%', 'VR%', 'CR%']].max(axis=1)

    df.to_sql('table1')

    df['Majority LCP index'] = 0
    df.loc[df['HP%'] == df[['HP%', 'ED%', 'VR%', 'CR%']].max(axis=1),
           'Majority LCP index'] = 1
    df.loc[df['ED%'] == df[['HP%', 'ED%', 'VR%', 'CR%']].max(axis=1),
           'Majority LCP index'] = 2
    df.loc[df['VR%'] == df[['HP%', 'ED%', 'VR%', 'CR%']].max(axis=1),
           'Majority LCP index'] = 3
    df.loc[df['CR%'] == df[['HP%', 'ED%', 'VR%', 'CR%']].max(axis=1),
           'Majority LCP index'] = 4

    df['Majority LCP'] = ''
    df.loc[df['Majority LCP index'] == 1, 'Majority LCP'] = 'HP'
    df.loc[df['Majority LCP index'] == 2, 'Majority LCP'] = 'ED'
    df.loc[df['Majority LCP index'] == 3, 'Majority LCP'] = 'VR'
    df.loc[df['Majority LCP index'] == 4, 'Majority LCP'] = 'CR'

    df.to_sql('table2')
    df.to_sql('table3')

    return df
