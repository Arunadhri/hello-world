import re
import numpy as np

a = open(r'\\ns-sisci01hd\home_s01\Citrix_Folder_Redirect\Downloads\NG\AutoAdjudication\mail\temp.txt').read()

to_replace = list(set(re.findall(r"(?<=\[\').*?(?=\'\])", a)))
from_replace = ["x['" + i + "']" for i in to_replace]
from_replace.append('(x)')
to_replace.append('(' + ', '.join(to_replace) + ')')

for i, j in zip(from_replace, to_replace):
    a = a.replace(i, j)
a = a.strip()

a = ' '.join(a.split())
a = a.replace(':', ':\n').replace('elif', '\nelif').replace(' if', '\n if').replace('else', '\nelse').replace(' in ', '.isin(')

func_def = a.split('\n')[0].strip()
func_name = func_def.split('def ')[1].split('(')[0]
conditions = 'conditions = ' + str(re.findall(r"(?<=if ).*?(?=:)", a))
choices = 'choices = ' + str(re.findall(r"(?<=return ).*?(?= +\n)", a))
default_cond = 'default_cond = ' + a.split('else:\n')[1].split('return ')[1].strip()
returns = 'return np.select(conditions, choices, default=default_cond)'
vector_func = func_name + ' = np.vectorize(' + func_name + ')'
opti_code = func_def + '\n' + conditions + '\n' + choices + '\n' + default_cond + '\n' + returns + '\n' + vector_func

with open(r'\\ns-sisci01hd\home_s01\Citrix_Folder_Redirect\Downloads\NG\AutoAdjudication\mail\temp_op.txt', 'w') as f:
    f.write(opti_code)

def changer(func_name, df_name, cols):
    cols = cols.split(', ')
    prefix = df_name + "['"
    suffix = "'].values"
    return func_name + '(' + ', '.join([prefix + i + suffix for i in cols]) + ')'
changer('mdc123', 'df3', 'MDC, V2, V3, ICD9, ICD, RTW_P')
'''
Open the o/p text file and replace all " with empty string
search for isin and if it's present, close the bracket for it
run autopep8 to take care of indendation etc (autopep8 --in-place test.py)
remove quotes from column names - usually the first or last choice / condition
modify the function call statement to take the columns as different inputs
works directly for string comparisons. for int comparisons find and replace in editor
for strings with double spaces in them find and add a space
'''
#Update-1
a = open(r'\\ns-sisci01hd\home_s01\Citrix_Folder_Redirect\Downloads\NG\AutoAdjudication\mail\temp.txt').read()

to_replace = list(set(re.findall(r"(?<=\[\').*?(?=\'\])", a)))
from_replace = ["x['" + i + "']" for i in to_replace]
from_replace.append('(x)')
to_replace.append('(' + ', '.join(to_replace) + ')')

for i, j in zip(from_replace, to_replace):
    a = a.replace(i, j)
a = a.strip()

a = ' '.join(a.split())
a = a.replace(':', ':\n').replace('elif', '\nelif').replace(' if', '\n if').replace('else', '\nelse').replace(' in ', '.isin(')
column_name = []
cond_value = []
return_value = []
if_elif = []
cond_type = []
func_def = ''
else_return = (a.split('\n')[-1]).strip()

for i in a.split('\n'):
    if 'def' in i:
        func_def = i
    if 'if ' in i:
        j = i.strip().split(' ')
        cond_type.append(j[2])
        if_elif.append(j[0])
        column_name.append(j[1])
        cond_value.append(j[3].split(':')[0])
    elif 'else:' in i:
        break
    elif 'return ' in i:
        return_value.append(i.strip().split(' ')[1])

n_column_name = [column_name[0]]
n_cond_value = [cond_value[0]]
n_return_value = [return_value[0]]
n_if_elif = [if_elif[0]]
n_cond_type = [cond_type[0]]

for i in range(1, len(if_elif)):
    if return_value[i] == return_value[i-1]\
    and column_name[i] == column_name[i-1]\
    and cond_type[i] == '=='\
    and cond_type[i-1] == '==':
        if isinstance(n_cond_value[-1], list):
            n_cond_value[-1] = n_cond_value[-1] + [cond_value[i]]
        else:
            n_cond_value[-1] = [n_cond_value[-1]] + [cond_value[i]]
    else:
        n_if_elif.append(if_elif[i])
        n_column_name.append(column_name[i])
        n_cond_type.append(cond_type[i])
        n_cond_value.append(cond_value[i])
        n_return_value.append(return_value[i])

fin_str = ''
for i in range(len(n_column_name)):
    if not isinstance(n_cond_value[i], list):
        fin_str += ' '.join([n_if_elif[i], n_column_name[i], n_cond_type[i], n_cond_value[i]])
        fin_str += ':\n return ' + n_return_value[i] + '\n'
    else:
        fin_str += n_if_elif[i] + ' np.isin(' + n_column_name[i] + ', ' + str(n_cond_value[i]) + '):\n return ' + n_return_value[i] + '\n'
fin_str = fin_str.replace('"', '')

a = (func_def + '\n' + fin_str.strip() + '\nelse:\n ' + else_return).strip()
func_def = a.split('\n')[0].strip()
func_name = func_def.split('def ')[1].split('(')[0]
conditions = 'conditions = ' + str(re.findall(r"(?<=if ).*?(?=:)", a))
choices = 'choices = ' + str(re.findall(r"(?<=return ).*?(?=\n)", a))
default_cond = 'default_cond = ' + a.split('else:\n')[1].split('return ')[1].strip()
returns = 'return np.select(conditions, choices, default=default_cond)'
opti_code = func_def + '\n\t' + conditions + '\n\t' + choices + '\n\t' + default_cond + '\n\t' + returns
opti_code = opti_code.replace('"', '')

with open(r'\\ns-sisci01hd\home_s01\Citrix_Folder_Redirect\Downloads\NG\AutoAdjudication\mail\temp_op.txt', 'w') as f:
    f.write(opti_code)


# better pep8
b = ''
a = "    conditions = [row == 'A072', row == 'B2799', row == 'B2792', row == 'B2791', row == 'B2790', row == 'B2789', row == 'B2782', row == 'B2781', row == 'B2780', row == 'B2719', row == 'B2712', row == 'B2711', row == 'B2710', row == 'B2709', row == 'B2702', row == 'B2701', row == 'B2700', row == 'A074', row == 'A09', row == 'C55', row == 'C61', row == 'C73', row == 'A218', row == 'A217', row == 'A239', row == 'A305', row == 'A308', row == 'F329', row == 'A311', row == 'J0301']"
print(len(a))
while(len(a) > 78):
    temp = (','.join(a[:78].split(',')[:-1])) + ',\n'
    b += temp
    a = a[len(temp)-1:].strip()
with open(r'\\ns-sisci01hd\home_s01\Citrix_Folder_Redirect\Downloads\NG\AutoAdjudication\mail\temp_op_pep8.txt', 'w') as f:
    f.write(b+a)