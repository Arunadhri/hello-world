a = """
def test(x):
    if x['a'] == '':
        return 'a'
    elif x['b'] == '':
        return 'b'
"""

to_replace = re.findall(r"(?<=\[\').*?(?=\'\])", a)
from_replace = ["x['" + i + "']" for i in to_replace]
from_replace.append('(x)')
to_replace.append('(' + ', '.join(to_replace) + ')')

for i, j in zip(from_replace, to_replace):
    a = a.replace(i, j)
print(a.strip())

def test(a, b):
    if a == '':
        return 'a'
    elif b == '':
        return 'b'
test = np.vectorize(test)