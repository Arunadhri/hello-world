def f_ICD10to9_1(x):
    if x["PRI_ICD_CD"] == 'A072':
        return '74'
    elif x["PRI_ICD_CD"] == 'B2799':
        return '75'
    elif x["PRI_ICD_CD"] == 'B2792':
        return '75'
    elif x["PRI_ICD_CD"] == 'B2791':
        return '75'
    elif x["PRI_ICD_CD"] == 'B2790':
        return '75'
    elif x["PRI_ICD_CD"] == 'B2789':
        return '75'
    elif x["PRI_ICD_CD"] == 'B2782':
        return '75'
    elif x["PRI_ICD_CD"] == 'B2781':
        return '75'
    elif x["PRI_ICD_CD"] == 'B2780':
        return '75'
    elif x["PRI_ICD_CD"] == 'B2719':
        return '75'
    elif x["PRI_ICD_CD"] == 'B2712':
        return '75'
    elif x["PRI_ICD_CD"] == 'B2711':
        return '75'
    elif x["PRI_ICD_CD"] == 'B2710':
        return '75'
    elif x["PRI_ICD_CD"] == 'B2709':
        return '75'
    elif x["PRI_ICD_CD"] == 'B2702':
        return '75'
    elif x["PRI_ICD_CD"] == 'B2701':
        return '75'
    elif x["PRI_ICD_CD"] == 'B2700':
        return '75'
    elif x["PRI_ICD_CD"] == 'A074':
        return '75'
    elif x["PRI_ICD_CD"] == 'A09':
        return '90'
    elif x["PRI_ICD_CD"] == 'C55':
        return '179'
    elif x["PRI_ICD_CD"] == 'C61':
        return '185'
    elif x["PRI_ICD_CD"] == 'C73':
        return '193'
    elif x["PRI_ICD_CD"] == 'A218':
        return '218'
    elif x["PRI_ICD_CD"] == 'A217':
        return '218'
    elif x["PRI_ICD_CD"] == 'A239':
        return '239'
    elif x["PRI_ICD_CD"] == 'A305':
        return '300'
    elif x["PRI_ICD_CD"] == 'A308':
        return '308'
    elif x["PRI_ICD_CD"] == 'F329':
        return '311'
    elif x["PRI_ICD_CD"] == 'A311':
        return '311'
    elif x["PRI_ICD_CD"] == 'J0301':
        return '340'
    elif x["PRI_ICD_CD"] == 'J0300':
        return '340'
    elif x["PRI_ICD_CD"] == 'J020':
        return '340'
    elif x["PRI_ICD_CD"] == 'G35':
        return '340'
    elif x["PRI_ICD_CD"] == 'A427':
        return '388'
    elif x["PRI_ICD_CD"] == 'A4189':
        return '388'
    elif x["PRI_ICD_CD"] == 'A4181':
        return '388'
    elif x["PRI_ICD_CD"] == 'A419':
        return '389'
    elif x["PRI_ICD_CD"] == 'A488':
        return '401'
    elif x["PRI_ICD_CD"] == 'A499':
        return '419'
    elif x["PRI_ICD_CD"] == 'I609':
        return '430'
    elif x["PRI_ICD_CD"] == 'I608':
        return '430'
    elif x["PRI_ICD_CD"] == 'I607':
        return '430'
    elif x["PRI_ICD_CD"] == 'I606':
        return '430'
    elif x["PRI_ICD_CD"] == 'I6052':
        return '430'
    elif x["PRI_ICD_CD"] == 'I6051':
        return '430'
    elif x["PRI_ICD_CD"] == 'I6050':
        return '430'
    elif x["PRI_ICD_CD"] == 'I604':
        return '430'
    elif x["PRI_ICD_CD"] == 'I6032':
        return '430'
    elif x["PRI_ICD_CD"] == 'I6031':
        return '430'
    elif x["PRI_ICD_CD"] == 'I6030':
        return '430'
    elif x["PRI_ICD_CD"] == 'I6022':
        return '430'
    elif x["PRI_ICD_CD"] == 'I6021':
        return '430'
    elif x["PRI_ICD_CD"] == 'I6020':
        return '430'
    elif x["PRI_ICD_CD"] == 'I6012':
        return '430'
    elif x["PRI_ICD_CD"] == 'I6011':
        return '430'
    elif x["PRI_ICD_CD"] == 'I6010':
        return '430'
    elif x["PRI_ICD_CD"] == 'I6002':
        return '430'
    elif x["PRI_ICD_CD"] == 'I6001':
        return '430'
    elif x["PRI_ICD_CD"] == 'I6000':
        return '430'
    elif x["PRI_ICD_CD"] == 'I619':
        return '431'
    elif x["PRI_ICD_CD"] == 'I618':
        return '431'
    elif x["PRI_ICD_CD"] == 'I616':
        return '431'
    elif x["PRI_ICD_CD"] == 'I615':
        return '431'
    elif x["PRI_ICD_CD"] == 'I614':
        return '431'
    elif x["PRI_ICD_CD"] == 'I613':
        return '431'
    elif x["PRI_ICD_CD"] == 'I612':
        return '431'
    elif x["PRI_ICD_CD"] == 'I611':
        return '431'
    elif x["PRI_ICD_CD"] == 'I610':
        return '431'
    elif x["PRI_ICD_CD"] == 'J00':
        return '460'
    elif x["PRI_ICD_CD"] == 'A8181':
        return '460'
    elif x["PRI_ICD_CD"] == 'J029':
        return '462'
    elif x["PRI_ICD_CD"] == 'J028':
        return '462'
    elif x["PRI_ICD_CD"] == 'A811':
        return '462'
    elif x["PRI_ICD_CD"] == 'J0391':
        return '463'
    elif x["PRI_ICD_CD"] == 'J0390':
        return '463'
    elif x["PRI_ICD_CD"] == 'J0381':
        return '463'
    elif x["PRI_ICD_CD"] == 'J0380':
        return '463'
    elif x["PRI_ICD_CD"] == 'I673':
        return '463'
    elif x["PRI_ICD_CD"] == 'A812':
        return '463'
    elif x["PRI_ICD_CD"] == 'J342':
        return '470'
    elif x["PRI_ICD_CD"] == 'A870':
        return '470'
    elif x["PRI_ICD_CD"] == 'J189':
        return '486'
    elif x["PRI_ICD_CD"] == 'J188':
        return '486'
    elif x["PRI_ICD_CD"] == 'J40':
        return '490'
    elif x["PRI_ICD_CD"] == 'A872':
        return '490'
    elif x["PRI_ICD_CD"] == 'B029':
        return '539'
    elif x["PRI_ICD_CD"] == 'B0089':
        return '539'
    elif x["PRI_ICD_CD"] == 'B000':
        return '540'
    elif x["PRI_ICD_CD"] == 'K37':
        return '541'
    elif x["PRI_ICD_CD"] == 'B004':
        return '543'
    elif x["PRI_ICD_CD"] == 'B050':
        return '550'
    elif x["PRI_ICD_CD"] == 'K614':
        return '566'
    elif x["PRI_ICD_CD"] == 'K613':
        return '566'
    elif x["PRI_ICD_CD"] == 'K612':
        return '566'
    elif x["PRI_ICD_CD"] == 'K611':
        return '566'
    elif x["PRI_ICD_CD"] == 'K610':
        return '566'
    elif x["PRI_ICD_CD"] == 'D563':
        return '566'
    elif x["PRI_ICD_CD"] == 'B069':
        return '569'
    elif x["PRI_ICD_CD"] == 'N19':
        return '586'
    elif x["PRI_ICD_CD"] == 'A831':
        return '621'
    elif x["PRI_ICD_CD"] == 'O019':
        return '630'
    elif x["PRI_ICD_CD"] == 'O011':
        return '630'
    elif x["PRI_ICD_CD"] == 'O010':
        return '630'
    elif x["PRI_ICD_CD"] == 'A840':
        return '630'
    elif x["PRI_ICD_CD"] == 'O80':
        return '650'
    elif x["PRI_ICD_CD"] == 'A980':
        return '650'
    elif x["PRI_ICD_CD"] == 'B262':
        return '722'
    elif x["PRI_ICD_CD"] == 'B263':
        return '723'
    elif x["PRI_ICD_CD"] == 'B081':
        return '780'
    elif x["PRI_ICD_CD"] == 'A752':
        return '810'
    elif x["PRI_ICD_CD"] == 'A753':
        return '812'
    elif x["PRI_ICD_CD"] == 'A771':
        return '821'
    elif x["PRI_ICD_CD"] == 'A773':
        return '823'
    elif x["PRI_ICD_CD"] == 'A790':
        return '831'
    elif x["PRI_ICD_CD"] == 'B509':
        return '840'
    elif x["PRI_ICD_CD"] == 'B508':
        return '840'
    elif x["PRI_ICD_CD"] == 'A047':
        return '845'
    elif x["PRI_ICD_CD"] == 'B550':
        return '850'
    elif x["PRI_ICD_CD"] == 'A64':
        return '999'
    elif x["PRI_ICD_CD"] == 'B998':
        return '1368'
    elif x["PRI_ICD_CD"] == 'B999':
        return '1369'
    elif x["PRI_ICD_CD"] == 'B89':
        return '1369'
    elif x["PRI_ICD_CD"] == 'C159':
        return '1509'
    elif x["PRI_ICD_CD"] == 'C189':
        return '1539'
    elif x["PRI_ICD_CD"] == 'C20':
        return '1541'
    elif x["PRI_ICD_CD"] == 'C228':
        return '1550'
    elif x["PRI_ICD_CD"] == 'C227':
        return '1550'
    elif x["PRI_ICD_CD"] == 'C224':
        return '1550'
    elif x["PRI_ICD_CD"] == 'C223':
        return '1550'
    elif x["PRI_ICD_CD"] == 'C222':
        return '1550'
    elif x["PRI_ICD_CD"] == 'C220':
        return '1550'
    elif x["PRI_ICD_CD"] == 'A1803':
        return '1550'
    elif x["PRI_ICD_CD"] == 'C259':
        return '1579'
    elif x["PRI_ICD_CD"] == 'C3492':
        return '1629'
    elif x["PRI_ICD_CD"] == 'C3491':
        return '1629'
    elif x["PRI_ICD_CD"] == 'C3490':
        return '1629'
    elif x["PRI_ICD_CD"] == 'D039':
        return '1729'
    elif x["PRI_ICD_CD"] == 'C439':
        return '1729'
    elif x["PRI_ICD_CD"] == 'C50019':
        return '1740'
    elif x["PRI_ICD_CD"] == 'C50012':
        return '1740'
    elif x["PRI_ICD_CD"] == 'C50011':
        return '1740'
    elif x["PRI_ICD_CD"] == 'A186':
        return '1740'
    elif x["PRI_ICD_CD"] == 'C50119':
        return '1741'
    elif x["PRI_ICD_CD"] == 'C50112':
        return '1741'
    elif x["PRI_ICD_CD"] == 'C50111':
        return '1741'
    elif x["PRI_ICD_CD"] == 'C50419':
        return '1744'
    elif x["PRI_ICD_CD"] == 'C50412':
        return '1744'
    elif x["PRI_ICD_CD"] == 'C50411':
        return '1744'
    elif x["PRI_ICD_CD"] == 'C50919':
        return '1749'
    elif x["PRI_ICD_CD"] == 'C50912':
        return '1749'
    elif x["PRI_ICD_CD"] == 'C50911':
        return '1749'
    elif x["PRI_ICD_CD"] == 'C539':
        return '1809'
    elif x["PRI_ICD_CD"] == 'C549':
        return '1820'
    elif x["PRI_ICD_CD"] == 'C543':
        return '1820'
    elif x["PRI_ICD_CD"] == 'C542':
        return '1820'
    elif x["PRI_ICD_CD"] == 'C541':
        return '1820'
    elif x["PRI_ICD_CD"] == 'C569':
        return '1830'
    elif x["PRI_ICD_CD"] == 'C562':
        return '1830'
    elif x["PRI_ICD_CD"] == 'C561':
        return '1830'
    elif x["PRI_ICD_CD"] == 'C679':
        return '1889'
    elif x["PRI_ICD_CD"] == 'C649':
        return '1890'
    elif x["PRI_ICD_CD"] == 'C642':
        return '1890'
    elif x["PRI_ICD_CD"] == 'C641':
        return '1890'
    elif x["PRI_ICD_CD"] == 'A199':
        return '1890'
    elif x["PRI_ICD_CD"] == 'C719':
        return '1919'
    elif x["PRI_ICD_CD"] == 'C800':
        return '1990'
    elif x["PRI_ICD_CD"] == 'C801':
        return '1991'
    elif x["PRI_ICD_CD"] == 'C459':
        return '1991'
    elif x["PRI_ICD_CD"] == 'D1739':
        return '2141'
    elif x["PRI_ICD_CD"] == 'D1730':
        return '2141'
    elif x["PRI_ICD_CD"] == 'D1724':
        return '2141'
    elif x["PRI_ICD_CD"] == 'D1723':
        return '2141'
    elif x["PRI_ICD_CD"] == 'D1722':
        return '2141'
    elif x["PRI_ICD_CD"] == 'D1721':
        return '2141'
    elif x["PRI_ICD_CD"] == 'D1720':
        return '2141'
    elif x["PRI_ICD_CD"] == 'D171':
        return '2141'
    elif x["PRI_ICD_CD"] == 'D250':
        return '2180'
    elif x["PRI_ICD_CD"] == 'D251':
        return '2181'
    elif x["PRI_ICD_CD"] == 'D259':
        return '2189'
    elif x["PRI_ICD_CD"] == 'D0592':
        return '2330'
    elif x["PRI_ICD_CD"] == 'D0591':
        return '2330'
    elif x["PRI_ICD_CD"] == 'D0590':
        return '2330'
    elif x["PRI_ICD_CD"] == 'D0582':
        return '2330'
    elif x["PRI_ICD_CD"] == 'D0581':
        return '2330'
    elif x["PRI_ICD_CD"] == 'D0580':
        return '2330'
    elif x["PRI_ICD_CD"] == 'D0512':
        return '2330'
    elif x["PRI_ICD_CD"] == 'D0511':
        return '2330'
    elif x["PRI_ICD_CD"] == 'D0510':
        return '2330'
    elif x["PRI_ICD_CD"] == 'D0502':
        return '2330'
    elif x["PRI_ICD_CD"] == 'D0501':
        return '2330'
    elif x["PRI_ICD_CD"] == 'D0500':
        return '2330'
    elif x["PRI_ICD_CD"] == 'D3912':
        return '2352'
    elif x["PRI_ICD_CD"] == 'D3911':
        return '2352'
    elif x["PRI_ICD_CD"] == 'D375':
        return '2352'
    elif x["PRI_ICD_CD"] == 'D374':
        return '2352'
    elif x["PRI_ICD_CD"] == 'D373':
        return '2352'
    elif x["PRI_ICD_CD"] == 'D372':
        return '2352'
    elif x["PRI_ICD_CD"] == 'D371':
        return '2352'
    elif x["PRI_ICD_CD"] == 'D496':
        return '2396'
    elif x["PRI_ICD_CD"] == 'E079':
        return '2469'
    elif x["PRI_ICD_CD"] == 'M109':
        return '2749'
    elif x["PRI_ICD_CD"] == 'D508':
        return '2808'
    elif x["PRI_ICD_CD"] == 'D501':
        return '2808'
    elif x["PRI_ICD_CD"] == 'D649':
        return '2826'
    elif x["PRI_ICD_CD"] == 'F341':
        return '3004'
    elif x["PRI_ICD_CD"] == 'R456':
        return '3009'
    elif x["PRI_ICD_CD"] == 'R455':
        return '3009'
    elif x["PRI_ICD_CD"] == 'R452':
        return '3009'
    elif x["PRI_ICD_CD"] == 'F99':
        return '3009'
    elif x["PRI_ICD_CD"] == 'R457':
        return '3089'
    elif x["PRI_ICD_CD"] == 'F430':
        return '3089'
    elif x["PRI_ICD_CD"] == 'F4321':
        return '3090'
    elif x["PRI_ICD_CD"] == 'F0781':
        return '3102'
    elif x["PRI_ICD_CD"] == 'G214':
        return '3320'
    elif x["PRI_ICD_CD"] == 'G20':
        return '3320'
    elif x["PRI_ICD_CD"] == 'G894':
        return '3384'
    elif x["PRI_ICD_CD"] == 'G8929':
        return '3384'
    elif x["PRI_ICD_CD"] == 'G40301':
        return '3453'
    elif x["PRI_ICD_CD"] == 'G500':
        return '3501'
    elif x["PRI_ICD_CD"] == 'G510':
        return '3510'
    elif x["PRI_ICD_CD"] == 'G5602':
        return '3540'
    elif x["PRI_ICD_CD"] == 'G5601':
        return '3540'
    elif x["PRI_ICD_CD"] == 'G5600':
        return '3540'
    elif x["PRI_ICD_CD"] == 'G5622':
        return '3542'
    elif x["PRI_ICD_CD"] == 'G5621':
        return '3542'
    elif x["PRI_ICD_CD"] == 'G5620':
        return '3542'
    elif x["PRI_ICD_CD"] == 'G5762':
        return '3556'
    elif x["PRI_ICD_CD"] == 'G5761':
        return '3556'
    elif x["PRI_ICD_CD"] == 'G5760':
        return '3556'
    elif x["PRI_ICD_CD"] == 'H3320':
        return '3619'
    elif x["PRI_ICD_CD"] == 'H269':
        return '3669'
    elif x["PRI_ICD_CD"] == 'H6692':
        return '3829'
    elif x["PRI_ICD_CD"] == 'H6691':
        return '3829'
    elif x["PRI_ICD_CD"] == 'H6690':
        return '3829'
    elif x["PRI_ICD_CD"] == 'H8149':
        return '3862'
    elif x["PRI_ICD_CD"] == 'H8143':
        return '3862'
    elif x["PRI_ICD_CD"] == 'H8142':
        return '3862'
    elif x["PRI_ICD_CD"] == 'H8141':
        return '3862'
    elif x["PRI_ICD_CD"] == 'I10':
        return '4019'
    elif x["PRI_ICD_CD"] == 'I25110':
        return '4111'
    elif x["PRI_ICD_CD"] == 'I200':
        return '4111'
    elif x["PRI_ICD_CD"] == 'B9561':
        return '4111'
    elif x["PRI_ICD_CD"] == 'A4901':
        return '4111'
    elif x["PRI_ICD_CD"] == 'I349':
        return '4240'
    elif x["PRI_ICD_CD"] == 'I348':
        return '4240'
    elif x["PRI_ICD_CD"] == 'I342':
        return '4240'
    elif x["PRI_ICD_CD"] == 'I341':
        return '4240'
    elif x["PRI_ICD_CD"] == 'I340':
        return '4240'
    elif x["PRI_ICD_CD"] == 'I359':
        return '4241'
    elif x["PRI_ICD_CD"] == 'I358':
        return '4241'
    elif x["PRI_ICD_CD"] == 'I352':
        return '4241'
    elif x["PRI_ICD_CD"] == 'I351':
        return '4241'
    elif x["PRI_ICD_CD"] == 'I350':
        return '4241'
    elif x["PRI_ICD_CD"] == 'I429':
        return '4254'
    elif x["PRI_ICD_CD"] == 'I428':
        return '4254'
    elif x["PRI_ICD_CD"] == 'I425':
        return '4254'
    elif x["PRI_ICD_CD"] == 'I420':
        return '4254'
    elif x["PRI_ICD_CD"] == 'I492':
        return '4270'
    elif x["PRI_ICD_CD"] == 'I471':
        return '4270'
    elif x["PRI_ICD_CD"] == 'I469':
        return '4275'
    elif x["PRI_ICD_CD"] == 'I468':
        return '4275'
    elif x["PRI_ICD_CD"] == 'I462':
        return '4275'
    elif x["PRI_ICD_CD"] == 'I509':
        return '4289'
    elif x["PRI_ICD_CD"] == 'I2510':
        return '4292'
    elif x["PRI_ICD_CD"] == 'I52':
        return '4299'
    elif x["PRI_ICD_CD"] == 'I519':
        return '4299'
    elif x["PRI_ICD_CD"] == 'I67848':
        return '4359'
    elif x["PRI_ICD_CD"] == 'I67841':
        return '4359'
    elif x["PRI_ICD_CD"] == 'G459':
        return '4359'
    elif x["PRI_ICD_CD"] == 'I671':
        return '4373'
    elif x["PRI_ICD_CD"] == 'I688':
        return '4378'
    elif x["PRI_ICD_CD"] == 'I680':
        return '4378'
    elif x["PRI_ICD_CD"] == 'I6789':
        return '4378'
    elif x["PRI_ICD_CD"] == 'G468':
        return '4378'
    elif x["PRI_ICD_CD"] == 'G467':
        return '4378'
    elif x["PRI_ICD_CD"] == 'G466':
        return '4378'
    elif x["PRI_ICD_CD"] == 'G465':
        return '4378'
    elif x["PRI_ICD_CD"] == 'G464':
        return '4378'
    elif x["PRI_ICD_CD"] == 'G463':
        return '4378'
    elif x["PRI_ICD_CD"] == 'I679':
        return '4379'
    elif x["PRI_ICD_CD"] == 'I739':
        return '4439'
    elif x["PRI_ICD_CD"] == 'I749':
        return '4449'
    elif x["PRI_ICD_CD"] == 'I8291':
        return '4539'
    elif x["PRI_ICD_CD"] == 'K649':
        return '4558'
    elif x["PRI_ICD_CD"] == 'K648':
        return '4558'
    elif x["PRI_ICD_CD"] == 'K643':
        return '4558'
    elif x["PRI_ICD_CD"] == 'K642':
        return '4558'
    elif x["PRI_ICD_CD"] == 'K641':
        return '4558'
    elif x["PRI_ICD_CD"] == 'J0101':
        return '4610'
    elif x["PRI_ICD_CD"] == 'J0100':
        return '4610'
    elif x["PRI_ICD_CD"] == 'J0190':
        return '4618'
    elif x["PRI_ICD_CD"] == 'J0181':
        return '4618'
    elif x["PRI_ICD_CD"] == 'J0180':
        return '4618'
    elif x["PRI_ICD_CD"] == 'J0141':
        return '4618'
    elif x["PRI_ICD_CD"] == 'J0140':
        return '4618'
    elif x["PRI_ICD_CD"] == 'J0191':
        return '4619'
    elif x["PRI_ICD_CD"] == 'A8109':
        return '4619'
    elif x["PRI_ICD_CD"] == 'A8100':
        return '4619'
    elif x["PRI_ICD_CD"] == 'J069':
        return '4659'
    elif x["PRI_ICD_CD"] == 'J209':
        return '4660'
    elif x["PRI_ICD_CD"] == 'J208':
        return '4660'
    elif x["PRI_ICD_CD"] == 'J207':
        return '4660'
    elif x["PRI_ICD_CD"] == 'J206':
        return '4660'
    elif x["PRI_ICD_CD"] == 'J205':
        return '4660'
    elif x["PRI_ICD_CD"] == 'J204':
        return '4660'
    elif x["PRI_ICD_CD"] == 'J203':
        return '4660'
    elif x["PRI_ICD_CD"] == 'J202':
        return '4660'
    elif x["PRI_ICD_CD"] == 'J201':
        return '4660'
    elif x["PRI_ICD_CD"] == 'J200':
        return '4660'
    elif x["PRI_ICD_CD"] == 'J329':
        return '4739'
    elif x["PRI_ICD_CD"] == 'J359':
        return '4749'
    elif x["PRI_ICD_CD"] == 'J120':
        return '4800'
    elif x["PRI_ICD_CD"] == 'J1289':
        return '4808'
    elif x["PRI_ICD_CD"] == 'J123':
        return '4808'
    elif x["PRI_ICD_CD"] == 'J129':
        return '4870'
    elif x["PRI_ICD_CD"] == 'J1108':
        return '4870'
    elif x["PRI_ICD_CD"] == 'J1100':
        return '4870'
    elif x["PRI_ICD_CD"] == 'J1000':
        return '4870'
    elif x["PRI_ICD_CD"] == 'J111':
        return '4871'
    elif x["PRI_ICD_CD"] == 'J1001':
        return '4871'
    elif x["PRI_ICD_CD"] == 'J09X9':
        return '4871'
    elif x["PRI_ICD_CD"] == 'J09X2':
        return '4871'
    elif x["PRI_ICD_CD"] == 'J1189':
        return '4878'
    elif x["PRI_ICD_CD"] == 'J1183':
        return '4878'
    elif x["PRI_ICD_CD"] == 'J1182':
        return '4878'
    elif x["PRI_ICD_CD"] == 'J1181':
        return '4878'
    elif x["PRI_ICD_CD"] == 'J112':
        return '4878'
    elif x["PRI_ICD_CD"] == 'J1089':
        return '4878'
    elif x["PRI_ICD_CD"] == 'J1083':
        return '4878'
    elif x["PRI_ICD_CD"] == 'J1082':
        return '4878'
    elif x["PRI_ICD_CD"] == 'J1081':
        return '4878'
    elif x["PRI_ICD_CD"] == 'J102':
        return '4878'
    elif x["PRI_ICD_CD"] == 'J9819':
        return '5180'
    elif x["PRI_ICD_CD"] == 'J9811':
        return '5180'
    elif x["PRI_ICD_CD"] == 'K011':
        return '5206'
    elif x["PRI_ICD_CD"] == 'K010':
        return '5206'
    elif x["PRI_ICD_CD"] == 'K006':
        return '5206'
    elif x["PRI_ICD_CD"] == 'K009':
        return '5209'
    elif x["PRI_ICD_CD"] == 'K089':
        return '5259'
    elif x["PRI_ICD_CD"] == 'K319':
        return '5379'
    elif x["PRI_ICD_CD"] == 'K352':
        return '5400'
    elif x["PRI_ICD_CD"] == 'K3589':
        return '5409'
    elif x["PRI_ICD_CD"] == 'K3580':
        return '5409'
    elif x["PRI_ICD_CD"] == 'K389':
        return '5439'
    elif x["PRI_ICD_CD"] == 'K388':
        return '5439'
    elif x["PRI_ICD_CD"] == 'K383':
        return '5439'
    elif x["PRI_ICD_CD"] == 'K382':
        return '5439'
    elif x["PRI_ICD_CD"] == 'K381':
        return '5439'
    elif x["PRI_ICD_CD"] == 'K420':
        return '5521'
    elif x["PRI_ICD_CD"] == 'K440':
        return '5523'
    elif x["PRI_ICD_CD"] == 'K460':
        return '5529'
    elif x["PRI_ICD_CD"] == 'K429':
        return '5531'
    elif x["PRI_ICD_CD"] == 'K449':
        return '5533'
    elif x["PRI_ICD_CD"] == 'K469':
        return '5539'
    elif x["PRI_ICD_CD"] == 'K50019':
        return '5550'
    elif x["PRI_ICD_CD"] == 'K50018':
        return '5550'
    elif x["PRI_ICD_CD"] == 'K50014':
        return '5550'
    elif x["PRI_ICD_CD"] == 'K50013':
        return '5550'
    elif x["PRI_ICD_CD"] == 'K50012':
        return '5550'
    elif x["PRI_ICD_CD"] == 'K50011':
        return '5550'
    elif x["PRI_ICD_CD"] == 'K5000':
        return '5550'
    elif x["PRI_ICD_CD"] == 'K50919':
        return '5559'
    elif x["PRI_ICD_CD"] == 'K50918':
        return '5559'
    elif x["PRI_ICD_CD"] == 'K50911':
        return '5559'
    elif x["PRI_ICD_CD"] == 'K5090':
        return '5559'
    elif x["PRI_ICD_CD"] == 'K529':
        return '5589'
    elif x["PRI_ICD_CD"] == 'K5289':
        return '5589'
    elif x["PRI_ICD_CD"] == 'K5660':
        return '5609'
    elif x["PRI_ICD_CD"] == 'K50912':
        return '5609'
    elif x["PRI_ICD_CD"] == 'B0609':
        return '5609'
    elif x["PRI_ICD_CD"] == 'B0602':
        return '5609'
    elif x["PRI_ICD_CD"] == 'K589':
        return '5641'
    elif x["PRI_ICD_CD"] == 'K580':
        return '5641'
    elif x["PRI_ICD_CD"] == 'K602':
        return '5650'
    elif x["PRI_ICD_CD"] == 'K601':
        return '5650'
    elif x["PRI_ICD_CD"] == 'K600':
        return '5650'
    elif x["PRI_ICD_CD"] == 'K605':
        return '5651'
    elif x["PRI_ICD_CD"] == 'K604':
        return '5651'
    elif x["PRI_ICD_CD"] == 'K603':
        return '5651'
    elif x["PRI_ICD_CD"] == 'K625':
        return '5693'
    elif x["PRI_ICD_CD"] == 'K929':
        return '5699'
    elif x["PRI_ICD_CD"] == 'K639':
        return '5699'
    elif x["PRI_ICD_CD"] == 'K7469':
        return '5715'
    elif x["PRI_ICD_CD"] == 'K7460':
        return '5715'
    elif x["PRI_ICD_CD"] == 'K740':
        return '5715'
    elif x["PRI_ICD_CD"] == 'K769':
        return '5739'
    elif x["PRI_ICD_CD"] == 'K810':
        return '5750'
    elif x["PRI_ICD_CD"] == 'K828':
        return '5758'
    elif x["PRI_ICD_CD"] == 'K829':
        return '5759'
    elif x["PRI_ICD_CD"] == 'K859':
        return '5770'
    elif x["PRI_ICD_CD"] == 'K858':
        return '5770'
    elif x["PRI_ICD_CD"] == 'K853':
        return '5770'
    elif x["PRI_ICD_CD"] == 'K852':
        return '5770'
    elif x["PRI_ICD_CD"] == 'K851':
        return '5770'
    elif x["PRI_ICD_CD"] == 'K850':
        return '5770'
    elif x["PRI_ICD_CD"] == 'K922':
        return '5789'
    elif x["PRI_ICD_CD"] == 'N179':
        return '5849'
    elif x["PRI_ICD_CD"] == 'N186':
        return '5856'
    elif x["PRI_ICD_CD"] == 'N202':
        return '5920'
    elif x["PRI_ICD_CD"] == 'B0879':
        return '5920'
    elif x["PRI_ICD_CD"] == 'B0870':
        return '5920'
    elif x["PRI_ICD_CD"] == 'N201':
        return '5921'
    elif x["PRI_ICD_CD"] == 'B0871':
        return '5921'
    elif x["PRI_ICD_CD"] == 'N29':
        return '5939'
    elif x["PRI_ICD_CD"] == 'N289':
        return '5939'
    elif x["PRI_ICD_CD"] == 'N329':
        return '5969'
    elif x["PRI_ICD_CD"] == 'N3289':
        return '5969'
    elif x["PRI_ICD_CD"] == 'N390':
        return '5990'
    elif x["PRI_ICD_CD"] == 'N429':
        return '6029'
    elif x["PRI_ICD_CD"] == 'N61':
        return '6110'
    elif x["PRI_ICD_CD"] == 'N62':
        return '6111'
    elif x["PRI_ICD_CD"] == 'N800':
        return '6170'
    elif x["PRI_ICD_CD"] == 'N809':
        return '6179'
    elif x["PRI_ICD_CD"] == 'N830':
        return '6200'
    elif x["PRI_ICD_CD"] == 'N8329':
        return '6202'
    elif x["PRI_ICD_CD"] == 'N8320':
        return '6202'
    elif x["PRI_ICD_CD"] == 'N858':
        return '6218'
    elif x["PRI_ICD_CD"] == 'N946':
        return '6253'
    elif x["PRI_ICD_CD"] == 'N945':
        return '6253'
    elif x["PRI_ICD_CD"] == 'N944':
        return '6253'
    elif x["PRI_ICD_CD"] == 'N393':
        return '6256'
    elif x["PRI_ICD_CD"] == 'N920':
        return '6262'
    elif x["PRI_ICD_CD"] == 'N921':
        return '6266'
    elif x["PRI_ICD_CD"] == 'N938':
        return '6268'
    elif x["PRI_ICD_CD"] == 'N925':
        return '6268'
    elif x["PRI_ICD_CD"] == 'N897':
        return '6268'
    elif x["PRI_ICD_CD"] == 'N939':
        return '6269'
    elif x["PRI_ICD_CD"] == 'N926':
        return '6269'
    elif x["PRI_ICD_CD"] == 'N950':
        return '6271'
    elif x["PRI_ICD_CD"] == 'N949':
        return '6299'
    elif x["PRI_ICD_CD"] == 'O2692':
        return '6469'
    elif x["PRI_ICD_CD"] == 'O2691':
        return '6469'
    elif x["PRI_ICD_CD"] == 'L03329':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L03326':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L03325':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L03324':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L03323':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L03322':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L03321':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L03319':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L03316':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L03315':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L03314':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L03313':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L03312':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L03311':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L02219':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L02216':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L02215':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L02214':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L02213':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L02212':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L02211':
        return '6822'
    elif x["PRI_ICD_CD"] == 'L03327':
        return '6825'
    elif x["PRI_ICD_CD"] == 'L03317':
        return '6825'
    elif x["PRI_ICD_CD"] == 'L0231':
        return '6825'
    elif x["PRI_ICD_CD"] == 'L03126':
        return '6826'
    elif x["PRI_ICD_CD"] == 'L03125':
        return '6826'
    elif x["PRI_ICD_CD"] == 'L03116':
        return '6826'
    elif x["PRI_ICD_CD"] == 'L03115':
        return '6826'
    elif x["PRI_ICD_CD"] == 'L02416':
        return '6826'
    elif x["PRI_ICD_CD"] == 'L02415':
        return '6826'
    elif x["PRI_ICD_CD"] == 'L03129':
        return '6827'
    elif x["PRI_ICD_CD"] == 'L03119':
        return '6827'
    elif x["PRI_ICD_CD"] == 'L02619':
        return '6827'
    elif x["PRI_ICD_CD"] == 'L02612':
        return '6827'
    elif x["PRI_ICD_CD"] == 'L02611':
        return '6827'
    elif x["PRI_ICD_CD"] == 'L983':
        return '6829'
    elif x["PRI_ICD_CD"] == 'L0391':
        return '6829'
    elif x["PRI_ICD_CD"] == 'L0390':
        return '6829'
    elif x["PRI_ICD_CD"] == 'L0291':
        return '6829'
    elif x["PRI_ICD_CD"] == 'L0502':
        return '6850'
    elif x["PRI_ICD_CD"] == 'L0501':
        return '6850'
    elif x["PRI_ICD_CD"] == 'L0592':
        return '6851'
    elif x["PRI_ICD_CD"] == 'L0591':
        return '6851'
    elif x["PRI_ICD_CD"] == 'L089':
        return '6869'
    elif x["PRI_ICD_CD"] == 'L729':
        return '7062'
    elif x["PRI_ICD_CD"] == 'L728':
        return '7062'
    elif x["PRI_ICD_CD"] == 'L723':
        return '7062'
    elif x["PRI_ICD_CD"] == 'L722':
        return '7062'
    elif x["PRI_ICD_CD"] == 'L720':
        return '7062'
    elif x["PRI_ICD_CD"] == 'B1921':
        return '7071'
    elif x["PRI_ICD_CD"] == 'M329':
        return '7100'
    elif x["PRI_ICD_CD"] == 'M328':
        return '7100'
    elif x["PRI_ICD_CD"] == 'M3219':
        return '7100'
    elif x["PRI_ICD_CD"] == 'M3215':
        return '7100'
    elif x["PRI_ICD_CD"] == 'M3214':
        return '7100'
    elif x["PRI_ICD_CD"] == 'M3213':
        return '7100'
    elif x["PRI_ICD_CD"] == 'M3212':
        return '7100'
    elif x["PRI_ICD_CD"] == 'M3211':
        return '7100'
    elif x["PRI_ICD_CD"] == 'M3210':
        return '7100'
    elif x["PRI_ICD_CD"] == 'M320':
        return '7100'
    elif x["PRI_ICD_CD"] == 'M069':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0689':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0688':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06879':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06872':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06871':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06869':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06862':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06861':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06859':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06852':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06851':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06849':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06842':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06841':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06839':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06832':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06831':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06829':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06822':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06821':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06819':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06812':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06811':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0680':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0639':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0638':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06379':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06372':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06371':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06369':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06362':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06361':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06359':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06352':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06351':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06349':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06342':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06341':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06339':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06332':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06331':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06329':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06322':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06321':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06319':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06312':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06311':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0630':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0629':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0628':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06279':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06272':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06271':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06269':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06262':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06261':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06259':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06252':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06251':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06249':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06242':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06241':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06239':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06232':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06231':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06229':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06222':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06221':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06219':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06212':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06211':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0620':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0609':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0608':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06079':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06072':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06071':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06069':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06062':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06061':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06059':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06052':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06051':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06049':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06042':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06041':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06039':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06032':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06031':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06029':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06022':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06021':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06019':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06012':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M06011':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0600':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M059':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0589':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05879':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05872':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05871':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05869':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05862':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05861':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05859':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05852':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05851':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05849':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05842':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05841':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05839':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05832':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05831':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05829':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05822':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05821':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05819':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05812':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05811':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0580':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0579':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05779':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05772':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05771':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05769':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05762':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05761':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05759':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05752':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05751':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05749':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05742':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05741':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05739':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05732':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05731':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05729':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05722':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05721':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05719':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05712':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05711':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0570':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0559':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05579':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05572':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05571':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05569':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05562':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05561':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05559':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05552':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05551':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05549':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05542':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05541':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05539':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05532':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05531':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05529':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05522':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05521':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05519':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05512':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05511':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0550':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0549':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05479':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05472':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05471':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05469':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05462':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05461':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05459':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05452':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05451':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05449':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05442':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05441':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05439':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05432':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05431':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05429':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05422':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05421':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05419':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05412':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M05411':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M0540':
        return '7140'
    elif x["PRI_ICD_CD"] == 'M23329':
        return '7172'
    elif x["PRI_ICD_CD"] == 'M23322':
        return '7172'
    elif x["PRI_ICD_CD"] == 'M23321':
        return '7172'
    elif x["PRI_ICD_CD"] == 'M23229':
        return '7172'
    elif x["PRI_ICD_CD"] == 'M23222':
        return '7172'
    elif x["PRI_ICD_CD"] == 'M23221':
        return '7172'
    elif x["PRI_ICD_CD"] == 'M23029':
        return '7172'
    elif x["PRI_ICD_CD"] == 'M23022':
        return '7172'
    elif x["PRI_ICD_CD"] == 'M23021':
        return '7172'
    elif x["PRI_ICD_CD"] == 'M23339':
        return '7173'
    elif x["PRI_ICD_CD"] == 'M23332':
        return '7173'
    elif x["PRI_ICD_CD"] == 'M23331':
        return '7173'
    elif x["PRI_ICD_CD"] == 'M23305':
        return '7173'
    elif x["PRI_ICD_CD"] == 'M23239':
        return '7173'
    elif x["PRI_ICD_CD"] == 'M23232':
        return '7173'
    elif x["PRI_ICD_CD"] == 'M23231':
        return '7173'
    elif x["PRI_ICD_CD"] == 'M23205':
        return '7173'
    elif x["PRI_ICD_CD"] == 'M23204':
        return '7173'
    elif x["PRI_ICD_CD"] == 'M23203':
        return '7173'
    elif x["PRI_ICD_CD"] == 'M23039':
        return '7173'
    elif x["PRI_ICD_CD"] == 'M23032':
        return '7173'
    elif x["PRI_ICD_CD"] == 'M23031':
        return '7173'
    elif x["PRI_ICD_CD"] == 'Q686':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M23309':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M23307':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M23306':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M23209':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M23207':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M23206':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M23009':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M23007':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M23006':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M23005':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M23004':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M23003':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M23002':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M23001':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M23000':
        return '7175'
    elif x["PRI_ICD_CD"] == 'M2342':
        return '7176'
    elif x["PRI_ICD_CD"] == 'M2341':
        return '7176'
    elif x["PRI_ICD_CD"] == 'M2340':
        return '7176'
    elif x["PRI_ICD_CD"] == 'M2242':
        return '7177'
    elif x["PRI_ICD_CD"] == 'M2241':
        return '7177'
    elif x["PRI_ICD_CD"] == 'M2240':
        return '7177'
    elif x["PRI_ICD_CD"] == 'M2392':
        return '7179'
    elif x["PRI_ICD_CD"] == 'M2391':
        return '7179'
    elif x["PRI_ICD_CD"] == 'M2390':
        return '7179'
    elif x["PRI_ICD_CD"] == 'M238X2':
        return '7179'
    elif x["PRI_ICD_CD"] == 'M2292':
        return '7179'
    elif x["PRI_ICD_CD"] == 'M2291':
        return '7179'
    elif x["PRI_ICD_CD"] == 'M2290':
        return '7179'
    elif x["PRI_ICD_CD"] == 'M488X9':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M488X8':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M488X7':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M488X6':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M488X5':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M488X4':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M488X3':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M488X2':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M488X1':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M459':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M458':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M457':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M456':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M455':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M454':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M453':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M452':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M451':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M450':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M081':
        return '7200'
    elif x["PRI_ICD_CD"] == 'M47893':
        return '7210'
    elif x["PRI_ICD_CD"] == 'M47892':
        return '7210'
    elif x["PRI_ICD_CD"] == 'M47891':
        return '7210'
    elif x["PRI_ICD_CD"] == 'M47813':
        return '7210'
    elif x["PRI_ICD_CD"] == 'M47812':
        return '7210'
    elif x["PRI_ICD_CD"] == 'M47811':
        return '7210'
    elif x["PRI_ICD_CD"] == 'M4723':
        return '7210'
    elif x["PRI_ICD_CD"] == 'M4722':
        return '7210'
    elif x["PRI_ICD_CD"] == 'M4721':
        return '7210'
    elif x["PRI_ICD_CD"] == 'M4713':
        return '7211'
    elif x["PRI_ICD_CD"] == 'M4712':
        return '7211'
    elif x["PRI_ICD_CD"] == 'M4711':
        return '7211'
    elif x["PRI_ICD_CD"] == 'M47029':
        return '7211'
    elif x["PRI_ICD_CD"] == 'M47022':
        return '7211'
    elif x["PRI_ICD_CD"] == 'M47021':
        return '7211'
    elif x["PRI_ICD_CD"] == 'M47019':
        return '7211'
    elif x["PRI_ICD_CD"] == 'M47016':
        return '7211'
    elif x["PRI_ICD_CD"] == 'M47015':
        return '7211'
    elif x["PRI_ICD_CD"] == 'M47014':
        return '7211'
    elif x["PRI_ICD_CD"] == 'M47013':
        return '7211'
    elif x["PRI_ICD_CD"] == 'M47012':
        return '7211'
    elif x["PRI_ICD_CD"] == 'M47011':
        return '7211'
    elif x["PRI_ICD_CD"] == 'M47898':
        return '7213'
    elif x["PRI_ICD_CD"] == 'M47897':
        return '7213'
    elif x["PRI_ICD_CD"] == 'M47896':
        return '7213'
    elif x["PRI_ICD_CD"] == 'M47818':
        return '7213'
    elif x["PRI_ICD_CD"] == 'M47817':
        return '7213'
    elif x["PRI_ICD_CD"] == 'M47816':
        return '7213'
    elif x["PRI_ICD_CD"] == 'M4728':
        return '7213'
    elif x["PRI_ICD_CD"] == 'M4727':
        return '7213'
    elif x["PRI_ICD_CD"] == 'M4726':
        return '7213'
    elif x["PRI_ICD_CD"] == 'M5023':
        return '7220'
    elif x["PRI_ICD_CD"] == 'M5022':
        return '7220'
    elif x["PRI_ICD_CD"] == 'M5021':
        return '7220'
    elif x["PRI_ICD_CD"] == 'M5020':
        return '7220'
    elif x["PRI_ICD_CD"] == 'M5033':
        return '7224'
    elif x["PRI_ICD_CD"] == 'M5032':
        return '7224'
    elif x["PRI_ICD_CD"] == 'M5031':
        return '7224'
    elif x["PRI_ICD_CD"] == 'M5030':
        return '7224'
    elif x["PRI_ICD_CD"] == 'M9971':
        return '7230'
    elif x["PRI_ICD_CD"] == 'M9970':
        return '7230'
    elif x["PRI_ICD_CD"] == 'M9961':
        return '7230'
    elif x["PRI_ICD_CD"] == 'M9960':
        return '7230'
    elif x["PRI_ICD_CD"] == 'M9951':
        return '7230'
    elif x["PRI_ICD_CD"] == 'M9950':
        return '7230'
    elif x["PRI_ICD_CD"] == 'M9941':
        return '7230'
    elif x["PRI_ICD_CD"] == 'M9940':
        return '7230'
    elif x["PRI_ICD_CD"] == 'M9931':
        return '7230'
    elif x["PRI_ICD_CD"] == 'M9930':
        return '7230'
    elif x["PRI_ICD_CD"] == 'M9921':
        return '7230'
    elif x["PRI_ICD_CD"] == 'M9920':
        return '7230'
    elif x["PRI_ICD_CD"] == 'M4803':
        return '7230'
    elif x["PRI_ICD_CD"] == 'M4802':
        return '7230'
    elif x["PRI_ICD_CD"] == 'M4801':
        return '7230'
    elif x["PRI_ICD_CD"] == 'M542':
        return '7231'
    elif x["PRI_ICD_CD"] == 'M5413':
        return '7234'
    elif x["PRI_ICD_CD"] == 'M5412':
        return '7234'
    elif x["PRI_ICD_CD"] == 'M5411':
        return '7234'
    elif x["PRI_ICD_CD"] == 'M5013':
        return '7234'
    elif x["PRI_ICD_CD"] == 'M5012':
        return '7234'
    elif x["PRI_ICD_CD"] == 'M5011':
        return '7234'
    elif x["PRI_ICD_CD"] == 'M5010':
        return '7234'
    elif x["PRI_ICD_CD"] == 'M5402':
        return '7236'
    elif x["PRI_ICD_CD"] == 'M5401':
        return '7236'
    elif x["PRI_ICD_CD"] == 'M5400':
        return '7236'
    elif x["PRI_ICD_CD"] == 'M546':
        return '7241'
    elif x["PRI_ICD_CD"] == 'M545':
        return '7242'
    elif x["PRI_ICD_CD"] == 'M5442':
        return '7242'
    elif x["PRI_ICD_CD"] == 'M5441':
        return '7243'
    elif x["PRI_ICD_CD"] == 'M5440':
        return '7243'
    elif x["PRI_ICD_CD"] == 'M5432':
        return '7243'
    elif x["PRI_ICD_CD"] == 'M5431':
        return '7243'
    elif x["PRI_ICD_CD"] == 'M5430':
        return '7243'
    elif x["PRI_ICD_CD"] == 'M5417':
        return '7244'
    elif x["PRI_ICD_CD"] == 'M5416':
        return '7244'
    elif x["PRI_ICD_CD"] == 'M5415':
        return '7244'
    elif x["PRI_ICD_CD"] == 'M5414':
        return '7244'
    elif x["PRI_ICD_CD"] == 'M5117':
        return '7244'
    elif x["PRI_ICD_CD"] == 'M5116':
        return '7244'
    elif x["PRI_ICD_CD"] == 'M5115':
        return '7244'
    elif x["PRI_ICD_CD"] == 'M5114':
        return '7244'
    elif x["PRI_ICD_CD"] == 'M549':
        return '7245'
    elif x["PRI_ICD_CD"] == 'M5489':
        return '7245'
    elif x["PRI_ICD_CD"] == 'M62830':
        return '7248'
    elif x["PRI_ICD_CD"] == 'M5409':
        return '7248'
    elif x["PRI_ICD_CD"] == 'M5408':
        return '7248'
    elif x["PRI_ICD_CD"] == 'M5407':
        return '7248'
    elif x["PRI_ICD_CD"] == 'M5406':
        return '7248'
    elif x["PRI_ICD_CD"] == 'M5405':
        return '7248'
    elif x["PRI_ICD_CD"] == 'M5404':
        return '7248'
    elif x["PRI_ICD_CD"] == 'M5403':
        return '7248'
    elif x["PRI_ICD_CD"] == 'M539':
        return '7249'
    elif x["PRI_ICD_CD"] == 'M5385':
        return '7249'
    elif x["PRI_ICD_CD"] == 'M5384':
        return '7249'
    elif x["PRI_ICD_CD"] == 'M5380':
        return '7249'
    elif x["PRI_ICD_CD"] == 'M4326':
        return '7249'
    elif x["PRI_ICD_CD"] == 'M4325':
        return '7249'
    elif x["PRI_ICD_CD"] == 'M4324':
        return '7249'
    elif x["PRI_ICD_CD"] == 'M4323':
        return '7249'
    elif x["PRI_ICD_CD"] == 'M4322':
        return '7249'
    elif x["PRI_ICD_CD"] == 'M4321':
        return '7249'
    elif x["PRI_ICD_CD"] == 'M4320':
        return '7249'
    elif x["PRI_ICD_CD"] == 'M7502':
        return '7260'
    elif x["PRI_ICD_CD"] == 'M7501':
        return '7260'
    elif x["PRI_ICD_CD"] == 'M7500':
        return '7260'
    elif x["PRI_ICD_CD"] == 'M7592':
        return '7262'
    elif x["PRI_ICD_CD"] == 'M7591':
        return '7262'
    elif x["PRI_ICD_CD"] == 'M7590':
        return '7262'
    elif x["PRI_ICD_CD"] == 'M7582':
        return '7262'
    elif x["PRI_ICD_CD"] == 'M7581':
        return '7262'
    elif x["PRI_ICD_CD"] == 'M7542':
        return '7262'
    elif x["PRI_ICD_CD"] == 'M7541':
        return '7262'
    elif x["PRI_ICD_CD"] == 'M7540':
        return '7262'
    elif x["PRI_ICD_CD"] == 'M7532':
        return '7262'
    elif x["PRI_ICD_CD"] == 'M7531':
        return '7262'
    elif x["PRI_ICD_CD"] == 'M7530':
        return '7262'
    elif x["PRI_ICD_CD"] == 'M25719':
        return '7262'
    elif x["PRI_ICD_CD"] == 'M25712':
        return '7262'
    elif x["PRI_ICD_CD"] == 'M25711':
        return '7262'
    elif x["PRI_ICD_CD"] == 'M7722':
        return '7264'
    elif x["PRI_ICD_CD"] == 'M7721':
        return '7264'
    elif x["PRI_ICD_CD"] == 'M7720':
        return '7264'
    elif x["PRI_ICD_CD"] == 'M7012':
        return '7264'
    elif x["PRI_ICD_CD"] == 'M7011':
        return '7264'
    elif x["PRI_ICD_CD"] == 'M7010':
        return '7264'
    elif x["PRI_ICD_CD"] == 'M25749':
        return '7264'
    elif x["PRI_ICD_CD"] == 'M25742':
        return '7264'
    elif x["PRI_ICD_CD"] == 'M25741':
        return '7264'
    elif x["PRI_ICD_CD"] == 'M25739':
        return '7264'
    elif x["PRI_ICD_CD"] == 'M25732':
        return '7264'
    elif x["PRI_ICD_CD"] == 'M25731':
        return '7264'
    elif x["PRI_ICD_CD"] == 'B2681':
        return '7271'
    elif x["PRI_ICD_CD"] == 'M797':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M791':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M609':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M6089':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M6088':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60879':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60872':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60871':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60869':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60862':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60861':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60859':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60852':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60851':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60849':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60842':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60841':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60839':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60832':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60831':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60829':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60822':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60821':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60819':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60812':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M60811':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M6080':
        return '7291'
    elif x["PRI_ICD_CD"] == 'M792':
        return '7292'
    elif x["PRI_ICD_CD"] == 'M5418':
        return '7292'
    elif x["PRI_ICD_CD"] == 'M5410':
        return '7292'
    elif x["PRI_ICD_CD"] == 'M79676':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79675':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79674':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79673':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79672':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79671':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79669':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79662':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79661':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79659':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79652':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79651':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79645':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79644':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79642':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79641':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79639':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79631':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79629':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79621':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79609':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79606':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79605':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79604':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79603':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79602':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M79601':
        return '7295'
    elif x["PRI_ICD_CD"] == 'M2012':
        return '7350'
    elif x["PRI_ICD_CD"] == 'M2011':
        return '7350'
    elif x["PRI_ICD_CD"] == 'M2010':
        return '7350'
    elif x["PRI_ICD_CD"] == 'M2022':
        return '7352'
    elif x["PRI_ICD_CD"] == 'M2021':
        return '7352'
    elif x["PRI_ICD_CD"] == 'M2020':
        return '7352'
    elif x["PRI_ICD_CD"] == 'M2042':
        return '7354'
    elif x["PRI_ICD_CD"] == 'M2041':
        return '7354'
    elif x["PRI_ICD_CD"] == 'M2040':
        return '7354'
    elif x["PRI_ICD_CD"] == 'M2062':
        return '7359'
    elif x["PRI_ICD_CD"] == 'M2061':
        return '7359'
    elif x["PRI_ICD_CD"] == 'M2060':
        return '7359'
    elif x["PRI_ICD_CD"] == 'M21869':
        return '7366'
    elif x["PRI_ICD_CD"] == 'M21862':
        return '7366'
    elif x["PRI_ICD_CD"] == 'M21861':
        return '7366'
    elif x["PRI_ICD_CD"] == 'M9981':
        return '7382'
    elif x["PRI_ICD_CD"] == 'M953':
        return '7382'
    elif x["PRI_ICD_CD"] == 'M4319':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4318':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4317':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4316':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4315':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4314':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4313':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4312':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4311':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4310':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4309':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4308':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4307':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4306':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4305':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4304':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4303':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4302':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4301':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M4300':
        return '7384'
    elif x["PRI_ICD_CD"] == 'M9903':
        return '7393'
    elif x["PRI_ICD_CD"] == 'R55':
        return '7802'
    elif x["PRI_ICD_CD"] == 'R42':
        return '7804'
    elif x["PRI_ICD_CD"] == 'Z753':
        return '7809'
    elif x["PRI_ICD_CD"] == 'Z750':
        return '7809'
    elif x["PRI_ICD_CD"] == 'Z048':
        return '7809'
    elif x["PRI_ICD_CD"] == 'R209':
        return '7820'
    elif x["PRI_ICD_CD"] == 'R208':
        return '7820'
    elif x["PRI_ICD_CD"] == 'R203':
        return '7820'
    elif x["PRI_ICD_CD"] == 'R202':
        return '7820'
    elif x["PRI_ICD_CD"] == 'R201':
        return '7820'
    elif x["PRI_ICD_CD"] == 'R200':
        return '7820'
    elif x["PRI_ICD_CD"] == 'R609':
        return '7823'
    elif x["PRI_ICD_CD"] == 'R601':
        return '7823'
    elif x["PRI_ICD_CD"] == 'R600':
        return '7823'
    elif x["PRI_ICD_CD"] == 'R51':
        return '7840'
    elif x["PRI_ICD_CD"] == 'G441':
        return '7840'
    elif x["PRI_ICD_CD"] == 'R05':
        return '7862'
    elif x["PRI_ICD_CD"] == 'B349':
        return '7908'
    elif x["PRI_ICD_CD"] == 'A749':
        return '7998'
    elif x["PRI_ICD_CD"] == 'R99':
        return '7999'
    elif x["PRI_ICD_CD"] == 'R69':
        return '7999'
    elif x["PRI_ICD_CD"] == 'B9710':
        return '7999'
    elif x["PRI_ICD_CD"] == 'S32059A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32058A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32052A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32051A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32050A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32049A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32048A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32042A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32041A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32040A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32039A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32038A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32032A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32031A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32030A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32029A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32028A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32022A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32021A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32020A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32019A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32018A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32012A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32011A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32010A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32008A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32002A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32001A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32000B':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S32000A':
        return '8054'
    elif x["PRI_ICD_CD"] == 'S72009A':
        return '8208'
    elif x["PRI_ICD_CD"] == 'S72002A':
        return '8208'
    elif x["PRI_ICD_CD"] == 'S72001A':
        return '8208'
    elif x["PRI_ICD_CD"] == 'S82099A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82092A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82091A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82046A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82045A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82044A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82043A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82042A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82041A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82036A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82035A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82034A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82033A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82032A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82031A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82026A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82025A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82024A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82023A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82022A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82021A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82016A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82015A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82014A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82013A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82012A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82011A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82009A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82002A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82001A':
        return '8220'
    elif x["PRI_ICD_CD"] == 'S82876A':
        return '8240'
    elif x["PRI_ICD_CD"] == 'S82875A':
        return '8240'
    elif x["PRI_ICD_CD"] == 'S82874A':
        return '8240'
    elif x["PRI_ICD_CD"] == 'S82873A':
        return '8240'
    elif x["PRI_ICD_CD"] == 'S82872A':
        return '8240'
    elif x["PRI_ICD_CD"] == 'S82871A':
        return '8240'
    elif x["PRI_ICD_CD"] == 'S8256XA':
        return '8240'
    elif x["PRI_ICD_CD"] == 'S8255XA':
        return '8240'
    elif x["PRI_ICD_CD"] == 'S8254XA':
        return '8240'
    elif x["PRI_ICD_CD"] == 'S8253XA':
        return '8240'
    elif x["PRI_ICD_CD"] == 'S8252XA':
        return '8240'
    elif x["PRI_ICD_CD"] == 'S8251XA':
        return '8240'
    elif x["PRI_ICD_CD"] == 'A7740':
        return '8240'
    elif x["PRI_ICD_CD"] == 'S8266XA':
        return '8242'
    elif x["PRI_ICD_CD"] == 'S8265XA':
        return '8242'
    elif x["PRI_ICD_CD"] == 'S8264XA':
        return '8242'
    elif x["PRI_ICD_CD"] == 'S8263XA':
        return '8242'
    elif x["PRI_ICD_CD"] == 'S8262XA':
        return '8242'
    elif x["PRI_ICD_CD"] == 'S8261XA':
        return '8242'
    elif x["PRI_ICD_CD"] == 'S82846A':
        return '8244'
    elif x["PRI_ICD_CD"] == 'S82845A':
        return '8244'
    elif x["PRI_ICD_CD"] == 'S82844A':
        return '8244'
    elif x["PRI_ICD_CD"] == 'S82843A':
        return '8244'
    elif x["PRI_ICD_CD"] == 'S82842A':
        return '8244'
    elif x["PRI_ICD_CD"] == 'S82841A':
        return '8244'
    elif x["PRI_ICD_CD"] == 'S82856A':
        return '8246'
    elif x["PRI_ICD_CD"] == 'S82855A':
        return '8246'
    elif x["PRI_ICD_CD"] == 'S82854A':
        return '8246'
    elif x["PRI_ICD_CD"] == 'S82853A':
        return '8246'
    elif x["PRI_ICD_CD"] == 'S82852A':
        return '8246'
    elif x["PRI_ICD_CD"] == 'S82851A':
        return '8246'
    elif x["PRI_ICD_CD"] == 'S89399A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89392A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89391A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89329A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89322A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89321A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89319A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89312A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89311A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89309A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89302A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89301A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89199A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89192A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89191A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89149A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89142A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89141A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89139A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89132A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89131A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89129A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89122A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89121A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89119A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89112A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89111A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89109A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89102A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S89101A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S82899A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S82892A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S82891A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S82399A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S82392A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S82391A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S82309A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S82302A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S82301A':
        return '8248'
    elif x["PRI_ICD_CD"] == 'S92066A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92065A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92064A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92063A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92062A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92061A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92056A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92055A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92054A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92053A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92052A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92051A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92046A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92045A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92044A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92043A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92042A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92041A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92036A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92035A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92034A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92033A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92032A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92031A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92026A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92025A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92024A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92023A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92022A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92021A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92016A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92015A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92014A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92013A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92012A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92011A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92009A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92002A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92001A':
        return '8250'
    elif x["PRI_ICD_CD"] == 'S92919A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92912A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92911A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92599A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92592A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92591A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92536A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92535A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92534A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92533A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92532A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92531A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92526A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92525A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92524A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92523A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92522A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92521A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92516A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92515A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92514A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92513A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92512A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92511A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92506A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92505A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92504A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92503A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92502A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92501A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92499A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92492A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92491A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92426A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92425A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92424A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92423A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92422A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92421A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92416A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92415A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92414A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92413A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92412A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92411A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92406A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92405A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92404A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92403A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92402A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S92401A':
        return '8260'
    elif x["PRI_ICD_CD"] == 'S8292XA':
        return '8270'
    elif x["PRI_ICD_CD"] == 'S8291XA':
        return '8270'
    elif x["PRI_ICD_CD"] == 'S8290XA':
        return '8270'
    elif x["PRI_ICD_CD"] == 'S83249A':
        return '8360'
    elif x["PRI_ICD_CD"] == 'S83242A':
        return '8360'
    elif x["PRI_ICD_CD"] == 'S83241A':
        return '8360'
    elif x["PRI_ICD_CD"] == 'S83239A':
        return '8360'
    elif x["PRI_ICD_CD"] == 'S83232A':
        return '8360'
    elif x["PRI_ICD_CD"] == 'S83231A':
        return '8360'
    elif x["PRI_ICD_CD"] == 'S83229A':
        return '8360'
    elif x["PRI_ICD_CD"] == 'S83222A':
        return '8360'
    elif x["PRI_ICD_CD"] == 'S83221A':
        return '8360'
    elif x["PRI_ICD_CD"] == 'S83219A':
        return '8360'
    elif x["PRI_ICD_CD"] == 'S83212A':
        return '8360'
    elif x["PRI_ICD_CD"] == 'S83211A':
        return '8360'
    elif x["PRI_ICD_CD"] == 'S8331XA':
        return '8361'
    elif x["PRI_ICD_CD"] == 'S83289A':
        return '8361'
    elif x["PRI_ICD_CD"] == 'S83282A':
        return '8361'
    elif x["PRI_ICD_CD"] == 'S83281A':
        return '8361'
    elif x["PRI_ICD_CD"] == 'S83279A':
        return '8361'
    elif x["PRI_ICD_CD"] == 'S83272A':
        return '8361'
    elif x["PRI_ICD_CD"] == 'S83271A':
        return '8361'
    elif x["PRI_ICD_CD"] == 'S83269A':
        return '8361'
    elif x["PRI_ICD_CD"] == 'S83262A':
        return '8361'
    elif x["PRI_ICD_CD"] == 'S83261A':
        return '8361'
    elif x["PRI_ICD_CD"] == 'S83259A':
        return '8361'
    elif x["PRI_ICD_CD"] == 'S83252A':
        return '8361'
    elif x["PRI_ICD_CD"] == 'S83251A':
        return '8361'
    elif x["PRI_ICD_CD"] == 'S8332XA':
        return '8362'
    elif x["PRI_ICD_CD"] == 'S8330XA':
        return '8362'
    elif x["PRI_ICD_CD"] == 'S83209A':
        return '8362'
    elif x["PRI_ICD_CD"] == 'S83207A':
        return '8362'
    elif x["PRI_ICD_CD"] == 'S83206A':
        return '8362'
    elif x["PRI_ICD_CD"] == 'S83205A':
        return '8362'
    elif x["PRI_ICD_CD"] == 'S83204A':
        return '8362'
    elif x["PRI_ICD_CD"] == 'S83203A':
        return '8362'
    elif x["PRI_ICD_CD"] == 'S83202A':
        return '8362'
    elif x["PRI_ICD_CD"] == 'S83201A':
        return '8362'
    elif x["PRI_ICD_CD"] == 'S83200A':
        return '8362'
    elif x["PRI_ICD_CD"] == 'S43429A':
        return '8404'
    elif x["PRI_ICD_CD"] == 'S43422A':
        return '8404'
    elif x["PRI_ICD_CD"] == 'S43421A':
        return '8404'
    elif x["PRI_ICD_CD"] == 'S43439A':
        return '8407'
    elif x["PRI_ICD_CD"] == 'S43432A':
        return '8407'
    elif x["PRI_ICD_CD"] == 'S43431A':
        return '8407'
    elif x["PRI_ICD_CD"] == 'S46819A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S46812A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S46811A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S46319A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S46312A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S46311A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S46219A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S46212A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S46211A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S46119A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S46112A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S46111A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S46019A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S46012A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S46011A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S4362XA':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S4361XA':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S4360XA':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S43499A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S43492A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S43491A':
        return '8408'
    elif x["PRI_ICD_CD"] == 'S46919A':
        return '8409'
    elif x["PRI_ICD_CD"] == 'S46912A':
        return '8409'
    elif x["PRI_ICD_CD"] == 'S46911A':
        return '8409'
    elif x["PRI_ICD_CD"] == 'S4392XA':
        return '8409'
    elif x["PRI_ICD_CD"] == 'S4391XA':
        return '8409'
    elif x["PRI_ICD_CD"] == 'S4390XA':
        return '8409'
    elif x["PRI_ICD_CD"] == 'S43409A':
        return '8409'
    elif x["PRI_ICD_CD"] == 'S43402A':
        return '8409'
    elif x["PRI_ICD_CD"] == 'S43401A':
        return '8409'
    elif x["PRI_ICD_CD"] == 'S76819A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S76812A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S76811A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S76319A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S76312A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S76311A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S76219A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S76212A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S76211A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S76119A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S76112A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S76111A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S76019A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S76012A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S76011A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S73199A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S73192A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S73191A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S73129A':
        return '8438'
    elif x["PRI_ICD_CD"] == 'S83429A':
        return '8440'
    elif x["PRI_ICD_CD"] == 'S83422A':
        return '8440'
    elif x["PRI_ICD_CD"] == 'S83421A':
        return '8440'
    elif x["PRI_ICD_CD"] == 'S83529A':
        return '8442'
    elif x["PRI_ICD_CD"] == 'S83522A':
        return '8442'
    elif x["PRI_ICD_CD"] == 'S83521A':
        return '8442'
    elif x["PRI_ICD_CD"] == 'S83519A':
        return '8442'
    elif x["PRI_ICD_CD"] == 'S83512S':
        return '8442'
    elif x["PRI_ICD_CD"] == 'S83512A':
        return '8442'
    elif x["PRI_ICD_CD"] == 'S83511A':
        return '8442'
    elif x["PRI_ICD_CD"] == 'S83509A':
        return '8442'
    elif x["PRI_ICD_CD"] == 'S83502A':
        return '8442'
    elif x["PRI_ICD_CD"] == 'S83501A':
        return '8442'
    elif x["PRI_ICD_CD"] == 'S86819A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S86812A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S86811A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S86319A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S86312A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S86311A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S86219A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S86212A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S86211A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S86119A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S86112A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S86111A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S838X9A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S838X2A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S838X1A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S83409A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S83402A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S83401A':
        return '8448'
    elif x["PRI_ICD_CD"] == 'S86919A':
        return '8449'
    elif x["PRI_ICD_CD"] == 'S86912A':
        return '8449'
    elif x["PRI_ICD_CD"] == 'S86911A':
        return '8449'
    elif x["PRI_ICD_CD"] == 'S8392XA':
        return '8449'
    elif x["PRI_ICD_CD"] == 'S8391XA':
        return '8449'
    elif x["PRI_ICD_CD"] == 'S8390XA':
        return '8449'
    elif x["PRI_ICD_CD"] == 'S161XXA':
        return '8470'
    elif x["PRI_ICD_CD"] == 'S138XXA':
        return '8470'
    elif x["PRI_ICD_CD"] == 'S134XXA':
        return '8470'
    elif x["PRI_ICD_CD"] == 'S238XXA':
        return '8471'
    elif x["PRI_ICD_CD"] == 'S233XXA':
        return '8471'
    elif x["PRI_ICD_CD"] == 'S335XXA':
        return '8472'
    elif x["PRI_ICD_CD"] == 'S239XXA':
        return '8479'
    elif x["PRI_ICD_CD"] == 'S139XXA':
        return '8479'
    elif x["PRI_ICD_CD"] == 'S39013A':
        return '8488'
    elif x["PRI_ICD_CD"] == 'S39012A':
        return '8488'
    elif x["PRI_ICD_CD"] == 'S39011A':
        return '8488'
    elif x["PRI_ICD_CD"] == 'S29019A':
        return '8488'
    elif x["PRI_ICD_CD"] == 'S29012A':
        return '8488'
    elif x["PRI_ICD_CD"] == 'S29011A':
        return '8488'
    elif x["PRI_ICD_CD"] == 'S039XXA':
        return '8488'
    elif x["PRI_ICD_CD"] == 'S038XXA':
        return '8488'
    elif x["PRI_ICD_CD"] == 'S61459A':
        return '8820'
    elif x["PRI_ICD_CD"] == 'S61452A':
        return '8820'
    elif x["PRI_ICD_CD"] == 'S61451A':
        return '8820'
    elif x["PRI_ICD_CD"] == 'S61439A':
        return '8820'
    elif x["PRI_ICD_CD"] == 'S61432A':
        return '8820'
    elif x["PRI_ICD_CD"] == 'S61431A':
        return '8820'
    elif x["PRI_ICD_CD"] == 'S61419A':
        return '8820'
    elif x["PRI_ICD_CD"] == 'S61412A':
        return '8820'
    elif x["PRI_ICD_CD"] == 'S61411A':
        return '8820'
    elif x["PRI_ICD_CD"] == 'S61409A':
        return '8820'
    elif x["PRI_ICD_CD"] == 'S61402A':
        return '8820'
    elif x["PRI_ICD_CD"] == 'S61401A':
        return '8820'
    elif x["PRI_ICD_CD"] == 'S61359A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61358A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61357A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61356A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61355A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61354A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61353A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61352A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61351A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61350A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61339A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61338A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61337A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61336A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61335A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61334A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61333A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61332A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61331A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61330A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61319A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61318A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61317A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61316A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61315A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61314A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61313A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61312A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61311A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61310A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61309A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61308A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61307A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61306A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61305A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61304A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61303A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61302A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61301A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61300A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61259A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61258A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61257A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61256A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61255A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61254A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61253A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61252A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61251A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61250A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61239A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61238A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61237A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61236A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61235A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61234A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61233A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61232A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61231A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61230A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61219A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61218A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61217A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61216A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61215A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61214A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61213A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61212A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61211A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61210A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61209A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61208A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61207A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61206A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61205A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61204A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61203A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61202A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61201A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61200A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61159A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61152A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61151A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61139A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61132A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61131A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61119A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61112A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61111A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61109A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61102A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61101A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61059A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61052A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61051A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61039A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61032A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61031A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61019A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61012A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61011A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61009A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61002A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'S61001A':
        return '8830'
    elif x["PRI_ICD_CD"] == 'A6929':
        return '8881'
    elif x["PRI_ICD_CD"] == 'A6923':
        return '8881'
    elif x["PRI_ICD_CD"] == 'A6922':
        return '8881'
    elif x["PRI_ICD_CD"] == 'A6921':
        return '8881'
    elif x["PRI_ICD_CD"] == 'A6920':
        return '8881'
    elif x["PRI_ICD_CD"] == 'S96919S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S96912S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S96911S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S96819S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S96812S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S96811S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S96219S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S96212S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S96211S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S96119S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S96112S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S96111S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S96019S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S96012S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S96011S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S96009S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93699S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93691S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93629S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93622S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93621S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93619S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93612S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93611S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93609S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93602S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93601S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93529S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93526S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93525S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93524S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93523S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93522S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93521S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93519S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93516S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93515S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93514S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93513S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93512S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93511S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93509S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93506S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93505S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93504S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93503S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93502S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93501S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93499S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93492S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93491S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93439S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93432S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93431S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93429S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93422S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93421S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93419S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93412S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93411S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93409S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93402S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S93401S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86919S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86912S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86911S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86819S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86812S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86811S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86319S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86312S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86219S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86212S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86211S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86119S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86112S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86111S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86019S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86012S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S86011S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S8392XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S8391XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S8390XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S838X9S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S838X2S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S838X1S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S8362XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S8361XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S8360XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83529S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83522S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83521S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83519S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83511S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83509S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83502S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83501S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83429S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83422S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83421S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83419S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83412S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83411S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83409S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83402S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83401S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S8332XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S8331XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S8330XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83289S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83282S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83281S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83279S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83272S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83271S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83269S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83262S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83261S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83259S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83252S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83251S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83249S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83242S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83241S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83239S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83232S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83231S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83229S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83222S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83221S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83219S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83212S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83211S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83209S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83207S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83206S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83205S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83204S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83203S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83202S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83201S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S83200S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76919S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76912S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76911S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76819S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76812S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76811S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76319S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76312S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76311S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76219S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76212S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76211S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76119S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76112S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76111S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76019S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76012S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S76011S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S73129S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S73122S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S73121S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S73119S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S73112S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S73111S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S73109S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S73102S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S73101S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S73046S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66919S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66912S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66911S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66819S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66812S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66811S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66519S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66518S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66517S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66516S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66515S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66514S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66513S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66512S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66511S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66510S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66419S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66412S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66411S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66319S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66318S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66317S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66316S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66315S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66314S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66313S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66312S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66311S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66310S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66219S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66212S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66211S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66119S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66118S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66117S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66116S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66115S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66114S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66113S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66112S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66111S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66110S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66019S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66012S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S66011S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S6392XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S6391XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S6390XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S638X9S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S638X2S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S638X1S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63699S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63698S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63697S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63696S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63695S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63694S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63693S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63692S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63691S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63690S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63689S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63682S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63681S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63659S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63658S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63657S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63656S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63655S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63654S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63653S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63652S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63651S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63650S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63649S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63642S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63641S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63639S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63638S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63637S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63636S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63635S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63634S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63633S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63632S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63631S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63630S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63629S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63622S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63621S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63619S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63618S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63617S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63616S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63615S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63614S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63613S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63612S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63611S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63610S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63609S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63602S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63601S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63599S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63592S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63591S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63529S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63522S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63521S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63519S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63512S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63511S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63509S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63502S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63501S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63499S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63498S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63497S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63496S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63495S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63494S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63493S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63492S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63491S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63490S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63439S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63438S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63437S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63436S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63435S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63434S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63433S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63432S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63431S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63430S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63429S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63428S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63427S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63426S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63425S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63424S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63423S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63422S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63421S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63420S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63419S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63418S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63417S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63416S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63415S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63414S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63413S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63412S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63411S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63410S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63409S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63408S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63407S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63406S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63405S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63404S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63403S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63402S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63401S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63400S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63399S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63392S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63391S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63339S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63332S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63331S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63329S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63322S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63321S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63319S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63312S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63311S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63309S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63302S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S63301S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56919S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56912S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56911S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56819S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56812S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56811S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56519S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56512S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56511S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56419S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56418S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56417S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56416S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56415S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56414S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56413S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56412S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56411S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56319S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56312S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56311S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56219S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56212S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56211S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56119S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56118S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56117S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56116S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56115S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56114S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56113S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56112S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56111S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56019S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56012S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S56011S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53499S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53492S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53491S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53449S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53442S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53441S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53439S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53432S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53431S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53429S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53422S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53421S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53419S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53412S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53411S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53409S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53402S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S53401S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S5332XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S5331XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S5330XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S5322XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S5321XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S5320XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46919S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46912S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46911S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46819S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46812S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46811S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46319S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46312S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46311S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46219S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46212S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46211S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46119S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46112S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46111S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46019S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46012S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S46011S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S4392XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S4391XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S4390XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S4382XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S4381XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S4380XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S4362XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S4361XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S4360XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S4352XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S4351XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S4350XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S43499S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S43492S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S43491S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S43439S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S43432S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S43431S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S43429S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S43422S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S43421S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S43419S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S43412S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S43411S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S43409S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S43402S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S43401S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S39013S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S39012S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S39011S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S339XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S338XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S336XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S335XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S334XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S29019S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S29012S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S29011S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S239XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S238XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S23429S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S23428S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S23421S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S23420S':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S2341XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S233XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S161XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S139XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S138XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S135XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S134XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S0911XS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S039XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S038XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S034XXS':
        return '9057'
    elif x["PRI_ICD_CD"] == 'S20219A':
        return '9221'
    elif x["PRI_ICD_CD"] == 'S20212A':
        return '9221'
    elif x["PRI_ICD_CD"] == 'S20211A':
        return '9221'
    elif x["PRI_ICD_CD"] == 'S4992XA':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S4991XA':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S4990XA':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S4982XA':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S4981XA':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S4980XA':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46999A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46992A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46991A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46909A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46902A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46901A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46899A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46892A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46891A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46809A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46802A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46801A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46399A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46392A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46391A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46309A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46302A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46301A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46299A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46292A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46291A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46209A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46202A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46201A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46199A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46192A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46191A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46109A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46102A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46101A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46099A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46092A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46091A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46009A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46002A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S46001A':
        return '9592'
    elif x["PRI_ICD_CD"] == 'S6981XA':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66999A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66992A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66991A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66909A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66902A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66901A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66899A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66892A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66891A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66809A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66802A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66801A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66599A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66598A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66597A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66596A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66595A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66594A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66593A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66592A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66591A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66590A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66509A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66508A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66507A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66506A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66505A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66504A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66503A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66502A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66501A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66500A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66499A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66492A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66491A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66409A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66402A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66401A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66399A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66398A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66397A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66396A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66395A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66394A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66393A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66392A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66391A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66390A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66309A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66308A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66307A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66306A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66305A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66304A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66303A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66302A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66301A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66300A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66299A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66292A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66291A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66202A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66201A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66199A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66198A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66197A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66196A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66195A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66194A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66193A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66192A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66191A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66190A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66109A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66108A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66107A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66106A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66105A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66104A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66103A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66102A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66101A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66100A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66099A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66092A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66091A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S59919A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S59912A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S59911A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S59909A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S59902A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S59901A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S59819A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S59812A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S59811A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S59809A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S59802A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S59801A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56999A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56992A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56991A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56909A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56902A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56901A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56899A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56892A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56891A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56809A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56802A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56801A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56599A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56592A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56591A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56509A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56502A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56501A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56499A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56498A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56497A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56496A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56495A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56494A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56493A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56492A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56491A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56409A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56408A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56407A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56406A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56405A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56404A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56403A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56402A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56401A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56399A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56392A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56391A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56309A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56302A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56301A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56299A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56292A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56291A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56209A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56202A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56201A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56199A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56198A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56197A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56196A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56195A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56194A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56193A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56192A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56191A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56109A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56108A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56107A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56106A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56105A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56104A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56103A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56102A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56101A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56099A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56092A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56091A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56009A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56002A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S56001A':
        return '9593'
    elif x["PRI_ICD_CD"] == 'S66209A':
        return '9594'
    elif x["PRI_ICD_CD"] == 'S66009A':
        return '9594'
    elif x["PRI_ICD_CD"] == 'S66002A':
        return '9594'
    elif x["PRI_ICD_CD"] == 'S66001A':
        return '9594'
    elif x["PRI_ICD_CD"] == 'S6992XA':
        return '9595'
    elif x["PRI_ICD_CD"] == 'S6991XA':
        return '9595'
    elif x["PRI_ICD_CD"] == 'S6990XA':
        return '9595'
    elif x["PRI_ICD_CD"] == 'S6982XA':
        return '9595'
    elif x["PRI_ICD_CD"] == 'S6980XA':
        return '9595'
    elif x["PRI_ICD_CD"] == 'S79929A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S79922A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S79921A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S79919A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S79912A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S79911A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S79829A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S79822A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S79821A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S79819A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S79812A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S79811A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76999A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76992A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76991A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76909A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76902A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76901A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76899A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76892A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76891A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76809A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76802A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76801A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76399A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76392A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76391A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76309A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76302A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76301A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76299A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76292A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76291A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76209A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76202A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76201A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76199A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76192A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76191A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76109A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76102A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76101A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76099A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76092A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76091A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76009A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76002A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S76001A':
        return '9596'
    elif x["PRI_ICD_CD"] == 'S99929A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S99922A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S99921A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S99919A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S99912A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S99911A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S99829A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S99822A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S99821A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S99819A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S99812A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S99811A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96999A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96992A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96991A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96909A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96902A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96901A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96899A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96892A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96891A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96809A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96802A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96801A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96299A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96292A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96291A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96209A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96202A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96201A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96199A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96192A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96191A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96109A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96102A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96101A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96099A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96092A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96091A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96002A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S96001A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S8992XA':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S8991XA':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S8990XA':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S8982XA':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S8981XA':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S8980XA':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86999A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86992A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86991A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86909A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86902A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86901A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86899A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86892A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86891A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86809A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86802A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86801A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86399A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86392A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86391A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86311S':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86309A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86302A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86301A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86299A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86292A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86291A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86209A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86202A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86201A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86199A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86192A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86191A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86109A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86102A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86101A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86099A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86092A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86091A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86009A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86002A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'S86001A':
        return '9597'
    elif x["PRI_ICD_CD"] == 'T07':
        return '9598'
    elif x["PRI_ICD_CD"] == 'T1491':
        return '9599'
    elif x["PRI_ICD_CD"] == 'T1490':
        return '9599'
    elif x["PRI_ICD_CD"] == 'T148':
        return '9599'
    elif x["PRI_ICD_CD"] == 'T473X6D':
        return '9952'
    elif x["PRI_ICD_CD"] == 'A563':
        return '9952'
    elif x["PRI_ICD_CD"] == 'T889XXA':
        return '9999'
    elif x["PRI_ICD_CD"] == 'T888XXA':
        return '9999'
    elif x["PRI_ICD_CD"] == 'T887XXA':
        return '9999'
    elif x["PRI_ICD_CD"] == 'T884XXA':
        return '9999'
    elif x["PRI_ICD_CD"] == 'T8181XA':
        return '9999'
    elif x["PRI_ICD_CD"] == 'C8599':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C8590':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C8589':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C8580':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C8529':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C8520':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C8519':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C8510':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C84Z9':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C84Z0':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C84A9':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C84A0':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C8499':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C8490':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C8259':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C8250':
        return '20280'
    elif x["PRI_ICD_CD"] == 'C9000':
        return '20300'
    elif x["PRI_ICD_CD"] == 'E138':
        return '24990'
    elif x["PRI_ICD_CD"] == 'E098':
        return '24990'
    elif x["PRI_ICD_CD"] == 'E088':
        return '24990'
    elif x["PRI_ICD_CD"] == 'E119':
        return '25000'
    elif x["PRI_ICD_CD"] == 'E1169':
        return '25000'
    elif x["PRI_ICD_CD"] == 'E1165':
        return '25080'
    elif x["PRI_ICD_CD"] == 'E11649':
        return '25080'
    elif x["PRI_ICD_CD"] == 'E11638':
        return '25080'
    elif x["PRI_ICD_CD"] == 'E11630':
        return '25080'
    elif x["PRI_ICD_CD"] == 'E11628':
        return '25080'
    elif x["PRI_ICD_CD"] == 'E11622':
        return '25080'
    elif x["PRI_ICD_CD"] == 'E11621':
        return '25080'
    elif x["PRI_ICD_CD"] == 'E11620':
        return '25080'
    elif x["PRI_ICD_CD"] == 'E11618':
        return '25080'
    elif x["PRI_ICD_CD"] == 'M1029':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M1028':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10279':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10272':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10271':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10269':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10262':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10261':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10259':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10252':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10251':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10249':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10242':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10241':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10239':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10232':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10231':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10229':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10222':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10221':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10219':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10212':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10211':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M1020':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M1009':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M1008':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10079':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10072':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10071':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10069':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10062':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10061':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10059':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10052':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10051':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10049':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10042':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10041':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10039':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10032':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10031':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10029':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10022':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10021':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10019':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10012':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M10011':
        return '27401'
    elif x["PRI_ICD_CD"] == 'M1000':
        return '27401'
    elif x["PRI_ICD_CD"] == 'N200':
        return '27411'
    elif x["PRI_ICD_CD"] == 'E669':
        return '27800'
    elif x["PRI_ICD_CD"] == 'E668':
        return '27800'
    elif x["PRI_ICD_CD"] == 'E661':
        return '27800'
    elif x["PRI_ICD_CD"] == 'E6609':
        return '27800'
    elif x["PRI_ICD_CD"] == 'E6601':
        return '27801'
    elif x["PRI_ICD_CD"] == 'F320':
        return '29621'
    elif x["PRI_ICD_CD"] == 'F321':
        return '29622'
    elif x["PRI_ICD_CD"] == 'F322':
        return '29623'
    elif x["PRI_ICD_CD"] == 'F323':
        return '29624'
    elif x["PRI_ICD_CD"] == 'F339':
        return '29630'
    elif x["PRI_ICD_CD"] == 'F3340':
        return '29630'
    elif x["PRI_ICD_CD"] == 'F330':
        return '29631'
    elif x["PRI_ICD_CD"] == 'F331':
        return '29632'
    elif x["PRI_ICD_CD"] == 'F332':
        return '29633'
    elif x["PRI_ICD_CD"] == 'F3189':
        return '29640'
    elif x["PRI_ICD_CD"] == 'F3110':
        return '29640'
    elif x["PRI_ICD_CD"] == 'F310':
        return '29640'
    elif x["PRI_ICD_CD"] == 'F319':
        return '29680'
    elif x["PRI_ICD_CD"] == 'F328':
        return '29682'
    elif x["PRI_ICD_CD"] == 'F3181':
        return '29689'
    elif x["PRI_ICD_CD"] == 'F419':
        return '30000'
    elif x["PRI_ICD_CD"] == 'F410':
        return '30001'
    elif x["PRI_ICD_CD"] == 'F411':
        return '30002'
    elif x["PRI_ICD_CD"] == 'F418':
        return '30009'
    elif x["PRI_ICD_CD"] == 'F413':
        return '30009'
    elif x["PRI_ICD_CD"] == 'F6812':
        return '30151'
    elif x["PRI_ICD_CD"] == 'F6810':
        return '30151'
    elif x["PRI_ICD_CD"] == 'F1020':
        return '30392'
    elif x["PRI_ICD_CD"] == 'F1129':
        return '30400'
    elif x["PRI_ICD_CD"] == 'F11251':
        return '30400'
    elif x["PRI_ICD_CD"] == 'F11250':
        return '30400'
    elif x["PRI_ICD_CD"] == 'F1124':
        return '30400'
    elif x["PRI_ICD_CD"] == 'F1123':
        return '30400'
    elif x["PRI_ICD_CD"] == 'F11229':
        return '30400'
    elif x["PRI_ICD_CD"] == 'F11221':
        return '30400'
    elif x["PRI_ICD_CD"] == 'F11220':
        return '30400'
    elif x["PRI_ICD_CD"] == 'F1120':
        return '30402'
    elif x["PRI_ICD_CD"] == 'F1920':
        return '30462'
    elif x["PRI_ICD_CD"] == 'F4322':
        return '30924'
    elif x["PRI_ICD_CD"] == 'F4323':
        return '30928'
    elif x["PRI_ICD_CD"] == 'F4312':
        return '30981'
    elif x["PRI_ICD_CD"] == 'F4311':
        return '30981'
    elif x["PRI_ICD_CD"] == 'F4310':
        return '30981'
    elif x["PRI_ICD_CD"] == 'G4730':
        return '32720'
    elif x["PRI_ICD_CD"] == 'G8921':
        return '33821'
    elif x["PRI_ICD_CD"] == 'G43009':
        return '34610'
    elif x["PRI_ICD_CD"] == 'G43909':
        return '34690'
    elif x["PRI_ICD_CD"] == 'H33009':
        return '36100'
    elif x["PRI_ICD_CD"] == 'H33003':
        return '36100'
    elif x["PRI_ICD_CD"] == 'H33002':
        return '36100'
    elif x["PRI_ICD_CD"] == 'H33001':
        return '36100'
    elif x["PRI_ICD_CD"] == 'H33059':
        return '36107'
    elif x["PRI_ICD_CD"] == 'H33053':
        return '36107'
    elif x["PRI_ICD_CD"] == 'H33052':
        return '36107'
    elif x["PRI_ICD_CD"] == 'H33051':
        return '36107'
    elif x["PRI_ICD_CD"] == 'H2513':
        return '36616'
    elif x["PRI_ICD_CD"] == 'H2512':
        return '36616'
    elif x["PRI_ICD_CD"] == 'H2511':
        return '36616'
    elif x["PRI_ICD_CD"] == 'H2510':
        return '36616'
    elif x["PRI_ICD_CD"] == 'H109':
        return '37200'
    elif x["PRI_ICD_CD"] == 'H1033':
        return '37200'
    elif x["PRI_ICD_CD"] == 'H1032':
        return '37200'
    elif x["PRI_ICD_CD"] == 'H1031':
        return '37200'
    elif x["PRI_ICD_CD"] == 'H1030':
        return '37200'
    elif x["PRI_ICD_CD"] == 'H1013':
        return '37200'
    elif x["PRI_ICD_CD"] == 'H81399':
        return '38610'
    elif x["PRI_ICD_CD"] == 'H81393':
        return '38610'
    elif x["PRI_ICD_CD"] == 'H81392':
        return '38610'
    elif x["PRI_ICD_CD"] == 'H81391':
        return '38610'
    elif x["PRI_ICD_CD"] == 'H8113':
        return '38611'
    elif x["PRI_ICD_CD"] == 'H8112':
        return '38611'
    elif x["PRI_ICD_CD"] == 'H8111':
        return '38611'
    elif x["PRI_ICD_CD"] == 'H8110':
        return '38611'
    elif x["PRI_ICD_CD"] == 'I110':
        return '40291'
    elif x["PRI_ICD_CD"] == 'I220':
        return '41011'
    elif x["PRI_ICD_CD"] == 'I2102':
        return '41011'
    elif x["PRI_ICD_CD"] == 'I2101':
        return '41011'
    elif x["PRI_ICD_CD"] == 'I214':
        return '41072'
    elif x["PRI_ICD_CD"] == 'I213':
        return '41092'
    elif x["PRI_ICD_CD"] == 'I2699':
        return '41519'
    elif x["PRI_ICD_CD"] == 'I4891':
        return '42731'
    elif x["PRI_ICD_CD"] == 'I482':
        return '42731'
    elif x["PRI_ICD_CD"] == 'I480':
        return '42731'
    elif x["PRI_ICD_CD"] == 'I5020':
        return '42820'
    elif x["PRI_ICD_CD"] == 'I513':
        return '42979'
    elif x["PRI_ICD_CD"] == 'I238':
        return '42979'
    elif x["PRI_ICD_CD"] == 'I237':
        return '42979'
    elif x["PRI_ICD_CD"] == 'I236':
        return '42979'
    elif x["PRI_ICD_CD"] == 'I233':
        return '42979'
    elif x["PRI_ICD_CD"] == 'I230':
        return '42979'
    elif x["PRI_ICD_CD"] == 'I639':
        return '43491'
    elif x["PRI_ICD_CD"] == 'I638':
        return '43491'
    elif x["PRI_ICD_CD"] == 'I63549':
        return '43491'
    elif x["PRI_ICD_CD"] == 'I63542':
        return '43491'
    elif x["PRI_ICD_CD"] == 'I63541':
        return '43491'
    elif x["PRI_ICD_CD"] == 'I63539':
        return '43491'
    elif x["PRI_ICD_CD"] == 'I63532':
        return '43491'
    elif x["PRI_ICD_CD"] == 'I63531':
        return '43491'
    elif x["PRI_ICD_CD"] == 'I63529':
        return '43491'
    elif x["PRI_ICD_CD"] == 'I63522':
        return '43491'
    elif x["PRI_ICD_CD"] == 'I63521':
        return '43491'
    elif x["PRI_ICD_CD"] == 'I63519':
        return '43491'
    elif x["PRI_ICD_CD"] == 'I63512':
        return '43491'
    elif x["PRI_ICD_CD"] == 'I63511':
        return '43491'
    elif x["PRI_ICD_CD"] == 'I6350':
        return '43491'
    elif x["PRI_ICD_CD"] == 'I744':
        return '44422'
    elif x["PRI_ICD_CD"] == 'I743':
        return '44422'
    elif x["PRI_ICD_CD"] == 'I82409':
        return '45340'
    elif x["PRI_ICD_CD"] == 'I82403':
        return '45340'
    elif x["PRI_ICD_CD"] == 'I82402':
        return '45340'
    elif x["PRI_ICD_CD"] == 'I82401':
        return '45340'
    elif x["PRI_ICD_CD"] == 'J040':
        return '46400'
    elif x["PRI_ICD_CD"] == 'J3501':
        return '47400'
    elif x["PRI_ICD_CD"] == 'J101':
        return '48812'
    elif x["PRI_ICD_CD"] == 'J449':
        return '49120'
    elif x["PRI_ICD_CD"] == 'J4550':
        return '49310'
    elif x["PRI_ICD_CD"] == 'J4540':
        return '49310'
    elif x["PRI_ICD_CD"] == 'J4530':
        return '49310'
    elif x["PRI_ICD_CD"] == 'J4520':
        return '49310'
    elif x["PRI_ICD_CD"] == 'J4551':
        return '49312'
    elif x["PRI_ICD_CD"] == 'J4541':
        return '49312'
    elif x["PRI_ICD_CD"] == 'J4531':
        return '49312'
    elif x["PRI_ICD_CD"] == 'J4521':
        return '49312'
    elif x["PRI_ICD_CD"] == 'J45998':
        return '49390'
    elif x["PRI_ICD_CD"] == 'J45909':
        return '49390'
    elif x["PRI_ICD_CD"] == 'J9692':
        return '51881'
    elif x["PRI_ICD_CD"] == 'J9691':
        return '51881'
    elif x["PRI_ICD_CD"] == 'J9690':
        return '51881'
    elif x["PRI_ICD_CD"] == 'J9602':
        return '51881'
    elif x["PRI_ICD_CD"] == 'J9601':
        return '51881'
    elif x["PRI_ICD_CD"] == 'J9600':
        return '51881'
    elif x["PRI_ICD_CD"] == 'J984':
        return '51889'
    elif x["PRI_ICD_CD"] == 'K029':
        return '52100'
    elif x["PRI_ICD_CD"] == 'K219':
        return '53081'
    elif x["PRI_ICD_CD"] == 'K4030':
        return '55010'
    elif x["PRI_ICD_CD"] == 'K4000':
        return '55012'
    elif x["PRI_ICD_CD"] == 'K4090':
        return '55090'
    elif x["PRI_ICD_CD"] == 'K4091':
        return '55091'
    elif x["PRI_ICD_CD"] == 'K4020':
        return '55092'
    elif x["PRI_ICD_CD"] == 'K430':
        return '55221'
    elif x["PRI_ICD_CD"] == 'K432':
        return '55321'
    elif x["PRI_ICD_CD"] == 'K439':
        return '55329'
    elif x["PRI_ICD_CD"] == 'K435':
        return '55329'
    elif x["PRI_ICD_CD"] == 'K5669':
        return '56089'
    elif x["PRI_ICD_CD"] == 'K51312':
        return '56089'
    elif x["PRI_ICD_CD"] == 'K5790':
        return '56210'
    elif x["PRI_ICD_CD"] == 'K5730':
        return '56210'
    elif x["PRI_ICD_CD"] == 'K5792':
        return '56211'
    elif x["PRI_ICD_CD"] == 'K5780':
        return '56211'
    elif x["PRI_ICD_CD"] == 'K5732':
        return '56211'
    elif x["PRI_ICD_CD"] == 'K5720':
        return '56211'
    elif x["PRI_ICD_CD"] == 'K629':
        return '56949'
    elif x["PRI_ICD_CD"] == 'K6289':
        return '56949'
    elif x["PRI_ICD_CD"] == 'K627':
        return '56949'
    elif x["PRI_ICD_CD"] == 'K8012':
        return '57400'
    elif x["PRI_ICD_CD"] == 'K8000':
        return '57400'
    elif x["PRI_ICD_CD"] == 'K8018':
        return '57410'
    elif x["PRI_ICD_CD"] == 'K8010':
        return '57410'
    elif x["PRI_ICD_CD"] == 'K8080':
        return '57420'
    elif x["PRI_ICD_CD"] == 'K8020':
        return '57420'
    elif x["PRI_ICD_CD"] == 'K819':
        return '57510'
    elif x["PRI_ICD_CD"] == 'K811':
        return '57511'
    elif x["PRI_ICD_CD"] == 'N539':
        return '60889'
    elif x["PRI_ICD_CD"] == 'N538':
        return '60889'
    elif x["PRI_ICD_CD"] == 'N5312':
        return '60889'
    elif x["PRI_ICD_CD"] == 'N508':
        return '60889'
    elif x["PRI_ICD_CD"] == 'N503':
        return '60889'
    elif x["PRI_ICD_CD"] == 'N448':
        return '60889'
    elif x["PRI_ICD_CD"] == 'N442':
        return '60889'
    elif x["PRI_ICD_CD"] == 'N441':
        return '60889'
    elif x["PRI_ICD_CD"] == 'N63':
        return '61172'
    elif x["PRI_ICD_CD"] == 'N8111':
        return '61801'
    elif x["PRI_ICD_CD"] == 'N8110':
        return '61801'
    elif x["PRI_ICD_CD"] == 'O039':
        return '63492'
    elif x["PRI_ICD_CD"] == 'O6003':
        return '64403'
    elif x["PRI_ICD_CD"] == 'O6002':
        return '64403'
    elif x["PRI_ICD_CD"] == 'O99354':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O99353':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O99352':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O99351':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O2993':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O2992':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O2991':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O298X3':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O298X2':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O298X1':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O2963':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O2962':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O2961':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O295X3':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O295X2':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O295X1':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O2943':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O2942':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O2941':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O293X3':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O293X2':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O293X1':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29293':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29292':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29291':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29213':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29212':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29211':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29193':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29192':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29191':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29123':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29122':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29121':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29113':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29112':
        return '64681'
    else:
        return 'Derive_2'


def f_ICD10to9_2(x):
    if x["ICD10to9_1"] != "Derive_2":
        return x["ICD10to9_1"]
    elif x["PRI_ICD_CD"] == 'O29111':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29093':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29092':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29091':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29023':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29022':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29021':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29013':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29012':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O29011':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O2693':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O2686':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O2672':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O26713':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O26712':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O26711':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O2633':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O2632':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O2631':
        return '64681'
    elif x["PRI_ICD_CD"] == 'O26813':
        return '64683'
    elif x["PRI_ICD_CD"] == 'O26812':
        return '64683'
    elif x["PRI_ICD_CD"] == 'O26811':
        return '64683'
    elif x["PRI_ICD_CD"] == 'O2643':
        return '64683'
    elif x["PRI_ICD_CD"] == 'O2642':
        return '64683'
    elif x["PRI_ICD_CD"] == 'O2641':
        return '64683'
    elif x["PRI_ICD_CD"] == 'O2613':
        return '64683'
    elif x["PRI_ICD_CD"] == 'O2612':
        return '64683'
    elif x["PRI_ICD_CD"] == 'O2611':
        return '64683'
    elif x["PRI_ICD_CD"] == 'O2690':
        return '64690'
    elif x["PRI_ICD_CD"] == 'O9989':
        return '64693'
    elif x["PRI_ICD_CD"] == 'O99810':
        return '64883'
    elif x["PRI_ICD_CD"] == 'O24419':
        return '64883'
    elif x["PRI_ICD_CD"] == 'O30003':
        return '65103'
    elif x["PRI_ICD_CD"] == 'O30002':
        return '65103'
    elif x["PRI_ICD_CD"] == 'O30001':
        return '65103'
    elif x["PRI_ICD_CD"] == 'O3421':
        return '65423'
    elif x["PRI_ICD_CD"] == 'O82':
        return '66971'
    elif x["PRI_ICD_CD"] == 'O26893':
        return '67903'
    elif x["PRI_ICD_CD"] == 'O26892':
        return '67903'
    elif x["PRI_ICD_CD"] == 'O26891':
        return '67903'
    elif x["PRI_ICD_CD"] == 'L732':
        return '70583'
    elif x["PRI_ICD_CD"] == 'M150':
        return '71509'
    elif x["PRI_ICD_CD"] == 'M19019':
        return '71511'
    elif x["PRI_ICD_CD"] == 'M19012':
        return '71511'
    elif x["PRI_ICD_CD"] == 'M19011':
        return '71511'
    elif x["PRI_ICD_CD"] == 'M19049':
        return '71514'
    elif x["PRI_ICD_CD"] == 'M19042':
        return '71514'
    elif x["PRI_ICD_CD"] == 'M19041':
        return '71514'
    elif x["PRI_ICD_CD"] == 'M1812':
        return '71514'
    elif x["PRI_ICD_CD"] == 'M1811':
        return '71514'
    elif x["PRI_ICD_CD"] == 'M1810':
        return '71514'
    elif x["PRI_ICD_CD"] == 'M180':
        return '71514'
    elif x["PRI_ICD_CD"] == 'M1612':
        return '71515'
    elif x["PRI_ICD_CD"] == 'M1611':
        return '71515'
    elif x["PRI_ICD_CD"] == 'M1610':
        return '71515'
    elif x["PRI_ICD_CD"] == 'M160':
        return '71515'
    elif x["PRI_ICD_CD"] == 'M1712':
        return '71516'
    elif x["PRI_ICD_CD"] == 'M1711':
        return '71516'
    elif x["PRI_ICD_CD"] == 'M1710':
        return '71516'
    elif x["PRI_ICD_CD"] == 'M170':
        return '71516'
    elif x["PRI_ICD_CD"] == 'M19079':
        return '71517'
    elif x["PRI_ICD_CD"] == 'M19072':
        return '71517'
    elif x["PRI_ICD_CD"] == 'M19071':
        return '71517'
    elif x["PRI_ICD_CD"] == 'M1990':
        return '71590'
    elif x["PRI_ICD_CD"] == 'M159':
        return '71590'
    elif x["PRI_ICD_CD"] == 'M169':
        return '71595'
    elif x["PRI_ICD_CD"] == 'M179':
        return '71596'
    elif x["PRI_ICD_CD"] == 'M23302':
        return '71740'
    elif x["PRI_ICD_CD"] == 'M23301':
        return '71740'
    elif x["PRI_ICD_CD"] == 'M23300':
        return '71740'
    elif x["PRI_ICD_CD"] == 'M23269':
        return '71740'
    elif x["PRI_ICD_CD"] == 'M23262':
        return '71740'
    elif x["PRI_ICD_CD"] == 'M23261':
        return '71740'
    elif x["PRI_ICD_CD"] == 'M23202':
        return '71740'
    elif x["PRI_ICD_CD"] == 'M23201':
        return '71740'
    elif x["PRI_ICD_CD"] == 'M23200':
        return '71740'
    elif x["PRI_ICD_CD"] == 'M238X9':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M238X1':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23679':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23672':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23671':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23649':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23642':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23641':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23639':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23632':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23631':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23629':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23622':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23621':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23619':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23612':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23611':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23609':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23602':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M23601':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M228X9':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M228X2':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M228X1':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M223X9':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M223X2':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M223X1':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M222X9':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M222X2':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M222X1':
        return '71789'
    elif x["PRI_ICD_CD"] == 'M25319':
        return '71881'
    elif x["PRI_ICD_CD"] == 'M25312':
        return '71881'
    elif x["PRI_ICD_CD"] == 'M25311':
        return '71881'
    elif x["PRI_ICD_CD"] == 'M25219':
        return '71881'
    elif x["PRI_ICD_CD"] == 'M25212':
        return '71881'
    elif x["PRI_ICD_CD"] == 'M25211':
        return '71881'
    elif x["PRI_ICD_CD"] == 'M24819':
        return '71881'
    elif x["PRI_ICD_CD"] == 'M24812':
        return '71881'
    elif x["PRI_ICD_CD"] == 'M24811':
        return '71881'
    elif x["PRI_ICD_CD"] == 'M25339':
        return '71883'
    elif x["PRI_ICD_CD"] == 'M25332':
        return '71883'
    elif x["PRI_ICD_CD"] == 'M25331':
        return '71883'
    elif x["PRI_ICD_CD"] == 'M25239':
        return '71883'
    elif x["PRI_ICD_CD"] == 'M25232':
        return '71883'
    elif x["PRI_ICD_CD"] == 'M25231':
        return '71883'
    elif x["PRI_ICD_CD"] == 'M24839':
        return '71883'
    elif x["PRI_ICD_CD"] == 'M24832':
        return '71883'
    elif x["PRI_ICD_CD"] == 'M24831':
        return '71883'
    elif x["PRI_ICD_CD"] == 'M25376':
        return '71887'
    elif x["PRI_ICD_CD"] == 'M25375':
        return '71887'
    elif x["PRI_ICD_CD"] == 'M25374':
        return '71887'
    elif x["PRI_ICD_CD"] == 'M25373':
        return '71887'
    elif x["PRI_ICD_CD"] == 'M25372':
        return '71887'
    elif x["PRI_ICD_CD"] == 'M25371':
        return '71887'
    elif x["PRI_ICD_CD"] == 'M25279':
        return '71887'
    elif x["PRI_ICD_CD"] == 'M25272':
        return '71887'
    elif x["PRI_ICD_CD"] == 'M25271':
        return '71887'
    elif x["PRI_ICD_CD"] == 'M24876':
        return '71887'
    elif x["PRI_ICD_CD"] == 'M24875':
        return '71887'
    elif x["PRI_ICD_CD"] == 'M24874':
        return '71887'
    elif x["PRI_ICD_CD"] == 'M24873':
        return '71887'
    elif x["PRI_ICD_CD"] == 'M24872':
        return '71887'
    elif x["PRI_ICD_CD"] == 'M24871':
        return '71887'
    elif x["PRI_ICD_CD"] == 'M25519':
        return '71941'
    elif x["PRI_ICD_CD"] == 'M25512':
        return '71941'
    elif x["PRI_ICD_CD"] == 'M25511':
        return '71941'
    elif x["PRI_ICD_CD"] == 'M79622':
        return '71942'
    elif x["PRI_ICD_CD"] == 'M25529':
        return '71942'
    elif x["PRI_ICD_CD"] == 'M25522':
        return '71942'
    elif x["PRI_ICD_CD"] == 'M25521':
        return '71942'
    elif x["PRI_ICD_CD"] == 'M79632':
        return '71943'
    elif x["PRI_ICD_CD"] == 'M25539':
        return '71943'
    elif x["PRI_ICD_CD"] == 'M25532':
        return '71943'
    elif x["PRI_ICD_CD"] == 'M25531':
        return '71943'
    elif x["PRI_ICD_CD"] == 'M79646':
        return '71944'
    elif x["PRI_ICD_CD"] == 'M79643':
        return '71944'
    elif x["PRI_ICD_CD"] == 'M25559':
        return '71945'
    elif x["PRI_ICD_CD"] == 'M25552':
        return '71945'
    elif x["PRI_ICD_CD"] == 'M25551':
        return '71945'
    elif x["PRI_ICD_CD"] == 'M25569':
        return '71946'
    elif x["PRI_ICD_CD"] == 'M25562':
        return '71946'
    elif x["PRI_ICD_CD"] == 'M25561':
        return '71946'
    elif x["PRI_ICD_CD"] == 'M25579':
        return '71947'
    elif x["PRI_ICD_CD"] == 'M25572':
        return '71947'
    elif x["PRI_ICD_CD"] == 'M25571':
        return '71947'
    elif x["PRI_ICD_CD"] == 'M25859':
        return '71985'
    elif x["PRI_ICD_CD"] == 'M25852':
        return '71985'
    elif x["PRI_ICD_CD"] == 'M25851':
        return '71985'
    elif x["PRI_ICD_CD"] == 'M25159':
        return '71985'
    elif x["PRI_ICD_CD"] == 'M5127':
        return '72210'
    elif x["PRI_ICD_CD"] == 'M5126':
        return '72210'
    elif x["PRI_ICD_CD"] == 'M5137':
        return '72252'
    elif x["PRI_ICD_CD"] == 'M5136':
        return '72252'
    elif x["PRI_ICD_CD"] == 'M5003':
        return '72271'
    elif x["PRI_ICD_CD"] == 'M5002':
        return '72271'
    elif x["PRI_ICD_CD"] == 'M5001':
        return '72271'
    elif x["PRI_ICD_CD"] == 'M5000':
        return '72271'
    elif x["PRI_ICD_CD"] == 'M5107':
        return '72273'
    elif x["PRI_ICD_CD"] == 'M5106':
        return '72273'
    elif x["PRI_ICD_CD"] == 'M519':
        return '72290'
    elif x["PRI_ICD_CD"] == 'M4649':
        return '72290'
    elif x["PRI_ICD_CD"] == 'M4648':
        return '72290'
    elif x["PRI_ICD_CD"] == 'M4640':
        return '72290'
    elif x["PRI_ICD_CD"] == 'M5093':
        return '72291'
    elif x["PRI_ICD_CD"] == 'M5092':
        return '72291'
    elif x["PRI_ICD_CD"] == 'M5091':
        return '72291'
    elif x["PRI_ICD_CD"] == 'M5090':
        return '72291'
    elif x["PRI_ICD_CD"] == 'M5083':
        return '72291'
    elif x["PRI_ICD_CD"] == 'M5082':
        return '72291'
    elif x["PRI_ICD_CD"] == 'M5081':
        return '72291'
    elif x["PRI_ICD_CD"] == 'M5080':
        return '72291'
    elif x["PRI_ICD_CD"] == 'M4644':
        return '72291'
    elif x["PRI_ICD_CD"] == 'M4643':
        return '72291'
    elif x["PRI_ICD_CD"] == 'M4642':
        return '72291'
    elif x["PRI_ICD_CD"] == 'M4641':
        return '72291'
    elif x["PRI_ICD_CD"] == 'M5187':
        return '72293'
    elif x["PRI_ICD_CD"] == 'M5186':
        return '72293'
    elif x["PRI_ICD_CD"] == 'M4647':
        return '72293'
    elif x["PRI_ICD_CD"] == 'M4646':
        return '72293'
    elif x["PRI_ICD_CD"] == 'M4800':
        return '72400'
    elif x["PRI_ICD_CD"] == 'M9973':
        return '72402'
    elif x["PRI_ICD_CD"] == 'M9963':
        return '72402'
    elif x["PRI_ICD_CD"] == 'M9953':
        return '72402'
    elif x["PRI_ICD_CD"] == 'M9943':
        return '72402'
    elif x["PRI_ICD_CD"] == 'M9933':
        return '72402'
    elif x["PRI_ICD_CD"] == 'M9923':
        return '72402'
    elif x["PRI_ICD_CD"] == 'M4807':
        return '72402'
    elif x["PRI_ICD_CD"] == 'M4806':
        return '72403'
    elif x["PRI_ICD_CD"] == 'M7552':
        return '72610'
    elif x["PRI_ICD_CD"] == 'M7551':
        return '72610'
    elif x["PRI_ICD_CD"] == 'M7550':
        return '72610'
    elif x["PRI_ICD_CD"] == 'M75102':
        return '72610'
    elif x["PRI_ICD_CD"] == 'M75101':
        return '72610'
    elif x["PRI_ICD_CD"] == 'M75100':
        return '72610'
    elif x["PRI_ICD_CD"] == 'M66819':
        return '72610'
    elif x["PRI_ICD_CD"] == 'M66812':
        return '72610'
    elif x["PRI_ICD_CD"] == 'M66811':
        return '72610'
    elif x["PRI_ICD_CD"] == 'M66219':
        return '72610'
    elif x["PRI_ICD_CD"] == 'M66212':
        return '72610'
    elif x["PRI_ICD_CD"] == 'M66211':
        return '72610'
    elif x["PRI_ICD_CD"] == 'M7522':
        return '72612'
    elif x["PRI_ICD_CD"] == 'M7521':
        return '72612'
    elif x["PRI_ICD_CD"] == 'M7520':
        return '72612'
    elif x["PRI_ICD_CD"] == 'M75110':
        return '72613'
    elif x["PRI_ICD_CD"] == 'M7580':
        return '72619'
    elif x["PRI_ICD_CD"] == 'M75112':
        return '72619'
    elif x["PRI_ICD_CD"] == 'M75111':
        return '72619'
    elif x["PRI_ICD_CD"] == 'M7702':
        return '72631'
    elif x["PRI_ICD_CD"] == 'M7701':
        return '72631'
    elif x["PRI_ICD_CD"] == 'M7700':
        return '72631'
    elif x["PRI_ICD_CD"] == 'M7712':
        return '72632'
    elif x["PRI_ICD_CD"] == 'M7711':
        return '72632'
    elif x["PRI_ICD_CD"] == 'M7710':
        return '72632'
    elif x["PRI_ICD_CD"] == 'M7742':
        return '72670'
    elif x["PRI_ICD_CD"] == 'M7741':
        return '72670'
    elif x["PRI_ICD_CD"] == 'M7740':
        return '72670'
    elif x["PRI_ICD_CD"] == 'M76899':
        return '72670'
    elif x["PRI_ICD_CD"] == 'M25776':
        return '72670'
    elif x["PRI_ICD_CD"] == 'M25775':
        return '72670'
    elif x["PRI_ICD_CD"] == 'M25774':
        return '72670'
    elif x["PRI_ICD_CD"] == 'M25773':
        return '72670'
    elif x["PRI_ICD_CD"] == 'M25772':
        return '72670'
    elif x["PRI_ICD_CD"] == 'M25771':
        return '72670'
    elif x["PRI_ICD_CD"] == 'M7662':
        return '72671'
    elif x["PRI_ICD_CD"] == 'M7661':
        return '72671'
    elif x["PRI_ICD_CD"] == 'M7660':
        return '72671'
    elif x["PRI_ICD_CD"] == 'M76829':
        return '72672'
    elif x["PRI_ICD_CD"] == 'M76822':
        return '72672'
    elif x["PRI_ICD_CD"] == 'M76821':
        return '72672'
    elif x["PRI_ICD_CD"] == 'M76819':
        return '72672'
    elif x["PRI_ICD_CD"] == 'M76812':
        return '72672'
    elif x["PRI_ICD_CD"] == 'M76811':
        return '72672'
    elif x["PRI_ICD_CD"] == 'M7732':
        return '72673'
    elif x["PRI_ICD_CD"] == 'M7731':
        return '72673'
    elif x["PRI_ICD_CD"] == 'M7730':
        return '72673'
    elif x["PRI_ICD_CD"] == 'M779':
        return '72690'
    elif x["PRI_ICD_CD"] == 'M2570':
        return '72691'
    elif x["PRI_ICD_CD"] == 'M65359':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M65352':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M65351':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M65349':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M65342':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M65341':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M65339':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M65332':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M65331':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M65329':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M65322':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M65321':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M65319':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M65312':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M65311':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M6530':
        return '72703'
    elif x["PRI_ICD_CD"] == 'M654':
        return '72704'
    elif x["PRI_ICD_CD"] == 'M65849':
        return '72705'
    elif x["PRI_ICD_CD"] == 'M65842':
        return '72705'
    elif x["PRI_ICD_CD"] == 'M65841':
        return '72705'
    elif x["PRI_ICD_CD"] == 'M65839':
        return '72705'
    elif x["PRI_ICD_CD"] == 'M65832':
        return '72705'
    elif x["PRI_ICD_CD"] == 'M65831':
        return '72705'
    elif x["PRI_ICD_CD"] == 'M65879':
        return '72706'
    elif x["PRI_ICD_CD"] == 'M65872':
        return '72706'
    elif x["PRI_ICD_CD"] == 'M65871':
        return '72706'
    elif x["PRI_ICD_CD"] == 'M6749':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M6748':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67479':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67472':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67471':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67469':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67462':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67461':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67459':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67452':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67451':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67449':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67442':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67441':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67439':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67432':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67431':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67429':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67422':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67421':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67419':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M67411':
        return '72742'
    elif x["PRI_ICD_CD"] == 'M6740':
        return '72743'
    elif x["PRI_ICD_CD"] == 'M75122':
        return '72761'
    elif x["PRI_ICD_CD"] == 'M75121':
        return '72761'
    elif x["PRI_ICD_CD"] == 'M75120':
        return '72761'
    elif x["PRI_ICD_CD"] == 'M66839':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M66832':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M66831':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M66829':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M66822':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M66821':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M66329':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M66322':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M66321':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M66319':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M66312':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M66311':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M6630':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M66229':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M66222':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M66221':
        return '72762'
    elif x["PRI_ICD_CD"] == 'M66259':
        return '72765'
    elif x["PRI_ICD_CD"] == 'M66252':
        return '72765'
    elif x["PRI_ICD_CD"] == 'M66251':
        return '72765'
    elif x["PRI_ICD_CD"] == 'M66869':
        return '72767'
    elif x["PRI_ICD_CD"] == 'M66862':
        return '72767'
    elif x["PRI_ICD_CD"] == 'M66861':
        return '72767'
    elif x["PRI_ICD_CD"] == 'M66369':
        return '72767'
    elif x["PRI_ICD_CD"] == 'M66362':
        return '72767'
    elif x["PRI_ICD_CD"] == 'M66361':
        return '72767'
    elif x["PRI_ICD_CD"] == 'M7149':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M7148':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71479':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71472':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71471':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71469':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71462':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71461':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71459':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71452':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71451':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71449':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71442':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71441':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71439':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71432':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71431':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71429':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71422':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M71421':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M7140':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M6529':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M6528':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65279':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65272':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65271':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65269':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65262':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65261':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65259':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65252':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65251':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65249':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65242':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65241':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65239':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65232':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65231':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65229':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65222':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M65221':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M6520':
        return '72782'
    elif x["PRI_ICD_CD"] == 'M722':
        return '72871'
    elif x["PRI_ICD_CD"] == 'M62838':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62831':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M6249':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M6248':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62479':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62472':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62471':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62469':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62462':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62461':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62459':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62452':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62451':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62449':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62442':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62441':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62439':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62432':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62431':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62429':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62422':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62421':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62419':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62412':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M62411':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M6240':
        return '72885'
    elif x["PRI_ICD_CD"] == 'M86279':
        return '73007'
    elif x["PRI_ICD_CD"] == 'M86272':
        return '73007'
    elif x["PRI_ICD_CD"] == 'M86271':
        return '73007'
    elif x["PRI_ICD_CD"] == 'M86179':
        return '73007'
    elif x["PRI_ICD_CD"] == 'M86172':
        return '73007'
    elif x["PRI_ICD_CD"] == 'M86171':
        return '73007'
    elif x["PRI_ICD_CD"] == 'M86079':
        return '73007'
    elif x["PRI_ICD_CD"] == 'M86072':
        return '73007'
    elif x["PRI_ICD_CD"] == 'M86071':
        return '73007'
    elif x["PRI_ICD_CD"] == 'S92919K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92912K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92911K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92909K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92902K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92901K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92599K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92592K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92591K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92536K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92535K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92534K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92533K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92532K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92531K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92526K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92525K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92524K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92523K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92522K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92521K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92516K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92515K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92514K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92513K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92512K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92511K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92506K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92505K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92504K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92503K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92502K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92501K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92499K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92492K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92491K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92426K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92425K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92424K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92423K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92422K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92421K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92416K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92415K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92414K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92413K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92412K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92411K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92406K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92405K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92404K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92403K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92402K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92401K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92356K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92355K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92354K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92353K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92352K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92351K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92346K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92345K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92344K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92343K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92342K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92341K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92336K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92335K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92334K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92333K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92332K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92331K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92326K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92325K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92324K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92323K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92322K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92321K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92316K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92315K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92314K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92313K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92312K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92311K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92309K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92302K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92301K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92256K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92255K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92254K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92253K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92252K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92251K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92246K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92245K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92244K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92243K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92242K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92241K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92236K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92235K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92234K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92233K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92232K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92231K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92226K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92225K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92224K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92223K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92222K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92221K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92216K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92215K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92214K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92213K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92212K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92211K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92209K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92202K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92201K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92199K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92192K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92191K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92156K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92155K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92154K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92153K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92152K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92151K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92146K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92145K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92144K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92143K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92142K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92141K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92136K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92135K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92134K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92133K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92132K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92131K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92126K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92125K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92124K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92123K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92122K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92121K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92116K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92115K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92114K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92113K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92112K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92111K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92109K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92102K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92101K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92066K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92065K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92064K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92063K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92062K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92061K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92056K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92055K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92054K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92053K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92052K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92051K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92046K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92045K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92044K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92043K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92042K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92041K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92036K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92035K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92034K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92033K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92032K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92031K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92026K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92025K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92024K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92023K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92022K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92021K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92016K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92015K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92014K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92013K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92012K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92011K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92009K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92002K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S92001K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89399K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89392K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89391K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89329K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89322K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89321K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89319K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89312K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89311K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89309K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89302K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89301K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89299K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89292K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89291K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89229K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89222K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89221K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89219K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89212K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89211K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89209K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89202K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89201K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89199K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89192K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89191K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89149K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89142K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89141K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89139K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89132K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89131K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89129K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89122K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89121K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89119K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89112K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89111K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89109K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89102K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89101K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89099K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89092K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89091K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89049K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89042K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89041K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89039K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89032K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89031K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89029K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89022K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89021K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89019K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89012K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89011K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89009K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89002K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S89001K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8292XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8292XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8292XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8291XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8291XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8291XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8290XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8290XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8290XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82899N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82899M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82899K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82892N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82892M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82892K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82891N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82891M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82891K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82876N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82876M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82876K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82875N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82875M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82875K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82874N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82874M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82874K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82873N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82873M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82873K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82872N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82872M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82872K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82871N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82871M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82871K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82866N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82866M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82866K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82865R':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82865Q':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82865P':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82865N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82865M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82865K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82864N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82864M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82864K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82863N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82863M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82863K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82862N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82862M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82862K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82861N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82861M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82861K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82856N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82856M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82856K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82855N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82855M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82855K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82854N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82854M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82854K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82853N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82853M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82853K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82852N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82852M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82852K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82851N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82851M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82851K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82846N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82846M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82846K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82845N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82845M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82845K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82844N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82844M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82844K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82843N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82843M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82843K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82842N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82842M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82842K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82841N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82841M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82841K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82839N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82839M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82839K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82832N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82832M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82832K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82831N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82831M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82831K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82829K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82822K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82821K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82819K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82812K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82811K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8266XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8266XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8266XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8265XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8265XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8265XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8264XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8264XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8264XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8263XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8263XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8263XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8262XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8262XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8262XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8261XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8261XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8261XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8256XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8256XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8256XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8255XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8255XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8255XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8254XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8254XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8254XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8253XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8253XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8253XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8252XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8252XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8252XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8251XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8251XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S8251XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82499N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82499M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82499K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82492N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82492M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82492K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82491N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82491M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82491K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82466N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82466M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82466K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82465N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82465M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82465K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82464N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82464M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82464K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82463N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82463M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82463K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82462N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82462M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82462K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82461N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82461M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82461K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82456N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82456M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82456K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82455N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82455M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82455K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82454N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82454M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82454K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82453N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82453M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82453K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82452N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82452M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82452K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82451N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82451M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82451K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82446N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82446M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82446K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82445N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82445M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82445K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82444N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82444M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82444K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82443N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82443M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82443K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82442N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82442M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82442K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82441N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82441M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82441K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82436N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82436M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82436K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82435N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82435M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82435K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82434N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82434M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82434K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82433N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82433M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82433K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82432N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82432M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82432K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82431N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82431M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82431K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82426N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82426M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82426K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82425N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82425M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82425K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82424N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82424M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82424K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82423N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82423M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82423K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82422N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82422M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82422K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82421N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82421M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82421K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82409N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82409M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82409K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82402N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82402M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82402K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82401N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82401M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82401K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82399N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82399M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82399K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82392N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82392M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82392K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82391N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82391M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82391K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82319K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82312K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82311K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82309N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82309M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82309K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82302N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82302M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82302K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82301N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82301M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82301K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82299N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82299M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82299K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82292N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82292M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82292K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82291N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82291M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82291K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82266N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82266M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82266K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82265N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82265M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82265K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82264N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82264M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82264K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82263N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82263M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82263K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82262N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82262M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82262K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82261N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82261M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82261K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82256N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82256M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82256K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82255N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82255M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82255K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82254N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82254M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82254K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82253N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82253M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82253K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82252N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82252M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82252K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82251N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82251M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82251K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82246N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82246M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82246K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82245N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82245M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82245K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82244N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82244M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82244K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82243N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82243M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82243K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82242N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82242M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82242K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82241N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82241M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82241K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82236N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82236M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82236K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82235N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82235M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82235K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82234N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82234M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82234K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82233N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82233M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82233K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82232N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82232M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82232K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82231N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82231M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82231K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82226N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82226M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82226K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82225N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82225M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82225K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82224N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82224M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82224K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82223N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82223M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82223K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82222N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82222M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82222K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82221N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82221M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82221K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82209N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82209M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82209K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82202N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82202M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82202K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82201N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82201M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82201K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82199N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82199M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82199K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82192N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82192M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82192K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82191N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82191M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82191K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82169K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82162K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82161K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82156N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82156M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82156K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82155N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82155M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82155K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82154N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82154M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82154K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82153N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82153M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82153K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82152N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82152M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82152K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82151N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82151M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82151K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82146N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82146M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82146K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82145N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82145M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82145K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82144N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82144M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82144K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82143N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82143M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82143K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82142N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82142M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82142K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82141N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82141M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82141K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82136N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82136M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82136K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82135N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82135M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82135K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82134N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82134M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82134K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82133N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82133M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82133K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82132N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82132M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82132K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82131N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82131M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82131K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82126N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82126M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82126K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82125N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82125M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82125K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82124N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82124M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82124K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82123N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82123M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82123K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82122N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82122M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82122K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82121N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82121M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82121K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82116N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82116M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82116K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82115N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82115M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82115K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82114N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82114M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82114K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82113N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82113M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82113K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82112N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82112M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82112K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82111N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82111M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82111K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82109N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82109M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82109K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82102N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82102M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82102K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82101N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82101M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82101K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82099N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82099M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82099K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82092N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82092M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82092K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82091N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82091M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82091K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82046N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82046M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82046K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82045N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82045M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82045K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82044N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82044M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82044K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82043N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82043M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82043K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82042N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82042M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82042K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82041N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82041M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82041K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82036N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82036M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82036K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82035N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82035M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82035K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82034N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82034M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82034K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82033N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82033M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82033K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82032N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82032M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82032K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82031N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82031M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82031K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82026N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82026M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82026K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82025N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82025M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82025K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82024N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82024M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82024K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82023N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82023M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82023K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82022N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82022M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82022K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82021N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82021M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82021K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82016N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82016M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82016K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82015N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82015M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82015K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82014N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82014M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82014K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82013N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82013M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82013K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82012N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82012M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82012K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82011N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82011M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82011K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82009N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82009M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82009K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82002N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82002M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82002K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82001N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82001M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S82001K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79199K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79192K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79191K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79149K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79142K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79141K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79139K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79132K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79131K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79129K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79122K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79121K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79119K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79112K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79111K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79109K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79102K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79101K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79099K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79092K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79091K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79019K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79012K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79011K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79009K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79002K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S79001K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7292XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7292XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7292XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7291XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7291XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7291XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7290XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7290XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7290XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S728X9N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S728X9M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S728X9K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S728X2N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S728X2M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S728X2K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S728X1N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S728X1M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S728X1K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72499N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72499M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72499K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72492N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72492M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72492K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72491N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72491M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72491K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72479K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72472K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72471K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72466N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72466M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72466K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72465N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72465M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72465K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72464N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72464M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72464K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72463N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72463M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72463K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72462N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72462M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72462K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72461N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72461M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72461K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72456N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72456M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72456K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72455N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72455M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72455K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72454N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72454M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72454K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72453N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72453M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72453K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72452N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72452M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72452K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72451N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72451M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72451K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72446N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72446M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72446K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72445N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72445M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72445K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72444N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72444M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72444K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72443N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72443M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72443K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72442N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72442M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72442K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72441N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72441M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72441K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72436N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72436M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72436K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72435N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72435M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72435K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72434N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72434M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72434K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72433N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72433M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72433K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72432N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72432M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72432K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72431N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72431M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72431K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72426N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72426M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72426K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72425N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72425M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72425K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72424N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72424M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72424K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72423N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72423M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72423K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72422N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72422M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72422K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72421N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72421M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72421K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72416N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72416M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72416K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72415N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72415M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72415K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72414N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72414M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72414K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72413N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72413M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72413K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72412N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72412M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72412K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72411N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72411M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72411K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72409N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72409M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72409K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72402N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72402M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72402K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72401N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72401M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72401K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72399N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72399M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72399K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72392N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72392M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72392K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72391N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72391M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72391K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72366N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72366M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72366K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72365N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72365M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72365K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72364N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72364M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72364K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72363N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72363M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72363K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72362N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72362M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72362K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72361N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72361M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72361K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72356N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72356M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72356K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72355N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72355M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72355K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72354N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72354M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72354K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72353N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72353M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72353K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72352N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72352M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72352K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72351N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72351M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72351K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72346N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72346M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72346K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72345N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72345M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72345K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72344N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72344M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72344K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72343N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72343M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72343K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72342N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72342M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72342K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72341N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72341M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72341K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72336N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72336M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72336K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72335N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72335M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72335K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72334N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72334M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72334K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72333N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72333M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72333K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72332N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72332M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72332K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72331N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72331M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72331K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72326N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72326M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72326K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72325N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72325M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72325K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72324N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72324M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72324K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72323N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72323M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72323K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72322N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72322M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72322K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72321N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72321M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72321K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72309N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72309M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72309K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72302N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72302M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72302K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72301N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72301M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72301K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7226XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7226XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7226XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7225XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7225XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7225XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7224XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7224XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7224XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7223XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7223XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7223XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7222XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7222XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7222XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7221XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7221XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S7221XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72146N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72146M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72146K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72145N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72145M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72145K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72144N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72144M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72144K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72143N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72143M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72143K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72142N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72142M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72142K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72141N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72141M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72141K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72136N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72136M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72136K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72135N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72135M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72135K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72134N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72134M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72134K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72133N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72133M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72133K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72132N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72132M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72132K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72131N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72131M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72131K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72126N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72126M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72126K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72125N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72125M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72125K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72124N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72124M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72124K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72123N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72123M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72123K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72122N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72122M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72122K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72121N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72121M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72121K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72116N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72116M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72116K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72115N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72115M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72115K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72114N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72114M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72114K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72113N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72113M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72113K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72112N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72112M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72112K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72111N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72111M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72111K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72109N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72109M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72109K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72102N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72102M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72102K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72101N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72101M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72101K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72099N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72099M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72099K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72092N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72092M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72092K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72091N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72091M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72091K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72066N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72066M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72066K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72065N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72065M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72065K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72064N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72064M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72064K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72063N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72063M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72063K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72062N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72062M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72062K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72061N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72061M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72061K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72059N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72059M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72059K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72052N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72052M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72052K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72051N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72051M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72051K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72046N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72046M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72046K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72045N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72045M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72045K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72044N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72044M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72044K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72043N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72043M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72043K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72042M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72042K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72041N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72041M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72036N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72036M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72036K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72035N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72035M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72035K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72034N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72034M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72034K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72033N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72033M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72033K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72032N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72032M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72032K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72031N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72031M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72031K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72026N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72026M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72026K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72025N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72025M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72025K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72024N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72024M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72024K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72023N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72023M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72023K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72022N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72022M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72022K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72021N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72021M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72021K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72019N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72019M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72019K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72012N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72012M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72012K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72011N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72011M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72011K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72009N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72009M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72009K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72002N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72002M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72002K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72001N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72001M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S72001K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S6292XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S6291XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S6290XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62669K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62668K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62667K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62666K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62665K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62664K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62663K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62662K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62661K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62660K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62659K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62658K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62657K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62656K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62655K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62654K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62653K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62652K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62651K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62650K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62649K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62648K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62647K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62646K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62645K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62644K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62643K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62642K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62641K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62640K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62639K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62638K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62637K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62636K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62635K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62634K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62633K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62632K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62631K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62630K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62629K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62628K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62627K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62626K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62625K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62624K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62623K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62622K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62621K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62620K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62619K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62618K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62617K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62616K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62615K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62614K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62613K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62612K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62611K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62610K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62609K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62608K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62607K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62606K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62605K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62604K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62603K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62602K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62601K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62600K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62526K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62525K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62524K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62523K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62522K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62521K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62516K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62515K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62514K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62513K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62512K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62511K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62509K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62502K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62501K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62399K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62398K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62397K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62396K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62395K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62394K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62393K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62392K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62391K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62390K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62369K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62368K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62367K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62366K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62365K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62364K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62363K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62362K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62361K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62360K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62359K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62358K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62357K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62356K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62355K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62354K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62353K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62352K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62351K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62350K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62349K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62348K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62347K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62346K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62345K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62344K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62343K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62342K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62341K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62340K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62339K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62338K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62337K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62336K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62335K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62334K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62333K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62332K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62331K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62330K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62329K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62328K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62327K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62326K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62325K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62324K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62323K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62322K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62321K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62320K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62319K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62318K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62317K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62316K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62315K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62314K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62313K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62312K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62311K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62310K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62309K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62308K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62307K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62306K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62305K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62304K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62303K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62302K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62301K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62300K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62299K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62292K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62291K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62256K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62255K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62254K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62253K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62252K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62251K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62246K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62245K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62244K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62243K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62242K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62241K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62236K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62235K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62234K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62233P':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62233K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62232K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62231K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62226K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62225K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62224K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62223K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62222K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62221K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62213K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62212K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62211K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62209K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62202K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62201K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62186K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62185K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62184K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62183K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62182K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62181K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62176K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62175K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62174K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62173K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62172K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62171K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62166K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62165K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62164K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62163K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62162K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62161K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62156K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62155K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62154K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62153K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62152K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62151K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62146K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62145K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62144K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62143K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62142K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62141K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62136K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62135K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62134K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62133K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62132K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62131K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62126K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62125K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62124K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62123K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62122K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62121K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62116K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62115K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62114K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62113K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62112K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62111K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62109K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62102K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62101K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62036K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62035K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62034K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62033K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62032K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62031K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62026K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62025K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62024K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62023K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62022K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62021K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62016K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62015K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62014K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62013K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62012K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62011K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62009K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62002K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S62001K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59299K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59292K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59291K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59249K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59242K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59241K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59239K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59232K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59231K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59229K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59222K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59221K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59219K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59212K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59211K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59209K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59202K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59201K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59199K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59192K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59191K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59149K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59142K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59141K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59139K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59132K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59131K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59129K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59122K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59121K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59119K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59112K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59111K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59109K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59102K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59101K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59099K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59092K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59091K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59049K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59042K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59041K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59039K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59032K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59031K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59029K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59022K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59021K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59019K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59012K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59011K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59009K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59002K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S59001K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S5292XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S5292XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S5292XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S5291XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S5291XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S5291XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S5290XN':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S5290XM':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S5290XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52699N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52699M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52699K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52692N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52692M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52692K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52691N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52691M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52691K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52629K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52622K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52621K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52616N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52616M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52616K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52615N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52615M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52615K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52614N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52614M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52614K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52613N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52613M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52613K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52612N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52612M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52612K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52611N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52611M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52611K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52609N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52609M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52609K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52602N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52602M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52602K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52601N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52601M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52601K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52599N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52599M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52599K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52592N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52592M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52592K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52591N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52591M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52591K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52579N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52579M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52579K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52572N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52572M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52572K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52571N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52571M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52571K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52569N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52569M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52569K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52562N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52562M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52562K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52561N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52561M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52561K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52559N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52559M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52559K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52552N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52552M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52552K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52551N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52551M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52551K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52549N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52549M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52549K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52542N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52542M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52542K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52541N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52541M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52541K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52539N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52539M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52539K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52532N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52532M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52532K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52531N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52531M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52531K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52529K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52522K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52521K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52516N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52516M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52516K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52515N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52515M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52515K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52514N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52514M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52514K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52513N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52513M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52513K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52512N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52512M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52512K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52511N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52511M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52511K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52509N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52509M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52509K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52502N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52502M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52502K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52501N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52501M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52501K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52399N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52399M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52399K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52392N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52392M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52392K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52391N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52391M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52391K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52389N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52389M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52389K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52382N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52382M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52382K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52381N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52381M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52381K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52379N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52379M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52379K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52372N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52372M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52372K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52371N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52371M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52371K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52366N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52366M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52366K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52365N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52365M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52365K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52364N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52364M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52364K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52363N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52363M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52363K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52362N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52362M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52362K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52361N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52361M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52361K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52356N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52356M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52356K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52355N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52355M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52355K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52354N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52354M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52354K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52353N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52353M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52353K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52352N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52352M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52352K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52351N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52351M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52351K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52346N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52346M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52346K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52345N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52345M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52345K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52344N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52344M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52344K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52343N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52343M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52343K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52342N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52342M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52342K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52341N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52341M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52341K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52336N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52336M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52336K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52335N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52335M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52335K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52334N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52334M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52334K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52333N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52333M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52333K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52332N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52332M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52332K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52331N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52331M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52331K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52326N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52326M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52326K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52325N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52325M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52325K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52324N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52324M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52324K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52323N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52323M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52323K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52322N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52322M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52322K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52321N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52321M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52321K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52319K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52312K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52311K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52309N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52309M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52309K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52302N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52302M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52302K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52301N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52301M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52301K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52299N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52299M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52299K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52292N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52292M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52292K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52291N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52291M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52291K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52283N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52283M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52283K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52282N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52282M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52282K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52281N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52281M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52281K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52279N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52279M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52279K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52272N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52272M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52272K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52271N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52271M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52271K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52266N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52266M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52266K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52265N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52265M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52265K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52264N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52264M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52264K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52263N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52263M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52263K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52262N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52262M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52262K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52261N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52261M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52261K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52256N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52256M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52256K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52255N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52255M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52255K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52254N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52254M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52254K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52253N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52253M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52253K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52252N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52252M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52252K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52251N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52251M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52251K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52246N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52246M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52246K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52245N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52245M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52245K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52244N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52244M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52244K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52243N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52243M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52243K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52242N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52242M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52242K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52241N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52241M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52241K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52236N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52236M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52236K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52235N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52235M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52235K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52234N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52234M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52234K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52233N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52233M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52233K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52232N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52232M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52232K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52231N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52231M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52231K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52226N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52226M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52226K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52225N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52225M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52225K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52224N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52224M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52224K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52223N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52223M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52223K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52222N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52222M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52222K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52221N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52221M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52221K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52219K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52212K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52211K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52209N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52209M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52209K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52202N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52202M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52202K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52201N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52201M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52201K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52189N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52189M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52189K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52182N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52182M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52182K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52181N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52181M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52181K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52136N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52136M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52136K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52135N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52135M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52135K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52134N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52134M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52134K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52133N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52133M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52133K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52132N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52132M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52132K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52131N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52131M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52131K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52126N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52126M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52126K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52125N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52125M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52125K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52124N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52124M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52124K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52123N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52123M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52123K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52122N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52122M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52122K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52121N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52121M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52121K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52119K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52112K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52111K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52109N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52109M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52109K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52102N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52102M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52102K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52101N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52101M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52101K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52099N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52099M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52099K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52092N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52092M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52092K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52091N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52091M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52091K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52046N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52046M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52046K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52045N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52045M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52045K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52044N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52044M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52044K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52043N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52043M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52043K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52042N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52042M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52042K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52041N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52041M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52041K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52036N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52036M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52036K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52035N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52035M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52035K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52034N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52034M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52034K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52033N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52033M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52033K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52032N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52032M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52032K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52031N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52031M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52031K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52026N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52026M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52026K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52025N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52025M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52025K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52024N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52024M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52024K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52023N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52023M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52023K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52022N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52022M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52022K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52021N':
        return '73382'
    else:
        return 'Derive_3'


def f_ICD10to9_3(x):
    if x["ICD10to9_2"] != "Derive_3":
        return x["ICD10to9_2"]
    elif x["PRI_ICD_CD"] == 'S52021M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52021K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52019K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52012K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52011K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52009N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52009M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52009K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52002N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52002M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52002K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52001P':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52001N':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52001M':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S52001K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49199K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49192K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49191K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49149K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49142K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49141K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49139K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49132K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49131K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49129K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49122K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49121K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49119K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49112K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49111K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49109K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49102K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49101K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49099K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49092K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49091K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49049K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49042K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49041K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49039K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49032K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49031K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49029K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49022K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49021K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49019K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49012K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49011K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49009K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49002K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S49001K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S4292XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S4291XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S4290XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42496K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42495K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42494K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42493K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42492K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42491K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42489K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42482K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42481K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42476K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42475K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42474K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42473K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42472K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42471K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42466K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42465K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42464K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42463K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42462K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42461K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42456K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42455K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42454K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42453K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42452K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42451K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42449K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42448K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42447K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42446K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42445K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42444K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42443K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42442K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42441K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42436K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42435K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42434K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42433K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42432K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42431K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42426K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42425K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42424K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42423K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42422K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42421K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42416K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42415K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42414K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42413K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42412K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42411K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42409K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42402K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42401K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42399K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42392K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42391K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42366K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42365K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42364K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42363K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42362K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42361K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42356K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42355K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42354K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42353K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42352K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42351K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42346K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42345K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42344K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42343K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42342K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42341K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42336K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42335K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42334K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42333K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42332K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42331K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42326K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42325K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42324K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42323K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42322K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42321K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42319K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42312K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42311K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42309K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42302K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42301K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42296K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42295K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42294K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42293K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42292K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42291K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42279K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42272K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42271K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42266K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42265K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42264K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42263K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42262K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42261K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42256K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42255K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42254K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42253K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42252K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42251K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42249K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42242K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42241K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42239K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42232K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42231K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42226K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42225K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42224K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42223K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42222K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42221K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42216K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42215K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42214K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42213K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42212K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42211K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42209K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42202K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42201K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42199K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42192K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42191K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42156K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42155K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42154K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42153K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42152K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42151K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42146K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42145K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42144K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42143K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42142K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42141K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42136K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42135K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42134K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42133K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42132K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42131K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42126K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42125K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42124K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42123K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42122K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42121K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42116K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42115K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42114K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42113K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42112K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42111K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42109K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42102K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42101K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42036K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42035K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42034K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42033K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42032K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42031K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42026K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42025K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42024K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42023K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42022K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42021K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42019K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42018K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42017K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42016K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42015K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42014K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42013K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42012K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42011K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42009K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42002K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S42001K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S329XXK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S3289XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S3282XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32811K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32810K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32699K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32692K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32691K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32616K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32615K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32614K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32613K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32612K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32611K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32609K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32602K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32601K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32599K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32592K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32591K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32519K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32512K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32511K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32509K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32502K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32501K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32499K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32492K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32491K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32486K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32485K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32484K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32483K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32482K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32481K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32476K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32475K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32474K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32473K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32472K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32471K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32466K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32465K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32464K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32463K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32462K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32461K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32456K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32455K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32454K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32453K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32452K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32451K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32446K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32445K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32444K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32443K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32442K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32441K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32436K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32435K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32434K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32433K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32432K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32431K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32426K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32425K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32424K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32423K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32422K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32421K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32416K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32415K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32414K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32413K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32412K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32411K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32409K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32402K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32401K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32399K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32392K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32391K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32316K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32315K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32314K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32313K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32312K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32311K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32309K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32302K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32301K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S322XXK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S3219XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S3217XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S3216XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S3215XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S3214XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32139K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32132K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32131K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32130K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32129K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32122K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32121K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32120K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32119K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32112K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32111K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32110K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S3210XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32059K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32058K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32052K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32051K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32050K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32049K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32048K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32042K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32041K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32040K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32039K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32038K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32032K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32031K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32030K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32029K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32028K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32022K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32021K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32020K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32019K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32018K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32012K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32011K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32010K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32009K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32008K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32002K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32001K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S32000K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S229XXK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S225XXK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S2249XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S2243XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S2242XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S2241XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S2239XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S2232XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S2231XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S2224XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S2223XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S2222XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S2221XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S2220XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22089K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22088K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22082K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22081K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22080K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22079K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22078K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22072K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22071K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22070K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22069K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22068K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22062K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22061K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22060K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22059K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22058K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22052K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22051K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22050K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22049K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22048K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22042K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22041K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22040K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22039K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22038K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22032K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22031K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22030K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22029K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22028K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22022K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22021K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22020K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22019K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22018K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22012K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22011K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22010K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22009K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22008K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22002K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22001K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S22000K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12691K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12690K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12651K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12650K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S1264XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12631K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12630K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12601K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12600K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12591K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12590K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12551K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12550K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S1254XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12531K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12530K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12501K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12500K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12491K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12490K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12451K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12450K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S1244XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12431K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12430K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12401K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12400K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12391K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12390K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12351K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12350K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S1234XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12331K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12330K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12301K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12300K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12291K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12290K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12251K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12250K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S1224XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12231K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12230K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12201K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12200K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12191K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12190K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12151K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12150K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S1214XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12131K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12130K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12121K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12120K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12112K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12111K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12110K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12101K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12100K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12091K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12090K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12041K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12040K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12031K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12030K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S1202XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S1201XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12001K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S12000K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S0292XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S0291XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S028XXK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S0269XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S0267XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S0266XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S0265XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S0264XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S0263XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S0262XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S0261XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S02609K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S02600K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S025XXK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S0242XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S02413K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S02412K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S02411K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S02402K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S02401K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S02400K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S023XXK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S022XXK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S0219XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S02119K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S02118K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S02113K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S02112K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S02111K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S02110K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S0210XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'S020XXK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M8468XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84676K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84675K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84674K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84673K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84672K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84671K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84669K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84664K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84663K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84662K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84661K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84659K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84653K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84652K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84651K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84650K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84649K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84642K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84641K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84639K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84634K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84633K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84632K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84631K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84629K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84622K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84621K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84619K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84612K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84611K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M8460XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M8458XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84576K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84575K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84574K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84573K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84572K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84571K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84569K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84564K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84563K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84562K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84561K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84559K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84553K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84552K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84551K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84550K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84549K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84542K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84541K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84539K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84534K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84533K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84532K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84531K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84529K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84522K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84521K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84519K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84512K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84511K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M8450XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M8448XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84479K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84478K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84477K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84476K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84475K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84474K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84473K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84472K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84471K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84469K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84464K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84463K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84462K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84461K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84459K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84454K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84453K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84452K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84451K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84446K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84445K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84444K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84443K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84442K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84441K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84439K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84434K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84433K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84432K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84431K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84429K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84422K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84421K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84419K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84412K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84411K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M8440XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M8438XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84379K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84378K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84377K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84376K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84375K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84374K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84373K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84372K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84371K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84369K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84364K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84363K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84362K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84361K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84359K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84353K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84352K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84351K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84350K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84346K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84345K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84344K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84343K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84342K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84341K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84339K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84333K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84332K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84331K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84329K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84322K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84321K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84319K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84312K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M84311K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M8430XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M8088XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80879K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80872K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80871K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80869K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80862K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80861K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80859K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80852K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80851K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80849K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80842K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80841K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80839K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80832K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80831K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80829K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80822K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80821K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80819K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80812K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80811K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M8080XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M8008XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80079K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80072K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80071K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80069K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80062K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80061K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80059K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80052K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80051K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80049K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80042K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80041K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80039K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80032P':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80032K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80031K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80029K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80022K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80021K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80019K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80012K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M80011K':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M8000XK':
        return '73382'
    elif x["PRI_ICD_CD"] == 'M948X9':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M948X8':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M948X7':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M948X6':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M948X5':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M948X4':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M948X3':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M948X2':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M948X1':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M948X0':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M94359':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M94352':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M94351':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M941':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M898X9':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M898X8':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M898X7':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M898X6':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M898X5':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M898X4':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M898X3':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M898X2':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M898X1':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M898X0':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8959':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8958':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89579':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89572':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89571':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89569':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89562':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89561':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89559':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89552':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89551':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89549':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89542':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89541':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89539':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89532':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89531':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89529':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89522':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89521':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89519':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89512':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89511':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8950':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8939':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8938':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89379':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89372':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89371':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89369':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89364':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89363':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89362':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89361':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89359':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89352':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89351':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89349':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89342':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89341':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89339':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89334':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89333':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89332':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89331':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89329':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89322':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89321':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89319':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89312':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89311':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8930':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8929':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8928':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89279':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89272':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89271':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89269':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89264':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89263':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89262':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89261':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89259':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89252':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89251':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89249':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89242':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89241':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89239':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89234':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89233':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89232':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89231':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89229':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89222':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89221':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89219':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89212':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M89211':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8920':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8589':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8588':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85879':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85872':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85871':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85869':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85862':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85861':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85859':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85852':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85851':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85849':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85842':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85841':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85839':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85832':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85831':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85829':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85822':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85821':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85819':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85812':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85811':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8580':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8519':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8518':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85179':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85172':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85171':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85169':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85162':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85161':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85159':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85152':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85151':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85149':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85142':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85141':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85139':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85132':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85131':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85129':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85122':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85121':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85119':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85112':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M85111':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8510':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M849':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8488':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84879':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84872':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84871':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84869':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84864':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84863':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84862':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84861':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84859':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84852':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84851':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84849':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84842':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84841':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84839':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84834':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84833':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84832':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84831':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84829':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84822':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84821':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84819':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84812':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M84811':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M8480':
        return '73399'
    elif x["PRI_ICD_CD"] == 'M21949':
        return '73600'
    elif x["PRI_ICD_CD"] == 'M21942':
        return '73600'
    elif x["PRI_ICD_CD"] == 'M21941':
        return '73600'
    elif x["PRI_ICD_CD"] == 'M21939':
        return '73600'
    elif x["PRI_ICD_CD"] == 'M21932':
        return '73600'
    elif x["PRI_ICD_CD"] == 'M21931':
        return '73600'
    elif x["PRI_ICD_CD"] == 'M216X9':
        return '73679'
    elif x["PRI_ICD_CD"] == 'M216X2':
        return '73679'
    elif x["PRI_ICD_CD"] == 'M216X1':
        return '73679'
    elif x["PRI_ICD_CD"] == 'M21379':
        return '73679'
    elif x["PRI_ICD_CD"] == 'M21372':
        return '73679'
    elif x["PRI_ICD_CD"] == 'M21371':
        return '73679'
    elif x["PRI_ICD_CD"] == 'M21079':
        return '73679'
    elif x["PRI_ICD_CD"] == 'M21072':
        return '73679'
    elif x["PRI_ICD_CD"] == 'M21071':
        return '73679'
    elif x["PRI_ICD_CD"] == 'M21969':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21962':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21961':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21929':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21922':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21921':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21829':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21822':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21821':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M2180':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21739':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21734':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21733':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21732':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21731':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21729':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21722':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21721':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M2170':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21279':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21272':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21271':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21269':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21262':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21261':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21259':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21252':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21251':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21249':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21242':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21241':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21239':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21232':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21231':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21229':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21222':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21221':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21219':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21212':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M21211':
        return '73689'
    elif x["PRI_ICD_CD"] == 'M2120':
        return '73689'
    elif x["PRI_ICD_CD"] == 'Q652':
        return '75430'
    elif x["PRI_ICD_CD"] == 'Q6500':
        return '75430'
    elif x["PRI_ICD_CD"] == 'Q6689':
        return '75567'
    elif x["PRI_ICD_CD"] == 'Q7649':
        return '75619'
    elif x["PRI_ICD_CD"] == 'Q76419':
        return '75619'
    elif x["PRI_ICD_CD"] == 'Q76415':
        return '75619'
    elif x["PRI_ICD_CD"] == 'Q76414':
        return '75619'
    elif x["PRI_ICD_CD"] == 'Q76413':
        return '75619'
    elif x["PRI_ICD_CD"] == 'Q76412':
        return '75619'
    elif x["PRI_ICD_CD"] == 'Q76411':
        return '75619'
    elif x["PRI_ICD_CD"] == 'R079':
        return '78650'
    elif x["PRI_ICD_CD"] == 'R109':
        return '78900'
    elif x["PRI_ICD_CD"] == 'R100':
        return '78900'
    elif x["PRI_ICD_CD"] == 'S2239XA':
        return '80701'
    elif x["PRI_ICD_CD"] == 'S2232XA':
        return '80701'
    elif x["PRI_ICD_CD"] == 'S2231XA':
        return '80701'
    elif x["PRI_ICD_CD"] == 'S2243XA':
        return '80704'
    elif x["PRI_ICD_CD"] == 'S2242XA':
        return '80704'
    elif x["PRI_ICD_CD"] == 'S2241XA':
        return '80704'
    elif x["PRI_ICD_CD"] == 'S2249XA':
        return '80709'
    elif x["PRI_ICD_CD"] == 'S42009A':
        return '81000'
    elif x["PRI_ICD_CD"] == 'S42002A':
        return '81000'
    elif x["PRI_ICD_CD"] == 'S42001A':
        return '81000'
    elif x["PRI_ICD_CD"] == 'S42209A':
        return '81200'
    elif x["PRI_ICD_CD"] == 'S42202A':
        return '81200'
    elif x["PRI_ICD_CD"] == 'S42201A':
        return '81200'
    elif x["PRI_ICD_CD"] == 'S4292XA':
        return '81220'
    elif x["PRI_ICD_CD"] == 'S4291XA':
        return '81220'
    elif x["PRI_ICD_CD"] == 'S4290XA':
        return '81220'
    elif x["PRI_ICD_CD"] == 'S42309A':
        return '81220'
    elif x["PRI_ICD_CD"] == 'S42302A':
        return '81220'
    elif x["PRI_ICD_CD"] == 'S42301A':
        return '81220'
    elif x["PRI_ICD_CD"] == 'S52126A':
        return '81305'
    elif x["PRI_ICD_CD"] == 'S52125A':
        return '81305'
    elif x["PRI_ICD_CD"] == 'S52124A':
        return '81305'
    elif x["PRI_ICD_CD"] == 'S52123A':
        return '81305'
    elif x["PRI_ICD_CD"] == 'S52122A':
        return '81305'
    elif x["PRI_ICD_CD"] == 'S52121A':
        return '81305'
    elif x["PRI_ICD_CD"] == 'S52299A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52292A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52291A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52283A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52282A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52281A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52266A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52265A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52264A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52263A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52262A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52261A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52256A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52255A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52254A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52253A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52252A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52251A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52246A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52245A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52244A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52243A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52242A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52241A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52236A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52235A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52234A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52233A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52232A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52231A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52226A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52225A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52224A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52223A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52222A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52221A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52219A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52212A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52211A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52209A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52202A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S52201A':
        return '81322'
    elif x["PRI_ICD_CD"] == 'S59299A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59292A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59291A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59249A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59242A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59241A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59239A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59232A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59231A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59229A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59222A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59221A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59219A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59212A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59211A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59209A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59202A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S59201A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52599A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52592A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52591A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52579A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52572A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52571A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52569A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52562A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52561A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52559A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52552A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52551A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52549A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52542A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52541A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52516A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52515A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52514A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52513A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52512A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52511A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52509A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52502A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S52501A':
        return '81342'
    elif x["PRI_ICD_CD"] == 'S5292XA':
        return '81380'
    elif x["PRI_ICD_CD"] == 'S5291XA':
        return '81380'
    elif x["PRI_ICD_CD"] == 'S5290XA':
        return '81380'
    elif x["PRI_ICD_CD"] == 'S62109A':
        return '81400'
    elif x["PRI_ICD_CD"] == 'S62102A':
        return '81400'
    elif x["PRI_ICD_CD"] == 'S62101A':
        return '81400'
    elif x["PRI_ICD_CD"] == 'S62036A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62035A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62034A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62033A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62032A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62031A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62026A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62025A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62024A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62023A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62022A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62021A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62016A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62015A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62014A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62013A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62012A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62011A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62009A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62002A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62001A':
        return '81401'
    elif x["PRI_ICD_CD"] == 'S62309A':
        return '81500'
    elif x["PRI_ICD_CD"] == 'S62609A':
        return '81600'
    elif x["PRI_ICD_CD"] == 'S62608A':
        return '81600'
    elif x["PRI_ICD_CD"] == 'S62607A':
        return '81600'
    elif x["PRI_ICD_CD"] == 'S62606A':
        return '81600'
    elif x["PRI_ICD_CD"] == 'S62605A':
        return '81600'
    elif x["PRI_ICD_CD"] == 'S62604A':
        return '81600'
    elif x["PRI_ICD_CD"] == 'S62603A':
        return '81600'
    elif x["PRI_ICD_CD"] == 'S62602A':
        return '81600'
    elif x["PRI_ICD_CD"] == 'S62601A':
        return '81600'
    elif x["PRI_ICD_CD"] == 'S62600A':
        return '81600'
    elif x["PRI_ICD_CD"] == 'S62509A':
        return '81600'
    elif x["PRI_ICD_CD"] == 'S62502A':
        return '81600'
    elif x["PRI_ICD_CD"] == 'S62501A':
        return '81600'
    elif x["PRI_ICD_CD"] == 'S89099A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89092A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89091A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89049A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89042A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89041A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89039A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89032A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89031A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89029A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89022A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89021A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89019A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89012A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89011A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89009A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S89002A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82199A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82192A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82191A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82156A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82155A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82154A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82153A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82152A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82151A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82146A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82145A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82144A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82143A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82142A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82141A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82136A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82135A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82134A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82133A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82132A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82131A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82126A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82125A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82124A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82123A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82122A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82121A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82116A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82115A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82114A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82113A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82112A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82111A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82109A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82102A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82101A':
        return '82300'
    elif x["PRI_ICD_CD"] == 'S82202A':
        return '82380'
    elif x["PRI_ICD_CD"] == 'S82402A':
        return '82381'
    elif x["PRI_ICD_CD"] == 'S82401A':
        return '82381'
    elif x["PRI_ICD_CD"] == 'S92909A':
        return '82520'
    elif x["PRI_ICD_CD"] == 'S92902A':
        return '82520'
    elif x["PRI_ICD_CD"] == 'S92901A':
        return '82520'
    elif x["PRI_ICD_CD"] == 'S92356A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92355A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92354A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92353A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92352A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92351G':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92351A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92346A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92345A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92344A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92343A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92342A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92341A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92336A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92335A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92334A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92333A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92332A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92331A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92326A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92325A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92324A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92323A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92322A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92321A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92316A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92315A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92314A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92313A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92312A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92311A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92302A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92301A':
        return '82525'
    elif x["PRI_ICD_CD"] == 'S92309A':
        return '82529'
    elif x["PRI_ICD_CD"] == 'S92209A':
        return '82529'
    elif x["PRI_ICD_CD"] == 'S92202A':
        return '82529'
    elif x["PRI_ICD_CD"] == 'S92201A':
        return '82529'
    elif x["PRI_ICD_CD"] == 'S43006A':
        return '83100'
    elif x["PRI_ICD_CD"] == 'S43005A':
        return '83100'
    elif x["PRI_ICD_CD"] == 'S43004A':
        return '83100'
    elif x["PRI_ICD_CD"] == 'S43003A':
        return '83100'
    elif x["PRI_ICD_CD"] == 'S43002A':
        return '83100'
    elif x["PRI_ICD_CD"] == 'S43001A':
        return '83100'
    elif x["PRI_ICD_CD"] == 'S43159A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43152A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43151A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43149A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43142A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43141A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43139A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43132A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43131A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43129A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43122A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43121A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43119A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43112A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43111A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43109A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43102A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S43101A':
        return '83104'
    elif x["PRI_ICD_CD"] == 'S66912A':
        return '84200'
    elif x["PRI_ICD_CD"] == 'S66911A':
        return '84200'
    elif x["PRI_ICD_CD"] == 'S63509A':
        return '84200'
    elif x["PRI_ICD_CD"] == 'S63502A':
        return '84200'
    elif x["PRI_ICD_CD"] == 'S63501A':
        return '84200'
    elif x["PRI_ICD_CD"] == 'S66919A':
        return '84210'
    elif x["PRI_ICD_CD"] == 'S6392XA':
        return '84210'
    elif x["PRI_ICD_CD"] == 'S6391XA':
        return '84210'
    elif x["PRI_ICD_CD"] == 'S6390XA':
        return '84210'
    elif x["PRI_ICD_CD"] == 'S96919A':
        return '84500'
    elif x["PRI_ICD_CD"] == 'S93409A':
        return '84500'
    elif x["PRI_ICD_CD"] == 'S93402A':
        return '84500'
    elif x["PRI_ICD_CD"] == 'S93401A':
        return '84500'
    elif x["PRI_ICD_CD"] == 'S96912A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S96911A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S96819A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S96812A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S96811A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S96219A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S96212A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S96211A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S96119A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S96112A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S96111A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S96019A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S96012A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S93499A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S93492A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S93491A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S86019A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S86012A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S86011A':
        return '84509'
    elif x["PRI_ICD_CD"] == 'S93609A':
        return '84510'
    elif x["PRI_ICD_CD"] == 'S93602A':
        return '84510'
    elif x["PRI_ICD_CD"] == 'S93601A':
        return '84510'
    elif x["PRI_ICD_CD"] == 'S060X0A':
        return '85409'
    elif x["PRI_ICD_CD"] == 'S8002XA':
        return '92411'
    elif x["PRI_ICD_CD"] == 'S8001XA':
        return '92411'
    elif x["PRI_ICD_CD"] == 'S8000XA':
        return '92411'
    elif x["PRI_ICD_CD"] == 'S0990XA':
        return '95901'
    elif x["PRI_ICD_CD"] == 'S098XXA':
        return '95901'
    elif x["PRI_ICD_CD"] == 'S0919XA':
        return '95901'
    elif x["PRI_ICD_CD"] == 'S0911XA':
        return '95901'
    elif x["PRI_ICD_CD"] == 'S0910XA':
        return '95901'
    elif x["PRI_ICD_CD"] == 'S199XXA':
        return '95909'
    elif x["PRI_ICD_CD"] == 'S1989XA':
        return '95909'
    elif x["PRI_ICD_CD"] == 'S1985XA':
        return '95909'
    elif x["PRI_ICD_CD"] == 'S1984XA':
        return '95909'
    elif x["PRI_ICD_CD"] == 'S1983XA':
        return '95909'
    elif x["PRI_ICD_CD"] == 'S1982XA':
        return '95909'
    elif x["PRI_ICD_CD"] == 'S1981XA':
        return '95909'
    elif x["PRI_ICD_CD"] == 'S1980XA':
        return '95909'
    elif x["PRI_ICD_CD"] == 'S169XXA':
        return '95909'
    elif x["PRI_ICD_CD"] == 'S168XXA':
        return '95909'
    elif x["PRI_ICD_CD"] == 'S0993XA':
        return '95909'
    elif x["PRI_ICD_CD"] == 'S0992XA':
        return '95909'
    elif x["PRI_ICD_CD"] == 'S3993XA':
        return '95919'
    elif x["PRI_ICD_CD"] == 'S3992XA':
        return '95919'
    elif x["PRI_ICD_CD"] == 'S3983XA':
        return '95919'
    elif x["PRI_ICD_CD"] == 'S3982XA':
        return '95919'
    elif x["PRI_ICD_CD"] == 'S39093A':
        return '95919'
    elif x["PRI_ICD_CD"] == 'S39092A':
        return '95919'
    elif x["PRI_ICD_CD"] == 'S39003A':
        return '95919'
    elif x["PRI_ICD_CD"] == 'S39002A':
        return '95919'
    else:
        return 'Unknown'


def f_PRMRY_ICD9_CD_5DIGIT(x):
    if len(str(x["Primary ICD9 Code"])) == 3:
        return str(x['Primary ICD9 Code']).strip() + "00"
    elif len(str(x["Primary ICD9 Code"])) == 4:
        return str(x['Primary ICD9 Code']).strip() + "0"
    else:
        return str(x['Primary ICD9 Code'])


def f_ICD9_TO_MDC(x):
    if (x["PRMRY_ICD9_CD_3DIGIT"] >= 'B20' and
        x["PRMRY_ICD9_CD_3DIGIT"] <= 'B24') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '042' and
         x["PRMRY_ICD9_CD_3DIGIT"] <= '044'):
        return "AIDS & ARC"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'A00' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'B99') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '001' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '139'):
        return "INFECTIOUS DISEASES"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'C00' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'D49') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '140' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '239'):
        return "NEOPLASMS"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'D50' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'D89') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '279' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '289'):
        return "BLOOD & BLOOD FORMING ORGANS"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'E00' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'E99') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '240' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '278'):
        return "ENDOCRINE SYSTEM"
    elif x["PRMRY_ICD9_CD_3DIGIT"] in ['F01', 'F02',
                                       'F03', 'F04', 'F05', 'F06',
                                       'F20', 'F21', 'F22', 'F23',
                                       'F24', 'F25', 'F28', 'F29',
                                       'F30', 'F31', 'F32', 'F33',
                                       'F34', 'F39', 'F53', 'F84'] or\
            (x["PRMRY_ICD9_CD_3DIGIT"] >= '290' and
             x["PRMRY_ICD9_CD_3DIGIT"] <= '299'):
        return "PSYCHOSES"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'F01' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'F99') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '300' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '319'):
        return "NON-PSYCHOTIC MENTAL DISORDERS"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'G00' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'G99') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '320' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '359'):
        return "NERVOUS SYSTEM"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'H00' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'H59') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '360' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '379'):
        return "EYE DISORDERS"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'H60' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'H95') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '380' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '389'):
        return "EAR DISORDERS"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'I00' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'I99') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '390' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '459'):
        return "CIRCULATORY SYSTEM"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'J00' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'J99') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '460' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '519'):
        return "RESPIRATORY SYSTEM"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'K00' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'K95') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '520' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '579'):
        return "DIGESTIVE  SYSTEM"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'L00' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'L99') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '680' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '709'):
        return "SKIN DISORDERS"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'M00' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'M96') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '710' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '739'):
        return "MUSCULOSKELETAL SYSTEM"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'N00' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'N99') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '580' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '629'):
        return "GENITOURINARY SYSTEM"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] == '650') or\
        x["PRMRY_ICD9_CD_3DIGIT"] in ['V22', 'V24', 'V27',
                                      'Z33', 'Z34', 'Z39', 'Z3A', 'O80']:
        return "NORMAL PREGNANCY & DELIVERY"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'O00' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'O99') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '630' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '679'):
        return "COMPLICATIONS OF PREGNANCY"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'P00' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'P96') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '760' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '779'):
        return "PERINATAL COMPLICATIONS"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'Q00' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'Q99') or\
        (x["PRMRY_ICD9_CD_3DIGIT"] >= '740' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '759'):
        return "CONGENITAL ANOMALIES"
    elif x["PRMRY_ICD9_CD_3DIGIT"] == '000' or\
            str(x["PRMRY_ICD9_CD_3DIGIT"]).strip() == '' or\
            x["PRMRY_ICD9_CD_3DIGIT"] == "" or\
            x["PRMRY_ICD9_CD_3DIGIT"] == 'Z75':
        return "UNKNOWN"
    elif (x["PRMRY_ICD9_CD_3DIGIT"] >= 'R00' and
          x["PRMRY_ICD9_CD_3DIGIT"] <= 'R99') or\
         (x["PRMRY_ICD9_CD_3DIGIT"] >= '780' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= '799') or\
         (x["PRMRY_ICD9_CD_3DIGIT"] >= 'Z00' and
            x["PRMRY_ICD9_CD_3DIGIT"] <= 'Z99'):
        return "ILL DEFINED CONDITIONS"
    else:
        return "INJURY & POISONING"


def f_ICD123(x):
    if x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M2390' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '6'
    elif x["MDC"] == 'ENDOCRINE SYSTEM' and x["PRI_ICD_CD"] == '27801' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '8'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == 'D259' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '10'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == 'F1020' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '14'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == 'O82' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '16'
    elif x["MDC"] == 'ENDOCRINE SYSTEM' and x["PRI_ICD_CD"] == '27801' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '19'
    elif x["MDC"] == 'ENDOCRINE SYSTEM' and x["PRI_ICD_CD"] == 'E6601' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '20'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == 'O82' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '25'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == 'F332' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '31'
    elif x["MDC"] == 'NORMAL PREGNANCY & DELIVERY' and x["PRI_ICD_CD"] == 'O80' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '38'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M1711' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '42'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == '6697' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '44'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M1711' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '45'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '55090' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '49'
    elif x["MDC"] == 'NORMAL PREGNANCY & DELIVERY' and x["PRI_ICD_CD"] == '650' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '53'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '71516' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '54'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M1712' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '56'
    elif x["MDC"] == 'NORMAL PREGNANCY & DELIVERY' and x["PRI_ICD_CD"] == 'O80' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '64'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '8360' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '67'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '2189' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '74'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == 'O82' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '75'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == 'D259' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '79'
    elif x["MDC"] == 'UNKNOWN' and x["PRI_ICD_CD"] == '74' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '80'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '71516' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '86'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == 'K4090' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '89'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == '6697' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '90'
    elif x["MDC"] == 'NORMAL PREGNANCY & DELIVERY' and x["PRI_ICD_CD"] == 'O80' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '96'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == '6697' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '98'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '717' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '99'
    elif x["MDC"] == 'NORMAL PREGNANCY & DELIVERY' and x["PRI_ICD_CD"] == '650' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '101'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7363' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '102'
    elif x["MDC"] == 'ENDOCRINE SYSTEM' and x["PRI_ICD_CD"] == 'E6601' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '103'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7366' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '105'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == '29633' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '112'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '4660' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '113'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '550' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '114'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == 'F322' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '128'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == '3540' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '129'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '486' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '130'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '72210' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '136'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == 'J209' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '137'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == 'J189' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '138'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == '29623' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '140'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7271' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '144'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '2189' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '145'
    elif x["MDC"] == 'NORMAL PREGNANCY & DELIVERY' and x["PRI_ICD_CD"] == '650' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '153'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '575' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '166'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == 'N949' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '169'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == 'I519' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '170'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '311' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '184'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == 'F331' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '188'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M5126' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '189'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '72210' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '192'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '72761' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '194'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == '29632' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '205'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M542' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '206'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '8360' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '209'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == 'J189' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '213'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == 'O82' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '214'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == '2962' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '217'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7242' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '220'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M5126' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '228'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M545' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '233'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == 'K829' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '237'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == '6697' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '238'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == '29633' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '239'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '8404' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '240'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == 'F1020' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '245'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '30002' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '246'
    elif x["MDC"] == 'NORMAL PREGNANCY & DELIVERY' and x["PRI_ICD_CD"] == 'O80' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '247'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '575' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '249'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == 'F320' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '253'
    elif x["MDC"] == 'NORMAL PREGNANCY & DELIVERY' and x["PRI_ICD_CD"] == '650' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '257'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7244' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '258'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == '3540' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '262'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7231' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '263'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == 'F332' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '264'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '72210' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '267'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7261' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '272'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == 'G5601' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '273'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '6218' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '274'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == 'G5600' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '276'
    elif x["MDC"] == 'NORMAL PREGNANCY & DELIVERY' and x["PRI_ICD_CD"] == 'O80' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '277'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '72252' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '281'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == 'N949' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '285'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '72210' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '286'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7245' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '291'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == 'F329' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '293'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == 'F411' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '297'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7366' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '299'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '8360' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '301'
    elif x["MDC"] == 'NORMAL PREGNANCY & DELIVERY' and x["PRI_ICD_CD"] == '650' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '304'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == 'F430' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '305'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '717' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '306'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '30000' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '307'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == 'F419' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '309'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7244' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '319'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '9999' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '320'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == 'F331' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '322'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M5126' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '327'
    elif x["MDC"] == 'NORMAL PREGNANCY & DELIVERY' and x["PRI_ICD_CD"] == 'O80' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '329'
    elif x["MDC"] == 'NORMAL PREGNANCY & DELIVERY' and x["PRI_ICD_CD"] == '650' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '337'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '71946' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '339'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == 'J189' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '344'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M542' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '353'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7242' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '354'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7231' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '356'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '30002' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '358'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == '646' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '360'
    elif x["MDC"] == 'UNKNOWN' and x["PRI_ICD_CD"] == 'Z759' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '367'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == 'F329' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '371'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '8470' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '375'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == 'F411' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '378'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M545' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '381'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == 'F320' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '383'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == '3540' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '384'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '486' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '385'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '8472' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '390'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '30981' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '392'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M549' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '393'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == 'I10' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '394'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '311' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '395'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == '2962' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '396'
    elif x["MDC"] == 'UNKNOWN' and x["PRI_ICD_CD"] == 'Z759' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '397'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == 'F419' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '398'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '30000' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '400'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == 'S3992XA' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '401'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '487' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '402'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == 'F328' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '403'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7245' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '404'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '724' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '405'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == '346' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '407'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == 'F430' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '408'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '9597' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '410'
    elif x["MDC"] == 'UNKNOWN' and x["PRI_ICD_CD"] == 'Z759' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '411'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '3089' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '412'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '9591' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '414'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == 'F6810' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '415'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == 'T1490' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '416'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '999' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '417'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '9599' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '418'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '7809' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '419'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '780' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '420'
    elif x["MDC"] == 'AIDS & ARC' and x["PRI_ICD_CD"] == '42' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '180'
    else:
        return 'Derive_2'


def f_ICD12(x):
    if x["ICD123"] != 'Derive_2':
        return x['ICD123']
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == '4140' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '5'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == 'K829' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '12'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '6262' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '13'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '71515' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '18'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '72210' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '30'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '5531' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '34'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '5531' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '36'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '1749' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '37'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M2010' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '58'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '575' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '62'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M1712' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '66'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == 'N949' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '70'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == 'G5601' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '78'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M150' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '88'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '1749' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '120'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '8404' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '132'
    elif x["MDC"] == 'NORMAL PREGNANCY & DELIVERY' and x["PRI_ICD_CD"] == 'O80' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '143'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M545' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '147'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M5416' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'No':
        return '154'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == 'K4090' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '156'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == 'K810' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '167'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '5539' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '173'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == 'F328' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '186'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == 'I10' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '193'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M2392' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '208'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == 'G5602' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '219'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == '29632' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'No':
        return '224'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '540' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '227'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '8470' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '252'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '30390' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'No':
        return '256'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M2391' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '279'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == '4299' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '287'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == '410' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'No':
        return '300'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == '340' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'No':
        return '315'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == 'F321' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'No':
        return '317'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M5136' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'No':
        return '324'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7220' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'No':
        return '336'
    elif x["MDC"] == 'UNKNOWN' and x["PRI_ICD_CD"] == 'Z759' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '352'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '71941' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'No':
        return '357'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '3039' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'No':
        return '362'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == '646' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '374'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '30001' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'No':
        return '380'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == '401' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'No':
        return '406'
    else:
        return 'Derive_3'


def f_ICD1(x):
    if x["ICD12"] != 'Derive_3':
        return x['ICD12']
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == 'I2510' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '3'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7354' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '4'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == 'C61' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '9'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '72402' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '11'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7350' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '15'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M722' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '22'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '56211' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '23'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '185' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '27'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M1611' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '29'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '5750' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '35'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M2012' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '40'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == 'K432' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '41'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M1612' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '43'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7220' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '46'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '57420' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '47'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == 'K3580' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '50'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == 'O82' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '51'
    elif x["MDC"] == 'ENDOCRINE SYSTEM' and x["PRI_ICD_CD"] == 'E6601' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '60'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == 'C50919' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '63'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M75121' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '69'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M5126' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '73'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M2011' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '76'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == 'K429' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '81'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '71596' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '85'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '82525' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '91'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == 'N8320' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '97'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == 'I639' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '111'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == 'K420' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '115'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == 'N920' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '116'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '71946' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '122'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == 'D259' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '125'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M4806' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '126'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '6218' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '131'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == 'I2510' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '133'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == 'D250' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '134'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '8442' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '135'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '470' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '141'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '2189' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '142'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7170' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '146'
    elif x["MDC"] == 'ENDOCRINE SYSTEM' and x["PRI_ICD_CD"] == '27801' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '157'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == '4140' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '159'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '621' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '160'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '174' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '161'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M5020' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '165'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '486' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '172'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == 'N200' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '178'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '72610' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '181'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '6259' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '182'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '5920' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '183'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '71516' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '195'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == 'J342' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '197'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == 'F322' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '201'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == '42731' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '202'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '496' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '216'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == 'F4323' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '223'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M2390' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '229'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7234' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '230'
    elif x["MDC"] == 'SKIN DISORDERS' and x["PRI_ICD_CD"] == '6826' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '231'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M722' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '232'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '3004' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '234'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M5412' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '236'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == 'G459' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '241'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M75101' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '242'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '72703' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '243'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '6202' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '244'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '7804' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '254'
    elif x["MDC"] == 'ENDOCRINE SYSTEM' and x["PRI_ICD_CD"] == 'E6601' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '255'
    elif x["MDC"] == 'CONGENITAL ANOMALIES' and x["PRI_ICD_CD"] == '75567' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '259'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M75100' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '266'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == '29620' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '268'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '487' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '271'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == 'G35' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '275'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '56211' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '278'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '72871' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '280'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '724' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '290'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '480' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '294'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '1749' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '296'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == 'F339' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '298'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == '2963' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '302'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '30928' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '303'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '7802' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '308'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M5020' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '310'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '78650' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '311'
    elif x["MDC"] == 'ENDOCRINE SYSTEM' and x["PRI_ICD_CD"] == '27801' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '313'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '3090' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '314'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == 'S134XXA' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '316'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7243' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '318'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == 'M25561' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '321'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == 'J069' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '323'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == 'F4310' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '328'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == 'F319' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '330'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == 'S335XXA' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '331'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == 'N200' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '335'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '824' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '338'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == 'F410' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '340'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '5920' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '341'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == 'J40' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '342'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '84500' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '346'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '8404' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '350'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == 'F1020' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '351'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '461' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '355'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '490' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '359'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '3000' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '361'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == 'G43009' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '365'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == 'S060X0A' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '369'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '7840' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '370'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == 'F4321' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '373'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '717' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '376'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7295' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '377'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '493' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '379'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '7890' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '389'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '7291' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '391'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '3009' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '409'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '780' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'No':
        return '413'
    else:
        return 'Derive_4'


def f_MDC123(x):
    if x["ICD1"] != 'Derive_4':
        return x['ICD1']
    elif x["MDC"] == 'SKIN DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '1'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '7'
    elif x["MDC"] == 'SKIN DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '17'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '21'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '24'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '26'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '28'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '32'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '33'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '39'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '48'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '52'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '55'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '57'
    elif x["MDC"] == 'SKIN DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '59'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '61'
    elif x["MDC"] == 'INFECTIOUS DISEASES' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '65'
    elif x["MDC"] == 'EYE DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '68'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '71'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '72'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '77'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '82'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '83'
    elif x["MDC"] == 'CONGENITAL ANOMALIES' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '84'
    elif x["MDC"] == 'ENDOCRINE SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '87'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '92'
    elif x["MDC"] == 'INFECTIOUS DISEASES' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '93'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '94'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '95'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '100'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '104'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '106'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '107'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '108'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '109'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '110'
    elif x["MDC"] == 'ENDOCRINE SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '117'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '118'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '119'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '121'
    elif x["MDC"] == 'SKIN DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '124'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '127'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '139'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '148'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '149'
    elif x["MDC"] == 'SKIN DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '150'
    elif x["MDC"] == 'ENDOCRINE SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '151'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '152'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '155'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '158'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '162'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '163'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '164'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '168'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '171'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '174'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '175'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '176'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '177'
    elif x["MDC"] == 'EAR DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '179'
    elif x["MDC"] == 'SKIN DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '185'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '187'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '190'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '191'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '196'
    elif x["MDC"] == 'INFECTIOUS DISEASES' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '198'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '199'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '200'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '203'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '204'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '207'
    elif x["MDC"] == 'EYE DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '210'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '211'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '212'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '215'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '218'
    elif x["MDC"] == 'ENDOCRINE SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '221'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '225'
    elif x["MDC"] == 'ENDOCRINE SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '226'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '248'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '250'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '251'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '261'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '265'
    elif x["MDC"] == 'ENDOCRINE SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '269'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '270'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '282'
    elif x["MDC"] == 'NEOPLASMS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '283'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '284'
    elif x["MDC"] == 'EYE DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '288'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '289'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '292'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'Yes' and x["V2"] == 'No' and x["V3"] == 'No':
        return '295'
    elif x["MDC"] == 'SKIN DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '312'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '325'
    elif x["MDC"] == 'PSYCHOSES' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '326'
    elif x["MDC"] == 'SKIN DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '332'
    elif x["MDC"] == 'EAR DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '333'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '334'
    elif x["MDC"] == 'MUSCULOSKELETAL SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '343'
    elif x["MDC"] == 'NERVOUS SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '345'
    elif x["MDC"] == 'EYE DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '347'
    elif x["MDC"] == 'CIRCULATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '348'
    elif x["MDC"] == 'COMPLICATIONS OF PREGNANCY' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '349'
    elif x["MDC"] == 'INJURY & POISONING' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '363'
    elif x["MDC"] == 'GENITOURINARY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '364'
    elif x["MDC"] == 'CONGENITAL ANOMALIES' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '366'
    elif x["MDC"] == 'RESPIRATORY SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '368'
    elif x["MDC"] == 'DIGESTIVE  SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '372'
    elif x["MDC"] == 'INFECTIOUS DISEASES' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '382'
    elif x["MDC"] == 'ENDOCRINE SYSTEM' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '386'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '387'
    elif x["MDC"] == 'ILL DEFINED CONDITIONS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '388'
    elif x["MDC"] == 'BLOOD & BLOOD FORMING ORGANS' and x["PRI_ICD_CD"] == '' and x["V1"] == 'No' and x["V2"] == 'No' and x["V3"] == 'No':
        return '399'
    else:
        return 'Derive_5'


def f_MDC_V23(x):
    if x["MDC123"] != 'Derive_5':
        return x['MDC123']
    elif x["MDC"] == 'CONGENITAL ANOMALIES' and x["PRI_ICD_CD"] == '' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'Yes':
        return '2'
    elif x["MDC"] == 'BLOOD & BLOOD FORMING ORGANS' and x["PRI_ICD_CD"] == '' and x["V1"] == '' and x["V2"] == 'Yes' and x["V3"] == 'No':
        return '123'
    elif x["MDC"] == 'NON-PSYCHOTIC MENTAL DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == '' and x["V2"] == 'No' and x["V3"] == 'Yes':
        return '235'
    else:
        return 'Derive_6'


def f_Microsegments_D(x):
    if x["MDC+V23"] != 'Derive_6':
        return x['MDC+V23']
    elif x["MDC"] == 'EAR DISORDERS' and x["PRI_ICD_CD"] == '' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '222'
    elif x["MDC"] == 'INFECTIOUS DISEASES' and x["PRI_ICD_CD"] == '' and x["V1"] == '' and x["V2"] == '' and x["V3"] == 'Yes':
        return '260'
    else:
        return 'Unknown'


def f_Approval_Rate(x):
    if x["Microsegments"] == 1:
        return 1
    elif x["Microsegments"] == 2:
        return 1
    elif x["Microsegments"] == 3:
        return 0.996
    elif x["Microsegments"] == 4:
        return 0.996
    elif x["Microsegments"] == 5:
        return 0.995
    elif x["Microsegments"] == 6:
        return 0.995
    elif x["Microsegments"] == 7:
        return 0.995
    elif x["Microsegments"] == 8:
        return 0.994
    elif x["Microsegments"] == 9:
        return 0.994
    elif x["Microsegments"] == 10:
        return 0.993
    elif x["Microsegments"] == 11:
        return 0.993
    elif x["Microsegments"] == 12:
        return 0.992
    elif x["Microsegments"] == 13:
        return 0.992
    elif x["Microsegments"] == 14:
        return 0.991
    elif x["Microsegments"] == 15:
        return 0.991
    elif x["Microsegments"] == 16:
        return 0.991
    elif x["Microsegments"] == 17:
        return 0.991
    elif x["Microsegments"] == 18:
        return 0.991
    elif x["Microsegments"] == 19:
        return 0.99
    elif x["Microsegments"] == 20:
        return 0.99
    elif x["Microsegments"] == 21:
        return 0.99
    elif x["Microsegments"] == 22:
        return 0.99
    elif x["Microsegments"] == 23:
        return 0.99
    elif x["Microsegments"] == 24:
        return 0.99
    elif x["Microsegments"] == 25:
        return 0.99
    elif x["Microsegments"] == 26:
        return 0.989
    elif x["Microsegments"] == 27:
        return 0.989
    elif x["Microsegments"] == 28:
        return 0.989
    elif x["Microsegments"] == 29:
        return 0.989
    elif x["Microsegments"] == 30:
        return 0.988
    elif x["Microsegments"] == 31:
        return 0.988
    elif x["Microsegments"] == 32:
        return 0.988
    elif x["Microsegments"] == 33:
        return 0.988
    elif x["Microsegments"] == 34:
        return 0.988
    elif x["Microsegments"] == 35:
        return 0.987
    elif x["Microsegments"] == 36:
        return 0.987
    elif x["Microsegments"] == 37:
        return 0.987
    elif x["Microsegments"] == 38:
        return 0.987
    elif x["Microsegments"] == 39:
        return 0.987
    elif x["Microsegments"] == 40:
        return 0.987
    elif x["Microsegments"] == 41:
        return 0.987
    elif x["Microsegments"] == 42:
        return 0.987
    elif x["Microsegments"] == 43:
        return 0.987
    elif x["Microsegments"] == 44:
        return 0.987
    elif x["Microsegments"] == 45:
        return 0.986
    elif x["Microsegments"] == 46:
        return 0.986
    elif x["Microsegments"] == 47:
        return 0.986
    elif x["Microsegments"] == 48:
        return 0.986
    elif x["Microsegments"] == 49:
        return 0.986
    elif x["Microsegments"] == 50:
        return 0.986
    elif x["Microsegments"] == 51:
        return 0.986
    elif x["Microsegments"] == 52:
        return 0.986
    elif x["Microsegments"] == 53:
        return 0.986
    elif x["Microsegments"] == 54:
        return 0.986
    elif x["Microsegments"] == 55:
        return 0.986
    elif x["Microsegments"] == 56:
        return 0.985
    elif x["Microsegments"] == 57:
        return 0.985
    elif x["Microsegments"] == 58:
        return 0.985
    elif x["Microsegments"] == 59:
        return 0.985
    elif x["Microsegments"] == 60:
        return 0.985
    elif x["Microsegments"] == 61:
        return 0.984
    elif x["Microsegments"] == 62:
        return 0.984
    elif x["Microsegments"] == 63:
        return 0.984
    elif x["Microsegments"] == 64:
        return 0.984
    elif x["Microsegments"] == 65:
        return 0.984
    elif x["Microsegments"] == 66:
        return 0.984
    elif x["Microsegments"] == 67:
        return 0.984
    elif x["Microsegments"] == 68:
        return 0.983
    elif x["Microsegments"] == 69:
        return 0.983
    elif x["Microsegments"] == 70:
        return 0.983
    elif x["Microsegments"] == 71:
        return 0.983
    elif x["Microsegments"] == 72:
        return 0.983
    elif x["Microsegments"] == 73:
        return 0.983
    elif x["Microsegments"] == 74:
        return 0.983
    elif x["Microsegments"] == 75:
        return 0.982
    elif x["Microsegments"] == 76:
        return 0.982
    elif x["Microsegments"] == 77:
        return 0.982
    elif x["Microsegments"] == 78:
        return 0.982
    elif x["Microsegments"] == 79:
        return 0.982
    elif x["Microsegments"] == 80:
        return 0.982
    elif x["Microsegments"] == 81:
        return 0.981
    elif x["Microsegments"] == 82:
        return 0.981
    elif x["Microsegments"] == 83:
        return 0.981
    elif x["Microsegments"] == 84:
        return 0.981
    elif x["Microsegments"] == 85:
        return 0.98
    elif x["Microsegments"] == 86:
        return 0.98
    elif x["Microsegments"] == 87:
        return 0.98
    elif x["Microsegments"] == 88:
        return 0.98
    elif x["Microsegments"] == 89:
        return 0.98
    elif x["Microsegments"] == 90:
        return 0.98
    elif x["Microsegments"] == 91:
        return 0.98
    elif x["Microsegments"] == 92:
        return 0.979
    elif x["Microsegments"] == 93:
        return 0.979
    elif x["Microsegments"] == 94:
        return 0.979
    elif x["Microsegments"] == 95:
        return 0.979
    elif x["Microsegments"] == 96:
        return 0.979
    elif x["Microsegments"] == 97:
        return 0.979
    elif x["Microsegments"] == 98:
        return 0.978
    elif x["Microsegments"] == 99:
        return 0.978
    elif x["Microsegments"] == 100:
        return 0.978
    elif x["Microsegments"] == 101:
        return 0.978
    elif x["Microsegments"] == 102:
        return 0.978
    elif x["Microsegments"] == 103:
        return 0.978
    elif x["Microsegments"] == 104:
        return 0.977
    elif x["Microsegments"] == 105:
        return 0.977
    elif x["Microsegments"] == 106:
        return 0.977
    elif x["Microsegments"] == 107:
        return 0.977
    elif x["Microsegments"] == 108:
        return 0.977
    elif x["Microsegments"] == 109:
        return 0.977
    elif x["Microsegments"] == 110:
        return 0.977
    elif x["Microsegments"] == 111:
        return 0.976
    elif x["Microsegments"] == 112:
        return 0.976
    elif x["Microsegments"] == 113:
        return 0.976
    elif x["Microsegments"] == 114:
        return 0.976
    elif x["Microsegments"] == 115:
        return 0.976
    elif x["Microsegments"] == 116:
        return 0.976
    elif x["Microsegments"] == 117:
        return 0.975
    elif x["Microsegments"] == 118:
        return 0.975
    elif x["Microsegments"] == 119:
        return 0.975
    elif x["Microsegments"] == 120:
        return 0.975
    elif x["Microsegments"] == 121:
        return 0.975
    elif x["Microsegments"] == 122:
        return 0.975
    elif x["Microsegments"] == 123:
        return 0.974
    elif x["Microsegments"] == 124:
        return 0.974
    elif x["Microsegments"] == 125:
        return 0.974
    elif x["Microsegments"] == 126:
        return 0.974
    elif x["Microsegments"] == 127:
        return 0.973
    elif x["Microsegments"] == 128:
        return 0.973
    elif x["Microsegments"] == 129:
        return 0.973
    elif x["Microsegments"] == 130:
        return 0.972
    elif x["Microsegments"] == 131:
        return 0.972
    elif x["Microsegments"] == 132:
        return 0.972
    elif x["Microsegments"] == 133:
        return 0.972
    elif x["Microsegments"] == 134:
        return 0.971
    elif x["Microsegments"] == 135:
        return 0.971
    elif x["Microsegments"] == 136:
        return 0.971
    elif x["Microsegments"] == 137:
        return 0.97
    elif x["Microsegments"] == 138:
        return 0.97
    elif x["Microsegments"] == 139:
        return 0.97
    elif x["Microsegments"] == 140:
        return 0.969
    elif x["Microsegments"] == 141:
        return 0.968
    elif x["Microsegments"] == 142:
        return 0.968
    elif x["Microsegments"] == 143:
        return 0.967
    elif x["Microsegments"] == 144:
        return 0.967
    elif x["Microsegments"] == 145:
        return 0.967
    elif x["Microsegments"] == 146:
        return 0.967
    elif x["Microsegments"] == 147:
        return 0.967
    elif x["Microsegments"] == 148:
        return 0.967
    elif x["Microsegments"] == 149:
        return 0.967
    elif x["Microsegments"] == 150:
        return 0.966
    elif x["Microsegments"] == 151:
        return 0.966
    elif x["Microsegments"] == 152:
        return 0.965
    elif x["Microsegments"] == 153:
        return 0.965
    elif x["Microsegments"] == 154:
        return 0.965
    elif x["Microsegments"] == 155:
        return 0.965
    elif x["Microsegments"] == 156:
        return 0.965
    elif x["Microsegments"] == 157:
        return 0.964
    elif x["Microsegments"] == 158:
        return 0.964
    elif x["Microsegments"] == 159:
        return 0.964
    elif x["Microsegments"] == 160:
        return 0.963
    elif x["Microsegments"] == 161:
        return 0.963
    elif x["Microsegments"] == 162:
        return 0.963
    elif x["Microsegments"] == 163:
        return 0.963
    elif x["Microsegments"] == 164:
        return 0.962
    elif x["Microsegments"] == 165:
        return 0.962
    elif x["Microsegments"] == 166:
        return 0.962
    elif x["Microsegments"] == 167:
        return 0.962
    elif x["Microsegments"] == 168:
        return 0.961
    elif x["Microsegments"] == 169:
        return 0.961
    elif x["Microsegments"] == 170:
        return 0.961
    elif x["Microsegments"] == 171:
        return 0.961
    elif x["Microsegments"] == 172:
        return 0.961
    elif x["Microsegments"] == 173:
        return 0.961
    elif x["Microsegments"] == 174:
        return 0.96
    elif x["Microsegments"] == 175:
        return 0.96
    elif x["Microsegments"] == 176:
        return 0.96
    elif x["Microsegments"] == 177:
        return 0.96
    elif x["Microsegments"] == 178:
        return 0.96
    elif x["Microsegments"] == 179:
        return 0.96
    elif x["Microsegments"] == 180:
        return 0.96
    elif x["Microsegments"] == 181:
        return 0.959
    elif x["Microsegments"] == 182:
        return 0.959
    elif x["Microsegments"] == 183:
        return 0.957
    elif x["Microsegments"] == 184:
        return 0.957
    elif x["Microsegments"] == 185:
        return 0.957
    elif x["Microsegments"] == 186:
        return 0.956
    elif x["Microsegments"] == 187:
        return 0.956
    elif x["Microsegments"] == 188:
        return 0.956
    elif x["Microsegments"] == 189:
        return 0.956
    elif x["Microsegments"] == 190:
        return 0.955
    elif x["Microsegments"] == 191:
        return 0.955
    elif x["Microsegments"] == 192:
        return 0.955
    elif x["Microsegments"] == 193:
        return 0.955
    elif x["Microsegments"] == 194:
        return 0.954
    elif x["Microsegments"] == 195:
        return 0.954
    elif x["Microsegments"] == 196:
        return 0.953
    elif x["Microsegments"] == 197:
        return 0.953
    elif x["Microsegments"] == 198:
        return 0.952
    elif x["Microsegments"] == 199:
        return 0.951
    elif x["Microsegments"] == 200:
        return 0.951
    elif x["Microsegments"] == 201:
        return 0.951
    elif x["Microsegments"] == 202:
        return 0.95
    elif x["Microsegments"] == 203:
        return 0.95
    elif x["Microsegments"] == 204:
        return 0.949
    elif x["Microsegments"] == 205:
        return 0.949
    elif x["Microsegments"] == 206:
        return 0.949
    elif x["Microsegments"] == 207:
        return 0.948
    elif x["Microsegments"] == 208:
        return 0.948
    elif x["Microsegments"] == 209:
        return 0.948
    elif x["Microsegments"] == 210:
        return 0.948
    elif x["Microsegments"] == 211:
        return 0.947
    elif x["Microsegments"] == 212:
        return 0.947
    elif x["Microsegments"] == 213:
        return 0.947
    elif x["Microsegments"] == 214:
        return 0.946
    elif x["Microsegments"] == 215:
        return 0.946
    elif x["Microsegments"] == 216:
        return 0.946
    elif x["Microsegments"] == 217:
        return 0.946
    elif x["Microsegments"] == 218:
        return 0.945
    elif x["Microsegments"] == 219:
        return 0.945
    elif x["Microsegments"] == 220:
        return 0.945
    elif x["Microsegments"] == 221:
        return 0.944
    elif x["Microsegments"] == 222:
        return 0.943
    elif x["Microsegments"] == 223:
        return 0.943
    elif x["Microsegments"] == 224:
        return 0.943
    elif x["Microsegments"] == 225:
        return 0.943
    elif x["Microsegments"] == 226:
        return 0.943
    elif x["Microsegments"] == 227:
        return 0.942
    elif x["Microsegments"] == 228:
        return 0.942
    elif x["Microsegments"] == 229:
        return 0.942
    elif x["Microsegments"] == 230:
        return 0.942
    elif x["Microsegments"] == 231:
        return 0.941
    elif x["Microsegments"] == 232:
        return 0.941
    elif x["Microsegments"] == 233:
        return 0.941
    elif x["Microsegments"] == 234:
        return 0.938
    elif x["Microsegments"] == 235:
        return 0.938
    elif x["Microsegments"] == 236:
        return 0.938
    elif x["Microsegments"] == 237:
        return 0.937
    elif x["Microsegments"] == 238:
        return 0.937
    elif x["Microsegments"] == 239:
        return 0.936
    elif x["Microsegments"] == 240:
        return 0.936
    elif x["Microsegments"] == 241:
        return 0.936
    elif x["Microsegments"] == 242:
        return 0.935
    elif x["Microsegments"] == 243:
        return 0.935
    elif x["Microsegments"] == 244:
        return 0.935
    elif x["Microsegments"] == 245:
        return 0.934
    elif x["Microsegments"] == 246:
        return 0.934
    elif x["Microsegments"] == 247:
        return 0.933
    elif x["Microsegments"] == 248:
        return 0.933
    elif x["Microsegments"] == 249:
        return 0.933
    elif x["Microsegments"] == 250:
        return 0.932
    elif x["Microsegments"] == 251:
        return 0.932
    elif x["Microsegments"] == 252:
        return 0.931
    elif x["Microsegments"] == 253:
        return 0.931
    elif x["Microsegments"] == 254:
        return 0.93
    elif x["Microsegments"] == 255:
        return 0.93
    elif x["Microsegments"] == 256:
        return 0.93
    elif x["Microsegments"] == 257:
        return 0.929
    elif x["Microsegments"] == 258:
        return 0.929
    elif x["Microsegments"] == 259:
        return 0.928
    elif x["Microsegments"] == 260:
        return 0.928
    elif x["Microsegments"] == 261:
        return 0.927
    elif x["Microsegments"] == 262:
        return 0.926
    elif x["Microsegments"] == 263:
        return 0.926
    elif x["Microsegments"] == 264:
        return 0.924
    elif x["Microsegments"] == 265:
        return 0.924
    elif x["Microsegments"] == 266:
        return 0.923
    elif x["Microsegments"] == 267:
        return 0.923
    elif x["Microsegments"] == 268:
        return 0.923
    elif x["Microsegments"] == 269:
        return 0.923
    elif x["Microsegments"] == 270:
        return 0.923
    elif x["Microsegments"] == 271:
        return 0.922
    elif x["Microsegments"] == 272:
        return 0.922
    elif x["Microsegments"] == 273:
        return 0.921
    elif x["Microsegments"] == 274:
        return 0.92
    elif x["Microsegments"] == 275:
        return 0.92
    elif x["Microsegments"] == 276:
        return 0.919
    elif x["Microsegments"] == 277:
        return 0.917
    elif x["Microsegments"] == 278:
        return 0.917
    elif x["Microsegments"] == 279:
        return 0.917
    elif x["Microsegments"] == 280:
        return 0.916
    elif x["Microsegments"] == 281:
        return 0.915
    elif x["Microsegments"] == 282:
        return 0.915
    elif x["Microsegments"] == 283:
        return 0.913
    elif x["Microsegments"] == 284:
        return 0.912
    elif x["Microsegments"] == 285:
        return 0.911
    elif x["Microsegments"] == 286:
        return 0.91
    elif x["Microsegments"] == 287:
        return 0.91
    elif x["Microsegments"] == 288:
        return 0.91
    elif x["Microsegments"] == 289:
        return 0.91
    elif x["Microsegments"] == 290:
        return 0.909
    elif x["Microsegments"] == 291:
        return 0.909
    elif x["Microsegments"] == 292:
        return 0.908
    elif x["Microsegments"] == 293:
        return 0.907
    elif x["Microsegments"] == 294:
        return 0.906
    elif x["Microsegments"] == 295:
        return 0.904
    elif x["Microsegments"] == 296:
        return 0.904
    elif x["Microsegments"] == 297:
        return 0.903
    elif x["Microsegments"] == 298:
        return 0.902
    elif x["Microsegments"] == 299:
        return 0.902
    elif x["Microsegments"] == 300:
        return 0.901
    elif x["Microsegments"] == 301:
        return 0.901
    elif x["Microsegments"] == 302:
        return 0.9
    elif x["Microsegments"] == 303:
        return 0.9
    elif x["Microsegments"] == 304:
        return 0.899
    elif x["Microsegments"] == 305:
        return 0.899
    elif x["Microsegments"] == 306:
        return 0.898
    elif x["Microsegments"] == 307:
        return 0.898
    elif x["Microsegments"] == 308:
        return 0.898
    elif x["Microsegments"] == 309:
        return 0.897
    elif x["Microsegments"] == 310:
        return 0.897
    elif x["Microsegments"] == 311:
        return 0.896
    elif x["Microsegments"] == 312:
        return 0.894
    elif x["Microsegments"] == 313:
        return 0.892
    elif x["Microsegments"] == 314:
        return 0.89
    elif x["Microsegments"] == 315:
        return 0.886
    elif x["Microsegments"] == 316:
        return 0.886
    elif x["Microsegments"] == 317:
        return 0.884
    elif x["Microsegments"] == 318:
        return 0.884
    elif x["Microsegments"] == 319:
        return 0.882
    elif x["Microsegments"] == 320:
        return 0.879
    elif x["Microsegments"] == 321:
        return 0.878
    elif x["Microsegments"] == 322:
        return 0.878
    elif x["Microsegments"] == 323:
        return 0.872
    elif x["Microsegments"] == 324:
        return 0.867
    elif x["Microsegments"] == 325:
        return 0.862
    elif x["Microsegments"] == 326:
        return 0.861
    elif x["Microsegments"] == 327:
        return 0.859
    elif x["Microsegments"] == 328:
        return 0.858
    elif x["Microsegments"] == 329:
        return 0.857
    elif x["Microsegments"] == 330:
        return 0.855
    elif x["Microsegments"] == 331:
        return 0.855
    elif x["Microsegments"] == 332:
        return 0.849
    elif x["Microsegments"] == 333:
        return 0.847
    elif x["Microsegments"] == 334:
        return 0.846
    elif x["Microsegments"] == 335:
        return 0.845
    elif x["Microsegments"] == 336:
        return 0.842
    elif x["Microsegments"] == 337:
        return 0.841
    elif x["Microsegments"] == 338:
        return 0.841
    elif x["Microsegments"] == 339:
        return 0.838
    elif x["Microsegments"] == 340:
        return 0.836
    elif x["Microsegments"] == 341:
        return 0.836
    elif x["Microsegments"] == 342:
        return 0.835
    elif x["Microsegments"] == 343:
        return 0.835
    elif x["Microsegments"] == 344:
        return 0.835
    elif x["Microsegments"] == 345:
        return 0.834
    elif x["Microsegments"] == 346:
        return 0.829
    elif x["Microsegments"] == 347:
        return 0.825
    elif x["Microsegments"] == 348:
        return 0.823
    elif x["Microsegments"] == 349:
        return 0.821
    elif x["Microsegments"] == 350:
        return 0.821
    elif x["Microsegments"] == 351:
        return 0.817
    elif x["Microsegments"] == 352:
        return 0.811
    elif x["Microsegments"] == 353:
        return 0.81
    elif x["Microsegments"] == 354:
        return 0.805
    elif x["Microsegments"] == 355:
        return 0.804
    elif x["Microsegments"] == 356:
        return 0.803
    elif x["Microsegments"] == 357:
        return 0.8
    elif x["Microsegments"] == 358:
        return 0.799
    elif x["Microsegments"] == 359:
        return 0.799
    elif x["Microsegments"] == 360:
        return 0.798
    elif x["Microsegments"] == 361:
        return 0.797
    elif x["Microsegments"] == 362:
        return 0.796
    elif x["Microsegments"] == 363:
        return 0.794
    elif x["Microsegments"] == 364:
        return 0.793
    elif x["Microsegments"] == 365:
        return 0.789
    elif x["Microsegments"] == 366:
        return 0.789
    elif x["Microsegments"] == 367:
        return 0.784
    elif x["Microsegments"] == 368:
        return 0.784
    elif x["Microsegments"] == 369:
        return 0.783
    elif x["Microsegments"] == 370:
        return 0.783
    elif x["Microsegments"] == 371:
        return 0.778
    elif x["Microsegments"] == 372:
        return 0.778
    elif x["Microsegments"] == 373:
        return 0.777
    elif x["Microsegments"] == 374:
        return 0.774
    elif x["Microsegments"] == 375:
        return 0.773
    elif x["Microsegments"] == 376:
        return 0.773
    elif x["Microsegments"] == 377:
        return 0.77
    elif x["Microsegments"] == 378:
        return 0.765
    elif x["Microsegments"] == 379:
        return 0.758
    elif x["Microsegments"] == 380:
        return 0.757
    elif x["Microsegments"] == 381:
        return 0.755
    elif x["Microsegments"] == 382:
        return 0.753
    elif x["Microsegments"] == 383:
        return 0.751
    elif x["Microsegments"] == 384:
        return 0.749
    elif x["Microsegments"] == 385:
        return 0.748
    elif x["Microsegments"] == 386:
        return 0.745
    elif x["Microsegments"] == 387:
        return 0.721
    elif x["Microsegments"] == 388:
        return 0.716
    elif x["Microsegments"] == 389:
        return 0.705
    elif x["Microsegments"] == 390:
        return 0.701
    elif x["Microsegments"] == 391:
        return 0.7
    elif x["Microsegments"] == 392:
        return 0.699
    elif x["Microsegments"] == 393:
        return 0.696
    elif x["Microsegments"] == 394:
        return 0.696
    elif x["Microsegments"] == 395:
        return 0.679
    elif x["Microsegments"] == 396:
        return 0.668
    elif x["Microsegments"] == 397:
        return 0.647
    elif x["Microsegments"] == 398:
        return 0.642
    elif x["Microsegments"] == 399:
        return 0.607
    elif x["Microsegments"] == 400:
        return 0.605
    elif x["Microsegments"] == 401:
        return 0.587
    elif x["Microsegments"] == 402:
        return 0.585
    elif x["Microsegments"] == 403:
        return 0.576
    elif x["Microsegments"] == 404:
        return 0.573
    elif x["Microsegments"] == 405:
        return 0.553
    elif x["Microsegments"] == 406:
        return 0.543
    elif x["Microsegments"] == 407:
        return 0.535
    elif x["Microsegments"] == 408:
        return 0.521
    elif x["Microsegments"] == 409:
        return 0.513
    elif x["Microsegments"] == 410:
        return 0.506
    elif x["Microsegments"] == 411:
        return 0.454
    elif x["Microsegments"] == 412:
        return 0.426
    elif x["Microsegments"] == 413:
        return 0.371
    elif x["Microsegments"] == 414:
        return 0.343
    elif x["Microsegments"] == 415:
        return 0.325
    elif x["Microsegments"] == 416:
        return 0.296
    elif x["Microsegments"] == 417:
        return 0.269
    elif x["Microsegments"] == 418:
        return 0.268
    elif x["Microsegments"] == 419:
        return 0.248
    elif x["Microsegments"] == 420:
        return 0.223
    else:
        return 0


def convert_to_float(x):
    try:
        return float(x)
    except:
        return x
