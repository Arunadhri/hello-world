#############################################################################
# ---------------------------------------------------------------------------
#                            Program Information
# ---------------------------------------------------------------------------
# Author                 : Arunadhri Srinivasan, Shanmugaraja Dakshinamoorthy
# Creation Date          : 29APR2019
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#                             Script Information
# ---------------------------------------------------------------------------
# Script Name            : std_dsaa_599_scoring.py
# Bitbucket Project/Repo : DnAAnalytics-US-Group/US-GRP-MO-STD-DSAA
# Brief Description      : Script for automating the adjudication process for
#                          std claims
# Data Used              : ad_main, ad_treatment
# Input Files            : N/A
# Output Files           : N/A
# Notes / Assumptions    : Imports helper functions from
#                          std_dsaa_599_functions.py
# ---------------------------------------------------------------------------
#                            Environment Information
# ---------------------------------------------------------------------------
# Python Version         : 3.6.3
# Anaconda Version       : 5.0.1
# Spark Version          : N/A
# Operating System       : Red Hat Enterprise Linux 7.4
# ---------------------------------------------------------------------------
# ###########################################################################

import pandas as pd
import os
import time
from datetime import datetime
import sys
sys.path.append('./python')

try:
    from config import Config
except ImportError:
    raise ImportError('Failed to import Config class')

# Fetch Config Parameters
try:
    env = os.environ.get('ENV')
    app_path = os.getcwd()
    config = Config(env, app_path)
    log = config.get_logger()
except Exception:
    raise Exception('Failed to initiate config and log file.')

# Get values stored in the config file.
try:
    outputdir = config.getConfigValueFor('outputdir')
    inputdir = config.getConfigValueFor('inputdir')
    main_data_file_name = config.getConfigValueFor('main_data_file_name')
    treatment_data_file_name = config.getConfigValueFor('treatment_data_file_name')
    export_file_name = config.getConfigValueFor('export_file_name')
except Exception as e:
    log.error('Failed to read the input and export data path')
    raise e

try:
    from std_dsaa_599_functions import (feature_supernode,
                                        feature_icd123,
                                        feature_icd12, feature_icd1,
                                        feature_mdc123, feature_mdc_v23,
                                        feature_microsegments_d,
                                        feature_approval_rate,
                                        check_numeric_icd_cd_ver)
except Exception as e:
    log.exception('Failed to import std_dsaa_599_functions')
    raise e

#############################################################################
#
# Function definitions
#
#############################################################################


def data_import(inputdir, main_data_file_name, treatment_data_file_name, log=log):
    log.info('Data import method is starting')
    # Get data from flat files
    ad_main_dtype = {'TRANS_ID': str,
                     'CLM_NUM_CD': str,
                     'CVR_CD': str,
                     'APRV_OPER_CD': str,
                     'RPT_NUM': str,
                     'JOB_CLASS_CD': str,
                     'ICD_CD_VER': str,
                     'PRI_ICD_CD': str,
                     'SEC_ICD_CD': str,
                     'MJR_DX_CTGY_DSCR': str}
    ad_treatment_dtype = {'CLM_NUM_CD': str,
                          'CPT4_PROC_1_CD': str,
                          'CPT4_PROC_2_CD': str}
    try:
        input_file1 = os.path.join(inputdir, main_data_file_name)
        ad_main = pd.read_csv(input_file1, sep='|',
                              parse_dates=['CLM_RECD_DT', 'DABL_DT',
                                           'RTRN_TO_WRK_DT', 'RQST_TS'],
                              dtype=ad_main_dtype)
    except Exception as e:
        log.exception('Failed to load the ad_main data')
        raise e
    try:
        input_file2 = os.path.join(inputdir, treatment_data_file_name)
        ad_treatment = pd.read_csv(input_file2, sep='|',
                                   parse_dates=['HOSP_ADMIT_DT', 'PROG_DT',
                                                'TREAT_DT'],
                                   dtype=ad_treatment_dtype)
    except Exception as e:
        log.exception('Failed to load the ad_treatment data')
        raise e
    log.info('Data import method is now complete')
    return ad_main, ad_treatment


def data_prep(ad_main, ad_treatment, log=log):
    start_time = time.time()
    log.info('Data preperation method is starting')
    ad_main['RequestReceivedTS'] = pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
    df = ad_main.merge(ad_treatment, how='left', on='CLM_NUM_CD')
    df.loc[:, 'DATA_VALIDATION'] = ''
    df.loc[:, 'DATA_VALIDATION'] = df['ICD_CD_VER'].apply(check_numeric_icd_cd_ver)
    df.loc[((df['CLM_NUM_CD'].str.strip() == '')
           | (df['CLM_NUM_CD'].isnull()))
           & (df['DATA_VALIDATION'] == ''), 'DATA_VALIDATION'] = 'Required value not provided for CLM_NUM_CD. A valid value for this field is required in order to calculate a score.'
    df.loc[((df['TRANS_ID'].str.strip() == '')
           | (df['TRANS_ID'].isnull()))
           & (df['DATA_VALIDATION'] == ''), 'DATA_VALIDATION'] = 'Required value not provided for TRANS_ID. A valid value for this field is required in order to calculate a score.'
    df.loc[((df['PRI_ICD_CD'].str.strip() == '')
           | (df['PRI_ICD_CD'].isnull()))
           & (df['DATA_VALIDATION'] == ''), 'DATA_VALIDATION'] = 'Required value not provided for PRI_ICD_CD.  A valid value for this field is required in order to calculate a score.'
    validation_fail_df = df[df['DATA_VALIDATION'] != ''].copy()
    validation_pass_df = df[df['DATA_VALIDATION'] == ''].copy()
    log.info('Data preperation is now complete')
    log.warning("data prep method is completed in: [ %s ] Seconds ---" % (time.time() - start_time))
    return validation_fail_df, validation_pass_df


def feature_validation_fail_process(df, log=log):
    start_time = time.time()
    log.info('feature_validation_fail_process method is starting')
    df.loc[:, 'ResultReasonDesc1'] = df['DATA_VALIDATION']
    df.loc[:, 'ResultReasonDesc2'] = ''
    df.loc[:, 'ResultReasonDesc3'] = ''
    df.loc[:, 'ResultReasonDesc4'] = ''
    df.loc[:, 'ResultReasonDesc5'] = ''
    df.loc[:, 'AutoAdjudicationDecision'] = 'U'
    df.loc[:, 'ApprovalRate'] = 0
    df.loc[:, 'HaveSurgeryDate'] = ''
    df.loc[:, 'HavePrognosisDate'] = ''
    df.loc[:, 'HaveHospitalizationDate'] = ''
    df.loc[:, 'XeroxGroup'] = ''
    df.loc[:, 'ClusterType'] = ''
    df.loc[:, 'Microsegment'] = 0
    df.rename(columns={'CLM_NUM_CD': 'ClaimNumberCode'}, inplace=True)
    df = df.drop(['CLM_RECD_DT', 'CVR_CD', 'DABL_DT', 'RTRN_TO_WRK_DT', 'APRV_OPER_CD',
                  'RPT_NUM', 'JOB_CLASS_CD', 'PRI_ICD_CD', 'SEC_ICD_CD',
                  'MJR_DX_CTGY_DSCR', 'RQST_TS'], axis=1)
    log.info('Feature_validation_fail_process method is now complete')
    log.warning("feature_validation_fail_process method is completed in: [ %s ] Seconds ---" % (time.time() - start_time))
    return df


def feature_validation_pass_process(df, log=log):
    start_time = time.time()
    log.info('feature_validation_pass_process method is starting')
    df = feature_supernode(df)
    df.rename(columns={'Have Hospitalization Date': 'V1',
                       'Have Prognosis Date': 'V2',
                       'Have Surgery Date': 'V3',
                       'MJR_DX_CTGY_DSCR': 'MDC'}, inplace=True)
    df1 = df.copy(deep=True)
    df1.loc[:, 'ICD123'] = feature_icd123(df1['MDC'].values, df1['PRI_ICD_CD'].values, df1['V2'].values, df1['V1'].values, df1['V3'].values)
    df2 = df1.copy(deep=True)
    df2 = df2[['CLM_NUM_CD', 'V1', 'V2']]
    df1.loc[:, 'V1'] = ''
    df1.loc[:, 'ICD12'] = feature_icd12(df1['MDC'].values, df1['PRI_ICD_CD'].values, df1['ICD123'].values, df1['V2'].values, df1['V1'].values, df1['V3'].values)
    df1.loc[:, 'V2'] = ''
    df1.loc[:, 'ICD1'] = feature_icd1(df1['ICD12'].values, df1['MDC'].values, df1['PRI_ICD_CD'].values, df1['V2'].values, df1['V1'].values, df1['V3'].values)
    df1 = df1.drop(['V1', 'V2'], axis=1)
    df1 = df1.merge(df2, how='left', on='CLM_NUM_CD')
    df1.loc[:, 'PRI_ICD_CD'] = ''
    df1.loc[:, 'MDC123'] = feature_mdc123(df1['MDC'].values, df1['PRI_ICD_CD'].values, df1['V2'].values, df1['V1'].values, df1['V3'].values, df1['ICD1'].values)
    df1.loc[:, 'V1'] = ''
    df1.loc[:, 'MDC+V23'] = df1.apply(feature_mdc_v23, axis=1)
    df1.loc[:, 'V2'] = ''
    df1['Microsegments_D'] = df1.apply(feature_microsegments_d, axis=1)
    df1 = df1[['CLM_NUM_CD', 'TRANS_ID', 'Microsegments_D']]
    df = df.merge(df1, how='left', on=['CLM_NUM_CD', 'TRANS_ID'])
    df['Microsegments_D'] = df['Microsegments_D'].apply(pd.to_numeric, errors='coerce')
    df = df[['CLM_NUM_CD', 'TRANS_ID', 'V1', 'V2', 'V3',
             'PRI_ICD_CD', 'RequestReceivedTS', 'MDC', 'Microsegments_D']]
    df.rename(columns={'V1': 'Have Hospitalization Date',
                       'V2': 'Have Prognosis Date',
                       'V3': 'Have Surgery Date',
                       'Microsegments_D': 'Microsegments'}, inplace=True)
    df.loc[:, 'Approval Rate'] = feature_approval_rate(df['Microsegments'].values)
    df.loc[:, 'AutoAdjudicationDecision'] = 'N'
    df.loc[df['Approval Rate'] == 0, 'AutoAdjudicationDecision'] = 'U'
    condition = (~((df['MDC'].str.strip() == 'NORMAL PREGNANCY & DELIVERY')
                   | (df['MDC'].str.strip() == 'COMPLICATIONS OF PREGNANCY'))
                 & (df['Approval Rate'] >= 0.895))\
        | (((df['MDC'].str.strip() == 'NORMAL PREGNANCY & DELIVERY')
            | (df['MDC'].str.strip() == 'COMPLICATIONS OF PREGNANCY'))
           & (df['Approval Rate'] >= 0.845))
    df.loc[condition, 'AutoAdjudicationDecision'] = 'Y'
    df.loc[(df['PRI_ICD_CD'].isnull())
           | (df['Microsegments'].astype(str) == '180'),
           'AutoAdjudicationDecision'] = 'Undecided'
    df.rename(columns={'CLM_NUM_CD': 'ClaimNumberCode',
                       'Have Hospitalization Date': 'HaveHospitalizationDate',
                       'Have Prognosis Date': 'HavePrognosisDate',
                       'Have Surgery Date': 'HaveSurgeryDate',
                       'Microsegments': 'Microsegment',
                       'Approval Rate': 'ApprovalRate'}, inplace=True)
    df.loc[:, 'Surgery'] = 'No Surgery Date'
    df.loc[df['HaveSurgeryDate'] == 'Yes', 'Surgery'] = 'Have Surgery Date'
    df.loc[:, 'Prognosis'] = 'No Prognosis Date'
    df.loc[df['HavePrognosisDate'] == 'Yes',
           'Prognosis'] = 'Have Prognosis Date'
    df.loc[:, 'Hospitalization'] = 'No Hospitalization Date'
    df.loc[df['HaveHospitalizationDate'] == 'Yes',
           'Hospitalization'] = 'Have Hospitalization Date'
    df['HaveSurgeryDate'].replace('Yes', 'Y', inplace=True)
    df.loc[df['HaveSurgeryDate'] != 'Y', 'HaveSurgeryDate'] = 'N'
    df['HavePrognosisDate'].replace('Yes', 'Y', inplace=True)
    df.loc[df['HavePrognosisDate'] != 'Y', 'HavePrognosisDate'] = 'N'
    df['HaveHospitalizationDate'].replace('Yes', 'Y', inplace=True)
    df.loc[df['HaveHospitalizationDate'] != 'Y',
           'HaveHospitalizationDate'] = 'N'
    df[['MDC', 'PRI_ICD_CD']] = df[['MDC', 'PRI_ICD_CD']].fillna('')
    df['ResultReasonDesc1'] = 'ICD=' + df['PRI_ICD_CD'].astype(str)
    df['ResultReasonDesc2'] = 'MDC=' + df['MDC'].astype(str)
    df.loc[:, 'ResultReasonDesc3'] = df['Surgery']
    df.loc[:, 'ResultReasonDesc4'] = df['Prognosis']
    df.loc[:, 'ResultReasonDesc5'] = df['Hospitalization']
    df.loc[:, 'ClusterType'] = ''
    df.loc[:, 'XeroxGroup'] = ''
    log.info('feature_validation_pass_process method is now complete')
    log.warning("feature_validation_pass_process method is completed in: [ %s ] Seconds ---" % (time.time() - start_time))
    return df


def data_processing(validation_fail_df, validation_pass_df, log=log):
    start_time = time.time()
    log.info('data_processing method is starting')
    validation_fail_flag = 0
    validation_pass_flag = 0
    if len(validation_fail_df) > 0:
        validation_fail_df = feature_validation_fail_process(validation_fail_df)
        validation_fail_flag = 1
    if len(validation_pass_df) > 0:
        validation_pass_df = feature_validation_pass_process(validation_pass_df)
        validation_pass_flag = 1
    if (validation_fail_flag == 1) and (validation_pass_flag == 1):
        validation_pass_columns = [i for i in validation_fail_df.columns if i in validation_pass_df.columns]
        validation_fail_df = validation_fail_df[validation_pass_columns]
        final_df = validation_pass_df.append(validation_fail_df)
        final_df = final_df.drop(['PRI_ICD_CD', 'MDC', 'Surgery',
                                  'Prognosis', 'Hospitalization'], axis=1)
    elif validation_pass_flag == 1:
        final_df = validation_pass_df
        final_df = final_df.drop(['PRI_ICD_CD', 'MDC', 'Surgery',
                                  'Prognosis', 'Hospitalization'], axis=1)
    elif validation_fail_flag == 1:
        final_df = validation_fail_df
    else:
        log.error('validation_fail_flag failed')
    final_df['RequestReturnedTS'] = pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
    final_df.rename(columns={'TRANS_ID': 'TransId'}, inplace=True)
    cols = ['TransId', 'ClaimNumberCode', 'AutoAdjudicationDecision',
            'ApprovalRate', 'HaveSurgeryDate', 'HavePrognosisDate',
            'HaveHospitalizationDate', 'XeroxGroup', 'ClusterType',
            'Microsegment', 'ResultReasonDesc1', 'ResultReasonDesc2',
            'ResultReasonDesc3', 'ResultReasonDesc4', 'ResultReasonDesc5',
            'RequestReceivedTS', 'RequestReturnedTS']
    final_df = final_df[cols]
    final_df = final_df.sort_values('ClaimNumberCode')
    log.info('data_processing method is now complete')
    log.warning("data_processing method is completed in: [ %s ] Seconds ---" % (time.time() - start_time))
    return final_df


def export_results(final_df, outputdir, export_file_name, log=log):
    log.info('Export data method is starting')
    export_file_name = export_file_name + '_' + str(datetime.now().strftime('%Y_%m_%d-%H_%M_%S')) + '.txt'
    output_path = os.path.join(outputdir, export_file_name)
    # Write out to location
    log.debug('Exporting the results to file: ' + output_path)
    try:
        final_df.to_csv(output_path, index=False, sep='|')
    except Exception as e:
        log.exception('Failed to export result data.')
        raise e
    log.info('Exporting results is now complete')
    return None


if __name__ == '__main__':
    start_time = time.time()
    # Start auto adjudication decision process
    log.info('Auto Adjudication Decision process has started')
    # Import data from flat files
    ad_main, ad_treatment = data_import(inputdir, main_data_file_name, treatment_data_file_name, log=log)
    # Data Preparation - ensuring correct datatypes
    try:
        validation_fail_df, validation_pass_df = data_prep(ad_main, ad_treatment, log=log)
    except Exception as e:
        log.exception('Failed to prepare the data.')
        raise e
    # Feature engineering
    try:
        final_df = data_processing(validation_fail_df, validation_pass_df, log=log)
    except Exception as e:
        log.exception('Failed to create Adjudication flag and reason cd')
        raise e
    # export data onto predefined location
    export_results(final_df, outputdir, export_file_name, log=log)
    # Log and end the process
    log.info('Auto Adjudication Decision method is complete')
    log.warning('The Auto Adjudication Decision method is completed in: [ %s ] Seconds ---' % (time.time() - start_time))