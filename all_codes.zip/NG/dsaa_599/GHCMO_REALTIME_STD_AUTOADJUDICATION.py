#############################################################################
# ---------------------------------------------------------------------------
#                            Program Information
# ---------------------------------------------------------------------------
# Author                 : Arunadhri
# Creation Date          : 03-04-2019
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#                             Script Information
# ---------------------------------------------------------------------------
# Script Name            : GHCMO_REALTIME_STD_AUTOADJUDICATION.py
# Bitbucket Project/Repo : DnAAnalytics-US-Group/US-GRP-MO-STD-AADJ-436
# Brief Description      : Automate the STD claims process and provide
#                          updates on a real time basis
# Data used              :
# Output Files           : std_aadj_results_set
# Notes / Assumptions    : ICD9_codes.py from utils folder needed to import global functions
#                          For config and logging - following files required
#                          config.py, yaml_wrappers.py from utils folder on server
#                          base.yml, development.yml  from use case config folder
# ---------------------------------------------------------------------------
#                            Environment Information
# ---------------------------------------------------------------------------
# Python Version         : 3.6.3
# Anaconda Version       : 5.0.1
# Spark Version          : 2.3.0
# Operating System       : Red Hat Enterprise Linux 7.4
# ---------------------------------------------------------------------------
#                           Change Control Information
# ---------------------------------------------------------------------------
# Programmer Name/Date   : Change and Reason
#
#############################################################################

#############################################################################
#
# Packages & Modules
#
#############################################################################

import pandas as pd
import logging
import os

try:
    from config import Config
except IOError:
    logging.error("Cannot import Config class.")
except Exception:
    logging.exception("Failed to import Config class.")

try:
    from ICD9_codes import *
except IOError:
    logging.error("Cannot import ICD9_codes")
except Exception:
    logging.exception("Failed to import ICD9_codes.")


#############################################################################
#
# Function definitions
#
#############################################################################
def data_import():
    log.info("Data Import method has started running.")
    # Get data from flat files
    try:
        ad_main = pd.read_csv(hdfs_import_file_path + 'AD_MAIN.txt', sep='|')
        ad_treatment = pd.read_csv(hdfs_import_file_path + 'AD_TREATMENT.txt', sep='|')
    except IOError:
        log.error("Could not import data from flat files")
    except Exception:
        log.error("Data import from flat files have failed")
    log.info("Data import is now complete")
    return ad_main, ad_treatment


def f_data_validation(df):
    log.info("Data validation process has started")
    df.loc[:, 'DATA_VALIDATION'] = ''
    df.loc[df['ICD_CD_VER'].isnull(), 'DATA_VALIDATION'] = 'Provided field value is an incorrect data type. ICD_CD_VER is expecting a NUMERIC value to be provided.'
    df.loc[(df['CLM_NUM_CD'].str.strip() == '') |
           (df['CLM_NUM_CD'].isnull()), 'DATA_VALIDATION'] ='Required value not provided for CLM_NUM_CD. A valid value for this field is required in order to calculate a score.'
    df.loc[(df['TRANS_ID'].str.strip() == '') |
           (df['TRANS_ID'].isnull()), 'DATA_VALIDATION'] = 'Required value not provided for TRANS_ID. A valid value for this field is required in order to calculate a score.'
    df.loc[(df['PRI_ICD_CD'].str.strip() == '') |
           (df['PRI_ICD_CD'].isnull()), 'DATA_VALIDATION'] = 'Required value not provided for PRI_ICD_CD. A valid value for this field is required in order to calculate a score.'
    return df


def f_validation_fail_process(df):
    log.info("Feature engineering for incorrect data has started")
    df.loc[:, 'ResultReasonDesc1'] = df['DATA_VALIDATION']
    df.loc[:, 'ResultReasonDesc2'] = ''
    df.loc[:, 'ResultReasonDesc3'] = ''
    df.loc[:, 'ResultReasonDesc4'] = ''
    df.loc[:, 'ResultReasonDesc5'] = ''
    df.loc[:, 'AutoAdjudicationDecision'] = 'U'
    df.loc[:, 'ApprovalRate'] = 0
    df.loc[:, 'HaveSurgeryDate'] = ''
    df.loc[:, 'HavePrognosisDate'] = ''
    df.loc[:, 'HaveHospitalizationDate'] = ''
    df.loc[:, 'XeroxGroup'] = ''
    df.loc[:, 'ClusterType'] = ''
    df.loc[:, 'Microsegment'] = 0
    df.rename(columns={'CLM_NUM_CD': 'ClaimNumberCode'}, inplace=True)
    df = df.drop(['CVR_CD', 'DABL_DT', 'RTRN_TO_WRK_DT', 'APRV_OPER_CD',
                  'RPT_NUM', 'JOB_CLASS_CD', 'PRI_ICD_CD', 'SEC_ICD_CD',
                  'MJR_DX_CTGY_DSCR', 'RQST_TS'], axis=1)
    return df


def f_validation_pass_process(df):
    log.info("Feature engineering for correct data has started")

    def f_supernode(df):
        df.loc[:, 'Job Class Bin'] = 'default'

        df.loc[df['JOB_CLASS_CD'].isin(['S', 'L']), 'Job Class Bin'] = 'L'
        df.loc[df['JOB_CLASS_CD'].isin(['H', 'V']), 'Job Class Bin'] = 'H'
        df.loc[df['JOB_CLASS_CD'] == 'M', 'Job Class Bin'] = 'M'
        df.loc[df['JOB_CLASS_CD'] == 'U', 'Job Class Bin'] = 'U'

        df2 = df.copy(deep=True)
        df2.loc[:, 'Hospital ind'] = 0
        df2.loc[~df2['HOSP_ADMIT_DT'].isnull(), 'Hospital ind'] = 1
        df2.loc[:, 'Prognosis ind'] = 0
        df2.loc[~df2['PROG_DT'].isnull(), 'Prognosis ind'] = 1
        df2.loc[:, 'Surgery ind'] = 0
        condition = ((~df2['CPT4_PROC_1_CD'].isnull()) &
                     (((df2['CPT4_PROC_1_CD'].astype(str) > '10000') &
                      (df2['CPT4_PROC_1_CD'].astype(str) < '69990')) |
                     ((df2['CPT4_PROC_2_CD'].astype(str) > '10000') &
                      (df2['CPT4_PROC_2_CD'].astype(str) < '69990'))))
        df2.loc[condition, 'Surgery ind'] = 1
        df2 = df2.groupby('CLM_NUM_CD')['Hospital ind',
                                        'Prognosis ind', 'Surgery ind'].sum().reset_index()

        df2.rename(columns={'Hospital ind': 'Hospital ind_Sum',
                            'Prognosis ind': 'Prognosis ind_Sum',
                            'Surgery ind': 'Surgery ind_Sum'}, inplace=True)

        df2.loc[:, 'Have Hospitalization Date'] = 'No'
        df2.loc[df2['Hospital ind_Sum'] > 0,
                'Have Hospitalization Date'] = 'Yes'
        df2.loc[:, 'Have Prognosis Date'] = 'No'
        df2.loc[df2['Prognosis ind_Sum'] > 0, 'Have Prognosis Date'] = 'Yes'
        df2.loc[:, 'Have Surgery Date'] = 'No'
        df2.loc[df2['Surgery ind_Sum'] > 0, 'Have Surgery Date'] = 'Yes'

        df = df.merge(df2, how='left', on='CLM_NUM_CD')
        df['Have Hospitalization Date'].fillna('No', inplace=True)
        df['Have Prognosis Date'].fillna('No', inplace=True)
        df['Have Surgery Date'].fillna('No', inplace=True)

        df.loc[:, 'Have RTW Date'] = 'No'
        df.loc[~df['RTRN_TO_WRK_DT'].isnull(), 'Have RTW Date'] = 'Yes'
        df.loc[:, 'PRI_ICD_CD'] = df['PRI_ICD_CD'].str.strip()
        df.loc[df['PRI_ICD_CD'] == 'Z75.9', 'PRI_ICD_CD'] = 'Z759'
        df.loc[df['PRI_ICD_CD'].isnull(), 'PRI_ICD_CD'] = ''
        df.loc[:, 'ICD10to9_1'] = df.apply(f_ICD10to9_1, axis=1)
        df.loc[:, 'ICD10to9_2'] = df.apply(f_ICD10to9_2, axis=1)
        df.loc[:, 'ICD10to9_3'] = df.apply(f_ICD10to9_3, axis=1)

        df = df.drop(['ICD10to9_1', 'ICD10to9_2'], axis=1)
        df.rename(columns={'ICD10to9_3': 'ICD9'}, inplace=True)

        df.loc[:, 'Primary ICD9 Code'] = df['ICD9']
        df.loc[(df['ICD9'].isnull()) |
               (df['ICD9'] == 'Unknown'),
               'Primary ICD9 Code'] = df['PRI_ICD_CD']
        df.loc[:, 'PRMRY_ICD9_CD_5DIGIT'] = df.apply(f_PRMRY_ICD9_CD_5DIGIT, axis=1)
        df.loc[:, 'PRMRY_ICD9_CD_3DIGIT'] = df['PRMRY_ICD9_CD_5DIGIT']\
            .apply(lambda x: x[:3])
        df.loc[:, 'ICD9_TO_MDC'] = df.apply(f_ICD9_TO_MDC, axis=1)

        df = df.drop(['MJR_DX_CTGY_DSCR', 'ICD9',
                      'Primary ICD9 Code', 'PRMRY_ICD9_CD_5DIGIT',
                      'PRMRY_ICD9_CD_3DIGIT'], axis=1)
        df.rename(columns={'ICD9_TO_MDC': 'MJR_DX_CTGY_DSCR'}, inplace=True)
        return df
    df = f_supernode(df)

    df.rename(columns={'Have Hospitalization Date': 'V1',
                       'Have Prognosis Date': 'V2',
                       'Have Surgery Date': 'V3',
                       'MJR_DX_CTGY_DSCR': 'MDC'}, inplace=True)
    df1 = df.copy(deep=True)
    df1.loc[:, 'ICD123'] = df1.apply(f_ICD123, axis=1)
    df2 = df1.copy(deep=True)
    df2 = df2[['CLM_NUM_CD', 'V1', 'V2']]
    df1.loc[:, 'V1'] = ''
    df1.loc[:, 'ICD12'] = df1.apply(f_ICD12, axis=1)
    df1.loc[:, 'V2'] = ''
    df1.loc[:, 'ICD1'] = df1.apply(f_ICD1, axis=1)
    df1 = df1.drop(['V1', 'V2'], axis=1)
    df1 = df1.merge(df2, how='left', on='CLM_NUM_CD')
    df1.loc[:, 'PRI_ICD_CD'] = ''
    df1.loc[:, 'MDC123'] = df1.apply(f_MDC123, axis=1)
    df1.loc[:, 'V1'] = ''
    df1.loc[:, 'MDC+V23'] = df1.apply(f_MDC_V23, axis=1)
    df1.loc[:, 'V2'] = ''

    df1['Microsegments_D'] = df1.apply(f_Microsegments_D, axis=1)
    df1 = df1[['CLM_NUM_CD', 'TRANS_ID', 'Microsegments_D']]
    df = df.merge(df1, how='left', on=['CLM_NUM_CD', 'TRANS_ID'])
    df['Microsegments_D'] = df[['Microsegments_D']].applymap(convert_to_float)
    df = df[['CLM_NUM_CD', 'TRANS_ID', 'V1', 'V2', 'V3',
             'PRI_ICD_CD', 'RequestReceivedTS', 'MDC', 'Microsegments_D']]
    df.rename(columns={'V1': 'Have Hospitalization Date',
                       'V2': 'Have Prognosis Date',
                       'V3': 'Have Surgery Date',
                       'Microsegments_D': 'Microsegments'}, inplace=True)

    df.loc[:, 'Approval Rate'] = df.apply(f_Approval_Rate, axis=1)
    df.loc[:, 'AutoAdjudicationDecision'] = 'N'
    df.loc[df['Approval Rate'] == 0, 'AutoAdjudicationDecision'] = 'U'

    condition = (~((df['MDC'].str.strip() == 'NORMAL PREGNANCY & DELIVERY') |
                   (df['MDC'].str.strip() == 'COMPLICATIONS OF PREGNANCY')) &
                  (df['Approval Rate'] >= 0.945)) |\
                (((df['MDC'].str.strip() == 'NORMAL PREGNANCY & DELIVERY') |
                  (df['MDC'].str.strip() == 'COMPLICATIONS OF PREGNANCY')) &
                    (df['Approval Rate'] >= 0.90))

    df.loc[condition, 'AutoAdjudicationDecision'] = 'Y'
    df.loc[(df['PRI_ICD_CD'].isnull()) |
           (df['Microsegments'].astype(str) == '180'),
           'AutoAdjudicationDecision'] = 'Undecided'

    df.rename(columns={'CLM_NUM_CD': 'ClaimNumberCode',
                       'Have Hospitalization Date': 'HaveHospitalizationDate',
                       'Have Prognosis Date': 'HavePrognosisDate',
                       'Have Surgery Date': 'HaveSurgeryDate',
                       'Microsegments': 'Microsegment',
                       'Approval Rate': 'ApprovalRate'}, inplace=True)

    df.loc[:, 'Surgery'] = 'No Surgery Date'
    df.loc[df['HaveSurgeryDate'] == 'Yes', 'Surgery'] = 'Have Surgery Date'
    df.loc[:, 'Prognosis'] = 'No Prognosis Date'
    df.loc[df['HavePrognosisDate'] == 'Yes',
           'Prognosis'] = 'Have Prognosis Date'
    df.loc[:, 'Hospitalization'] = 'No Hospitalization Date'
    df.loc[df['HaveHospitalizationDate'] == 'Yes',
           'Hospitalization'] = 'Have Hospitalization Date'
    df['HaveSurgeryDate'].replace('Yes', 'Y', inplace=True)
    df.loc[df['HaveSurgeryDate'] != 'Y', 'HaveSurgeryDate'] = 'N'
    df['HavePrognosisDate'].replace('Yes', 'Y', inplace=True)
    df.loc[df['HavePrognosisDate'] != 'Y', 'HavePrognosisDate'] = 'N'
    df['HaveHospitalizationDate'].replace('Yes', 'Y', inplace=True)
    df.loc[df['HaveHospitalizationDate'] != 'Y',
           'HaveHospitalizationDate'] = 'N'
    df[['MDC', 'PRI_ICD_CD']] = df[['MDC', 'PRI_ICD_CD']].fillna('')
    df['ResultReasonDesc1'] = 'ICD=' + df['PRI_ICD_CD'].astype(str)
    df['ResultReasonDesc2'] = 'MDC=' + df['MDC'].astype(str)
    df.loc[:, 'ResultReasonDesc3'] = df['Surgery']
    df.loc[:, 'ResultReasonDesc4'] = df['Prognosis']
    df.loc[:, 'ResultReasonDesc5'] = df['Hospitalization']
    df.loc[:, 'ClusterType'] = ''
    df.loc[:, 'XeroxGroup'] = ''
    log.info("Feature engineering for correct data is complete")
    return df


def export_data(df):
    log.info("Export data method has started")
    # Write out to hdfs
    log.debug("Exporting the results to file: " + hdfs_export_file_path +
              export_file_name + ".txt")
    try:
        final_df.to_csv(hdfs_export_file_path + export_file_name+'.txt', index=False, sep='|')
    except IOError:
        log.error("Could not load file to hdfs path.")
    except Exception:
        log.exception("Failed to load categories dictionary pickle file.")
    log.info("Exporting resultant df is now complete")


def main():
    log.info("Auto Adjudication Decision process has started")
    # ad_main, ad_treatment = data_import()
    # ad_main['RequestReceivedTS'] = pd.Timestamp.now()
    # merged_df = ad_main.merge(ad_treatment, how='left', on='CLM_NUM_CD')
    dtype = {'APRV_OPER_CD': str,
             'CLM_NUM_CD': str,
             'CPT4_PROC_1_CD': str,
             'CPT4_PROC_2_CD': str,
             'CVR_CD': str,
             'ICD_CD_VER': str,
             'JOB_CLASS_CD': str,
             'MJR_DX_CTGY_DSCR': str,
             'PRI_ICD_CD': str,
             'RPT_NUM': str,
             'SEC_ICD_CD': str,
             'TRANS_ID': str}
    merged_df = pd.read_csv(hdfs_import_file_path + 'Input.txt', dtype=dtype,
                            parse_dates=['CLM_RECD_DT', 'HOSP_ADMIT_DT',
                                         'DABL_DT', 'PROG_DT', 'RQST_TS',
                                         'RTRN_TO_WRK_DT', 'TREAT_DT',
                                         'RequestReceivedTS'])

    data_validation_df = f_data_validation(merged_df)

    validation_fail_df = data_validation_df[
        data_validation_df['DATA_VALIDATION'] != ''].copy()
    validation_pass_df = data_validation_df[
        data_validation_df['DATA_VALIDATION'] == ''].copy()

    validation_fail_df = f_validation_fail_process(validation_fail_df)
    validation_pass_df = f_validation_pass_process(validation_pass_df)

    validation_pass_columns = [i for i in validation_fail_df.columns if i in validation_pass_df.columns]
    validation_fail_df = validation_fail_df[validation_pass_columns]

    final_df = validation_pass_df.append(validation_fail_df)

    final_df['RequestReturnedTS'] = pd.Timestamp.now()
    final_df.rename(columns={'TRANS_ID': 'TransId'}, inplace=True)

    final_df = final_df.drop(['PRI_ICD_CD', 'MDC', 'Surgery',
                              'Prognosis', 'Hospitalization'], axis=1)

    cols = ['TransId', 'ClaimNumberCode', 'AutoAdjudicationDecision',
            'ApprovalRate', 'HaveSurgeryDate', 'HavePrognosisDate',
            'HaveHospitalizationDate', 'XeroxGroup', 'ClusterType',
            'Microsegment', 'ResultReasonDesc1', 'ResultReasonDesc2',
            'ResultReasonDesc3', 'ResultReasonDesc4', 'ResultReasonDesc5',
            'RequestReceivedTS', 'RequestReturnedTS']
    final_df = final_df[cols]
    final_df.sort_values('ClaimNumberCode', inplace=True)
    final_df.drop_duplicates(inplace=True)
    export_data(final_df)
    log.info("Auto Adjudication Decision process is complete")

if __name__ == '__main__':
    env = os.environ.get("ENV")
    app_path = os.getcwd()
    config = Config(env, app_path)
    log = config.get_logger()
    hdfs_export_file_path = config.getConfigValueFor("hdfs_export_file_path")
    hdfs_import_file_path = config.getConfigValueFor("hdfs_in_path")
    export_file_name = config.getConfigValueFor("export_file_name")
    main()
