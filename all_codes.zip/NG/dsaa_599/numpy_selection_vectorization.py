# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pandas as pd
import numpy as np
import timeit

from sklearn import datasets


def initialize_iris():
    iris = datasets.load_iris()
    iris_df = pd.DataFrame(iris.data, columns=iris.feature_names)
    iris_df.columns = iris_df.columns.str.replace('(', '').str.replace(')', '').str.replace(' ', '_')
    return iris_df


def select_stmt(sepal_ln, sepal_wd, petal_ln, petal_wd):
    conditions = [(sepal_ln > 5), (sepal_wd == 2), (petal_ln >= 5), 
                  (petal_ln < 7)]
    choices = ['A', 'B', 'C', 'D']
    return np.select(conditions, choices, default='default')


def select_non_vec(df):
    conditions = [(df['sepal_length_cm'] > 5), 
                  (df['sepal_width_cm'] == 2), 
                  (df['petal_length_cm'] >= 5), 
                  (df['petal_width_cm'] < 7)]
    choices = ['A', 'B', 'C', 'D']
    return np.select(conditions, choices, default='default')


v_select_stmt = np.vectorize(select_stmt)


def vectorized():
    iris_series = v_select_stmt(iris_df['sepal_length_cm'], 
           iris_df['sepal_width_cm'],
           iris_df['petal_length_cm'],
           iris_df['petal_width_cm']
           )
    return iris_series


def not_vectorized():
    iris_series = iris_df.apply(select_non_vec, axis=1)
    return iris_series


iris_df = initialize_iris()

timeit.timeit(vectorized, number=100)
# returns 0.5877314664953701


timeit.timeit(not_vectorized, number=100)
# returns 3.112242005750886

