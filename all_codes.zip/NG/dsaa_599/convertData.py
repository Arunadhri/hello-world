test = pd.read_csv('STD_AA_Scoring_Input.txt', sep='|', dtype={'SERIAL': str, 'RI_NAME': str, 'RI_VALUE': str})
test.drop(['AUDITLOGEXTRACTRUNTIMESTAMP', 'MODEL_VERSION_MARKER', 'CONFIGURATION_NAME'], inplace=True, axis=1)
test.drop_duplicates(inplace=True)
test.head(2)

d={}
for index, row in test.iterrows():
    if row['SERIAL'] in d:
        if row['RI_NAME'] in d[row['SERIAL']]:
            print(row['SERIAL'], row['RI_NAME'])
        d[row['SERIAL']][row['RI_NAME']] = row['RI_VALUE']
        d[row['SERIAL']]['STAMP'] = row['STAMP']
    else:
        d[row['SERIAL']] = {}
        d[row['SERIAL']][row['RI_NAME']] = row['RI_VALUE']
len(d)

df = pd.DataFrame.from_dict(d, orient='index')
df.drop_duplicates(inplace=True)
df.rename(columns={'STAMP': 'RequestReceivedTS'}, inplace=True)

df.to_csv('Input.txt', index=False)

op = pd.read_csv('STD_AA_Scoring_Output.txt', sep='|', dtype={'SERIAL': str, 'OUTPUT_NAME': str, 'OUTPUT_VALUE': str})
op.drop(['AUDITLOGEXTRACTRUNTIMESTAMP', 'MODEL_VERSION_MARKER', 'CONFIGURATION_NAME', 'STAMP'], inplace=True, axis=1)
op.drop_duplicates(inplace=True)
op.head(2)

d={}
for index, row in op.iterrows():
    if row['SERIAL'] in d:
        if row['OUTPUT_NAME'] in d[row['SERIAL']]:
            print(row['SERIAL'], row['OUTPUT_NAME'])
        d[row['SERIAL']][row['OUTPUT_NAME']] = row['OUTPUT_VALUE']
    else:
        d[row['SERIAL']] = {}
        d[row['SERIAL']][row['OUTPUT_NAME']] = row['OUTPUT_VALUE']
len(d)

df = pd.DataFrame.from_dict(d, orient='index')
df.drop_duplicates(inplace=True)

df.to_csv('SPSSData_Output.txt', index=False)