import string
import pandas as pd
#pd.options.mode.chained_assignment = 'raise'
import os
os.chdir(r'//ns-sisci01hd/home_s01/Citrix_Folder_Redirect/Downloads/NG/AutoAdjudication/')
import copy
from ICD9_codes import *

dtype = {'APRV_OPER_CD': str,
         'CLM_NUM_CD': str,
         'CPT4_PROC_1_CD': str,
         'CPT4_PROC_2_CD': str,
         'CVR_CD': str,
         'ICD_CD_VER': str,
         'JOB_CLASS_CD': str,
         'MJR_DX_CTGY_DSCR': str,
         'PRI_ICD_CD': str,
         'RPT_NUM': str,
         'SEC_ICD_CD': str,
         'TRANS_ID': str}

df = pd.read_csv('Input.txt', dtype=dtype,
                 parse_dates = ['CLM_RECD_DT', 'HOSP_ADMIT_DT', 'DABL_DT',
                                'PROG_DT', 'RQST_TS', 'RTRN_TO_WRK_DT',
                                'TREAT_DT', 'RequestReceivedTS'])

def f_data_validation(df):
    df.loc[:, 'DATA_VALIDATION'] = ''

    df.loc[df['ICD_CD_VER'].isnull(), 'DATA_VALIDATION'] =\
        'Provided field value is an incorrect data type. \
    ICD_CD_VER is expecting a NUMERIC value to be provided.'

    df.loc[(df['CLM_NUM_CD'].str.strip() == '') |
           (df['CLM_NUM_CD'].isnull()), 'DATA_VALIDATION'] =\
        'Required value not provided for CLM_NUM_CD.\
             A valid value for this field is required in\
             order to calculate a score.'

    df.loc[(df['TRANS_ID'].str.strip() == '') |
           (df['TRANS_ID'].isnull()), 'DATA_VALIDATION'] = \
        'Required value not provided for TRANS_ID.  \
           A valid value for this field is required in\
           order to calculate a score.'

    df.loc[(df['PRI_ICD_CD'].str.strip() == '') |
           (df['PRI_ICD_CD'].isnull()), 'DATA_VALIDATION'] = \
        'Required value not provided for PRI_ICD_CD.  \
           A valid value for this field is required in\
           order to calculate a score.'
    return df


def f_validation_fail_process(df):
    df.loc[:, 'ResultReasonDesc1'] = df['DATA_VALIDATION']
    df.loc[:, 'ResultReasonDesc2'] = ''
    df.loc[:, 'ResultReasonDesc3'] = ''
    df.loc[:, 'ResultReasonDesc4'] = ''
    df.loc[:, 'ResultReasonDesc5'] = ''
    df.loc[:, 'AutoAdjudicationDecision'] = 'U'
    df.loc[:, 'ApprovalRate'] = 0
    df.loc[:, 'HaveSurgeryDate'] = ''
    df.loc[:, 'HavePrognosisDate'] = ''
    df.loc[:, 'HaveHospitalizationDate'] = ''
    df.loc[:, 'XeroxGroup'] = ''
    df.loc[:, 'ClusterType'] = ''
    df.loc[:, 'Microsegment'] = '0'
    df.rename(columns={'CLM_NUM_CD': 'ClaimNumberCode'}, inplace=True)
    df = df.drop(['CVR_CD', 'DABL_DT', 'RTRN_TO_WRK_DT', 'APRV_OPER_CD',
                  'RPT_NUM', 'JOB_CLASS_CD', 'PRI_ICD_CD', 'SEC_ICD_CD',
                  'MJR_DX_CTGY_DSCR', 'RQST_TS'], axis=1)
    return df


def f_validation_pass_process(df):
    def f_supernode(df):
        df.loc[:, 'Job Class Bin'] = 'default'

        df.loc[df['JOB_CLASS_CD'].isin(['S', 'L']), 'Job Class Bin'] = 'L'
        df.loc[df['JOB_CLASS_CD'].isin(['H', 'V']), 'Job Class Bin'] = 'H'
        df.loc[df['JOB_CLASS_CD'] == 'M', 'Job Class Bin'] = 'M'
        df.loc[df['JOB_CLASS_CD'] == 'U', 'Job Class Bin'] = 'U'

        df2 = df.copy(deep=True)
        df2.loc[:, 'Hospital ind'] = 0
        df2.loc[~df2['HOSP_ADMIT_DT'].isnull(), 'Hospital ind'] = 1

        df2.loc[:, 'Prognosis ind'] = 0
        df2.loc[~df2['PROG_DT'].isnull(), 'Prognosis ind'] = 1

        df2.loc[:, 'Surgery ind'] = 0
        condition = ((~df2['CPT4_PROC_1_CD'].isnull()) &
        (((df2['CPT4_PROC_1_CD'].astype(str) > '10000') &
           (df2['CPT4_PROC_1_CD'].astype(str) < '69990')) |
         ((df2['CPT4_PROC_2_CD'].astype(str) > '10000') &
           (df2['CPT4_PROC_2_CD'].astype(str) < '69990'))))
        df2.loc[condition, 'Surgery ind'] = 1
        df2 = df2.groupby('CLM_NUM_CD')['Hospital ind',
                                        'Prognosis ind', 'Surgery ind'].sum().reset_index()

        df2.rename(columns={'Hospital ind': 'Hospital ind_Sum',
                            'Prognosis ind': 'Prognosis ind_Sum',
                            'Surgery ind': 'Surgery ind_Sum'}, inplace=True)

        df2.loc[:, 'Have Hospitalization Date'] = 'No'
        df2.loc[df2['Hospital ind_Sum'] > 0,
                'Have Hospitalization Date'] = 'Yes'

        df2.loc[:, 'Have Prognosis Date'] = 'No'
        df2.loc[df2['Prognosis ind_Sum'] > 0, 'Have Prognosis Date'] = 'Yes'

        df2.loc[:, 'Have Surgery Date'] = 'No'
        df2.loc[df2['Surgery ind_Sum'] > 0, 'Have Surgery Date'] = 'Yes'

        df = df.merge(df2, how='left', on='CLM_NUM_CD')
        df['Have Hospitalization Date'].fillna('No', inplace=True)
        df['Have Prognosis Date'].fillna('No', inplace=True)
        df['Have Surgery Date'].fillna('No', inplace=True)

        df.loc[:, 'Have RTW Date'] = 'No'
        df.loc[~df['RTRN_TO_WRK_DT'].isnull(), 'Have RTW Date'] = 'Yes'

        df.loc[:, 'PRI_ICD_CD'] = df['PRI_ICD_CD'].str.strip()
        df.loc[df['PRI_ICD_CD'] == 'Z75.9', 'PRI_ICD_CD'] = 'Z759'
        df.loc[df['PRI_ICD_CD'].isnull(), 'PRI_ICD_CD'] = ''

        df.loc[:, 'ICD10to9_1'] = df.apply(f_ICD10to9_1, axis=1)
        df.loc[:, 'ICD10to9_2'] = df.apply(f_ICD10to9_2, axis=1)
        df.loc[:, 'ICD10to9_3'] = df.apply(f_ICD10to9_3, axis=1)
        

        df = df.drop(['ICD10to9_1', 'ICD10to9_2'], axis=1)
        df.rename(columns={'ICD10to9_3': 'ICD9'}, inplace=True)
        
        df.loc[:, 'Primary ICD9 Code'] = df['ICD9']

        df.loc[(df['ICD9'].isnull()) |
               (df['ICD9'] == 'Unknown'),
               'Primary ICD9 Code'] = df['PRI_ICD_CD']

        df.loc[:, 'PRMRY_ICD9_CD_5DIGIT'] = df.apply(f_PRMRY_ICD9_CD_5DIGIT, axis=1)
        df.loc[:, 'PRMRY_ICD9_CD_3DIGIT'] = df['PRMRY_ICD9_CD_5DIGIT']\
            .apply(lambda x: x[:3])
            
        df.loc[:, 'ICD9_TO_MDC'] = df.apply(f_ICD9_TO_MDC, axis=1)
        df = df.drop(['MJR_DX_CTGY_DSCR', 'ICD9',
                 'Primary ICD9 Code', 'PRMRY_ICD9_CD_5DIGIT',
                 'PRMRY_ICD9_CD_3DIGIT'], axis=1)
        df.rename(columns={'ICD9_TO_MDC': 'MJR_DX_CTGY_DSCR'}, inplace=True)
        return df
    df = f_supernode(df)

    #df.drop('Record_Count', axis=1, inplace=True)
    df.rename(columns={'Have Hospitalization Date': 'V1',
                       'Have Prognosis Date': 'V2',
                       'Have Surgery Date': 'V3',
                       'MJR_DX_CTGY_DSCR': 'MDC'}, inplace=True)
    df1 = df.copy(deep=True)
    df1.loc[:, 'ICD123'] = df1.apply(f_ICD123, axis=1)
    df2 = df1.copy(deep=True)
    df2 = df2[['CLM_NUM_CD', 'V1', 'V2']]
    df1.loc[:, 'V1'] = ''
    df1.loc[:, 'ICD12'] = df1.apply(f_ICD12, axis=1)
    df1.loc[:, 'V2'] = ''
    df1.loc[:, 'ICD1'] = df1.apply(f_ICD1, axis=1)
    df1 = df1.drop(['V1', 'V2'], axis=1)
    df1 = df1.merge(df2, how='left', on='CLM_NUM_CD')
    df1.loc[:, 'PRI_ICD_CD'] = ''
    df1.loc[:, 'MDC123'] = df1.apply(f_MDC123, axis=1)
    df1.loc[:, 'V1'] = ''
    df1.loc[:, 'MDC+V23'] = df1.apply(f_MDC_V23, axis=1)
    df1.loc[:, 'V2'] = ''
    df1['Microsegments_D'] = df1.apply(f_Microsegments_D, axis=1)
    df1 = df1[['CLM_NUM_CD', 'TRANS_ID', 'Microsegments_D']]

    df = df.merge(df1, how='left', on=['CLM_NUM_CD', 'TRANS_ID'])

    df = df[['CLM_NUM_CD', 'TRANS_ID', 'V1', 'V2', 'V3',
             'PRI_ICD_CD', 'RequestReceivedTS', 'MDC', 'Microsegments_D']]

    df.rename(columns={'V1': 'Have Hospitalization Date',
                       'V2': 'Have Prognosis Date',
                       'V3': 'Have Surgery Date',
                       'Microsegments_D': 'Microsegments'}, inplace=True)

    df.loc[:, 'Approval Rate'] = df.apply(f_Approval_Rate, axis=1)

    df.loc[:, 'AutoAdjudicationDecision'] = 'N'
    df.loc[df['Approval Rate'] == 0, 'AutoAdjudicationDecision'] = 'U'

    condition = (~((df['MDC'].str.strip() == 'NORMAL PREGNANCY & DELIVERY') |
                   (df['MDC'].str.strip() == 'COMPLICATIONS OF PREGNANCY')) &
                  (df['Approval Rate'] >= 0.945)) |\
                (((df['MDC'].str.strip() == 'NORMAL PREGNANCY & DELIVERY') |
                  (df['MDC'].str.strip() == 'COMPLICATIONS OF PREGNANCY')) &
                    (df['Approval Rate'] >= 0.90))

    df.loc[condition, 'AutoAdjudicationDecision'] = 'Y'
    df.loc[(df['PRI_ICD_CD'].isnull()) |
           (df['Microsegments'].astype(str) == '180'),
           'AutoAdjudicationDecision'] = 'Undecided'

    df.rename(columns={'CLM_NUM_CD': 'ClaimNumberCode',
                       'Have Hospitalization Date': 'HaveHospitalizationDate',
                       'Have Prognosis Date': 'HavePrognosisDate',
                       'Have Surgery Date': 'HaveSurgeryDate',
                       'Microsegments': 'Microsegment',
                       'Approval Rate': 'ApprovalRate'}, inplace=True)

    df.loc[:, 'Surgery'] = 'No Surgery Date'
    df.loc[df['HaveSurgeryDate'] == 'Yes', 'Surgery'] = 'Have Surgery Date'

    df.loc[:, 'Prognosis'] = 'No Prognosis Date'
    df.loc[df['HavePrognosisDate'] == 'Yes',
           'Prognosis'] = 'Have Prognosis Date'

    df.loc[:, 'Hospitalization'] = 'No Hospitalization Date'
    df.loc[df['HaveHospitalizationDate'] == 'Yes',
           'Hospitalization'] = 'Have Hospitalization Date'

    df['HaveSurgeryDate'].replace('Yes', 'Y', inplace=True)
    df.loc[df['HaveSurgeryDate'] != 'Y', 'HaveSurgeryDate'] = 'N'

    df['HavePrognosisDate'].replace('Yes', 'Y', inplace=True)
    df.loc[df['HavePrognosisDate'] != 'Y', 'HavePrognosisDate'] = 'N'

    df['HaveHospitalizationDate'].replace('Yes', 'Y', inplace=True)
    df.loc[df['HaveHospitalizationDate'] != 'Y',
           'HaveHospitalizationDate'] = 'N'

    df[['MDC', 'PRI_ICD_CD']] = df[['MDC', 'PRI_ICD_CD']].fillna('')

    df['ResultReasonDesc1'] = 'ICD=' + df['PRI_ICD_CD'].astype(str)
    df['ResultReasonDesc2'] = 'MDC=' + df['MDC'].astype(str)
    df.loc[:, 'ResultReasonDesc3'] = df['Surgery']
    df.loc[:, 'ResultReasonDesc4'] = df['Prognosis']
    df.loc[:, 'ResultReasonDesc5'] = df['Hospitalization']

    df.loc[:, 'ClusterType'] = ''
    df.loc[:, 'XeroxGroup'] = ''
    return df

data_validation_df = f_data_validation(df)

validation_fail_df = data_validation_df[
    data_validation_df['DATA_VALIDATION'] != ''].copy()
validation_pass_df = data_validation_df[
    data_validation_df['DATA_VALIDATION'] == ''].copy()

validation_fail_df = f_validation_fail_process(validation_fail_df)
validation_pass_df = f_validation_pass_process(validation_pass_df)

validation_pass_columns = [i for i in validation_fail_df.columns if i in validation_pass_df.columns]
validation_fail_df = validation_fail_df[validation_pass_columns]

final_df = validation_pass_df.append(validation_fail_df)

final_df['RequestReturnedTS'] = pd.Timestamp.now()
final_df.rename(columns={'TRANS_ID': 'TransId'})

final_df = final_df.drop(['PRI_ICD_CD', 'MDC', 'Surgery',
               'Prognosis', 'Hospitalization'], axis=1)

cols = ['TRANS_ID','ClaimNumberCode','AutoAdjudicationDecision',
        'ApprovalRate','HaveSurgeryDate','HavePrognosisDate',
        'HaveHospitalizationDate','XeroxGroup','ClusterType',
        'Microsegment','ResultReasonDesc1','ResultReasonDesc2',
        'ResultReasonDesc3','ResultReasonDesc4','ResultReasonDesc5',
        'RequestReceivedTS','RequestReturnedTS']
final_df = final_df[cols]
final_df.sort_values('ClaimNumberCode', inplace=True)

final_df.drop_duplicates(inplace=True)
final_df.to_excel('PythonOutput.xlsx', index=False)