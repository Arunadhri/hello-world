dat = pd.read_csv('intermediate_output.txt')
bet = pd.read_pickle('target.pkl')
bet['cname'] = bet['name']+'_'+bet['value']
bet.drop(['name', 'value', 'optype'], inplace=True, axis=1)

#Getting dummies for columns which have Beta value and are used in the equation in SPSS along with index columns
dummies = pd.get_dummies(data = dat[["REQ_GuidewireID", "REQ_PolicyNum", "REQ_PolicySuffix","PFM_TENURE","SRC_OF_BUS_CD","ST_RET","TRM_TYP_CD"]],
                         columns=["PFM_TENURE","SRC_OF_BUS_CD","ST_RET","TRM_TYP_CD"]) 

#Adding intercept to the data
dummies['Intercept'] = bet.loc[0, 'beta']
dummies.reset_index(drop=True, inplace=True)

# Pivoting the Beta values data so as to multiply with the raw data
test = bet.pivot_table(values='beta',columns='cname')
test = test.reset_index(drop=True)
test = pd.DataFrame(np.repeat(test.values,len(dummies),axis=0),columns=test.columns)

for i in list(dummies.columns)[3:len(dummies.columns)-1]:
    dummies[i] = dummies[i] * test[i]

# applying the logistic regression equation
dummies['score'] = dummies[list(dummies.columns)[3:]].sum(axis=1)
dummies['score'] = dummies['score'].apply(lambda x: round(1/(1+np.exp(x)),3))
dummies = dummies[['REQ_GuidewireID','REQ_PolicyNum','REQ_PolicySuffix','score']]

# Getting final score to original data
dat = dat.merge(dummies, how='inner',on=['REQ_GuidewireID','REQ_PolicyNum','REQ_PolicySuffix'])