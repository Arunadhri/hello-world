import sys,os
import _pickle as pickle
sys.path.append(os.path.abspath(os.path.join('..', 'config')))
from config import Config
from std_dsaa_599_scoring import *


#class dsaaModel:
#A risk inspection prediction engine

class dsaaModel:

    def get_final_df(self, validation_fail_df, validation_pass_df):
        #model_coeff_dict = self.get_model_coeff_dict()
        #submodel_mapping_dict = self.get_submodel_map_dict()
        #df_all_models = model_selection_and_scoring(CIS_Hits, model_coeff_dict, submodel_map_dict)
        final_df = data_processing(validation_fail_df, validation_pass_df)
        return final_df


    def __init__(self, config_path):
    #Init the prediction engine given a configuration path
        env = os.environ.get("ENV")
        self.config = Config(env , config_path)
        self.log = self.config.get_consolelogger()