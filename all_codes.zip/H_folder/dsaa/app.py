# -*- coding: utf-8 -*-
"""
Created on Mon May 26 22:12:50 2019

@author: Ranjith Dasaradhi
"""

import sys,os
from flask import  Flask, request, json, jsonify, Blueprint, abort, make_response
import pandas as pd
import json
import time

#import utils and ds_fucntions
cwd = os.path.dirname(os.path.abspath(__file__))
req = os.path.dirname(cwd)
req_dir = os.path.join(os.path.dirname(req), "utils")
sys.path.insert(0, req_dir)
ds_dir = os.path.join(os.path.dirname(cwd), "utils")
sys.path.insert(1, ds_dir)

from config import Config

try:
    from ds_functions import *
except ImportError:
    raise ImportError("loading ds_functions has failed")

try:
    from std_dsaa_599_scoring import (data_import, data_prep, feature_validation_fail_process, 
                                    feature_validation_pass_process, data_processing, export_results)
except ImportError:
    raise ImportError("Loading std_dsaa_599_scoring has failed")

try:
    from dsaa_model import dsaaModel
except ImportError:
    raise ImportError("Loading dsaa_model has failed")
                                  



app = Flask(__name__)

def create_app(config_path):
    
    start_time = time.time()
    global log
    global config
    
    global prediction_engine
    
    #config params
    app_path = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.abspath(os.path.join(app_path, '..'))
    env = os.environ.get("ENV")
    config = Config(env, config_path)
    log = config.get_consolelogger()
    log.info("create app method has started")

    try:
        prediction_engine = dsaaModel(config_path)
    except ImportError:
        raise error("Failed to load dsaaModel")
    log.warning("--- %s seconds ---" % (time.time() - start_time))
    log.info("Create app method is now complete")
    return app

def get_app():
    
    app_path = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.abspath(os.path.join(app_path, '..'))
    env = os.environ.get("ENV")
    config = Config(env, config_path)
    log = config.get_consolelogger()
    log.info("get_app method is now complete")

    #Create the app
    return(create_app(config_path))


app = get_app()

#healthcheck for dsaa model
@app.route('/api/dsaa599/health',methods=["GET"])
def get():
    log.info("Health check method has started")
    responses = jsonify(health="Server Up")
    responses.status_code = 200
    log.info("Health check method is now complete")
    return (responses)

#predict model
@app.route('/api/dsaa599/predict',methods=["POST"])
def predict():
    start_time = time.time()
    log.info("predict method has started");

    #Getting the JSON
    input_json = request.get_json()
    log.warning("Request: %s", input_json);

    # Call functions 
    main, treatment = data_import(main_data=input_json["main"], treatment_data=input_json["treatment"])

    validation_fail_df, validation_pass_df = data_prep(main, treatment)
    final_df = prediction_engine.get_final_df(validation_fail_df, validation_pass_df)
    responses = jsonify(predictions=final_df.to_json(orient="records"))
    log.info("Response to the request generated")
    log.warning(("The predict method is completed in --- %s seconds ---" % (time.time() - start_time)))
    responses.status_code = 200
    return (responses)

   
@app.errorhandler(400)
def not_found(error):
    """
    Gives error message when any bad requests are made.
    Args:
        error (string):
    Returns:
        Error message.
    """
    print(error)
    return make_response(jsonify({'error': 'Bad request'}), 400)


@app.errorhandler(404)
def not_found(error):
    """
    Gives error message when any invalid url are requested.
    Args:
        error (string): 
    Returns:
        Error message.
    """
    print(error)
    return make_response(jsonify({'error': 'Not found'}), 404)


@app.errorhandler(500)
def not_found(error):
    """
    Gives error message when any bad requests are made.
    Args:
        error (string):
    Returns:
        Error message.
    """
    print(error)
    return make_response(jsonify({'error': 'Internal Server Error'}), 500)

if __name__ == "__main__":
    env = os.environ.get("ENV")
    app_path = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.abspath(os.path.join(app_path, '..'))
    #Create the app
    app = create_app(config_path)
    #run_server(app)
    app.run()
