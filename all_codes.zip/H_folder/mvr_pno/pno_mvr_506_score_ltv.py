# #############################################################################
# -----------------------------------------------------------------------------
#                            Program Information
# -----------------------------------------------------------------------------
# Author                 : Sushant Kulkarni
# Creation Date          : 15MAY2019
# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
#                             Script Information
# -----------------------------------------------------------------------------
# Script Name            : pno_mvr_506_score_ltv.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-PNO-MVR
# Brief Description      : Script for scoring MVR
# Data used              : N/A
# Input Files            : N/A
# Output Files           : N/A
# Notes / Assumptions    : This module will be initiated from pno_mvr_506_scoring.py
#                          pno_mvr_506_data_prep.py,
#                          pno_mvr_506_common_functions.py is required in
#                          python directory
# -----------------------------------------------------------------------------
#                            Environment Information
# -----------------------------------------------------------------------------
# Python Version         : 3.6.3
# Anaconda Version       : 5.0.1
# Spark Version          : N/A
# Operating System       : Red Hat Linux 7.4
# -----------------------------------------------------------------------------
#
# ##############################################################################

import pandas as pd
import numpy as np
from pno_mvr_506_common_functions import get_poisson_score, cat_encoding_scoring


def apply_new_veh_yr(x):
    if x >= 2013:
        return "2013_14"
    elif x >= 2010:
        return "2010_12"
    elif x >= 2007:
        return "2007_09"
    elif x >= 2004:
        return "2004_06"
    elif x >= 1910:
        return "2003_PR"
    else:
        return "NA"


def apply_source(row):
    if row["OriginatingSystemCd"] == "058":
        return "GPC"
    elif row["OriginatingSystemCd"] == "080":
        return "RETAIL"
    elif row["OriginatingSystemCd"] == "056":
        return "RETAIL"
    elif (row["OriginatingSystemCd"] == "040") and (row["Marketingsourcecode"] == "AA"):
        return "RETAIL"
    elif (row["OriginatingSystemCd"] == "040") and (row["Marketingsourcecode"] == "BB"):
        return "RETAIL"
    elif (row["OriginatingSystemCd"] == "040") and (row["Marketingsourcecode"] == "CC"):
        return "RETAIL"
    elif (row["OriginatingSystemCd"] == "040") and (row["Marketingsourcecode"] == "DD"):
        return "RETAIL"
    elif (row["OriginatingSystemCd"] == "040") and (row["Marketingsourcecode"] == "EE"):
        return "GPC"
    elif (row["OriginatingSystemCd"] == "040") and (row["Marketingsourcecode"] == "ZZ"):
        return "RETAIL"
    else:
        return "GPC"


def apply_drv_cnt(x):
    if x == 1:
        return "01"
    elif x == 2:
        return "02"
    elif x > 2:
        return "03"
    else:
        return "02"


def apply_yng_rt_drv_age_yr_tilen(x):
    if int(x) < 24:
        return "00_23"
    elif int(x) < 30:
        return "24_29"
    elif int(x) < 35:
        return "30_34"
    elif int(x) < 47:
        return "35_46"
    elif int(x) < 55:
        return "47_54"
    elif int(x) < 64:
        return "55_63"
    elif int(x) < 110:
        return "64_UP"
    else:
        return ""


def apply_old_rt_drv_age_yr_tilen(x):
    if int(x) < 30:
        return "00_29"
    elif int(x) < 36:
        return "30_35"
    elif int(x) < 41:
        return "36_40"
    elif int(x) < 53:
        return "41_52"
    elif int(x) < 59:
        return "53_58"
    elif int(x) < 67:
        return "59_66"
    elif int(x) < 120:
        return "67_UP"
    else:
        return ""


def apply_bi_pol_lmt_dscr(x):
    if x == "A":
        return "LOW"
    elif x == "B":
        return "25_50"
    elif x == "C":
        return "50_100"
    elif x == "D" or x == "E":
        return "100_300"
    elif x == "F":
        return "HIGH"
    else:
        return "100_300"


def retention_factors(df):
    df["PFM_FACTOR"] = 0.00
    df["PFM_FACTOR"] = df.apply(lambda x: -1.06 if x["PFM_LVL_CD"] == "B" else x["PFM_FACTOR"], axis=1)
    df["PFM_FACTOR"] = df.apply(lambda x: -0.74 if x["PFM_LVL_CD"] == "C" else x["PFM_FACTOR"], axis=1)
    df["PFM_FACTOR"] = df.apply(lambda x: -0.50 if x["PFM_LVL_CD"] == "D" else x["PFM_FACTOR"], axis=1)
    df["PFM_FACTOR"] = df.apply(lambda x: -0.32 if x["PFM_LVL_CD"] == "E" else x["PFM_FACTOR"], axis=1)
    df["PFM_FACTOR"] = df.apply(lambda x: 0.03 if x["PFM_LVL_CD"] == "F" else x["PFM_FACTOR"], axis=1)
    df["PFM_FACTOR"] = df.apply(lambda x: 0.28 if x["PFM_LVL_CD"] == "G" else x["PFM_FACTOR"], axis=1)
    df["PFM_FACTOR"] = df.apply(lambda x: 0.53 if x["PFM_LVL_CD"] == "H" else x["PFM_FACTOR"], axis=1)
    df["PFM_FACTOR"] = df.apply(lambda x: -0.30 if x["PFM_LVL_CD"] == "NA" else x["PFM_FACTOR"], axis=1)
    df["YTH_FACTOR"] = df.apply(lambda x: -0.38 if x["YTH_ON_POL_IND"] == "N" else 0.16, axis=1)
    df["AGE_FACTOR"] = 0.45
    df["AGE_FACTOR"] = df.apply(lambda x: 0.39 if x["AGE_CROSS_O_Y"] == "B" else x["AGE_FACTOR"], axis=1)
    df["AGE_FACTOR"] = df.apply(lambda x: 0.18 if x["AGE_CROSS_O_Y"] == "C" else x["AGE_FACTOR"], axis=1)
    df["AGE_FACTOR"] = df.apply(lambda x: 0.02 if x["AGE_CROSS_O_Y"] in ["D", "E", "F", "G", "H"] else x["AGE_FACTOR"], axis=1)
    df["AGE_FACTOR"] = df.apply(lambda x: 0.19 if x["AGE_CROSS_O_Y"] == "I" else x["AGE_FACTOR"], axis=1)
    df["AGE_FACTOR"] = df.apply(lambda x: 0.08 if x["AGE_CROSS_O_Y"] == "J" else x["AGE_FACTOR"], axis=1)
    df["DRVR_FACTOR"] = 0.01
    df["DRVR_FACTOR"] = df.apply(lambda x: -0.18 if x["DRV_CNT"] == "01" else x["DRVR_FACTOR"], axis=1)
    df["DRVR_FACTOR"] = df.apply(lambda x: -0.05 if x["DRV_CNT"] == "02" else x["DRVR_FACTOR"], axis=1)
    return df


def apply_retention(row):
    retention = 1 - np.exp(row["PFM_FACTOR"] + row["DRVR_FACTOR"] + row["AGE_FACTOR"] + row["YTH_FACTOR"] - 0.555) / (1 + np.exp(row["AGE_FACTOR"] + row["YTH_FACTOR"] + row["PFM_FACTOR"] + row["DRVR_FACTOR"] - 0.555))
    return retention


def apply_cltv(row):
    CLTV = row["ERN_PREM"] * (0.06171 + 3.30154 * row["RETENTION"] - 0.07527 * row["PRED_LR"] - 4.11722 * row["PRED_LR"] * row["RETENTION"])
    return CLTV


def score_ltv(df, poisson_coeff):
    current_year = int(pd.to_datetime("today").year)
    df["NEWEST_VEH_YR"] = df["MinVehAge"].apply(lambda x: int(current_year - x))
    df["OLDEST_VEH_YR"] = df["MaxVehAge"].apply(lambda x: int(current_year - x))
    df["NEW_VEH_YR"] = df["NEWEST_VEH_YR"].apply(apply_new_veh_yr)
    df["OLD_VEH_YR"] = df["OLDEST_VEH_YR"].apply(apply_new_veh_yr)
    # need update for NOV
    df["SOURCE"] = df.apply(apply_source, axis=1)
    df["Carrier"] = df["Carrier"].str.strip()
    df["PRIR_CARY"] = df["Carrier"].str[:5]
    PRIR_CARY_list = ["ALLST", "AMERI", "FARME", "GEICO", "LIBER", "METRO",
                      "NATIO", "NO PR", "PROGR", "SAFEC", "STATE", "TRAVE",
                      "21ST", "AAA M", "COMME", "ESURA", "GOVER", "HARTF",
                      "MERCU", "NO LI", "ECONO", "HANOV", "PALIS"]
    df["PRIR_CARY_NM"] = df["PRIR_CARY"].apply(lambda x: x if x in PRIR_CARY_list else "OTHER")
    df["DRV_CNT"] = df["DrCount"].apply(apply_drv_cnt)
    df["YNG_RT_DRV_AGE_YR"] = df.loc[:, "MinDrAge"]
    df["OLD_RT_DRV_AGE_YR"] = df.loc[:, "MaxDrAge"]
    pfm_mapp = {"": "NA",
                "0": "NA",
                "1": "B",
                "2": "D",
                "3": "E",
                "4": "G",
                "1A": "B",
                "1B": "C",
                "2A": "D",
                "2B": "NH",
                "3A": "E",
                "3B": "F",
                "4A": "G",
                "4B": "H",
                "4G": "G",
                "BD": "B",
                "BH": "B",
                "BL": "B",
                "BP": "B",
                "BT": "B",
                "BW": "B",
                "CD": "C",
                "CH": "C",
                "CL": "C",
                "CP": "C",
                "CT": "C",
                "CW": "C",
                "DD": "D",
                "DG": "D",
                "DJ": "D",
                "DN": "D",
                "DQ": "D",
                "DT": "D",
                "DW": "D",
                "ED": "E",
                "EG": "E",
                "EJ": "E",
                "EN": "E",
                "EQ": "E",
                "ET": "E",
                "EW": "E",
                "FD": "F",
                "FG": "F",
                "FJ": "F",
                "FN": "F",
                "FQ": "F",
                "FT": "F",
                "FW": "F",
                "GD": "G",
                "GH": "G",
                "GL": "G",
                "GP": "G",
                "GT": "G",
                "HD": "H",
                "HH": "H",
                "HL": "H",
                "HP": "H",
                "HT": "H",
                "HW": "H",
                "NF": "NH",
                "NK": "NH",
                "NN": "NH",
                "NQ": "NH"}
    df["PFM_LVL_CD"] = df["PFM_LVL_CD"].map(pfm_mapp).fillna("NA")
    df["TRM_TYP_CD"] = "A"
    df["TIER_CD"] = "OTHER"
    df["GOOD_STUD_IND"] = "N"
    df["XCL_DRV_IND"] = "N"
    df["POL_FIN_RSPN_IND"] = "N"
    df["LIAB_ONLY_IND"] = "N"
    df["YTH_ON_POL_IND"] = "N"
    df["PR_CARR_SOURCE"] = df.loc[:, "SOURCE"] + "_" + df.loc[:, "PRIR_CARY_NM"]
    df["YNG_RT_DRV_AGE_YR_TILEN"] = df["YNG_RT_DRV_AGE_YR"].apply(apply_yng_rt_drv_age_yr_tilen)
    df["OLD_RT_DRV_AGE_YR_TILEN"] = df["YNG_RT_DRV_AGE_YR"].apply(apply_old_rt_drv_age_yr_tilen)
    df["PRIR_BI_LMT_CD"] = "A"
    df["BI_POL_LMT_DSCR"] = df["PRIR_BI_LMT_CD"].apply(apply_bi_pol_lmt_dscr)
    df["AGE_CROSS_O_Y"] = df.loc[:, "OLD_RT_DRV_AGE_YR_TILEN"] + "__" + df.loc[:, "YNG_RT_DRV_AGE_YR_TILEN"]
    df = df[~df["ERN_PREM"].isnull()]
    age_cross_dict = {"00_29__00_23": "A",
                      "00_29__24_29": "A",
                      "30_35__00_23": "A",
                      "30_35__24_29": "A",
                      "30_35__30_34": "B",
                      "30_35__35_46": "B",
                      "36_40__00_23": "I",
                      "36_40__24_29": "I",
                      "36_40__30_34": "B",
                      "36_40__35_46": "B",
                      "41_52__00_23": "K",
                      "41_52__24_29": "I",
                      "41_52__30_34": "I",
                      "41_52__35_46": "C",
                      "41_52__47_54": "C",
                      "53_58__00_23": "J",
                      "53_58__24_29": "I",
                      "53_58__30_34": "I",
                      "53_58__35_46": "C",
                      "53_58__47_54": "C",
                      "53_58__55_63": "C",
                      "59_66__00_23": "J",
                      "59_66__24_29": "H",
                      "59_66__30_34": "H",
                      "59_66__35_46": "G",
                      "59_66__47_54": "F",
                      "59_66__55_63": "D",
                      "59_66__64_UP": "E",
                      "67_UP__00_23": "H",
                      "67_UP__24_29": "H",
                      "67_UP__30_34": "H",
                      "67_UP__35_46": "G",
                      "67_UP__47_54": "F",
                      "67_UP__55_63": "D",
                      "67_UP__64_UP": "E",
                      "_": "K",
                      "67_UP__": "K",
                      "": "K"}
    df["AGE_CROSS_O_Y"] = df["AGE_CROSS_O_Y"].map(age_cross_dict).fillna("NA")
    df["LOG_EP"] = np.log(df["ERN_PREM"])
    drop_cols = ["MinDrAge", "MaxDrAge", "MinVehAge", "PRIR_CARY_NM",
                 "YNG_RT_DRV_AGE_YR", "OLD_RT_DRV_AGE_YR",
                 "YNG_RT_DRV_AGE_YR_TILEN", "OLD_RT_DRV_AGE_YR_TILEN"]
    df = df.drop(drop_cols, axis=1)
    df = df[df["ERN_PREM"] >= 0.01]
    # List of categorical variable and its values for one-hot encoding
    model_vars_values = {"PFM_LVL_CD": ["B", "C", "D", "E", "F", "G", "H", "NA", "NH"],
                         "TIER_CD": ["01_05", "06_10", "11_15", "16_20", "21_25", "26_30", "31_99", "OTHER"],
                         "TRM_TYP_CD": ["6", "A"],
                         "BI_POL_LMT_DSCR": ["100_300", "25_50", "50_100", "HIGH", "LOW"],
                         "XCL_DRV_IND": ["Y", "N"],
                         "POL_FIN_RSPN_IND": ["Y", "N"],
                         "LIAB_ONLY_IND": ["Y", "N"],
                         "YTH_ON_POL_IND": ["Y", "N"],
                         "DRV_CNT": ["01", "02", "03"],
                         "GOOD_STUD_IND": ["Y", "N"],
                         "NEW_VEH_YR": ["2003_PR", "2004_06", "2007_09", "2010_12", "2013_14", "NA"],
                         "OLD_VEH_YR": ["2003_PR", "2004_06", "2007_09", "2010_12", "2013_14", "NA"],
                         "PR_CARR_SOURCE": ["GPC_", "GPC_21ST", "GPC_AAA M",
                                            "GPC_ALLST", "GPC_AMERI", "GPC_COMME",
                                            "GPC_ESURA", "GPC_FARME", "GPC_GEICO",
                                            "GPC_GOVER", "GPC_HARTF", "GPC_LIBER",
                                            "GPC_MERCU", "GPC_METRO", "GPC_NATIO",
                                            "GPC_NO LI", "GPC_NO PR", "GPC_OTHER",
                                            "GPC_PROGR", "GPC_SAFEC", "GPC_STATE",
                                            "GPC_TRAVE", "RETAIL_", "RETAIL_21ST",
                                            "RETAIL_AAA M", "RETAIL_ALLIE",
                                            "RETAIL_ALLST", "RETAIL_AMERI",
                                            "RETAIL_COMME", "RETAIL_ECONO",
                                            "RETAIL_ENCOM", "RETAIL_FARME",
                                            "RETAIL_GEICO", "RETAIL_HANOV",
                                            "RETAIL_HARTF", "RETAIL_KEMPE",
                                            "RETAIL_LIBER", "RETAIL_MERCU",
                                            "RETAIL_METRO", "RETAIL_NATIO",
                                            "RETAIL_NO LI", "RETAIL_NO PR",
                                            "RETAIL_OTHER", "RETAIL_PALIS",
                                            "RETAIL_PROGR", "RETAIL_SAFEC",
                                            "RETAIL_STATE", "RETAIL_TRAVE"],
                         "AGE_CROSS_O_Y": ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"]}
    df_ctg_encod, dummy_cols = cat_encoding_scoring(model_vars_values, df.copy(), drop_first=False)
    # Score data using Poisson model
    scored_df = get_poisson_score(poisson_coeff, df_ctg_encod, "ERN_PREM", "$G-INCUR_LOSS")
    # drop one hot encodings
    scored_df = scored_df.drop(dummy_cols, axis=1)
    scored_df = retention_factors(scored_df)
    scored_df["RETENTION"] = scored_df.apply(apply_retention, axis=1)
    scored_df["PRED_LR"] = scored_df.loc[:, "$G-INCUR_LOSS"] / scored_df.loc[:, "ERN_PREM"]
    scored_df["CLTV"] = scored_df.apply(apply_cltv, axis=1)
    # Cap the CLTV
    scored_df["CLTV"] = scored_df.apply(lambda x: -3000 if x["CLTV"] < -3000 else x["CLTV"], axis=1)
    scored_df["CLTV"] = scored_df.apply(lambda x: 10000 if x["CLTV"] > 10000 else x["CLTV"], axis=1)
    return scored_df
