##########################################################################
# ------------------------------------------------------------------------
#                            Program Information
# ------------------------------------------------------------------------
# Author                 : Chakravarthula Chakravarthy, Prabakar Subramani
# Creation Date          : 28MAR2019
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
#                             Script Information
# ------------------------------------------------------------------------
# Script Name            : pno_mvr_506_model_coeff_pkl.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC/US-PNC-PNC-PNO-MVR
# Brief Description      : Contains function to write the model
#                          coefficients from the SPSS model node into a
#                          pickle file.
# Data used              : XML file - <file name>.xml. A single xml file
#                          contains the information of single model used
#                          in the SPSS stream. If "n" number of models are
#                          used in the SPSS stream, then the corresponding
#                          "n" of xml files will be used to create
#                          the pkl file. All xml files are present in
#                          the "inputs" folder in the edge node.
# Input Files            : N/A
# Output Files           : PKL file - pno_mvr_506_model_GZLM.pkl,
#                          pno_mvr_506_model_multinomialLogistic.pkl
# Notes / Assumptions    : This module requires the xml file to be in a
#                          folder. In case of multiple xml files, it will
#                          be iterated over all the files in the folder.
# ------------------------------------------------------------------------
#                            Environment Information
# ------------------------------------------------------------------------
# Python Version         : 3.6.8
# Anaconda Version       : 5.0.1
# Operating System       : Red Hat Linux 7.4
# ------------------------------------------------------------------------
# ########################################################################

import os
import time
import sys
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
sys.path.insert(0, "./utils")


try:
    from config import Config
except ImportError:
    raise ImportError("Failed to import config")

try:
    env = os.environ.get("ENV")
    app_path = os.getcwd()
    config = Config(env, app_path)
    log = config.get_logger()
except Exception:
    raise Exception("Failed to initiate config file.")

try:
    from ds_functions import save_pickle
except ImportError as e:
    log.exception("Failed to import ds_functions")
    raise e

# Get values stored in the config file.
try:
    xml_file_path = config.getConfigValueFor("input_file_path")
    pkl_path = config.getConfigValueFor("pkl_path")
    pkl_file_name = config.getConfigValueFor("model_file_name")
except Exception as e:
    log.exception("Failed to read the XML file path and pickle file path")
    raise e

log.debug("Found the pkl object file path as {}".format(os.path.join(pkl_path)))


# Function to read the file
def read_xml_file(xml_file):
    """
    Function to open a xml file in a location and convert its
    contents to soup format

    Inputs:
    xml_file -------> xml file name
    Returns:
    soup ------> soup formatted content
    """
    try:
        with open(xml_file) as file:
            data = file.read()
            soup = BeautifulSoup(data, "xml")
    except Exception as e:
        log.exception("Failed to read the xml data.")
        raise e
    return soup


# Function to find the tag that contains model results
def find_model_tag(soup, model_name):
    """
    Function to find the tag that contains model results

    Inputs:
    soup ------> soup formatted content
    model_name -----> model name
    Returns:
    model type  ------> model type
    """
    all_tags = soup.find_all()
    for each_tag in all_tags:
        try:
            attributes = each_tag.attrs
            attr_name = attributes.get("algorithmName")
            if attr_name == model_name:
                model_type = each_tag.name
                break
        except Exception as e:
            log.debug("Not able to find the Model tag", e)
            model_type = ""
    return model_type


def create_coefficient_table(soup, model_type):
    """
    Function to create coefficient dataframe from soup content

    Inputs:
    soup ------> soup formatted content
    model type  ------> model type
    Returns:
    coeff_df ------> Pandas dataframe with coefficients for each model
    """
    coeff_matrix = soup.find("PMML").find(model_type).find("ParamMatrix")
    param_matrix = soup.find("PMML").find(model_type).find("PPMatrix")
    coefficient_table = coeff_matrix.find_all("PCell")
    parameters_table = param_matrix.find_all("PPCell")
    coeff_list = []
    for each_row in coefficient_table:
        data_dict = each_row.attrs
        coeff_list.append(data_dict)
    param_list = []
    for each_row in parameters_table:
        data_dict = each_row.attrs
        param_list.append(data_dict)
    coeff_df = pd.DataFrame(coeff_list)
    param_df = pd.DataFrame(param_list)
    try:
        coeff_df = pd.merge(coeff_df, param_df, how="left", on=["parameterName"])
        coeff_df["predictorName"] = np.where(coeff_df["predictorName"].isnull(),
                                             coeff_df["parameterName"],
                                             coeff_df["predictorName"])
    except Exception as e:
        log.exception(str(e))
        raise e
    return coeff_df


def xml_parse_main(xml_file_path, xml_file, model_name):
    """
    Function to create coefficient dataframe for a given xml file
    Inputs:
    xml_file_path ------> path of xml file
    xml_file  ------> xml file name
    model_name -----> model name
    Returns:
    coeff_table --------> Pandas dataframe with coefficients for each model
    """
    soup = read_xml_file(os.path.join(xml_file_path, xml_file))
    model_type = find_model_tag(soup, model_name)
    coff_table = create_coefficient_table(soup, model_type)
    return coff_table


if __name__ == "__main__":
    start_time = time.time()
    log.info(str(pkl_file_name) + " writing method has started")
    # Script to run all PMML xml files and generate a collated pickle file
    all_files = [file for file in os.listdir(xml_file_path) if file.endswith(".xml")]
    for file in all_files:
        model_name = file.split("_nuid_")[0]
        coeff_df = xml_parse_main(xml_file_path, file, model_name)
        pkl_file_name_i = pkl_file_name + "_" + model_name + ".pkl"
        try:
            save_pickle(coeff_df, path=pkl_path, file_name=pkl_file_name_i)
            log.info("Writing " + str(pkl_file_name_i) + " is complete")
        except Exception as e:
            log.exception("Failed to export the pkl object data.")
            raise e
    log.info(str(pkl_file_name) + " writing method has completed")
    log.warning("The Writing " + str(pkl_file_name) + " is completed in: [ %s ] Seconds ---" % (time.time() - start_time))
