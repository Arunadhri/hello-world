# #############################################################################
# -----------------------------------------------------------------------------
#                            Program Information
# -----------------------------------------------------------------------------
# Author                 : Sushant Kulkarni
# Creation Date          : 15MAY2019
# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
#                             Script Information
# -----------------------------------------------------------------------------
# Script Name            : pno_mvr_506_scoring.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-PNO-MVR
# Brief Description      : Script for scoring MVR
# Data used              : input_df
# Output Files           : CSV file - pno_mvr_506_output_file.csv
# Notes / Assumptions    : This module requires ds_functions.py from utils
#                          folder, pno_mvr_506_models.pkl from the pickles
#                          folder and pno_mvr_506_data_prep.py,
#                          pno_mvr_506_score_ltv.py,
#                          pno_mvr_506_driver_data_prep.py,
#                          pno_mvr_506_driver_scoring.py,
#                          pno_mvr_506_post_process.py,
#                          pno_mvr_506_common_functions.py and
#                          pno_mvr_506_mvr_data_prep.py from python folder.
# -----------------------------------------------------------------------------
#                            Environment Information
# -----------------------------------------------------------------------------
# Python Version         : 3.6.3
# Anaconda Version       : 5.0.1
# Spark Version          : N/A
# Operating System       : Red Hat Linux 7.4
# -----------------------------------------------------------------------------
#
# ##############################################################################


import os
import sys
import time
import pandas as pd
from datetime import datetime
sys.path.insert(0, "./utils")
sys.path.append("./python")

try:
    from config import Config
except ImportError:
    raise ImportError("Failed to import config")

# fetch config params
try:
    env = os.environ.get("ENV")
    app_path = os.getcwd()
    config = Config(env, app_path)
    log = config.get_logger()
except Exception:
    raise Exception("Failed to initiate config and log file.")

try:
    from ds_functions import load_pickle
except ImportError as e:
    log.exception("Failed to import ds_functions")
    raise e


try:
    from pno_mvr_506_data_prep import data_prep
    from pno_mvr_506_score_ltv import score_ltv
    from pno_mvr_506_driver_data_prep import assump_cutoff
    from pno_mvr_506_driver_scoring import driver_scoring
    from pno_mvr_506_post_process import post_process
except ImportError as e:
    log.exception("Cannot import required modules")
    raise e


# Get values stored in the config file.
try:
    pkl_path = config.getConfigValueFor("pkl_path")
    logistic_pkl = config.getConfigValueFor("model_pkl_logistic")
    poisson_pkl = config.getConfigValueFor("model_pkl_poisson")
    input_path = config.getConfigValueFor("input_file_path")
    input_payload_path = config.getConfigValueFor("INPUT_PAYLOAD")
    output_path = config.getConfigValueFor("export_file_path")
    output_file_name = config.getConfigValueFor("export_file_name")
except Exception as e:
    log.exception("Failed to read the input and export data path")
    raise e


# Reading the models from the pickle file.
try:
    poisson_coeff = load_pickle(pkl_path, poisson_pkl)
    logistic_coeff = load_pickle(pkl_path, logistic_pkl)
except Exception as e:
    log.exception("Failed to load the model pickle file")
    raise e

# ##############################################################################
#
# Data Import
#
# ##############################################################################


def data_import():
    log.info("data_import method has started")
    dtype_dic = {"CA_OriginatingSystemCd": str,
                 "OriginatingSystemCd": str}
    # Reading the input data
    try:
        input_df = pd.read_csv(os.path.join(input_path, input_payload_path), dtype=dtype_dic)
    except Exception as e:
        log.exception("Failed to load the input data.")
        raise e
    log.info("data_import method has completed")
    return input_df

# ##############################################################################
#
# Data Preparation
#
# ##############################################################################


def data_preparation(input_df):
    log.info("data_prep method has started")
    date_type = ["CA_BirthDt1", "CA_BirthDt2", "CA_BirthDt3", "CA_BirthDt4",
                 "CA_BirthDt5", "CA_BirthDt6", "CA_BirthDt7", "CA_BirthDt8",
                 "CA_BirthDt9", "CA_BirthDt10", "CA_BirthDt11",
                 "BirthDt1", "BirthDt2", "BirthDt3", "BirthDt4", "BirthDt5",
                 "BirthDt6", "BirthDt7", "BirthDt8", "BirthDt9", "BirthDt10",
                 "BirthDt11"]
    for col in date_type:
        input_df[col] = pd.to_datetime(input_df[col], errors="coerce")
    str_type = ["StateProvCd1", "StateProvCd2", "StateProvCd3", "StateProvCd4",
                "StateProvCd5", "StateProvCd6", "StateProvCd7", "StateProvCd8",
                "StateProvCd9", "StateProvCd10", "StateProvCd11",
                "Gender1", "Gender2", "Gender3", "Gender4", "Gender5", "Gender6",
                "Gender7", "Gender8", "Gender9", "Gender10", "Gender11",
                "CA_GenderCd1", "CA_GenderCd2", "CA_GenderCd3", "CA_GenderCd4",
                "CA_GenderCd5", "CA_GenderCd6", "CA_GenderCd7", "CA_GenderCd8",
                "CA_GenderCd9", "CA_GenderCd10", "CA_GenderCd11",
                "AccidentViolationCd1", "AccidentViolationCd2",
                "AccidentViolationCd3", "AccidentViolationCd4",
                "AccidentViolationCd5", "AccidentViolationCd6",
                "AccidentViolationCd7", "AccidentViolationCd8",
                "AccidentViolationCd9", "AccidentViolationCd10",
                "CA_AccidentViolationCd1", "CA_AccidentViolationCd2",
                "CA_AccidentViolationCd3", "CA_AccidentViolationCd4",
                "CA_AccidentViolationCd5", "CA_AccidentViolationCd6",
                "CA_AccidentViolationCd7", "CA_AccidentViolationCd8",
                "CA_InsurerCd", "CA_PostalCode",
                "StateProv", "CA_StateProv"]
    for col in str_type:
        input_df[col] = input_df[col].fillna("")
    data_prep_df = data_prep(input_df)
    log.info("data_prep method has completed")
    return data_prep_df

# ##############################################################################
#
# LTV Model scoring
#
# ##############################################################################


def ltv_model_scoring(modeldf, poisson_coeff):
    log.info("ltv_model_scoring method has started")
    ltv_scored = score_ltv(modeldf, poisson_coeff)
    log.info("ltv_model_scoring method is now complete")
    return ltv_scored

# ##############################################################################
#
# Driver data preparation and scoring
#
# ##############################################################################


def driver_data_prep(ltv_df):
    log.info("driver_model_data_prep method has started")
    driver_df = assump_cutoff(ltv_df)
    log.info("driver_model_data_prep is now complete")
    return driver_df


def driver_model_scoring(driver_df, logistic_coeff):
    log.info("driver_model_scoring method has started")
    driver_scored = driver_scoring(driver_df, logistic_coeff)
    log.info("driver_model_scoring method is now complete")
    return driver_scored

# ##############################################################################
#
# Post model processing
#
# ##############################################################################


def post_processing(driver_df):
    log.info("post_processing method has started")
    finaldf = post_process(driver_df)
    log.info("post_processing method is now complete")
    return finaldf

# ##############################################################################
#
# Save final output
#
# ##############################################################################


def export_scored(scored_df):
    log.info("export_scored method has started")
    try:
        scored_df.to_csv(os.path.join(output_path, output_file_name + "_" +
                         str(datetime.now().strftime("%Y_%m_%d-%H_%M_%S")) + ".csv"), index=False)
    except Exception as e:
        log.exception("Failed to export the scored data.")
        raise e
    log.info("export_scored method has completed")
    return None

# ##############################################################################
#
# Main function
#
# ##############################################################################


if __name__ == "__main__":
    start_time = time.time()
    # Read input data and required pickle file data
    input_df = data_import()
    # Preparing data for scoring
    try:
        data_prepared = data_preparation(input_df)
    except Exception as e:
        log.exception("Failed to prepare the data for scoring.")
        raise e
    # Score data using LTV model
    try:
        ltv_scored_df = ltv_model_scoring(data_prepared, poisson_coeff)
    except Exception as e:
        log.exception("Failed to score the data for LTV model.")
        raise e
    # Prepare data for driver model scoring
    try:
        driver_prep_df = driver_data_prep(ltv_scored_df)
    except Exception as e:
        log.exception("Failed to prepare the data for driver model.")
        raise e
    # Score data using driver model
    try:
        driver_scored_df = driver_model_scoring(driver_prep_df, logistic_coeff)
    except Exception as e:
        log.exception("Failed to score the data for driver model.")
        raise e
    # Post-processing the scored data
    try:
        scored_df = post_processing(driver_scored_df)
    except Exception as e:
        log.exception("Failed to post process the data.")
        raise e
    # Exporting the scored data
    export_scored(scored_df)
    log.info("Scoring is complete")
    log.warning("The scoring is completed in: [ %s ] Seconds ---" % (time.time() - start_time))
