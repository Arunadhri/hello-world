# #############################################################################
# -----------------------------------------------------------------------------
#                            Program Information
# -----------------------------------------------------------------------------
# Author                 : Sushant Kulkarni
# Creation Date          : 15MAY2019
# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
#                             Script Information
# -----------------------------------------------------------------------------
# Script Name            : pno_mvr_506_data_prep.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-PNO-MVR
# Brief Description      : Preparing data for model scoring
# Data used              : N/A
# Input FIles            : N/A
# Output Files           : N/A
# Notes / Assumptions    : This module will be initiated from pno_mvr_506_scoring.py
#                          pno_mvr_506_data_prep.py,
#                          pno_mvr_506_common_functions.py is required in
#                          python directory
# -----------------------------------------------------------------------------
#                            Environment Information
# -----------------------------------------------------------------------------
# Python Version         : 3.6.3
# Anaconda Version       : 5.0.1
# Spark Version          : N/A
# Operating System       : Red Hat Linux 7.4
# -----------------------------------------------------------------------------
#
# ##############################################################################

import pandas as pd
import numpy as np

from pno_mvr_506_mvr_data_prep import mvr_model_prep
from pno_mvr_506_common_functions import years_differ


def default_birthdt(row, drv_no):
    base = pd.to_datetime("1900-01-01")
    cond1 = row["BirthDt" + drv_no] == ""
    cond2 = row["Gender" + drv_no].strip() != ""
    cond3 = pd.to_datetime(row["LicensedDt" + drv_no]) > base
    cond4 = row["StateProvCd" + drv_no].strip() != ""
    if (cond1) and (cond2 or cond3 or cond4):
        return pd.to_datetime("1994-01-01")
    else:
        return row["BirthDt" + drv_no]


def default_values(df):
    df["BirthDt1"] = df.apply(lambda x: default_birthdt(x, "1"), axis=1)
    df["BirthDt2"] = df.apply(lambda x: default_birthdt(x, "2"), axis=1)
    df["BirthDt3"] = df.apply(lambda x: default_birthdt(x, "3"), axis=1)
    df["BirthDt4"] = df.apply(lambda x: default_birthdt(x, "4"), axis=1)
    df["BirthDt5"] = df.apply(lambda x: default_birthdt(x, "5"), axis=1)
    df["BirthDt6"] = df.apply(lambda x: default_birthdt(x, "6"), axis=1)
    df["BirthDt7"] = df.apply(lambda x: default_birthdt(x, "7"), axis=1)
    df["BirthDt8"] = df.apply(lambda x: default_birthdt(x, "8"), axis=1)
    df["BirthDt9"] = df.apply(lambda x: default_birthdt(x, "9"), axis=1)
    df["BirthDt10"] = df.apply(lambda x: default_birthdt(x, "10"), axis=1)
    df["BirthDt11"] = df.apply(lambda x: default_birthdt(x, "11"), axis=1)
    return df


def check_ca_sex(row, drv_no):
    base = pd.to_datetime("1900-01-01")
    if row["CA_GenderCd" + drv_no] != "":
        return row["CA_GenderCd" + drv_no]
    elif ((row["Gender" + drv_no] == "") and ((row["CA_BirthDt" + drv_no] > base) or (row["BirthDt" + drv_no] > base))):
        return "M"
    else:
        return row["Gender" + drv_no]


def check_ca_licdt(row, drv_no):
    if (row["CA_LicensedDt" + drv_no] != ""):
        return row["CA_LicensedDt" + drv_no]
    else:
        return row["LicensedDt" + drv_no]


def check_ca(df):
    df["Accident_Cd1"] = df.apply(lambda x: x["CA_AccidentViolationCd1"] if x["CA_AccidentViolationCd1"] != "" else x["AccidentViolationCd1"], axis=1)
    df["Accident_Cd2"] = df.apply(lambda x: x["CA_AccidentViolationCd2"] if x["CA_AccidentViolationCd2"] != "" else x["AccidentViolationCd2"], axis=1)
    df["Accident_Cd3"] = df.apply(lambda x: x["CA_AccidentViolationCd3"] if x["CA_AccidentViolationCd3"] != "" else x["AccidentViolationCd3"], axis=1)
    df["Accident_Cd4"] = df.apply(lambda x: x["CA_AccidentViolationCd4"] if x["CA_AccidentViolationCd4"] != "" else x["AccidentViolationCd4"], axis=1)
    df["Accident_Cd5"] = df.apply(lambda x: x["CA_AccidentViolationCd5"] if x["CA_AccidentViolationCd5"] != "" else x["AccidentViolationCd5"], axis=1)
    df["Accident_Cd6"] = df.apply(lambda x: x["CA_AccidentViolationCd6"] if x["CA_AccidentViolationCd6"] != "" else x["AccidentViolationCd6"], axis=1)
    df["Accident_Cd7"] = df.apply(lambda x: x["CA_AccidentViolationCd7"] if x["CA_AccidentViolationCd7"] != "" else x["AccidentViolationCd7"], axis=1)
    df["Accident_Cd8"] = df.apply(lambda x: x["CA_AccidentViolationCd8"] if x["CA_AccidentViolationCd8"] != "" else x["AccidentViolationCd8"], axis=1)
    df["YR_DIFF_VIOL1"] = df.apply(lambda x: years_differ(x["CA_AccidentViolationDt1"], pd.to_datetime("today")), axis=1)
    df["YR_DIFF_VIOL2"] = df.apply(lambda x: years_differ(x["CA_AccidentViolationDt2"], pd.to_datetime("today")), axis=1)
    df["YR_DIFF_VIOL3"] = df.apply(lambda x: years_differ(x["CA_AccidentViolationDt3"], pd.to_datetime("today")), axis=1)
    df["YR_DIFF_VIOL4"] = df.apply(lambda x: years_differ(x["CA_AccidentViolationDt4"], pd.to_datetime("today")), axis=1)
    df["YR_DIFF_VIOL5"] = df.apply(lambda x: years_differ(x["CA_AccidentViolationDt5"], pd.to_datetime("today")), axis=1)
    df["YR_DIFF_VIOL6"] = df.apply(lambda x: years_differ(x["CA_AccidentViolationDt6"], pd.to_datetime("today")), axis=1)
    df["YR_DIFF_VIOL7"] = df.apply(lambda x: years_differ(x["CA_AccidentViolationDt7"], pd.to_datetime("today")), axis=1)
    df["YR_DIFF_VIOL8"] = df.apply(lambda x: years_differ(x["CA_AccidentViolationDt8"], pd.to_datetime("today")), axis=1)
    df["Sex1"] = df.apply(lambda x: check_ca_sex(x, "1"), axis=1)
    df["Sex2"] = df.apply(lambda x: check_ca_sex(x, "2"), axis=1)
    df["Sex3"] = df.apply(lambda x: check_ca_sex(x, "3"), axis=1)
    df["Sex4"] = df.apply(lambda x: check_ca_sex(x, "4"), axis=1)
    df["Sex5"] = df.apply(lambda x: check_ca_sex(x, "5"), axis=1)
    df["Sex6"] = df.apply(lambda x: check_ca_sex(x, "6"), axis=1)
    df["Sex7"] = df.apply(lambda x: check_ca_sex(x, "7"), axis=1)
    df["Sex8"] = df.apply(lambda x: check_ca_sex(x, "8"), axis=1)
    df["Sex9"] = df.apply(lambda x: check_ca_sex(x, "9"), axis=1)
    df["Sex10"] = df.apply(lambda x: check_ca_sex(x, "10"), axis=1)
    df["Sex11"] = df.apply(lambda x: check_ca_sex(x, "11"), axis=1)
    df["LicDt1"] = df.apply(lambda x: check_ca_licdt(x, "1"), axis=1)
    df["LicDt2"] = df.apply(lambda x: check_ca_licdt(x, "2"), axis=1)
    df["LicDt3"] = df.apply(lambda x: check_ca_licdt(x, "3"), axis=1)
    df["LicDt4"] = df.apply(lambda x: check_ca_licdt(x, "4"), axis=1)
    df["LicDt5"] = df.apply(lambda x: check_ca_licdt(x, "5"), axis=1)
    df["LicDt6"] = df.apply(lambda x: check_ca_licdt(x, "6"), axis=1)
    df["LicDt7"] = df.apply(lambda x: check_ca_licdt(x, "7"), axis=1)
    df["LicDt8"] = df.apply(lambda x: check_ca_licdt(x, "8"), axis=1)
    df["LicDt9"] = df.apply(lambda x: check_ca_licdt(x, "9"), axis=1)
    df["LicDt10"] = df.apply(lambda x: check_ca_licdt(x, "10"), axis=1)
    df["LicDt11"] = df.apply(lambda x: check_ca_licdt(x, "11"), axis=1)
    drop_list = ["CVICd",
                 "CA_GenderCd",
                 "CA_GenderCd1", "CA_LicensedDt1",
                 "CA_GenderCd2", "CA_LicensedDt2",
                 "CA_GenderCd3", "CA_LicensedDt3",
                 "CA_GenderCd4", "CA_LicensedDt4",
                 "CA_GenderCd5", "CA_LicensedDt5",
                 "CA_GenderCd6", "CA_LicensedDt6",
                 "CA_GenderCd7", "CA_LicensedDt7",
                 "CA_GenderCd8", "CA_LicensedDt8",
                 "CA_GenderCd9", "CA_LicensedDt9",
                 "CA_GenderCd10", "CA_LicensedDt10",
                 "CA_GenderCd11", "CA_LicensedDt11",
                 "AccidentViolationCd1",
                 "AccidentViolationCd2", "AccidentViolationDt2",
                 "AccidentViolationCd3", "AccidentViolationDt3",
                 "CA_AccidentViolationCd4", "CA_AccidentViolationDt4",
                 "CA_AccidentViolationCd5", "CA_AccidentViolationDt5",
                 "CA_AccidentViolationCd6", "CA_AccidentViolationDt6",
                 "CA_AccidentViolationCd7", "CA_AccidentViolationDt7",
                 "CA_AccidentViolationCd8", "CA_AccidentViolationDt8",
                 "Gender1", "LicensedDt1",
                 "Gender2", "LicensedDt2",
                 "Gender3", "LicensedDt3",
                 "Gender4", "LicensedDt4",
                 "Gender5", "LicensedDt5",
                 "Gender6", "LicensedDt6",
                 "Gender7", "LicensedDt7",
                 "Gender8", "LicensedDt8",
                 "Gender9", "LicensedDt9",
                 "Gender10", "LicensedDt10",
                 "Gender11", "LicensedDt11",
                 "Gender",
                 "CA_AccidentViolationCd1", "CA_AccidentViolationDt1",
                 "CA_AccidentViolationCd2", "CA_AccidentViolationDt2",
                 "CA_AccidentViolationCd3", "CA_AccidentViolationDt3",
                 "AccidentViolationCd4", "AccidentViolationDt4",
                 "AccidentViolationCd5", "AccidentViolationDt5",
                 "AccidentViolationCd6", "AccidentViolationDt6",
                 "AccidentViolationCd7", "AccidentViolationDt7",
                 "AccidentViolationCd8", "AccidentViolationDt8"]
    df = df.drop(drop_list, axis=1)
    df.rename(columns={"Accident_Cd1": "AccidentViolationCd1",
                       "Accident_Cd2": "AccidentViolationCd2",
                       "Accident_Cd3": "AccidentViolationCd3",
                       "Accident_Cd4": "AccidentViolationCd4",
                       "Accident_Cd5": "AccidentViolationCd5",
                       "Accident_Cd6": "AccidentViolationCd6",
                       "Accident_Cd7": "AccidentViolationCd7",
                       "Accident_Cd8": "AccidentViolationCd8",
                       "Sex1": "Gender1",
                       "Sex2": "Gender2",
                       "Sex3": "Gender3",
                       "Sex4": "Gender4",
                       "Sex5": "Gender5",
                       "Sex6": "Gender6",
                       "Sex7": "Gender7",
                       "Sex8": "Gender8",
                       "Sex9": "Gender9",
                       "Sex10": "Gender10",
                       "Sex11": "Gender11",
                       "LicDt1": "LicensedDt1",
                       "LicDt2": "LicensedDt2",
                       "LicDt3": "LicensedDt3",
                       "LicDt4": "LicensedDt4",
                       "LicDt5": "LicensedDt5",
                       "LicDt6": "LicensedDt6",
                       "LicDt7": "LicensedDt7",
                       "LicDt8": "LicensedDt8",
                       "LicDt9": "LicensedDt9",
                       "LicDt10": "LicensedDt10",
                       "LicDt11": "LicensedDt11"}, inplace=True)
    return df


def claimcount(row):
    ct = 0
    if len(row["AccidentViolationCd1"]) > 0:
        ct += 1
    if len(row["AccidentViolationCd2"]) > 0:
        ct += 1
    if len(row["AccidentViolationCd3"]) > 0:
        ct += 1
    if len(row["AccidentViolationCd4"]) > 0:
        ct += 1
    if len(row["AccidentViolationCd5"]) > 0:
        ct += 1
    if len(row["AccidentViolationCd6"]) > 0:
        ct += 1
    if len(row["AccidentViolationCd7"]) > 0:
        ct += 1
    if len(row["AccidentViolationCd8"]) > 0:
        ct += 1
    if len(row["AccidentViolationCd9"]) > 0:
        ct += 1
    if len(row["AccidentViolationCd10"]) > 0:
        ct += 1
    return ct


def apply_vehcountdisc(row):
    ct = 0
    if row["CA_ModelYear1"] >= 1900:
        ct += 1
    if row["CA_ModelYear2"] >= 1900:
        ct += 1
    if row["CA_ModelYear3"] >= 1900:
        ct += 1
    if row["CA_ModelYear4"] >= 1900:
        ct += 1
    if row["CA_ModelYear5"] >= 1900:
        ct += 1
    if row["CA_ModelYear6"] >= 1900:
        ct += 1
    if row["CA_ModelYear7"] >= 1900:
        ct += 1
    if row["CA_ModelYear8"] >= 1900:
        ct += 1
    if row["CA_ModelYear9"] >= 1900:
        ct += 1
    if row["CA_ModelYear10"] >= 1900:
        ct += 1
    return ct


def apply_vehcount(row):
    ct = 0
    if row["VehCountDisc"] > 0:
        return row["VehCountDisc"]
    else:
        if row["ModelYear1"] >= 1900:
            ct += 1
        if row["ModelYear2"] >= 1900:
            ct += 1
        if row["ModelYear3"] >= 1900:
            ct += 1
        if row["ModelYear4"] >= 1900:
            ct += 1
        if row["ModelYear5"] >= 1900:
            ct += 1
        if row["ModelYear6"] >= 1900:
            ct += 1
        if row["ModelYear7"] >= 1900:
            ct += 1
        if row["ModelYear8"] >= 1900:
            ct += 1
        if row["ModelYear9"] >= 1900:
            ct += 1
        if row["ModelYear10"] >= 1900:
            ct += 1
        return ct


def apply_drcountdisc(row):
    ct = 0
    base = pd.to_datetime("1900-01-01")
    if row["CA_BirthDt1"] > base:
        ct += 1
    if row["CA_BirthDt2"] > base:
        ct += 1
    if row["CA_BirthDt3"] > base:
        ct += 1
    if row["CA_BirthDt4"] > base:
        ct += 1
    if row["CA_BirthDt5"] > base:
        ct += 1
    if row["CA_BirthDt6"] > base:
        ct += 1
    if row["CA_BirthDt7"] > base:
        ct += 1
    if row["CA_BirthDt8"] > base:
        ct += 1
    if row["CA_BirthDt9"] > base:
        ct += 1
    if row["CA_BirthDt10"] > base:
        ct += 1
    if row["CA_BirthDt11"] > base:
        ct += 1
    return ct


def apply_drcount(row):
    base = pd.to_datetime("1900-01-01")
    if row["DrCountDisc"] > 0:
        return row["DrCountDisc"]
    else:
        ct = 0
        if row["BirthDt1"] > base:
            ct += 1
        if row["BirthDt2"] > base:
            ct += 1
        if row["BirthDt3"] > base:
            ct += 1
        if row["BirthDt4"] > base:
            ct += 1
        if row["BirthDt5"] > base:
            ct += 1
        if row["BirthDt6"] > base:
            ct += 1
        if row["BirthDt7"] > base:
            ct += 1
        if row["BirthDt8"] > base:
            ct += 1
        if row["BirthDt9"] > base:
            ct += 1
        if row["BirthDt10"] > base:
            ct += 1
        if row["BirthDt11"] > base:
            ct += 1
        return ct


def apply_drdob1(row):
    if row["DrCountDisc"] > 0:
        if row["DrCount"] >= 1:
            return row["CA_BirthDt1"]
        else:
            return np.nan
    else:
        if row["DrCount"] >= 1:
            return row["BirthDt1"]
        else:
            return np.nan


def apply_drdob_2_7(row, drv_no):
    base = pd.to_datetime("1900-01-01")
    if row["DrCountDisc"] > 0:
        if (row["DrCount"] >= 1) and (row["CA_BirthDt" + drv_no] > base):
            return row["CA_BirthDt" + drv_no]
        else:
            return np.nan
    else:
        if (row["DrCount"] >= 1) and (row["BirthDt" + drv_no] > base):
            return row["BirthDt" + drv_no]
        else:
            return np.nan


def apply_drage(row, drv_no):
    if row["DrCount"] >= int(drv_no):
        return years_differ(row["DrDOB" + drv_no], pd.to_datetime("today"))
    else:
        return np.nan


def apply_min_dr_age(row):
    age_min = min([row["DrAge1"], row["DrAge2"], row["DrAge3"],
                  row["DrAge4"], row["DrAge5"], row["DrAge6"],
                  row["DrAge7"], row["DrAge8"], row["DrAge9"],
                  row["DrAge10"]])
    return age_min


def apply_max_dr_age(row):
    age_max = max([row["DrAge1"], row["DrAge2"], row["DrAge3"],
                  row["DrAge4"], row["DrAge5"], row["DrAge6"],
                  row["DrAge7"], row["DrAge8"], row["DrAge9"],
                  row["DrAge10"]])
    return age_max


def apply_vehage(row, drv_no):
    current_year = int(pd.to_datetime("today").year)
    if row["VehCountDisc"] > 0:
        if type(row["CA_ModelYear" + drv_no]) == str:
            return current_year - int(row["CA_ModelYear" + drv_no])
        else:
            return current_year - row["CA_ModelYear" + drv_no]
    else:
        if type(row["ModelYear" + drv_no]) == str:
            return current_year - int(row["ModelYear" + drv_no])
        else:
            return current_year - row["ModelYear" + drv_no]


def apply_avg_veh_yrs(row):
    veh_avg = np.nanmean(np.array([row["VehAge1"], row["VehAge2"],
                                   row["VehAge3"], row["VehAge4"],
                                   row["VehAge5"], row["VehAge6"],
                                   row["VehAge7"], row["VehAge8"],
                                   row["VehAge9"], row["VehAge10"]]))
    return veh_avg


def apply_max_veh_age(row):
    veh_max = max(np.array([row["VehAge1"], row["VehAge2"], row["VehAge3"],
                  row["VehAge4"], row["VehAge5"], row["VehAge6"],
                  row["VehAge7"], row["VehAge8"], row["VehAge9"],
                  row["VehAge10"]]))
    return veh_max


def apply_min_veh_age(row):
    veh_min = min(np.array([row["VehAge1"], row["VehAge2"], row["VehAge3"],
                  row["VehAge4"], row["VehAge5"], row["VehAge6"],
                  row["VehAge7"], row["VehAge8"], row["VehAge9"],
                  row["VehAge10"]]))
    return veh_min


def vehicle_driver(df):
    df["VehCountDisc"] = df.apply(apply_vehcountdisc, axis=1)
    df["VehCount"] = df.apply(apply_vehcount, axis=1)
    # Filling missing values for CA birth date  as 1900-01-01
    missing_birth_ca = ["CA_BirthDt1", "CA_BirthDt2", "CA_BirthDt3",
                        "CA_BirthDt4", "CA_BirthDt5", "CA_BirthDt6",
                        "CA_BirthDt7", "CA_BirthDt8", "CA_BirthDt9",
                        "CA_BirthDt10", "CA_BirthDt11"]
    for col in missing_birth_ca:
        df[col] = df[col].fillna(pd.to_datetime("1900-01-01", format="%Y-%m-%d"))
    df["DrCountDisc"] = df.apply(apply_drcountdisc, axis=1)
    # Filling missing values for birth date as 1900-01-01
    missing_birth = ["BirthDt1", "BirthDt2", "BirthDt3", "BirthDt4",
                     "BirthDt5", "BirthDt6", "BirthDt7", "BirthDt8",
                     "BirthDt9", "BirthDt10", "BirthDt11"]
    for col in missing_birth:
        df[col] = df[col].fillna(pd.to_datetime("1900-01-01", format="%Y-%m-%d"))
    # Computing no of drivers
    df["DrCount"] = df.apply(apply_drcount, axis=1)
    # Computing each driver DOB
    df["DrDOB1"] = df.apply(apply_drdob1, axis=1)
    df["DrDOB2"] = df.apply(lambda x: apply_drdob_2_7(x, "2"), axis=1)
    df["DrDOB3"] = df.apply(lambda x: apply_drdob_2_7(x, "3"), axis=1)
    df["DrDOB4"] = df.apply(lambda x: apply_drdob_2_7(x, "4"), axis=1)
    df["DrDOB5"] = df.apply(lambda x: apply_drdob_2_7(x, "5"), axis=1)
    df["DrDOB6"] = df.apply(lambda x: apply_drdob_2_7(x, "6"), axis=1)
    df["DrDOB7"] = df.apply(lambda x: apply_drdob_2_7(x, "7"), axis=1)
    df["DrDOB8"] = df.apply(lambda x: apply_drdob_2_7(x, "8"), axis=1)
    df["DrDOB9"] = df.apply(lambda x: apply_drdob_2_7(x, "9"), axis=1)
    df["DrDOB10"] = df.apply(lambda x: apply_drdob_2_7(x, "10"), axis=1)
    df["DrDOB11"] = df.apply(lambda x: apply_drdob_2_7(x, "11"), axis=1)
    date_type = ["DrDOB1", "DrDOB2", "DrDOB3", "DrDOB4", "DrDOB5", "DrDOB6",
                 "DrDOB7", "DrDOB8", "DrDOB9", "DrDOB10", "DrDOB11"]
    for col in date_type:
        df[col] = pd.to_datetime(df[col], errors="coerce")
    # Computing each driver age
    df["DrAge1"] = df.apply(lambda x: apply_drage(x, "1"), axis=1)
    df["DrAge2"] = df.apply(lambda x: apply_drage(x, "2"), axis=1)
    df["DrAge3"] = df.apply(lambda x: apply_drage(x, "3"), axis=1)
    df["DrAge4"] = df.apply(lambda x: apply_drage(x, "4"), axis=1)
    df["DrAge5"] = df.apply(lambda x: apply_drage(x, "5"), axis=1)
    df["DrAge6"] = df.apply(lambda x: apply_drage(x, "6"), axis=1)
    df["DrAge7"] = df.apply(lambda x: apply_drage(x, "7"), axis=1)
    df["DrAge8"] = df.apply(lambda x: apply_drage(x, "8"), axis=1)
    df["DrAge9"] = df.apply(lambda x: apply_drage(x, "9"), axis=1)
    df["DrAge10"] = df.apply(lambda x: apply_drage(x, "10"), axis=1)
    df["DrAge11"] = df.apply(lambda x: apply_drage(x, "11"), axis=1)
    # Computing minimum driver age
    df["MinDrAge"] = df.apply(apply_min_dr_age, axis=1)
    # Computing maximum driver age
    df["MaxDrAge"] = df.apply(apply_max_dr_age, axis=1)
    # Computing vehicle age
    df["VehAge1"] = df.apply(lambda x: apply_vehage(x, "1"), axis=1)
    df["VehAge2"] = df.apply(lambda x: apply_vehage(x, "2"), axis=1)
    df["VehAge3"] = df.apply(lambda x: apply_vehage(x, "3"), axis=1)
    df["VehAge4"] = df.apply(lambda x: apply_vehage(x, "4"), axis=1)
    df["VehAge5"] = df.apply(lambda x: apply_vehage(x, "5"), axis=1)
    df["VehAge6"] = df.apply(lambda x: apply_vehage(x, "6"), axis=1)
    df["VehAge7"] = df.apply(lambda x: apply_vehage(x, "7"), axis=1)
    df["VehAge8"] = df.apply(lambda x: apply_vehage(x, "8"), axis=1)
    df["VehAge9"] = df.apply(lambda x: apply_vehage(x, "9"), axis=1)
    df["VehAge10"] = df.apply(lambda x: apply_vehage(x, "10"), axis=1)
    # Computing average vehicle age
    df["Avg_VEH_YRs"] = df.apply(apply_avg_veh_yrs, axis=1)
    # Computing maximum vehicle age
    df["MaxVehAge"] = df.apply(apply_max_veh_age, axis=1)
    # Computing minimum vehicle age
    df["MinVehAge"] = df.apply(apply_min_veh_age, axis=1)
    return df


def data_prep(df):
    df["PFM"] = df.apply(lambda x: x["CA_CreditScore"] if x["CA_CreditScore"] != "" else x["CreditScore"], axis=1)
    df["Origination"] = df.apply(lambda x: x["CA_OriginatingSystemCd"] if x["CA_OriginatingSystemCd"] != "" else x["OriginatingSystemCd"], axis=1)
    # Change 06082017
    df["PostalCode"] = df.apply(lambda x: x["CA_PostalCode"] if x["CA_PostalCode"] != "" else x["PostalCode"], axis=1)
    df["StateProv"] = df.apply(lambda x: x["CA_StateProv"] if x["CA_StateProv"] != "" else x["StateProv"], axis=1)
    # Filter and rename
    drop_cols = ["OriginatingSystemCd", "CreditScore"]
    df = df.drop(drop_cols, axis=1)
    df.rename(columns={"CA_DriverID1": "DriverID1",
                       "CA_DriverID2": "DriverID2",
                       "CA_DriverID3": "DriverID3",
                       "CA_DriverID4": "DriverID4",
                       "CA_DriverID5": "DriverID5",
                       "CA_DriverID6": "DriverID6",
                       "CA_DriverID7": "DriverID7",
                       "CA_DriverID8": "DriverID8",
                       "CA_DriverID9": "DriverID9",
                       "CA_DriverID10": "DriverID10",
                       "CA_DriverID11": "DriverID11",
                       "CA_TransactionCd": "TransactionCd",
                       "PFM": "PFM_LVL_CD",
                       "Origination": "OriginatingSystemCd"}, inplace=True)
    df["ERN_PREM"] = df["TotalPremium"].apply(lambda x: 1500 if np.isnan(x) else x)
    df = default_values(df)
    df = check_ca(df)
    df["ClaimCount"] = df.apply(claimcount, axis=1)
    df = vehicle_driver(df)
    df["Carrier"] = df.apply(lambda x: x["CA_InsurerCd"] if x["CA_InsurerCd"] != "" else x["InsurerCd"], axis=1)
    keep_list = ["AccidentViolationCd15", "AccidentViolationDt15",
                 "AccidentViolationCd16", "AccidentViolationDt16",
                 "AccidentViolationCd17", "AccidentViolationDt17",
                 "AccidentViolationCd18", "AccidentViolationDt18",
                 "AccidentViolationCd19", "AccidentViolationDt19",
                 "AccidentViolationCd20", "AccidentViolationDt20",
                 "AccidentViolationCd21", "AccidentViolationDt21",
                 "AccidentViolationCd22", "AccidentViolationDt22",
                 "AccidentViolationCd23", "AccidentViolationDt23",
                 "AccidentViolationCd24", "AccidentViolationDt24",
                 "AccidentViolationCd25", "AccidentViolationDt25",
                 "AccidentViolationCd26", "AccidentViolationDt26",
                 "AccidentViolationCd27", "AccidentViolationDt27",
                 "AccidentViolationCd28", "AccidentViolationDt28",
                 "AccidentViolationCd29", "AccidentViolationDt29",
                 "AccidentViolationCd30", "AccidentViolationDt30",
                 "CA_StateProv", "CA_ModelYear1", "CA_ModelYear2",
                 "CA_ModelYear3", "CA_ModelYear4", "CA_ModelYear5",
                 "CA_ModelYear6", "CA_ModelYear7", "CA_ModelYear8",
                 "CA_ModelYear9", "CA_ModelYear10", "AccidentViolationDt1",
                 "ReferenceNumber", "StateProv", "InsurerCd", "StateProvCd1",
                 "StateProvCd2", "StateProvCd3", "StateProvCd4",
                 "StateProvCd5", "StateProvCd6", "StateProvCd7",
                 "StateProvCd8", "StateProvCd9", "StateProvCd10",
                 "StateProvCd11", "PostalCode", "ModelYear5", "ModelYear4",
                 "ModelYear3", "ModelYear2", "ModelYear1", "ModelYear6",
                 "ModelYear7", "ModelYear8", "ModelYear9", "ModelYear10",
                 "AccidentViolationCd9", "AccidentViolationDt9",
                 "AccidentViolationCd10", "AccidentViolationDt10",
                 "AccidentViolationCd11", "AccidentViolationDt11",
                 "AccidentViolationCd12", "AccidentViolationDt12",
                 "AccidentViolationCd13", "AccidentViolationDt13",
                 "AccidentViolationCd14", "AccidentViolationDt14",
                 "QuoteId", "CallReasonCd", "MarketingSource",
                 "Agent", "CA_ReferenceNumber", "DriverID1", "DriverID2",
                 "DriverID3", "DriverID4", "DriverID5", "DriverID6",
                 "DriverID7", "DriverID8", "DriverID9", "DriverID10",
                 "DriverID11", "TransactionCd", "CA_MarketingSource",
                 "PFM_LVL_CD", "OriginatingSystemCd", "ERN_PREM",
                 "AccidentViolationCd1", "AccidentViolationCd2",
                 "AccidentViolationCd3", "AccidentViolationCd4",
                 "AccidentViolationCd5", "AccidentViolationCd6",
                 "AccidentViolationCd7", "AccidentViolationCd8",
                 "YR_DIFF_VIOL1", "YR_DIFF_VIOL2", "YR_DIFF_VIOL3",
                 "YR_DIFF_VIOL4", "YR_DIFF_VIOL5", "YR_DIFF_VIOL6",
                 "YR_DIFF_VIOL7", "YR_DIFF_VIOL8", "Gender1", "Gender2",
                 "Gender3", "Gender4", "Gender5", "Gender6", "Gender7",
                 "Gender8", "Gender9", "Gender10", "Gender11", "LicensedDt1",
                 "LicensedDt2", "LicensedDt3", "LicensedDt4", "LicensedDt5",
                 "LicensedDt6", "LicensedDt7", "LicensedDt8", "LicensedDt9",
                 "LicensedDt10", "LicensedDt11", "ClaimCount", "DrCount",
                 "DrDOB1", "DrDOB2", "DrDOB3", "DrDOB4", "DrDOB5", "DrDOB6",
                 "DrDOB7", "DrDOB8", "DrDOB9", "DrDOB10", "DrDOB11", "DrAge1",
                 "DrAge2", "DrAge3", "DrAge4", "DrAge5", "DrAge6", "DrAge7",
                 "DrAge8", "DrAge9", "DrAge10", "DrAge11", "MinDrAge",
                 "MaxDrAge", "Avg_VEH_YRs", "MaxVehAge", "MinVehAge",
                 "Carrier"]
    df = df[keep_list]
    df.rename(columns={"DrDOB1": "BirthDt1",
                       "DrDOB2": "BirthDt2",
                       "DrDOB3": "BirthDt3",
                       "DrDOB4": "BirthDt4",
                       "DrDOB5": "BirthDt5",
                       "DrDOB6": "BirthDt6",
                       "DrDOB7": "BirthDt7",
                       "DrDOB8": "BirthDt8",
                       "DrDOB9": "BirthDt9",
                       "DrDOB10": "BirthDt10",
                       "DrDOB11": "BirthDt11"}, inplace=True)
    df["Marketingsourcecode"] = df.apply(lambda x: x["CA_MarketingSource"] if x["CA_MarketingSource"] != "" else x["MarketingSource"], axis=1)
    df["GEN_NUM"] = df.loc[:, "CA_ReferenceNumber"]
    df = df.drop(["ReferenceNumber"], axis=1)
    df = mvr_model_prep(df)
    # Adjust semi-annual premium
    # disabled node in SPSS-- keeping commented out code at business request
    # df["ERN_PREM"] = df.apply(lambda x: x["PREMIUM"]*2 if x["TRM_TYP_CD"] == "S" else x["PREMIUM"], axis=1)
    return df
