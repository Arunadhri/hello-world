# #############################################################################
# -----------------------------------------------------------------------------
#                            Program Information
# -----------------------------------------------------------------------------
# Author                 : Sushant Kulkarni
# Creation Date          : 15MAY2019
# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
#                             Script Information
# -----------------------------------------------------------------------------
# Script Name            : pno_mvr_506_mvr_data_prep.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-PNO-MVR
# Brief Description      : Script for MVR data preparation
# Data used              : N/A
# Input Files            : N/A
# Output Files           : N/A
# Notes / Assumptions    : This module will be initiated from
#                          pno_mvr_506_data_prep.py
# -----------------------------------------------------------------------------
#                            Environment Information
# -----------------------------------------------------------------------------
# Python Version         : 3.6.3
# Anaconda Version       : 5.0.1
# Spark Version          : N/A
# Operating System       : Red Hat Linux 7.4
# -----------------------------------------------------------------------------
#
# ##############################################################################

import numpy as np


def mvr_prep_st(row):
    if row["CA_StateProv"] != "":
        return row["CA_StateProv"]
    else:
        return row["StateProv"]


def mvr_prep_pfm_group(row):
    if row["PFM_LVL_CD"].startswith("B"):
        return "B"
    elif row["PFM_LVL_CD"].startswith("C"):
        return "C"
    elif row["PFM_LVL_CD"].startswith("D"):
        return "D"
    elif row["PFM_LVL_CD"].startswith("E"):
        return "E"
    elif row["PFM_LVL_CD"].startswith("F"):
        return "F"
    elif row["PFM_LVL_CD"].startswith("G"):
        return "G"
    elif row["PFM_LVL_CD"].startswith("H"):
        return "H"
    elif row["PFM_LVL_CD"].startswith("N"):
        return "N"
    else:
        return "O"


def mvr_prep_semci(row):
    if row["OriginatingSystemCd"] == "058":
        return "GRP"
    elif row["OriginatingSystemCd"] == "080":
        return "IA_SEMCI"
    elif row["OriginatingSystemCd"] == "056":
        return "IM"
    elif (row["OriginatingSystemCd"] == "040") and (row["Marketingsourcecode"] == "AA"):
        return "IA_NONSEMCI"
    elif (row["OriginatingSystemCd"] == "040") and (row["Marketingsourcecode"] == "BB"):
        return "IB"
    elif (row["OriginatingSystemCd"] == "040") and (row["Marketingsourcecode"] == "CC"):
        return "PCS"
    elif (row["OriginatingSystemCd"] == "040") and (row["Marketingsourcecode"] == "DD"):
        return "IM"
    elif (row["OriginatingSystemCd"] == "040") and (row["Marketingsourcecode"] == "EE"):
        return "GRP"
    elif (row["OriginatingSystemCd"] == "040") and (row["Marketingsourcecode"] == "ZZ"):
        return "IM"
    else:
        return "IM"


def mvr_prep_avg_veh_yrs_tile20(x):
    if (x < 2.0):
        return 1
    elif (x >= 2.0) and (x < 3.0):
        return 2
    elif (x >= 3.0) and (x < 4.0):
        return 3
    elif (x >= 4.0) and (x < 5.0):
        return 4
    elif (x >= 5.0) and (x < 5.5):
        return 5
    elif (x >= 5.5) and (x < 6.0):
        return 6
    elif (x >= 6.0) and (x < 7.0):
        return 7
    elif (x >= 7.0) and (x < 7.5):
        return 8
    elif (x >= 7.5) and (x < 8.0):
        return 9
    elif (x >= 8.0) and (x < 8.5):
        return 10
    elif (x >= 8.5) and (x < 9.0):
        return 11
    elif (x >= 9.0) and (x < 10.0):
        return 12
    elif (x >= 10.0) and (x < 10.5):
        return 13
    elif (x >= 10.5) and (x < 11.0):
        return 14
    elif (x >= 11.0) and (x < 12.0):
        return 15
    elif (x >= 12.0) and (x < 12.75):
        return 16
    elif (x >= 12.75) and (x < 14.0):
        return 17
    elif (x >= 14.0) and (x < 15.0):
        return 18
    elif (x >= 15.0) and (x < 17.33333300000004):
        return 19
    elif (x >= 17.33333300000004):
        return 20
    else:
        return 2


def mvr_prep_prir_cary(row):
    if row["Carrier"].strip() == "":
        return "NOPRIR"
    elif row["Carrier"].strip().startswith("NO PR"):
        return "NOPRIR"
    else:
        return row["Carrier"].strip()[:5]


def mvr_prep_carrier(row):
    cary = ["ALLST", "AMERI", "FARME", "GEICO", "LIBER", "METRO", "NATIO",
            "NOPRIR", "PROGR", "SAFEC", "STATE", "TRAVE"]
    if row["PRIR_CARY"] in cary:
        return row["PRIR_CARY"]
    else:
        return "Other Carriers"


def mvr_prep_yr_since_viol(row):
    min_yr = min(np.array([row["YR_DIFF_VIOL1"], row["YR_DIFF_VIOL2"],
                 row["YR_DIFF_VIOL3"], row["YR_DIFF_VIOL4"],
                 row["YR_DIFF_VIOL5"], row["YR_DIFF_VIOL6"],
                 row["YR_DIFF_VIOL7"], row["YR_DIFF_VIOL8"]]))
    if min_yr <= 1:
        return 1
    elif min_yr <= 2:
        return 2
    elif min_yr <= 3:
        return 3
    else:
        return 4


def mvr_prep_hh_grp(row):
    if row["ClaimCount"] == "":
        return "0"
    elif row["ClaimCount"] < 6:
        return str(row["ClaimCount"])
    elif row["ClaimCount"] < 8:
        return "6_7"
    else:
        return "8 and more"


def mvr_prep_num_drv_grp(x):
    if x < 2:
        return "1D"
    elif x < 3:
        return "2D"
    else:
        return "3+D"


def mvr_prep_drv_viol(row):
    if row["ClaimCount"] > 7:
        return "8andMORE"
    else:
        return row["NUM_DRV_GRP"] + row["NUM_CLM_HH_grp"]


def mvr_model_prep(df):
    # Data preparation for MVR model
    df["ST"] = df.apply(mvr_prep_st, axis=1)
    df["PFM group"] = df.apply(mvr_prep_pfm_group, axis=1)
    df["DISTRIBUTION_SEMCI"] = df.apply(mvr_prep_semci, axis=1)
    df["B2B_IND_REC"] = "A"
    # One of the below must be disabled
    # Enabled
    df["BI_LIMIT_CD"] = "A-B"
    # Disabled
    # disabled node in SPSS-- keeping commented out code at business request
    # BI_LIMIT_CD_dict = {"G": "Z_Missing",
    #                     "A": "A-B",
    #                     "B": "A-B",
    #                     "C": "C-E",
    #                     "D": "C-E",
    #                     "E": "C-E",
    #                     "F": "F",
    #                     "M": "M",
    #                     "Missing": "Z_Missing",
    #                     "N": "N"}
    # df["BI_LIMIT_CD"] = df["PRIR_BI_LMT_CD"].replace(BI_LIMIT_CD_dict)
    df["Avg_VEH_YRs_TILE20"] = df["Avg_VEH_YRs"].apply(mvr_prep_avg_veh_yrs_tile20)
    df["PRIR_CARY"] = df.apply(mvr_prep_prir_cary, axis=1)
    df["CARRIER"] = df.apply(mvr_prep_carrier, axis=1)
    df.drop(["PRIR_CARY"], axis=1, inplace=True)
    df["YR_SINCE_VIOL"] = df.apply(mvr_prep_yr_since_viol, axis=1)
    df["NUM_CLM_HH_grp"] = df.apply(mvr_prep_hh_grp, axis=1)
    df["NUM_DRV_GRP"] = df["DrCount"].apply(mvr_prep_num_drv_grp)
    df["DRV_VIOL"] = df.apply(mvr_prep_drv_viol, axis=1)
    drv_viol_dict = {"1D0": "1D0",
                     "1D1": "1D1",
                     "1D2": "1D2",
                     "1D3": "1D3",
                     "1D4": "1D4+",
                     "1D5": "1D4+",
                     "1D6_7": "1D4+",
                     "2D0": "2D0",
                     "2D1": "2D1",
                     "2D2": "2D2",
                     "2D3": "2D3",
                     "2D4": "2D4",
                     "2D5": "2D5",
                     "2D6_7": "2D6_7",
                     "3+D0": "3+D0_1",
                     "3+D1": "3+D0_1",
                     "3+D2": "3+D2",
                     "3+D3": "3+D3",
                     "3+D4": "3+D4",
                     "3+D5": "3+D5",
                     "3+D6_7": "3+D6_7",
                     "8andMORE": "8andMORE"}
    df["DRV_VIOL"] = df["DRV_VIOL"].replace(drv_viol_dict)
    PFM_group_dict = {"B": "B",
                      "C": "C",
                      "D": "D",
                      "E": "E",
                      "F": "F-H",
                      "G": "F-H",
                      "H": "F-H",
                      "N": "N",
                      "O": "O"}
    df["PFM_grp"] = df["PFM group"].replace(PFM_group_dict)
    Avg_VEH_YRs_TILE20_dict = {1: "1to4",
                               2: "1to4",
                               3: "1to4",
                               4: "1to4",
                               5: "5to16",
                               6: "5to16",
                               7: "5to16",
                               8: "5to16",
                               9: "5to16",
                               10: "5to16",
                               11: "5to16",
                               12: "5to16",
                               13: "5to16",
                               14: "5to16",
                               15: "5to16",
                               16: "5to16",
                               17: "Z_17-20",
                               18: "Z_17-20",
                               19: "Z_17-20",
                               20: "Z_17-20"}
    df["Avg_VEH_AGE"] = df["Avg_VEH_YRs_TILE20"].replace(Avg_VEH_YRs_TILE20_dict)
    ST_dict = {"AK": "Z_OTHER",
               "DC": "Z_OTHER",
               "HI": "Z_OTHER",
               "MT": "Z_OTHER",
               "AL": "AL",
               "AR": "Z_GRP4",
               "AZ": "Z_GRP9",
               "CA": "CA",
               "CO": "CO",
               "CT": "CT",
               "DE": "Z_GRP2",
               "FL": "FL",
               "GA": "GA",
               "IA": "Z_GRP5",
               "ID": "Z_GRP7",
               "IL": "IL",
               "IN": "IN",
               "KS": "Z_GRP8",
               "KY": "Z_GRP3",
               "LA": "Z_GRP4",
               "MA": "Z_GRP6",
               "MD": "Z_GRP2",
               "ME": "Z_GRP6",
               "MI": "MI",
               "MN": "Z_GRP5",
               "MO": "Z_GRP5",
               "MS": "Z_GRP4",
               "NC": "NC",
               "ND": "Z_GRP5",
               "NE": "Z_GRP8",
               "NH": "Z_GRP6",
               "NJ": "NJ",
               "NM": "Z_GRP9",
               "NV": "Z_GRP9",
               "NY": "NY",
               "OH": "OH",
               "OK": "Z_GRP4",
               "OR": "Z_GRP7",
               "PA": "PA",
               "RI": "Z_GRP6",
               "SC": "Z_GRP1",
               "SD": "Z_GRP8",
               "TN": "Z_GRP1",
               "TX": "TX",
               "UT": "Z_GRP7",
               "VA": "Z_GRP1",
               "VT": "Z_GRP6",
               "WA": "WA",
               "WI": "WI",
               "WV": "Z_GRP3",
               "WY": "Z_GRP7"}
    df["STATE"] = df["ST"].replace(ST_dict)
    drop_cols = ["AccidentViolationCd15", "AccidentViolationDt15",
                 "AccidentViolationCd16", "AccidentViolationDt16",
                 "AccidentViolationCd17", "AccidentViolationDt17",
                 "AccidentViolationCd18", "AccidentViolationDt18",
                 "AccidentViolationCd19", "AccidentViolationDt19",
                 "AccidentViolationCd20", "AccidentViolationDt20",
                 "AccidentViolationCd21", "AccidentViolationDt21",
                 "AccidentViolationCd22", "AccidentViolationDt22",
                 "AccidentViolationCd23", "AccidentViolationDt23",
                 "AccidentViolationCd24", "AccidentViolationDt24",
                 "AccidentViolationCd25", "AccidentViolationDt25",
                 "AccidentViolationCd26", "AccidentViolationDt26",
                 "AccidentViolationCd27", "AccidentViolationDt27",
                 "AccidentViolationCd28", "AccidentViolationDt28",
                 "AccidentViolationCd29", "AccidentViolationDt29",
                 "AccidentViolationCd30", "AccidentViolationDt30",
                 "AccidentViolationDt1",
                 "AccidentViolationCd9", "AccidentViolationDt9",
                 "AccidentViolationCd10", "AccidentViolationDt10",
                 "AccidentViolationCd11", "AccidentViolationDt11",
                 "AccidentViolationCd12", "AccidentViolationDt12",
                 "AccidentViolationCd13", "AccidentViolationDt13",
                 "AccidentViolationCd14", "AccidentViolationDt14",
                 "AccidentViolationCd1", "AccidentViolationCd2",
                 "AccidentViolationCd3", "AccidentViolationCd4",
                 "AccidentViolationCd5", "AccidentViolationCd6",
                 "AccidentViolationCd7", "AccidentViolationCd8"]
    df = df.drop(drop_cols, axis=1)
    return df
