# #############################################################################
# -----------------------------------------------------------------------------
#                            Program Information
# -----------------------------------------------------------------------------
# Author                 : Sushant Kulkarni
# Creation Date          : 15MAY2019
# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
#                             Script Information
# -----------------------------------------------------------------------------
# Script Name            : pno_mvr_506_common_functions.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-PNO-MVR
# Brief Description      : Script for scoring MVR
# Data used              : N/A
# Input Files            : N/A
# Output Files           : N/A
# Notes / Assumptions    : This module will be initiated from
#                          pno_mvr_506_driver_scoring.py,
#                          pno_mvr_506_data_prep.py
# -----------------------------------------------------------------------------
#                            Environment Information
# -----------------------------------------------------------------------------
# Python Version         : 3.6.3
# Anaconda Version       : 5.0.1
# Spark Version          : N/A
# Operating System       : Red Hat Linux 7.4
# -----------------------------------------------------------------------------
#
# ##############################################################################

import pandas as pd
import numpy as np


def get_logistic_score(logist_coeff, score_df, trgt_prob_name, trgt_ctg_name):
    """ Scores data based Logistic regression

    The trained Logistic regression model's coefficients are required.
    The coefficients are assumed to be in dataframe where "beta" column
    would have coefficients and "predictorName" column would have corresponding
    predictor variables(IDV).
    The constant term in "predictorName" should be saved as "P0000001"

    Parameters:
        logist_coeff (dataframe): Logistic model coefficients
        score_df (dataframe): scoring dataset with predictors
                              [category variables should be one-hot encoded]
        trgt_prob_name (string): name of probability outcome column
        trgt_ctg_name (string): name for category outcome column

    Returns:
        score_df (dataframe): scoring data with Logistic model score appended

    Examples:
        >>> get_logistic_score(logistic_coeff_df, score_df, trgt_prob_name = "Pred_probab", trgt_ctg_name = "Predicted"):
    """
    logist_coeff["weights"] = pd.to_numeric(logist_coeff["beta"])
    # fetch the constant estimate
    beta = float(logist_coeff.loc[logist_coeff["predictorName"] == "P0000001", "weights"])
    # model estimates without constant
    logist_coeff = logist_coeff[logist_coeff["predictorName"] != "P0000001"]
    logist_coeff = logist_coeff.reset_index(drop=True)
    # Fetching IDV names for one-hot encoded variables
    logist_coeff["variable"] = logist_coeff["predictorName"] + "_" + logist_coeff["value"]
    # get the model predicitors (IDV)
    param_names = logist_coeff["variable"].values
    # score data - Logistic regression implementation
    score_df[trgt_prob_name] = (np.dot(score_df[param_names].values, logist_coeff["weights"].values) + beta)
    score_df[trgt_prob_name] = 1 / (1 + (1 / np.exp(score_df[trgt_prob_name])))
    # Converting probability to binary class output
    score_df[trgt_ctg_name] = score_df[trgt_prob_name].apply(lambda x: 1 if x >= 0.5 else 0)
    return score_df


def get_poisson_score(pois_coeff_df, score_df, offset_var_name, target_var_name):
    """ Scores data based Poisson regression

    The trained Poisson regression model's coefficients are required.
    The coefficients are assumed to be in dataframe where "beta" column
    would have coefficients and "predictorName" column would have corresponding
    predictor variables(IDV)
    The constant term in "predictorName" should be saved as "P0000001"
    The offset variable should also be present in scoring data

    Parameters:
        pois_coeff_df (dataframe): Poisson model coefficients
        score_df (dataframe): scoring dataset with predictors and offset
                              [category predictors should be one-hot encoded]
        offset_var_name (string): name of offset column in "score_df"
        target_var_name (string): name for final target column

    Returns:
        score_df (dataframe): scoring data with poisson score appended

    Examples:
        >>> get_poisson_score(pois_coeff_df, score_df, offset_var_name = "ERN_PREM", target_var_name = "$G-INCUR_LOSS"):
    """
    pois_coeff_df["weights"] = pd.to_numeric(pois_coeff_df["beta"])
    # fetch the constant estimate
    beta = float(pois_coeff_df.loc[pois_coeff_df["predictorName"] == "P0000001", "weights"])
    # model estimates without constant
    pois_coeff_df = pois_coeff_df[pois_coeff_df["predictorName"] != "P0000001"]
    pois_coeff_df = pois_coeff_df.reset_index(drop=True)
    # Fetching variables names for one hot encoded variables
    pois_coeff_df["variable"] = pois_coeff_df["predictorName"] + "_" + pois_coeff_df["value"]
    # get the model predicitors (IDV)
    param_names = pois_coeff_df["variable"].values
    # score data - Poisson regression implementation
    score_df[target_var_name] = np.exp(np.dot(score_df[param_names].values, pois_coeff_df["weights"].values) + beta) * score_df[offset_var_name]
    return score_df


def years_differ(date1, date2):
    """
    Computes years difference between two dates
    if date1 > date2, difference is negative
    Conversion logic is based ons SPSS 'date_years_difference' function
    """
    date1 = pd.to_datetime(date1)
    date2 = pd.to_datetime(date2)
    year_diff = round(((date2 - date1).days) / 365.25, 3)
    return year_diff


def cat_encoding_scoring(categories_dict, scoring_df, drop_first=True):
    """Encodes categorical variables in scoring data

    The expected categories should be saved in a pickle file during
    training. Load pickle file. This function will derive the same
    dummy variables used in the training data.

    Parameters:
        categories_dict (dictionary): Output of make_categorical_dict().
        scoring_df (dataframe): The scoring DataFrame.
        drop_first (boolean): Default True. Parameter for get_dummies
                              to get k-1 dummies out of k categorical
                              levels by removing the first level.

    Returns:
        scoring_df (dataframe): The updated scoring DataFrame.
        dummy_columns (list): List of dummy columns added.

    Examples:
        >>> df, dummy_columns = cat_encoding_scoring(categories_dict, scoring_df=df)

    """
    # Get the string variables from the passed dictionary
    string_vars = list(categories_dict.keys())
    # Taking copy of categorical columns to be encoded
    ctg_colsdf = scoring_df.loc[:, string_vars]
    # iterate through dictionary to convert object variables to categories type
    for key, value in categories_dict.items():
        value = list(map(lambda x: str(x), value))
        ctg_colsdf[key] = ctg_colsdf[key].astype(str).astype("category", categories=value)
    # create dummy columns based on categories passed in through the dictionary
    df_dummies = pd.get_dummies(ctg_colsdf, columns=string_vars, drop_first=drop_first)
    # Concatenate dummy columns with original training DataFrame
    scoring_df = pd.concat([scoring_df, df_dummies], axis=1)
    # create a list of dummy columns
    dummy_columns = df_dummies.columns.tolist()
    return scoring_df, dummy_columns
