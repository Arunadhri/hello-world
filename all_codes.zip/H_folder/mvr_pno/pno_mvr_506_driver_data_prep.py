# #############################################################################
# -----------------------------------------------------------------------------
#                            Program Information
# -----------------------------------------------------------------------------
# Author                 : Sushant Kulkarni
# Creation Date          : 15MAY2019
# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
#                             Script Information
# -----------------------------------------------------------------------------
# Script Name            : pno_mvr_506_driver_data_prep.py
# Bitbucket Project/Repo : DnAAnalytics-US-PNC / US-PNC-PNC-PNO-MVR
# Brief Description      : Script for updating channels
# Data used              : N/A
# Input Files            : N/A
# Output Files           : N/A
# Notes / Assumptions    : This module will be initiated from pno_mvr_506_scoring.py
# -----------------------------------------------------------------------------
#                            Environment Information
# -----------------------------------------------------------------------------
# Python Version         : 3.6.3
# Anaconda Version       : 5.0.1
# Spark Version          : N/A
# Operating System       : Red Hat Linux 7.4
# -----------------------------------------------------------------------------
#
# ##############################################################################

import numpy as np
import pandas as pd


def assump_surcharge(x):
    if x == "WY":
        return 870
    elif x == "MI":
        return 1263
    elif x == "WI":
        return 925
    elif x == "IL":
        return 978
    elif x == "DC":
        return 1159
    elif x == "NJ":
        return 1352
    elif x == "AL":
        return 797
    elif x == "AR":
        return 1381
    elif x == "WA":
        return 1034
    elif x == "MD":
        return 567
    elif x == "CO":
        return 1024
    elif x == "IN":
        return 719
    elif x == "KY":
        return 767
    elif x == "NV":
        return 1383
    elif x == "NE":
        return 1382
    elif x == "HI":
        return 1159
    elif x == "MN":
        return 1644
    elif x == "MS":
        return 2132
    elif x == "TX":
        return 776
    elif x == "GA":
        return 1321
    elif x == "WV":
        return 324
    elif x == "FL":
        return 1940
    elif x == "IA":
        return 691
    elif x == "NM":
        return 891
    elif x == "MO":
        return 1108
    elif x == "VA":
        return 1192
    elif x == "CT":
        return 1055
    elif x == "SD":
        return 1463
    elif x == "TN":
        return 1030
    elif x == "KS":
        return 554
    elif x == "OK":
        return 1569
    elif x == "NY":
        return 1279
    elif x == "NH":
        return 1134
    elif x == "ID":
        return 717
    elif x == "RI":
        return 1636
    elif x == "OH":
        return 1379
    elif x == "AK":
        return 1159
    elif x == "UT":
        return 1061
    elif x == "AZ":
        return 1499
    elif x == "DE":
        return 1979
    elif x == "MT":
        return 2146
    elif x == "NC":
        return 693
    elif x == "OR":
        return 867
    elif x == "SC":
        return 1339
    elif x == "PA":
        return 1781
    elif x == "ND":
        return 1532
    elif x == "CA":
        return 846
    elif x == "LA":
        return 1007
    elif x == "ME":
        return 370
    elif x == "VT":
        return 1061
    else:
        return ""


def assump_mvr_cost(x):
    if x == "WY":
        return 2.895
    elif x == "MI":
        return 6.710
    elif x == "WI":
        return 5.535
    elif x == "IL":
        return 8.370
    elif x == "DC":
        return 13.000
    elif x == "NJ":
        return 8.860
    elif x == "AL":
        return 6.630
    elif x == "AR":
        return 6.515
    elif x == "WA":
        return 8.835
    elif x == "MD":
        return 8.760
    elif x == "CO":
        return 3.635
    elif x == "IN":
        return 6.325
    elif x == "KY":
        return 4.680
    elif x == "MA":
        return 6.720
    elif x == "NV":
        return 5.055
    elif x == "NE":
        return 2.530
    elif x == "HI":
        return 14.430
    elif x == "MN":
        return 3.265
    elif x == "MS":
        return 10.090
    elif x == "TX":
        return 4.855
    elif x == "GA":
        return 4.985
    elif x == "WV":
        return 6.280
    elif x == "FL":
        return 5.920
    elif x == "IA":
        return 6.095
    elif x == "NM":
        return 5.710
    elif x == "MO":
        return 0.680
    elif x == "VA":
        return 5.420
    elif x == "CT":
        return 14.110
    elif x == "SD":
        return 3.790
    elif x == "TN":
        return 4.275
    elif x == "KS":
        return 6.125
    elif x == "OK":
        return 18.190
    elif x == "NY":
        return 5.700
    elif x == "NH":
        return 8.820
    elif x == "ID":
        return 6.520
    elif x == "RI":
        return 12.320
    elif x == "OH":
        return 3.405
    elif x == "AK":
        return 4.410
    elif x == "UT":
        return 6.560
    elif x == "AZ":
        return 3.085
    elif x == "DE":
        return 10.395
    elif x == "MT":
        return 6.160
    elif x == "NC":
        return 5.510
    elif x == "OR":
        return 6.565
    elif x == "SC":
        return 6.800
    elif x == "PA":
        return 8.570
    elif x == "ND":
        return 2.580
    elif x == "CA":
        return 2.170
    elif x == "LA":
        return 5.270
    elif x == "ME":
        return 4.735
    elif x == "VT":
        return 13.190
    else:
        return None


def assump_close_ratio(row):
    if row["OriginatingSystemCd"] == "058":
        return 0.02
    elif row["OriginatingSystemCd"] == "080":
        return 0.05
    elif row["OriginatingSystemCd"] == "056":
        return 0.02
    elif (row["OriginatingSystemCd"] == "040") and (row["DISTRIBUTION_SEMCI"] == "IA_NONSEMCI"):
        return 0.08
    elif (row["OriginatingSystemCd"] == "040") and (row["DISTRIBUTION_SEMCI"] == "IB"):
        return 0.08
    elif (row["OriginatingSystemCd"] == "040") and (row["DISTRIBUTION_SEMCI"] == "PCS"):
        return 0.08
    elif (row["OriginatingSystemCd"] == "040") and (row["DISTRIBUTION_SEMCI"] == "IM"):
        return 0.08
    elif (row["OriginatingSystemCd"] == "040") and (row["DISTRIBUTION_SEMCI"] == "GRP"):
        return 0.20
    else:
        return 0.08


def assump_close_ratio_miss_activ(row):
    if row["OriginatingSystemCd"] == "058":
        return 0.04
    elif row["OriginatingSystemCd"] == "080":
        return 0.2
    elif row["OriginatingSystemCd"] == "056":
        return 0.04
    elif (row["OriginatingSystemCd"] == "040") and (row["DISTRIBUTION_SEMCI"] == "IA_NONSEMCI"):
        return 0.16
    elif (row["OriginatingSystemCd"] == "040") and (row["DISTRIBUTION_SEMCI"] == "IB"):
        return 0.16
    elif (row["OriginatingSystemCd"] == "040") and (row["DISTRIBUTION_SEMCI"] == "PCS"):
        return 0.16
    elif (row["OriginatingSystemCd"] == "040") and (row["DISTRIBUTION_SEMCI"] == "IM"):
        return 0.16
    elif (row["OriginatingSystemCd"] == "040") and (row["DISTRIBUTION_SEMCI"] == "GRP"):
        return 0.25
    else:
        return 0.16


def assump_cutoff_ran(row):
    state_list1 = ["MO", "CA", "NC", "MI"]
    state_list2 = ["CT", "IL"]
    state_list3 = ["NE", "OH", "ND", "SD", "CO", "SC", "VA", "GA", "MN", "TN", "WY"]
    state_list4 = ["MT", "AZ", "UT"]
    if row["ST"] in state_list1:
        return -0.01
    elif (row["ST"] == "NY") and (row["OriginatingSystemCd"] == "040"):
        return -0.01
    elif (row["OriginatingSystemCd"] == "040") and (row["ST"] in state_list2):
        return 0.06
    elif (row["OriginatingSystemCd"] == "040") and (row["ST"] in state_list3):
        return -0.01
    elif (row["OriginatingSystemCd"] == "040") and (row["ST"] == "MT" in state_list4) and (row["SOURCE"] == "RETAIL"):
        return -0.01
    elif (row["OriginatingSystemCd"] == "040"):
        return 0.03
    else:
        return 0.05


def assump_cutoff(df):
    df["RAN_NUM"] = np.random.uniform()
    df["Surcharge"] = df["ST"].apply(assump_surcharge)
    df["MVR_COST"] = df["ST"].apply(assump_mvr_cost)
    df["Close_Ratio"] = df.apply(assump_close_ratio, axis=1)
    df["Close_Ratio_Miss_Activ"] = df.apply(assump_close_ratio_miss_activ, axis=1)
    df["Cutoff1"] = df["OriginatingSystemCd"].apply(lambda x: -1.0 if (x == "056") | (x == "058") else 0)
    df["Cutoff2"] = df["OriginatingSystemCd"].apply(lambda x: -5.0 if (x == "056") | (x == "058") else 0)
    df["Cutoff_RAN"] = df.apply(assump_cutoff_ran, axis=1)
    df["RD_ORDER"] = df.apply(lambda row: "T" if row["RAN_NUM"] <= row["Cutoff_RAN"] else "F", axis=1)
    df["Driver_Ind1"] = df["BirthDt1"].apply(lambda x: "N" if pd.isnull(x) else "Y")
    df["Driver_Ind2"] = df["BirthDt2"].apply(lambda x: "N" if pd.isnull(x) else "Y")
    df["Driver_Ind3"] = df["BirthDt3"].apply(lambda x: "N" if pd.isnull(x) else "Y")
    df["Driver_Ind4"] = df["BirthDt4"].apply(lambda x: "N" if pd.isnull(x) else "Y")
    df["Driver_Ind5"] = df["BirthDt5"].apply(lambda x: "N" if pd.isnull(x) else "Y")
    df["Driver_Ind6"] = df["BirthDt6"].apply(lambda x: "N" if pd.isnull(x) else "Y")
    df["Driver_Ind7"] = df["BirthDt7"].apply(lambda x: "N" if pd.isnull(x) else "Y")
    return df
