#############################################################################
# ---------------------------------------------------------------------------
#                            Program Information
# ---------------------------------------------------------------------------
# Author                  : Prakash Ranjan
# Creation Date           : 29APR2019
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#                             Script Information
# ---------------------------------------------------------------------------
# Script Name             : std_dlcp_600_functions.py
# Bitbucket Project/Repo  : DnAAnalytics-US-Group / US-GRP-MO-STD-DLCP
# Brief Description       : Script containing helper functions for
#                           std_dlcp_600_scoring.py
# Data Used               : N/A
# Input Files             : N/A
# Output Files            : N/A
# Notes / Assumptions     : This file contains helper functions which are
#                           imported in std_dlcp_600_scoring.py
# ---------------------------------------------------------------------------
#                            Environment Information
# ---------------------------------------------------------------------------
# Python Version          : 3.6.3
# Anaconda Version        : 5.0.1
# Spark Version           : N/A
# Operating System        :Red Hat Enterprise Linux 7.4
# ---------------------------------------------------------------------------
#############################################################################


import pandas as pd
import numpy as np


def co_morbidity(row):
    if row == '':
        return 0
    else:
        return 1


def rtw_in_the_past(row):
    if row == '':
        return 0
    elif ((row - pd.to_datetime('today')).days) < 0:
        return 1
    else:
        return 0


def icd10to9_1(row):
    conditions = [row == 'A072', row == 'B2799', row == 'B2792',
                  row == 'B2791', row == 'B2790', row == 'B2789', row == 'B2782',
                  row == 'B2781', row == 'B2780', row == 'B2719', row == 'B2712',
                  row == 'B2711', row == 'B2710', row == 'B2709', row == 'B2702',
                  row == 'B2701', row == 'B2700', row == 'A074', row == 'A09', row == 'C55',
                  row == 'C61', row == 'C73', row == 'A218', row == 'A217', row == 'A239',
                  row == 'A305', row == 'A308', row == 'F329', row == 'A311', row == 'J0301',
                  row == 'J0300', row == 'J020', row == 'G35', row == 'A427', row == 'A4189',
                  row == 'A4181', row == 'A419', row == 'A488', row == 'A499', row == 'I609',
                  row == 'I608', row == 'I607', row == 'I606', row == 'I6052', row == 'I6051',
                  row == 'I6050', row == 'I604', row == 'I6032', row == 'I6031', row == 'I6030',
                  row == 'I6022', row == 'I6021', row == 'I6020', row == 'I6012',
                  row == 'I6011', row == 'I6010', row == 'I6002', row == 'I6001',
                  row == 'I6000', row == 'I619', row == 'I618', row == 'I616', row == 'I615',
                  row == 'I614', row == 'I613', row == 'I612', row == 'I611', row == 'I610',
                  row == 'J00', row == 'A8181', row == 'J029', row == 'J028', row == 'A811',
                  row == 'J0391', row == 'J0390', row == 'J0381', row == 'J0380', row == 'I673',
                  row == 'A812', row == 'J342', row == 'A870', row == 'J189', row == 'J188',
                  row == 'J40', row == 'A872', row == 'B029', row == 'B0089', row == 'B000',
                  row == 'K37', row == 'B004', row == 'B050', row == 'K614', row == 'K613',
                  row == 'K612', row == 'K611', row == 'K610', row == 'D563', row == 'B069',
                  row == 'N19', row == 'A831', row == 'O019', row == 'O011', row == 'O010',
                  row == 'A840', row == 'O80', row == 'A980', row == 'B262', row == 'B263',
                  row == 'B081', row == 'A752', row == 'A753', row == 'A771', row == 'A773',
                  row == 'A790', row == 'B509', row == 'B508', row == 'A047', row == 'B550',
                  row == 'A64', row == 'B998', row == 'B999', row == 'B89', row == 'C159',
                  row == 'C189', row == 'C20', row == 'C228', row == 'C227', row == 'C224',
                  row == 'C223', row == 'C222', row == 'C220', row == 'A1803', row == 'C259',
                  row == 'C3492', row == 'C3491', row == 'C3490', row == 'D039', row == 'C439',
                  row == 'C50019', row == 'C50012', row == 'C50011', row == 'A186',
                  row == 'C50119', row == 'C50112', row == 'C50111', row == 'C50419',
                  row == 'C50412', row == 'C50411', row == 'C50919', row == 'C50912',
                  row == 'C50911', row == 'C539', row == 'C549', row == 'C543', row == 'C542',
                  row == 'C541', row == 'C569', row == 'C562', row == 'C561', row == 'C679',
                  row == 'C649', row == 'C642', row == 'C641', row == 'A199', row == 'C719',
                  row == 'C800', row == 'C801', row == 'C459', row == 'D1739', row == 'D1730',
                  row == 'D1724', row == 'D1723', row == 'D1722', row == 'D1721',
                  row == 'D1720', row == 'D171', row == 'D250', row == 'D251', row == 'D259',
                  row == 'D0592', row == 'D0591', row == 'D0590', row == 'D0582',
                  row == 'D0581', row == 'D0580', row == 'D0512', row == 'D0511',
                  row == 'D0510', row == 'D0502', row == 'D0501', row == 'D0500',
                  row == 'D3912', row == 'D3911', row == 'D375', row == 'D374', row == 'D373',
                  row == 'D372', row == 'D371', row == 'D496', row == 'E079', row == 'M109',
                  row == 'D508', row == 'D501', row == 'D649', row == 'F341', row == 'R456',
                  row == 'R455', row == 'R452', row == 'F99', row == 'R457', row == 'F430',
                  row == 'F4321', row == 'F0781', row == 'G214', row == 'G20', row == 'G894',
                  row == 'G8929', row == 'G40301', row == 'G500', row == 'G510', row == 'G5602',
                  row == 'G5601', row == 'G5600', row == 'G5622', row == 'G5621',
                  row == 'G5620', row == 'G5762', row == 'G5761', row == 'G5760',
                  row == 'H3320', row == 'H269', row == 'H6692', row == 'H6691', row == 'H6690',
                  row == 'H8149', row == 'H8143', row == 'H8142', row == 'H8141', row == 'I10',
                  row == 'I25110', row == 'I200', row == 'B9561', row == 'A4901', row == 'I349',
                  row == 'I348', row == 'I342', row == 'I341', row == 'I340', row == 'I359',
                  row == 'I358', row == 'I352', row == 'I351', row == 'I350', row == 'I429',
                  row == 'I428', row == 'I425', row == 'I420', row == 'I492', row == 'I471',
                  row == 'I469', row == 'I468', row == 'I462', row == 'I509', row == 'I2510',
                  row == 'I52', row == 'I519', row == 'I67848', row == 'I67841', row == 'G459',
                  row == 'I671', row == 'I688', row == 'I680', row == 'I6789', row == 'G468',
                  row == 'G467', row == 'G466', row == 'G465', row == 'G464', row == 'G463',
                  row == 'I679', row == 'I739', row == 'I749', row == 'I8291', row == 'K649',
                  row == 'K648', row == 'K643', row == 'K642', row == 'K641', row == 'J0101',
                  row == 'J0100', row == 'J0190', row == 'J0181', row == 'J0180',
                  row == 'J0141', row == 'J0140', row == 'J0191', row == 'A8109',
                  row == 'A8100', row == 'J069', row == 'J209', row == 'J208', row == 'J207',
                  row == 'J206', row == 'J205', row == 'J204', row == 'J203', row == 'J202',
                  row == 'J201', row == 'J200', row == 'J329', row == 'J359', row == 'J120',
                  row == 'J1289', row == 'J123', row == 'J129', row == 'J1108', row == 'J1100',
                  row == 'J1000', row == 'J111', row == 'J1001', row == 'J09X9', row == 'J09X2',
                  row == 'J1189', row == 'J1183', row == 'J1182', row == 'J1181', row == 'J112',
                  row == 'J1089', row == 'J1083', row == 'J1082', row == 'J1081', row == 'J102',
                  row == 'J9819', row == 'J9811', row == 'K011', row == 'K010', row == 'K006',
                  row == 'K009', row == 'K089', row == 'K319', row == 'K352', row == 'K3589',
                  row == 'K3580', row == 'K389', row == 'K388', row == 'K383', row == 'K382',
                  row == 'K381', row == 'K420', row == 'K440', row == 'K460', row == 'K429',
                  row == 'K449', row == 'K469', row == 'K50019', row == 'K50018',
                  row == 'K50014', row == 'K50013', row == 'K50012', row == 'K50011',
                  row == 'K5000', row == 'K50919', row == 'K50918', row == 'K50911',
                  row == 'K5090', row == 'K529', row == 'K5289', row == 'K5660',
                  row == 'K50912', row == 'B0609', row == 'B0602', row == 'K589', row == 'K580',
                  row == 'K602', row == 'K601', row == 'K600', row == 'K605', row == 'K604',
                  row == 'K603', row == 'K625', row == 'K929', row == 'K639', row == 'K7469',
                  row == 'K7460', row == 'K740', row == 'K769', row == 'K810', row == 'K828',
                  row == 'K829', row == 'K859', row == 'K858', row == 'K853', row == 'K852',
                  row == 'K851', row == 'K850', row == 'K922', row == 'N179', row == 'N186',
                  row == 'N202', row == 'B0879', row == 'B0870', row == 'N201', row == 'B0871',
                  row == 'N29', row == 'N289', row == 'N329', row == 'N3289', row == 'N390',
                  row == 'N429', row == 'N61', row == 'N62', row == 'N800', row == 'N809',
                  row == 'N830', row == 'N8329', row == 'N8320', row == 'N858', row == 'N946',
                  row == 'N945', row == 'N944', row == 'N393', row == 'N920', row == 'N921',
                  row == 'N938', row == 'N925', row == 'N897', row == 'N939', row == 'N926',
                  row == 'N950', row == 'N949', row == 'O2692', row == 'O2691', row == 'L03329',
                  row == 'L03326', row == 'L03325', row == 'L03324', row == 'L03323',
                  row == 'L03322', row == 'L03321', row == 'L03319', row == 'L03316',
                  row == 'L03315', row == 'L03314', row == 'L03313', row == 'L03312',
                  row == 'L03311', row == 'L02219', row == 'L02216', row == 'L02215',
                  row == 'L02214', row == 'L02213', row == 'L02212', row == 'L02211',
                  row == 'L03327', row == 'L03317', row == 'L0231', row == 'L03126',
                  row == 'L03125', row == 'L03116', row == 'L03115', row == 'L02416',
                  row == 'L02415', row == 'L03129', row == 'L03119', row == 'L02619',
                  row == 'L02612', row == 'L02611', row == 'L983', row == 'L0391',
                  row == 'L0390', row == 'L0291', row == 'L0502', row == 'L0501',
                  row == 'L0592', row == 'L0591', row == 'L089', row == 'L729', row == 'L728',
                  row == 'L723', row == 'L722', row == 'L720', row == 'B1921', row == 'M329',
                  row == 'M328', row == 'M3219', row == 'M3215', row == 'M3214', row == 'M3213',
                  row == 'M3212', row == 'M3211', row == 'M3210', row == 'M320', row == 'M069',
                  row == 'M0689', row == 'M0688', row == 'M06879', row == 'M06872',
                  row == 'M06871', row == 'M06869', row == 'M06862', row == 'M06861',
                  row == 'M06859', row == 'M06852', row == 'M06851', row == 'M06849',
                  row == 'M06842', row == 'M06841', row == 'M06839', row == 'M06832',
                  row == 'M06831', row == 'M06829', row == 'M06822', row == 'M06821',
                  row == 'M06819', row == 'M06812', row == 'M06811', row == 'M0680',
                  row == 'M0639', row == 'M0638', row == 'M06379', row == 'M06372',
                  row == 'M06371', row == 'M06369', row == 'M06362', row == 'M06361',
                  row == 'M06359', row == 'M06352', row == 'M06351', row == 'M06349',
                  row == 'M06342', row == 'M06341', row == 'M06339', row == 'M06332',
                  row == 'M06331', row == 'M06329', row == 'M06322', row == 'M06321',
                  row == 'M06319', row == 'M06312', row == 'M06311', row == 'M0630',
                  row == 'M0629', row == 'M0628', row == 'M06279', row == 'M06272',
                  row == 'M06271', row == 'M06269', row == 'M06262', row == 'M06261',
                  row == 'M06259', row == 'M06252', row == 'M06251', row == 'M06249',
                  row == 'M06242', row == 'M06241', row == 'M06239', row == 'M06232',
                  row == 'M06231', row == 'M06229', row == 'M06222', row == 'M06221',
                  row == 'M06219', row == 'M06212', row == 'M06211', row == 'M0620',
                  row == 'M0609', row == 'M0608', row == 'M06079', row == 'M06072',
                  row == 'M06071', row == 'M06069', row == 'M06062', row == 'M06061',
                  row == 'M06059', row == 'M06052', row == 'M06051', row == 'M06049',
                  row == 'M06042', row == 'M06041', row == 'M06039', row == 'M06032',
                  row == 'M06031', row == 'M06029', row == 'M06022', row == 'M06021',
                  row == 'M06019', row == 'M06012', row == 'M06011', row == 'M0600',
                  row == 'M059', row == 'M0589', row == 'M05879', row == 'M05872',
                  row == 'M05871', row == 'M05869', row == 'M05862', row == 'M05861',
                  row == 'M05859', row == 'M05852', row == 'M05851', row == 'M05849',
                  row == 'M05842', row == 'M05841', row == 'M05839', row == 'M05832',
                  row == 'M05831', row == 'M05829', row == 'M05822', row == 'M05821',
                  row == 'M05819', row == 'M05812', row == 'M05811', row == 'M0580',
                  row == 'M0579', row == 'M05779', row == 'M05772', row == 'M05771',
                  row == 'M05769', row == 'M05762', row == 'M05761', row == 'M05759',
                  row == 'M05752', row == 'M05751', row == 'M05749', row == 'M05742',
                  row == 'M05741', row == 'M05739', row == 'M05732', row == 'M05731',
                  row == 'M05729', row == 'M05722', row == 'M05721', row == 'M05719',
                  row == 'M05712', row == 'M05711', row == 'M0570', row == 'M0559',
                  row == 'M05579', row == 'M05572', row == 'M05571', row == 'M05569',
                  row == 'M05562', row == 'M05561', row == 'M05559', row == 'M05552',
                  row == 'M05551', row == 'M05549', row == 'M05542', row == 'M05541',
                  row == 'M05539', row == 'M05532', row == 'M05531', row == 'M05529',
                  row == 'M05522', row == 'M05521', row == 'M05519', row == 'M05512',
                  row == 'M05511', row == 'M0550', row == 'M0549', row == 'M05479',
                  row == 'M05472', row == 'M05471', row == 'M05469', row == 'M05462',
                  row == 'M05461', row == 'M05459', row == 'M05452', row == 'M05451',
                  row == 'M05449', row == 'M05442', row == 'M05441', row == 'M05439',
                  row == 'M05432', row == 'M05431', row == 'M05429', row == 'M05422',
                  row == 'M05421', row == 'M05419', row == 'M05412', row == 'M05411',
                  row == 'M0540', row == 'M23329', row == 'M23322', row == 'M23321',
                  row == 'M23229', row == 'M23222', row == 'M23221', row == 'M23029',
                  row == 'M23022', row == 'M23021', row == 'M23339', row == 'M23332',
                  row == 'M23331', row == 'M23305', row == 'M23239', row == 'M23232',
                  row == 'M23231', row == 'M23205', row == 'M23204', row == 'M23203',
                  row == 'M23039', row == 'M23032', row == 'M23031', row == 'Q686',
                  row == 'M23309', row == 'M23307', row == 'M23306', row == 'M23209',
                  row == 'M23207', row == 'M23206', row == 'M23009', row == 'M23007',
                  row == 'M23006', row == 'M23005', row == 'M23004', row == 'M23003',
                  row == 'M23002', row == 'M23001', row == 'M23000', row == 'M2342',
                  row == 'M2341', row == 'M2340', row == 'M2242', row == 'M2241',
                  row == 'M2240', row == 'M2392', row == 'M2391', row == 'M2390',
                  row == 'M238X2', row == 'M2292', row == 'M2291', row == 'M2290',
                  row == 'M488X9', row == 'M488X8', row == 'M488X7', row == 'M488X6',
                  row == 'M488X5', row == 'M488X4', row == 'M488X3', row == 'M488X2',
                  row == 'M488X1', row == 'M459', row == 'M458', row == 'M457', row == 'M456',
                  row == 'M455', row == 'M454', row == 'M453', row == 'M452', row == 'M451',
                  row == 'M450', row == 'M081', row == 'M47893', row == 'M47892',
                  row == 'M47891', row == 'M47813', row == 'M47812', row == 'M47811',
                  row == 'M4723', row == 'M4722', row == 'M4721', row == 'M4713',
                  row == 'M4712', row == 'M4711', row == 'M47029', row == 'M47022',
                  row == 'M47021', row == 'M47019', row == 'M47016', row == 'M47015',
                  row == 'M47014', row == 'M47013', row == 'M47012', row == 'M47011',
                  row == 'M47898', row == 'M47897', row == 'M47896', row == 'M47818',
                  row == 'M47817', row == 'M47816', row == 'M4728', row == 'M4727',
                  row == 'M4726', row == 'M5023', row == 'M5022', row == 'M5021',
                  row == 'M5020', row == 'M5033', row == 'M5032', row == 'M5031',
                  row == 'M5030', row == 'M9971', row == 'M9970', row == 'M9961',
                  row == 'M9960', row == 'M9951', row == 'M9950', row == 'M9941',
                  row == 'M9940', row == 'M9931', row == 'M9930', row == 'M9921',
                  row == 'M9920', row == 'M4803', row == 'M4802', row == 'M4801', row == 'M542',
                  row == 'M5413', row == 'M5412', row == 'M5411', row == 'M5013',
                  row == 'M5012', row == 'M5011', row == 'M5010', row == 'M5402',
                  row == 'M5401', row == 'M5400', row == 'M546', row == 'M545', row == 'M5442',
                  row == 'M5441', row == 'M5440', row == 'M5432', row == 'M5431',
                  row == 'M5430', row == 'M5417', row == 'M5416', row == 'M5415',
                  row == 'M5414', row == 'M5117', row == 'M5116', row == 'M5115',
                  row == 'M5114', row == 'M549', row == 'M5489', row == 'M62830',
                  row == 'M5409', row == 'M5408', row == 'M5407', row == 'M5406',
                  row == 'M5405', row == 'M5404', row == 'M5403', row == 'M539', row == 'M5385',
                  row == 'M5384', row == 'M5380', row == 'M4326', row == 'M4325',
                  row == 'M4324', row == 'M4323', row == 'M4322', row == 'M4321',
                  row == 'M4320', row == 'M7502', row == 'M7501', row == 'M7500',
                  row == 'M7592', row == 'M7591', row == 'M7590', row == 'M7582',
                  row == 'M7581', row == 'M7542', row == 'M7541', row == 'M7540',
                  row == 'M7532', row == 'M7531', row == 'M7530', row == 'M25719',
                  row == 'M25712', row == 'M25711', row == 'M7722', row == 'M7721',
                  row == 'M7720', row == 'M7012', row == 'M7011', row == 'M7010',
                  row == 'M25749', row == 'M25742', row == 'M25741', row == 'M25739',
                  row == 'M25732', row == 'M25731', row == 'B2681', row == 'M797',
                  row == 'M791', row == 'M609', row == 'M6089', row == 'M6088', row == 'M60879',
                  row == 'M60872', row == 'M60871', row == 'M60869', row == 'M60862',
                  row == 'M60861', row == 'M60859', row == 'M60852', row == 'M60851',
                  row == 'M60849', row == 'M60842', row == 'M60841', row == 'M60839',
                  row == 'M60832', row == 'M60831', row == 'M60829', row == 'M60822',
                  row == 'M60821', row == 'M60819', row == 'M60812', row == 'M60811',
                  row == 'M6080', row == 'M792', row == 'M5418', row == 'M5410',
                  row == 'M79676', row == 'M79675', row == 'M79674', row == 'M79673',
                  row == 'M79672', row == 'M79671', row == 'M79669', row == 'M79662',
                  row == 'M79661', row == 'M79659', row == 'M79652', row == 'M79651',
                  row == 'M79645', row == 'M79644', row == 'M79642', row == 'M79641',
                  row == 'M79639', row == 'M79631', row == 'M79629', row == 'M79621',
                  row == 'M79609', row == 'M79606', row == 'M79605', row == 'M79604',
                  row == 'M79603', row == 'M79602', row == 'M79601', row == 'M2012',
                  row == 'M2011', row == 'M2010', row == 'M2022', row == 'M2021',
                  row == 'M2020', row == 'M2042', row == 'M2041', row == 'M2040',
                  row == 'M2062', row == 'M2061', row == 'M2060', row == 'M21869',
                  row == 'M21862', row == 'M21861', row == 'M9981', row == 'M953',
                  row == 'M4319', row == 'M4318', row == 'M4317', row == 'M4316',
                  row == 'M4315', row == 'M4314', row == 'M4313', row == 'M4312',
                  row == 'M4311', row == 'M4310', row == 'M4309', row == 'M4308',
                  row == 'M4307', row == 'M4306', row == 'M4305', row == 'M4304',
                  row == 'M4303', row == 'M4302', row == 'M4301', row == 'M4300',
                  row == 'M9903', row == 'R55', row == 'R42', row == 'Z753', row == 'Z750',
                  row == 'Z048', row == 'R209', row == 'R208', row == 'R203', row == 'R202',
                  row == 'R201', row == 'R200', row == 'R609', row == 'R601', row == 'R600',
                  row == 'R51', row == 'G441', row == 'R05', row == 'B349', row == 'A749',
                  row == 'R99', row == 'R69', row == 'B9710', row == 'S32059A',
                  row == 'S32058A', row == 'S32052A', row == 'S32051A', row == 'S32050A',
                  row == 'S32049A', row == 'S32048A', row == 'S32042A', row == 'S32041A',
                  row == 'S32040A', row == 'S32039A', row == 'S32038A', row == 'S32032A',
                  row == 'S32031A', row == 'S32030A', row == 'S32029A', row == 'S32028A',
                  row == 'S32022A', row == 'S32021A', row == 'S32020A', row == 'S32019A',
                  row == 'S32018A', row == 'S32012A', row == 'S32011A', row == 'S32010A',
                  row == 'S32008A', row == 'S32002A', row == 'S32001A', row == 'S32000B',
                  row == 'S32000A', row == 'S72009A', row == 'S72002A', row == 'S72001A',
                  row == 'S82099A', row == 'S82092A', row == 'S82091A', row == 'S82046A',
                  row == 'S82045A', row == 'S82044A', row == 'S82043A', row == 'S82042A',
                  row == 'S82041A', row == 'S82036A', row == 'S82035A', row == 'S82034A',
                  row == 'S82033A', row == 'S82032A', row == 'S82031A', row == 'S82026A',
                  row == 'S82025A', row == 'S82024A', row == 'S82023A', row == 'S82022A',
                  row == 'S82021A', row == 'S82016A', row == 'S82015A', row == 'S82014A',
                  row == 'S82013A', row == 'S82012A', row == 'S82011A', row == 'S82009A',
                  row == 'S82002A', row == 'S82001A', row == 'S82876A', row == 'S82875A',
                  row == 'S82874A', row == 'S82873A', row == 'S82872A', row == 'S82871A',
                  row == 'S8256XA', row == 'S8255XA', row == 'S8254XA', row == 'S8253XA',
                  row == 'S8252XA', row == 'S8251XA', row == 'A7740', row == 'S8266XA',
                  row == 'S8265XA', row == 'S8264XA', row == 'S8263XA', row == 'S8262XA',
                  row == 'S8261XA', row == 'S82846A', row == 'S82845A', row == 'S82844A',
                  row == 'S82843A', row == 'S82842A', row == 'S82841A', row == 'S82856A',
                  row == 'S82855A', row == 'S82854A', row == 'S82853A', row == 'S82852A',
                  row == 'S82851A', row == 'S89399A', row == 'S89392A', row == 'S89391A',
                  row == 'S89329A', row == 'S89322A', row == 'S89321A', row == 'S89319A',
                  row == 'S89312A', row == 'S89311A', row == 'S89309A', row == 'S89302A',
                  row == 'S89301A', row == 'S89199A', row == 'S89192A', row == 'S89191A',
                  row == 'S89149A', row == 'S89142A', row == 'S89141A', row == 'S89139A',
                  row == 'S89132A', row == 'S89131A', row == 'S89129A', row == 'S89122A',
                  row == 'S89121A', row == 'S89119A', row == 'S89112A', row == 'S89111A',
                  row == 'S89109A', row == 'S89102A', row == 'S89101A', row == 'S82899A',
                  row == 'S82892A', row == 'S82891A', row == 'S82399A', row == 'S82392A',
                  row == 'S82391A', row == 'S82309A', row == 'S82302A', row == 'S82301A',
                  row == 'S92066A', row == 'S92065A', row == 'S92064A', row == 'S92063A',
                  row == 'S92062A', row == 'S92061A', row == 'S92056A', row == 'S92055A',
                  row == 'S92054A', row == 'S92053A', row == 'S92052A', row == 'S92051A',
                  row == 'S92046A', row == 'S92045A', row == 'S92044A', row == 'S92043A',
                  row == 'S92042A', row == 'S92041A', row == 'S92036A', row == 'S92035A',
                  row == 'S92034A', row == 'S92033A', row == 'S92032A', row == 'S92031A',
                  row == 'S92026A', row == 'S92025A', row == 'S92024A', row == 'S92023A',
                  row == 'S92022A', row == 'S92021A', row == 'S92016A', row == 'S92015A',
                  row == 'S92014A', row == 'S92013A', row == 'S92012A', row == 'S92011A',
                  row == 'S92009A', row == 'S92002A', row == 'S92001A', row == 'S92919A',
                  row == 'S92912A', row == 'S92911A', row == 'S92599A', row == 'S92592A',
                  row == 'S92591A', row == 'S92536A', row == 'S92535A', row == 'S92534A',
                  row == 'S92533A', row == 'S92532A', row == 'S92531A', row == 'S92526A',
                  row == 'S92525A', row == 'S92524A', row == 'S92523A', row == 'S92522A',
                  row == 'S92521A', row == 'S92516A', row == 'S92515A', row == 'S92514A',
                  row == 'S92513A', row == 'S92512A', row == 'S92511A', row == 'S92506A',
                  row == 'S92505A', row == 'S92504A', row == 'S92503A', row == 'S92502A',
                  row == 'S92501A', row == 'S92499A', row == 'S92492A', row == 'S92491A',
                  row == 'S92426A', row == 'S92425A', row == 'S92424A', row == 'S92423A',
                  row == 'S92422A', row == 'S92421A', row == 'S92416A', row == 'S92415A',
                  row == 'S92414A', row == 'S92413A', row == 'S92412A', row == 'S92411A',
                  row == 'S92406A', row == 'S92405A', row == 'S92404A', row == 'S92403A',
                  row == 'S92402A', row == 'S92401A', row == 'S8292XA', row == 'S8291XA',
                  row == 'S8290XA', row == 'S83249A', row == 'S83242A', row == 'S83241A',
                  row == 'S83239A', row == 'S83232A', row == 'S83231A', row == 'S83229A',
                  row == 'S83222A', row == 'S83221A', row == 'S83219A', row == 'S83212A',
                  row == 'S83211A', row == 'S8331XA', row == 'S83289A', row == 'S83282A',
                  row == 'S83281A', row == 'S83279A', row == 'S83272A', row == 'S83271A',
                  row == 'S83269A', row == 'S83262A', row == 'S83261A', row == 'S83259A',
                  row == 'S83252A', row == 'S83251A', row == 'S8332XA', row == 'S8330XA',
                  row == 'S83209A', row == 'S83207A', row == 'S83206A', row == 'S83205A',
                  row == 'S83204A', row == 'S83203A', row == 'S83202A', row == 'S83201A',
                  row == 'S83200A', row == 'S43429A', row == 'S43422A', row == 'S43421A',
                  row == 'S43439A', row == 'S43432A', row == 'S43431A', row == 'S46819A',
                  row == 'S46812A', row == 'S46811A', row == 'S46319A', row == 'S46312A',
                  row == 'S46311A', row == 'S46219A', row == 'S46212A', row == 'S46211A',
                  row == 'S46119A', row == 'S46112A', row == 'S46111A', row == 'S46019A',
                  row == 'S46012A', row == 'S46011A', row == 'S4362XA', row == 'S4361XA',
                  row == 'S4360XA', row == 'S43499A', row == 'S43492A', row == 'S43491A',
                  row == 'S46919A', row == 'S46912A', row == 'S46911A', row == 'S4392XA',
                  row == 'S4391XA', row == 'S4390XA', row == 'S43409A', row == 'S43402A',
                  row == 'S43401A', row == 'S76819A', row == 'S76812A', row == 'S76811A',
                  row == 'S76319A', row == 'S76312A', row == 'S76311A', row == 'S76219A',
                  row == 'S76212A', row == 'S76211A', row == 'S76119A', row == 'S76112A',
                  row == 'S76111A', row == 'S76019A', row == 'S76012A', row == 'S76011A',
                  row == 'S73199A', row == 'S73192A', row == 'S73191A', row == 'S73129A',
                  row == 'S83429A', row == 'S83422A', row == 'S83421A', row == 'S83529A',
                  row == 'S83522A', row == 'S83521A', row == 'S83519A', row == 'S83512S',
                  row == 'S83512A', row == 'S83511A', row == 'S83509A', row == 'S83502A',
                  row == 'S83501A', row == 'S86819A', row == 'S86812A', row == 'S86811A',
                  row == 'S86319A', row == 'S86312A', row == 'S86311A', row == 'S86219A',
                  row == 'S86212A', row == 'S86211A', row == 'S86119A', row == 'S86112A',
                  row == 'S86111A', row == 'S838X9A', row == 'S838X2A', row == 'S838X1A',
                  row == 'S83409A', row == 'S83402A', row == 'S83401A', row == 'S86919A',
                  row == 'S86912A', row == 'S86911A', row == 'S8392XA', row == 'S8391XA',
                  row == 'S8390XA', row == 'S161XXA', row == 'S138XXA', row == 'S134XXA',
                  row == 'S238XXA', row == 'S233XXA', row == 'S335XXA', row == 'S239XXA',
                  row == 'S139XXA', row == 'S39013A', row == 'S39012A', row == 'S39011A',
                  row == 'S29019A', row == 'S29012A', row == 'S29011A', row == 'S039XXA',
                  row == 'S038XXA', row == 'S61459A', row == 'S61452A', row == 'S61451A',
                  row == 'S61439A', row == 'S61432A', row == 'S61431A', row == 'S61419A',
                  row == 'S61412A', row == 'S61411A', row == 'S61409A', row == 'S61402A',
                  row == 'S61401A', row == 'S61359A', row == 'S61358A', row == 'S61357A',
                  row == 'S61356A', row == 'S61355A', row == 'S61354A', row == 'S61353A',
                  row == 'S61352A', row == 'S61351A', row == 'S61350A', row == 'S61339A',
                  row == 'S61338A', row == 'S61337A', row == 'S61336A', row == 'S61335A',
                  row == 'S61334A', row == 'S61333A', row == 'S61332A', row == 'S61331A',
                  row == 'S61330A', row == 'S61319A', row == 'S61318A', row == 'S61317A',
                  row == 'S61316A', row == 'S61315A', row == 'S61314A', row == 'S61313A',
                  row == 'S61312A', row == 'S61311A', row == 'S61310A', row == 'S61309A',
                  row == 'S61308A', row == 'S61307A', row == 'S61306A', row == 'S61305A',
                  row == 'S61304A', row == 'S61303A', row == 'S61302A', row == 'S61301A',
                  row == 'S61300A', row == 'S61259A', row == 'S61258A', row == 'S61257A',
                  row == 'S61256A', row == 'S61255A', row == 'S61254A', row == 'S61253A',
                  row == 'S61252A', row == 'S61251A', row == 'S61250A', row == 'S61239A',
                  row == 'S61238A', row == 'S61237A', row == 'S61236A', row == 'S61235A',
                  row == 'S61234A', row == 'S61233A', row == 'S61232A', row == 'S61231A',
                  row == 'S61230A', row == 'S61219A', row == 'S61218A', row == 'S61217A',
                  row == 'S61216A', row == 'S61215A', row == 'S61214A', row == 'S61213A',
                  row == 'S61212A', row == 'S61211A', row == 'S61210A', row == 'S61209A',
                  row == 'S61208A', row == 'S61207A', row == 'S61206A', row == 'S61205A',
                  row == 'S61204A', row == 'S61203A', row == 'S61202A', row == 'S61201A',
                  row == 'S61200A', row == 'S61159A', row == 'S61152A', row == 'S61151A',
                  row == 'S61139A', row == 'S61132A', row == 'S61131A', row == 'S61119A',
                  row == 'S61112A', row == 'S61111A', row == 'S61109A', row == 'S61102A',
                  row == 'S61101A', row == 'S61059A', row == 'S61052A', row == 'S61051A',
                  row == 'S61039A', row == 'S61032A', row == 'S61031A', row == 'S61019A',
                  row == 'S61012A', row == 'S61011A', row == 'S61009A', row == 'S61002A',
                  row == 'S61001A', row == 'A6929', row == 'A6923', row == 'A6922',
                  row == 'A6921', row == 'A6920', row == 'S96919S', row == 'S96912S',
                  row == 'S96911S', row == 'S96819S', row == 'S96812S', row == 'S96811S',
                  row == 'S96219S', row == 'S96212S', row == 'S96211S', row == 'S96119S',
                  row == 'S96112S', row == 'S96111S', row == 'S96019S', row == 'S96012S',
                  row == 'S96011S', row == 'S96009S', row == 'S93699S', row == 'S93691S',
                  row == 'S93629S', row == 'S93622S', row == 'S93621S', row == 'S93619S',
                  row == 'S93612S', row == 'S93611S', row == 'S93609S', row == 'S93602S',
                  row == 'S93601S', row == 'S93529S', row == 'S93526S', row == 'S93525S',
                  row == 'S93524S', row == 'S93523S', row == 'S93522S', row == 'S93521S',
                  row == 'S93519S', row == 'S93516S', row == 'S93515S', row == 'S93514S',
                  row == 'S93513S', row == 'S93512S', row == 'S93511S', row == 'S93509S',
                  row == 'S93506S', row == 'S93505S', row == 'S93504S', row == 'S93503S',
                  row == 'S93502S', row == 'S93501S', row == 'S93499S', row == 'S93492S',
                  row == 'S93491S', row == 'S93439S', row == 'S93432S', row == 'S93431S',
                  row == 'S93429S', row == 'S93422S', row == 'S93421S', row == 'S93419S',
                  row == 'S93412S', row == 'S93411S', row == 'S93409S', row == 'S93402S',
                  row == 'S93401S', row == 'S86919S', row == 'S86912S', row == 'S86911S',
                  row == 'S86819S', row == 'S86812S', row == 'S86811S', row == 'S86319S',
                  row == 'S86312S', row == 'S86219S', row == 'S86212S', row == 'S86211S',
                  row == 'S86119S', row == 'S86112S', row == 'S86111S', row == 'S86019S',
                  row == 'S86012S', row == 'S86011S', row == 'S8392XS', row == 'S8391XS',
                  row == 'S8390XS', row == 'S838X9S', row == 'S838X2S', row == 'S838X1S',
                  row == 'S8362XS', row == 'S8361XS', row == 'S8360XS', row == 'S83529S',
                  row == 'S83522S', row == 'S83521S', row == 'S83519S', row == 'S83511S',
                  row == 'S83509S', row == 'S83502S', row == 'S83501S', row == 'S83429S',
                  row == 'S83422S', row == 'S83421S', row == 'S83419S', row == 'S83412S',
                  row == 'S83411S', row == 'S83409S', row == 'S83402S', row == 'S83401S',
                  row == 'S8332XS', row == 'S8331XS', row == 'S8330XS', row == 'S83289S',
                  row == 'S83282S', row == 'S83281S', row == 'S83279S', row == 'S83272S',
                  row == 'S83271S', row == 'S83269S', row == 'S83262S', row == 'S83261S',
                  row == 'S83259S', row == 'S83252S', row == 'S83251S', row == 'S83249S',
                  row == 'S83242S', row == 'S83241S', row == 'S83239S', row == 'S83232S',
                  row == 'S83231S', row == 'S83229S', row == 'S83222S', row == 'S83221S',
                  row == 'S83219S', row == 'S83212S', row == 'S83211S', row == 'S83209S',
                  row == 'S83207S', row == 'S83206S', row == 'S83205S', row == 'S83204S',
                  row == 'S83203S', row == 'S83202S', row == 'S83201S', row == 'S83200S',
                  row == 'S76919S', row == 'S76912S', row == 'S76911S', row == 'S76819S',
                  row == 'S76812S', row == 'S76811S', row == 'S76319S', row == 'S76312S',
                  row == 'S76311S', row == 'S76219S', row == 'S76212S', row == 'S76211S',
                  row == 'S76119S', row == 'S76112S', row == 'S76111S', row == 'S76019S',
                  row == 'S76012S', row == 'S76011S', row == 'S73129S', row == 'S73122S',
                  row == 'S73121S', row == 'S73119S', row == 'S73112S', row == 'S73111S',
                  row == 'S73109S', row == 'S73102S', row == 'S73101S', row == 'S73046S',
                  row == 'S66919S', row == 'S66912S', row == 'S66911S', row == 'S66819S',
                  row == 'S66812S', row == 'S66811S', row == 'S66519S', row == 'S66518S',
                  row == 'S66517S', row == 'S66516S', row == 'S66515S', row == 'S66514S',
                  row == 'S66513S', row == 'S66512S', row == 'S66511S', row == 'S66510S',
                  row == 'S66419S', row == 'S66412S', row == 'S66411S', row == 'S66319S',
                  row == 'S66318S', row == 'S66317S', row == 'S66316S', row == 'S66315S',
                  row == 'S66314S', row == 'S66313S', row == 'S66312S', row == 'S66311S',
                  row == 'S66310S', row == 'S66219S', row == 'S66212S', row == 'S66211S',
                  row == 'S66119S', row == 'S66118S', row == 'S66117S', row == 'S66116S',
                  row == 'S66115S', row == 'S66114S', row == 'S66113S', row == 'S66112S',
                  row == 'S66111S', row == 'S66110S', row == 'S66019S', row == 'S66012S',
                  row == 'S66011S', row == 'S6392XS', row == 'S6391XS', row == 'S6390XS',
                  row == 'S638X9S', row == 'S638X2S', row == 'S638X1S', row == 'S63699S',
                  row == 'S63698S', row == 'S63697S', row == 'S63696S', row == 'S63695S',
                  row == 'S63694S', row == 'S63693S', row == 'S63692S', row == 'S63691S',
                  row == 'S63690S', row == 'S63689S', row == 'S63682S', row == 'S63681S',
                  row == 'S63659S', row == 'S63658S', row == 'S63657S', row == 'S63656S',
                  row == 'S63655S', row == 'S63654S', row == 'S63653S', row == 'S63652S',
                  row == 'S63651S', row == 'S63650S', row == 'S63649S', row == 'S63642S',
                  row == 'S63641S', row == 'S63639S', row == 'S63638S', row == 'S63637S',
                  row == 'S63636S', row == 'S63635S', row == 'S63634S', row == 'S63633S',
                  row == 'S63632S', row == 'S63631S', row == 'S63630S', row == 'S63629S',
                  row == 'S63622S', row == 'S63621S', row == 'S63619S', row == 'S63618S',
                  row == 'S63617S', row == 'S63616S', row == 'S63615S', row == 'S63614S',
                  row == 'S63613S', row == 'S63612S', row == 'S63611S', row == 'S63610S',
                  row == 'S63609S', row == 'S63602S', row == 'S63601S', row == 'S63599S',
                  row == 'S63592S', row == 'S63591S', row == 'S63529S', row == 'S63522S',
                  row == 'S63521S', row == 'S63519S', row == 'S63512S', row == 'S63511S',
                  row == 'S63509S', row == 'S63502S', row == 'S63501S', row == 'S63499S',
                  row == 'S63498S', row == 'S63497S', row == 'S63496S', row == 'S63495S',
                  row == 'S63494S', row == 'S63493S', row == 'S63492S', row == 'S63491S',
                  row == 'S63490S', row == 'S63439S', row == 'S63438S', row == 'S63437S',
                  row == 'S63436S', row == 'S63435S', row == 'S63434S', row == 'S63433S',
                  row == 'S63432S', row == 'S63431S', row == 'S63430S', row == 'S63429S',
                  row == 'S63428S', row == 'S63427S', row == 'S63426S', row == 'S63425S',
                  row == 'S63424S', row == 'S63423S', row == 'S63422S', row == 'S63421S',
                  row == 'S63420S', row == 'S63419S', row == 'S63418S', row == 'S63417S',
                  row == 'S63416S', row == 'S63415S', row == 'S63414S', row == 'S63413S',
                  row == 'S63412S', row == 'S63411S', row == 'S63410S', row == 'S63409S',
                  row == 'S63408S', row == 'S63407S', row == 'S63406S', row == 'S63405S',
                  row == 'S63404S', row == 'S63403S', row == 'S63402S', row == 'S63401S',
                  row == 'S63400S', row == 'S63399S', row == 'S63392S', row == 'S63391S',
                  row == 'S63339S', row == 'S63332S', row == 'S63331S', row == 'S63329S',
                  row == 'S63322S', row == 'S63321S', row == 'S63319S', row == 'S63312S',
                  row == 'S63311S', row == 'S63309S', row == 'S63302S', row == 'S63301S',
                  row == 'S56919S', row == 'S56912S', row == 'S56911S', row == 'S56819S',
                  row == 'S56812S', row == 'S56811S', row == 'S56519S', row == 'S56512S',
                  row == 'S56511S', row == 'S56419S', row == 'S56418S', row == 'S56417S',
                  row == 'S56416S', row == 'S56415S', row == 'S56414S', row == 'S56413S',
                  row == 'S56412S', row == 'S56411S', row == 'S56319S', row == 'S56312S',
                  row == 'S56311S', row == 'S56219S', row == 'S56212S', row == 'S56211S',
                  row == 'S56119S', row == 'S56118S', row == 'S56117S', row == 'S56116S',
                  row == 'S56115S', row == 'S56114S', row == 'S56113S', row == 'S56112S',
                  row == 'S56111S', row == 'S56019S', row == 'S56012S', row == 'S56011S',
                  row == 'S53499S', row == 'S53492S', row == 'S53491S', row == 'S53449S',
                  row == 'S53442S', row == 'S53441S', row == 'S53439S', row == 'S53432S',
                  row == 'S53431S', row == 'S53429S', row == 'S53422S', row == 'S53421S',
                  row == 'S53419S', row == 'S53412S', row == 'S53411S', row == 'S53409S',
                  row == 'S53402S', row == 'S53401S', row == 'S5332XS', row == 'S5331XS',
                  row == 'S5330XS', row == 'S5322XS', row == 'S5321XS', row == 'S5320XS',
                  row == 'S46919S', row == 'S46912S', row == 'S46911S', row == 'S46819S',
                  row == 'S46812S', row == 'S46811S', row == 'S46319S', row == 'S46312S',
                  row == 'S46311S', row == 'S46219S', row == 'S46212S', row == 'S46211S',
                  row == 'S46119S', row == 'S46112S', row == 'S46111S', row == 'S46019S',
                  row == 'S46012S', row == 'S46011S', row == 'S4392XS', row == 'S4391XS',
                  row == 'S4390XS', row == 'S4382XS', row == 'S4381XS', row == 'S4380XS',
                  row == 'S4362XS', row == 'S4361XS', row == 'S4360XS', row == 'S4352XS',
                  row == 'S4351XS', row == 'S4350XS', row == 'S43499S', row == 'S43492S',
                  row == 'S43491S', row == 'S43439S', row == 'S43432S', row == 'S43431S',
                  row == 'S43429S', row == 'S43422S', row == 'S43421S', row == 'S43419S',
                  row == 'S43412S', row == 'S43411S', row == 'S43409S', row == 'S43402S',
                  row == 'S43401S', row == 'S39013S', row == 'S39012S', row == 'S39011S',
                  row == 'S339XXS', row == 'S338XXS', row == 'S336XXS', row == 'S335XXS',
                  row == 'S334XXS', row == 'S29019S', row == 'S29012S', row == 'S29011S',
                  row == 'S239XXS', row == 'S238XXS', row == 'S23429S', row == 'S23428S',
                  row == 'S23421S', row == 'S23420S', row == 'S2341XS', row == 'S233XXS',
                  row == 'S161XXS', row == 'S139XXS', row == 'S138XXS', row == 'S135XXS',
                  row == 'S134XXS', row == 'S0911XS', row == 'S039XXS', row == 'S038XXS',
                  row == 'S034XXS', row == 'S20219A', row == 'S20212A', row == 'S20211A',
                  row == 'S4992XA', row == 'S4991XA', row == 'S4990XA', row == 'S4982XA',
                  row == 'S4981XA', row == 'S4980XA', row == 'S46999A', row == 'S46992A',
                  row == 'S46991A', row == 'S46909A', row == 'S46902A', row == 'S46901A',
                  row == 'S46899A', row == 'S46892A', row == 'S46891A', row == 'S46809A',
                  row == 'S46802A', row == 'S46801A', row == 'S46399A', row == 'S46392A',
                  row == 'S46391A', row == 'S46309A', row == 'S46302A', row == 'S46301A',
                  row == 'S46299A', row == 'S46292A', row == 'S46291A', row == 'S46209A',
                  row == 'S46202A', row == 'S46201A', row == 'S46199A', row == 'S46192A',
                  row == 'S46191A', row == 'S46109A', row == 'S46102A', row == 'S46101A',
                  row == 'S46099A', row == 'S46092A', row == 'S46091A', row == 'S46009A',
                  row == 'S46002A', row == 'S46001A', row == 'S6981XA', row == 'S66999A',
                  row == 'S66992A', row == 'S66991A', row == 'S66909A', row == 'S66902A',
                  row == 'S66901A', row == 'S66899A', row == 'S66892A', row == 'S66891A',
                  row == 'S66809A', row == 'S66802A', row == 'S66801A', row == 'S66599A',
                  row == 'S66598A', row == 'S66597A', row == 'S66596A', row == 'S66595A',
                  row == 'S66594A', row == 'S66593A', row == 'S66592A', row == 'S66591A',
                  row == 'S66590A', row == 'S66509A', row == 'S66508A', row == 'S66507A',
                  row == 'S66506A', row == 'S66505A', row == 'S66504A', row == 'S66503A',
                  row == 'S66502A', row == 'S66501A', row == 'S66500A', row == 'S66499A',
                  row == 'S66492A', row == 'S66491A', row == 'S66409A', row == 'S66402A',
                  row == 'S66401A', row == 'S66399A', row == 'S66398A', row == 'S66397A',
                  row == 'S66396A', row == 'S66395A', row == 'S66394A', row == 'S66393A',
                  row == 'S66392A', row == 'S66391A', row == 'S66390A', row == 'S66309A',
                  row == 'S66308A', row == 'S66307A', row == 'S66306A', row == 'S66305A',
                  row == 'S66304A', row == 'S66303A', row == 'S66302A', row == 'S66301A',
                  row == 'S66300A', row == 'S66299A', row == 'S66292A', row == 'S66291A',
                  row == 'S66202A', row == 'S66201A', row == 'S66199A', row == 'S66198A',
                  row == 'S66197A', row == 'S66196A', row == 'S66195A', row == 'S66194A',
                  row == 'S66193A', row == 'S66192A', row == 'S66191A', row == 'S66190A',
                  row == 'S66109A', row == 'S66108A', row == 'S66107A', row == 'S66106A',
                  row == 'S66105A', row == 'S66104A', row == 'S66103A', row == 'S66102A',
                  row == 'S66101A', row == 'S66100A', row == 'S66099A', row == 'S66092A',
                  row == 'S66091A', row == 'S59919A', row == 'S59912A', row == 'S59911A',
                  row == 'S59909A', row == 'S59902A', row == 'S59901A', row == 'S59819A',
                  row == 'S59812A', row == 'S59811A', row == 'S59809A', row == 'S59802A',
                  row == 'S59801A', row == 'S56999A', row == 'S56992A', row == 'S56991A',
                  row == 'S56909A', row == 'S56902A', row == 'S56901A', row == 'S56899A',
                  row == 'S56892A', row == 'S56891A', row == 'S56809A', row == 'S56802A',
                  row == 'S56801A', row == 'S56599A', row == 'S56592A', row == 'S56591A',
                  row == 'S56509A', row == 'S56502A', row == 'S56501A', row == 'S56499A',
                  row == 'S56498A', row == 'S56497A', row == 'S56496A', row == 'S56495A',
                  row == 'S56494A', row == 'S56493A', row == 'S56492A', row == 'S56491A',
                  row == 'S56409A', row == 'S56408A', row == 'S56407A', row == 'S56406A',
                  row == 'S56405A', row == 'S56404A', row == 'S56403A', row == 'S56402A',
                  row == 'S56401A', row == 'S56399A', row == 'S56392A', row == 'S56391A',
                  row == 'S56309A', row == 'S56302A', row == 'S56301A', row == 'S56299A',
                  row == 'S56292A', row == 'S56291A', row == 'S56209A', row == 'S56202A',
                  row == 'S56201A', row == 'S56199A', row == 'S56198A', row == 'S56197A',
                  row == 'S56196A', row == 'S56195A', row == 'S56194A', row == 'S56193A',
                  row == 'S56192A', row == 'S56191A', row == 'S56109A', row == 'S56108A',
                  row == 'S56107A', row == 'S56106A', row == 'S56105A', row == 'S56104A',
                  row == 'S56103A', row == 'S56102A', row == 'S56101A', row == 'S56099A',
                  row == 'S56092A', row == 'S56091A', row == 'S56009A', row == 'S56002A',
                  row == 'S56001A', row == 'S66209A', row == 'S66009A', row == 'S66002A',
                  row == 'S66001A', row == 'S6992XA', row == 'S6991XA', row == 'S6990XA',
                  row == 'S6982XA', row == 'S6980XA', row == 'S79929A', row == 'S79922A',
                  row == 'S79921A', row == 'S79919A', row == 'S79912A', row == 'S79911A',
                  row == 'S79829A', row == 'S79822A', row == 'S79821A', row == 'S79819A',
                  row == 'S79812A', row == 'S79811A', row == 'S76999A', row == 'S76992A',
                  row == 'S76991A', row == 'S76909A', row == 'S76902A', row == 'S76901A',
                  row == 'S76899A', row == 'S76892A', row == 'S76891A', row == 'S76809A',
                  row == 'S76802A', row == 'S76801A', row == 'S76399A', row == 'S76392A',
                  row == 'S76391A', row == 'S76309A', row == 'S76302A', row == 'S76301A',
                  row == 'S76299A', row == 'S76292A', row == 'S76291A', row == 'S76209A',
                  row == 'S76202A', row == 'S76201A', row == 'S76199A', row == 'S76192A',
                  row == 'S76191A', row == 'S76109A', row == 'S76102A', row == 'S76101A',
                  row == 'S76099A', row == 'S76092A', row == 'S76091A', row == 'S76009A',
                  row == 'S76002A', row == 'S76001A', row == 'S99929A', row == 'S99922A',
                  row == 'S99921A', row == 'S99919A', row == 'S99912A', row == 'S99911A',
                  row == 'S99829A', row == 'S99822A', row == 'S99821A', row == 'S99819A',
                  row == 'S99812A', row == 'S99811A', row == 'S96999A', row == 'S96992A',
                  row == 'S96991A', row == 'S96909A', row == 'S96902A', row == 'S96901A',
                  row == 'S96899A', row == 'S96892A', row == 'S96891A', row == 'S96809A',
                  row == 'S96802A', row == 'S96801A', row == 'S96299A', row == 'S96292A',
                  row == 'S96291A', row == 'S96209A', row == 'S96202A', row == 'S96201A',
                  row == 'S96199A', row == 'S96192A', row == 'S96191A', row == 'S96109A',
                  row == 'S96102A', row == 'S96101A', row == 'S96099A', row == 'S96092A',
                  row == 'S96091A', row == 'S96002A', row == 'S96001A', row == 'S8992XA',
                  row == 'S8991XA', row == 'S8990XA', row == 'S8982XA', row == 'S8981XA',
                  row == 'S8980XA', row == 'S86999A', row == 'S86992A', row == 'S86991A',
                  row == 'S86909A', row == 'S86902A', row == 'S86901A', row == 'S86899A',
                  row == 'S86892A', row == 'S86891A', row == 'S86809A', row == 'S86802A',
                  row == 'S86801A', row == 'S86399A', row == 'S86392A', row == 'S86391A',
                  row == 'S86311S', row == 'S86309A', row == 'S86302A', row == 'S86301A',
                  row == 'S86299A', row == 'S86292A', row == 'S86291A', row == 'S86209A',
                  row == 'S86202A', row == 'S86201A', row == 'S86199A', row == 'S86192A',
                  row == 'S86191A', row == 'S86109A', row == 'S86102A', row == 'S86101A',
                  row == 'S86099A', row == 'S86092A', row == 'S86091A', row == 'S86009A',
                  row == 'S86002A', row == 'S86001A', row == 'T07', row == 'T1491',
                  row == 'T1490', row == 'T148', row == 'T473X6D', row == 'A563',
                  row == 'T889XXA', row == 'T888XXA', row == 'T887XXA', row == 'T884XXA',
                  row == 'T8181XA', row == 'C8599', row == 'C8590', row == 'C8589',
                  row == 'C8580', row == 'C8529', row == 'C8520', row == 'C8519',
                  row == 'C8510', row == 'C84Z9', row == 'C84Z0', row == 'C84A9',
                  row == 'C84A0', row == 'C8499', row == 'C8490', row == 'C8259',
                  row == 'C8250', row == 'C9000', row == 'E138', row == 'E098', row == 'E088',
                  row == 'E119', row == 'E1169', row == 'E1165', row == 'E11649',
                  row == 'E11638', row == 'E11630', row == 'E11628', row == 'E11622',
                  row == 'E11621', row == 'E11620', row == 'E11618', row == 'M1029',
                  row == 'M1028', row == 'M10279', row == 'M10272', row == 'M10271',
                  row == 'M10269', row == 'M10262', row == 'M10261', row == 'M10259',
                  row == 'M10252', row == 'M10251', row == 'M10249', row == 'M10242',
                  row == 'M10241', row == 'M10239', row == 'M10232', row == 'M10231',
                  row == 'M10229', row == 'M10222', row == 'M10221', row == 'M10219',
                  row == 'M10212', row == 'M10211', row == 'M1020', row == 'M1009',
                  row == 'M1008', row == 'M10079', row == 'M10072', row == 'M10071',
                  row == 'M10069', row == 'M10062', row == 'M10061', row == 'M10059',
                  row == 'M10052', row == 'M10051', row == 'M10049', row == 'M10042',
                  row == 'M10041', row == 'M10039', row == 'M10032', row == 'M10031',
                  row == 'M10029', row == 'M10022', row == 'M10021', row == 'M10019',
                  row == 'M10012', row == 'M10011', row == 'M1000', row == 'N200',
                  row == 'E669', row == 'E668', row == 'E661', row == 'E6609', row == 'E6601',
                  row == 'F320', row == 'F321', row == 'F322', row == 'F323', row == 'F339',
                  row == 'F3340', row == 'F330', row == 'F331', row == 'F332', row == 'F3189',
                  row == 'F3110', row == 'F310', row == 'F319', row == 'F328', row == 'F3181',
                  row == 'F419', row == 'F410', row == 'F411', row == 'F418', row == 'F413',
                  row == 'F6812', row == 'F6810', row == 'F1020', row == 'F1129',
                  row == 'F11251', row == 'F11250', row == 'F1124', row == 'F1123',
                  row == 'F11229', row == 'F11221', row == 'F11220', row == 'F1120',
                  row == 'F1920', row == 'F4322', row == 'F4323', row == 'F4312',
                  row == 'F4311', row == 'F4310', row == 'G4730', row == 'G8921',
                  row == 'G43009', row == 'G43909', row == 'H33009', row == 'H33003',
                  row == 'H33002', row == 'H33001', row == 'H33059', row == 'H33053',
                  row == 'H33052', row == 'H33051', row == 'H2513', row == 'H2512',
                  row == 'H2511', row == 'H2510', row == 'H109', row == 'H1033', row == 'H1032',
                  row == 'H1031', row == 'H1030', row == 'H1013', row == 'H81399',
                  row == 'H81393', row == 'H81392', row == 'H81391', row == 'H8113',
                  row == 'H8112', row == 'H8111', row == 'H8110', row == 'I110', row == 'I220',
                  row == 'I2102', row == 'I2101', row == 'I214', row == 'I213', row == 'I2699',
                  row == 'I4891', row == 'I482', row == 'I480', row == 'I5020', row == 'I513',
                  row == 'I238', row == 'I237', row == 'I236', row == 'I233', row == 'I230',
                  row == 'I639', row == 'I638', row == 'I63549', row == 'I63542',
                  row == 'I63541', row == 'I63539', row == 'I63532', row == 'I63531',
                  row == 'I63529', row == 'I63522', row == 'I63521', row == 'I63519',
                  row == 'I63512', row == 'I63511', row == 'I6350', row == 'I744',
                  row == 'I743', row == 'I82409', row == 'I82403', row == 'I82402',
                  row == 'I82401', row == 'J040', row == 'J3501', row == 'J101', row == 'J449',
                  row == 'J4550', row == 'J4540', row == 'J4530', row == 'J4520',
                  row == 'J4551', row == 'J4541', row == 'J4531', row == 'J4521',
                  row == 'J45998', row == 'J45909', row == 'J9692', row == 'J9691',
                  row == 'J9690', row == 'J9602', row == 'J9601', row == 'J9600', row == 'J984',
                  row == 'K029', row == 'K219', row == 'K4030', row == 'K4000', row == 'K4090',
                  row == 'K4091', row == 'K4020', row == 'K430', row == 'K432', row == 'K439',
                  row == 'K435', row == 'K5669', row == 'K51312', row == 'K5790',
                  row == 'K5730', row == 'K5792', row == 'K5780', row == 'K5732',
                  row == 'K5720', row == 'K629', row == 'K6289', row == 'K627', row == 'K8012',
                  row == 'K8000', row == 'K8018', row == 'K8010', row == 'K8080',
                  row == 'K8020', row == 'K819', row == 'K811', row == 'N539', row == 'N538',
                  row == 'N5312', row == 'N508', row == 'N503', row == 'N448', row == 'N442',
                  row == 'N441', row == 'N63', row == 'N8111', row == 'N8110', row == 'O039',
                  row == 'O6003', row == 'O6002', row == 'O99354', row == 'O99353',
                  row == 'O99352', row == 'O99351', row == 'O2993', row == 'O2992',
                  row == 'O2991', row == 'O298X3', row == 'O298X2', row == 'O298X1',
                  row == 'O2963', row == 'O2962', row == 'O2961', row == 'O295X3',
                  row == 'O295X2', row == 'O295X1', row == 'O2943', row == 'O2942',
                  row == 'O2941', row == 'O293X3', row == 'O293X2', row == 'O293X1',
                  row == 'O29293', row == 'O29292', row == 'O29291', row == 'O29213',
                  row == 'O29212', row == 'O29211', row == 'O29193', row == 'O29192',
                  row == 'O29191', row == 'O29123', row == 'O29122', row == 'O29121',
                  row == 'O29113', row == 'O29112']
    choices = ['74', '75', '75', '75', '75', '75', '75', '75', '75', '75',
               '75', '75', '75', '75', '75', '75', '75', '75', '90', '179', '185', '193',
               '218', '218', '239', '300', '308', '311', '311', '340', '340', '340', '340',
               '388', '388', '388', '389', '401', '419', '430', '430', '430', '430', '430',
               '430', '430', '430', '430', '430', '430', '430', '430', '430', '430', '430',
               '430', '430', '430', '430', '431', '431', '431', '431', '431', '431', '431',
               '431', '431', '460', '460', '462', '462', '462', '463', '463', '463', '463',
               '463', '463', '470', '470', '486', '486', '490', '490', '539', '539', '540',
               '541', '543', '550', '566', '566', '566', '566', '566', '566', '569', '586',
               '621', '630', '630', '630', '630', '650', '650', '722', '723', '780', '810',
               '812', '821', '823', '831', '840', '840', '845', '850', '999', '1368', '1369',
               '1369', '1509', '1539', '1541', '1550', '1550', '1550', '1550', '1550',
               '1550', '1550', '1579', '1629', '1629', '1629', '1729', '1729', '1740',
               '1740', '1740', '1740', '1741', '1741', '1741', '1744', '1744', '1744',
               '1749', '1749', '1749', '1809', '1820', '1820', '1820', '1820', '1830',
               '1830', '1830', '1889', '1890', '1890', '1890', '1890', '1919', '1990',
               '1991', '1991', '2141', '2141', '2141', '2141', '2141', '2141', '2141',
               '2141', '2180', '2181', '2189', '2330', '2330', '2330', '2330', '2330',
               '2330', '2330', '2330', '2330', '2330', '2330', '2330', '2352', '2352',
               '2352', '2352', '2352', '2352', '2352', '2396', '2469', '2749', '2808',
               '2808', '2826', '3004', '3009', '3009', '3009', '3009', '3089', '3089',
               '3090', '3102', '3320', '3320', '3384', '3384', '3453', '3501', '3510',
               '3540', '3540', '3540', '3542', '3542', '3542', '3556', '3556', '3556',
               '3619', '3669', '3829', '3829', '3829', '3862', '3862', '3862', '3862',
               '4019', '4111', '4111', '4111', '4111', '4240', '4240', '4240', '4240',
               '4240', '4241', '4241', '4241', '4241', '4241', '4254', '4254', '4254',
               '4254', '4270', '4270', '4275', '4275', '4275', '4289', '4292', '4299',
               '4299', '4359', '4359', '4359', '4373', '4378', '4378', '4378', '4378',
               '4378', '4378', '4378', '4378', '4378', '4379', '4439', '4449', '4539',
               '4558', '4558', '4558', '4558', '4558', '4610', '4610', '4618', '4618',
               '4618', '4618', '4618', '4619', '4619', '4619', '4659', '4660', '4660',
               '4660', '4660', '4660', '4660', '4660', '4660', '4660', '4660', '4739',
               '4749', '4800', '4808', '4808', '4870', '4870', '4870', '4870', '4871',
               '4871', '4871', '4871', '4878', '4878', '4878', '4878', '4878', '4878',
               '4878', '4878', '4878', '4878', '5180', '5180', '5206', '5206', '5206',
               '5209', '5259', '5379', '5400', '5409', '5409', '5439', '5439', '5439',
               '5439', '5439', '5521', '5523', '5529', '5531', '5533', '5539', '5550',
               '5550', '5550', '5550', '5550', '5550', '5550', '5559', '5559', '5559',
               '5559', '5589', '5589', '5609', '5609', '5609', '5609', '5641', '5641',
               '5650', '5650', '5650', '5651', '5651', '5651', '5693', '5699', '5699',
               '5715', '5715', '5715', '5739', '5750', '5758', '5759', '5770', '5770',
               '5770', '5770', '5770', '5770', '5789', '5849', '5856', '5920', '5920',
               '5920', '5921', '5921', '5939', '5939', '5969', '5969', '5990', '6029',
               '6110', '6111', '6170', '6179', '6200', '6202', '6202', '6218', '6253',
               '6253', '6253', '6256', '6262', '6266', '6268', '6268', '6268', '6269',
               '6269', '6271', '6299', '6469', '6469', '6822', '6822', '6822', '6822',
               '6822', '6822', '6822', '6822', '6822', '6822', '6822', '6822', '6822',
               '6822', '6822', '6822', '6822', '6822', '6822', '6822', '6822', '6825',
               '6825', '6825', '6826', '6826', '6826', '6826', '6826', '6826', '6827',
               '6827', '6827', '6827', '6827', '6829', '6829', '6829', '6829', '6850',
               '6850', '6851', '6851', '6869', '7062', '7062', '7062', '7062', '7062',
               '7071', '7100', '7100', '7100', '7100', '7100', '7100', '7100', '7100',
               '7100', '7100', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140', '7140',
               '7140', '7140', '7140', '7172', '7172', '7172', '7172', '7172', '7172',
               '7172', '7172', '7172', '7173', '7173', '7173', '7173', '7173', '7173',
               '7173', '7173', '7173', '7173', '7173', '7173', '7173', '7175', '7175',
               '7175', '7175', '7175', '7175', '7175', '7175', '7175', '7175', '7175',
               '7175', '7175', '7175', '7175', '7175', '7176', '7176', '7176', '7177',
               '7177', '7177', '7179', '7179', '7179', '7179', '7179', '7179', '7179',
               '7200', '7200', '7200', '7200', '7200', '7200', '7200', '7200', '7200',
               '7200', '7200', '7200', '7200', '7200', '7200', '7200', '7200', '7200',
               '7200', '7200', '7210', '7210', '7210', '7210', '7210', '7210', '7210',
               '7210', '7210', '7211', '7211', '7211', '7211', '7211', '7211', '7211',
               '7211', '7211', '7211', '7211', '7211', '7211', '7213', '7213', '7213',
               '7213', '7213', '7213', '7213', '7213', '7213', '7220', '7220', '7220',
               '7220', '7224', '7224', '7224', '7224', '7230', '7230', '7230', '7230',
               '7230', '7230', '7230', '7230', '7230', '7230', '7230', '7230', '7230',
               '7230', '7230', '7231', '7234', '7234', '7234', '7234', '7234', '7234',
               '7234', '7236', '7236', '7236', '7241', '7242', '7242', '7243', '7243',
               '7243', '7243', '7243', '7244', '7244', '7244', '7244', '7244', '7244',
               '7244', '7244', '7245', '7245', '7248', '7248', '7248', '7248', '7248',
               '7248', '7248', '7248', '7249', '7249', '7249', '7249', '7249', '7249',
               '7249', '7249', '7249', '7249', '7249', '7260', '7260', '7260', '7262',
               '7262', '7262', '7262', '7262', '7262', '7262', '7262', '7262', '7262',
               '7262', '7262', '7262', '7262', '7264', '7264', '7264', '7264', '7264',
               '7264', '7264', '7264', '7264', '7264', '7264', '7264', '7271', '7291',
               '7291', '7291', '7291', '7291', '7291', '7291', '7291', '7291', '7291',
               '7291', '7291', '7291', '7291', '7291', '7291', '7291', '7291', '7291',
               '7291', '7291', '7291', '7291', '7291', '7291', '7291', '7291', '7292',
               '7292', '7292', '7295', '7295', '7295', '7295', '7295', '7295', '7295',
               '7295', '7295', '7295', '7295', '7295', '7295', '7295', '7295', '7295',
               '7295', '7295', '7295', '7295', '7295', '7295', '7295', '7295', '7295',
               '7295', '7295', '7350', '7350', '7350', '7352', '7352', '7352', '7354',
               '7354', '7354', '7359', '7359', '7359', '7366', '7366', '7366', '7382',
               '7382', '7384', '7384', '7384', '7384', '7384', '7384', '7384', '7384',
               '7384', '7384', '7384', '7384', '7384', '7384', '7384', '7384', '7384',
               '7384', '7384', '7384', '7393', '7802', '7804', '7809', '7809', '7809',
               '7820', '7820', '7820', '7820', '7820', '7820', '7823', '7823', '7823',
               '7840', '7840', '7862', '7908', '7998', '7999', '7999', '7999', '8054',
               '8054', '8054', '8054', '8054', '8054', '8054', '8054', '8054', '8054',
               '8054', '8054', '8054', '8054', '8054', '8054', '8054', '8054', '8054',
               '8054', '8054', '8054', '8054', '8054', '8054', '8054', '8054', '8054',
               '8054', '8054', '8208', '8208', '8208', '8220', '8220', '8220', '8220',
               '8220', '8220', '8220', '8220', '8220', '8220', '8220', '8220', '8220',
               '8220', '8220', '8220', '8220', '8220', '8220', '8220', '8220', '8220',
               '8220', '8220', '8220', '8220', '8220', '8220', '8220', '8220', '8240',
               '8240', '8240', '8240', '8240', '8240', '8240', '8240', '8240', '8240',
               '8240', '8240', '8240', '8242', '8242', '8242', '8242', '8242', '8242',
               '8244', '8244', '8244', '8244', '8244', '8244', '8246', '8246', '8246',
               '8246', '8246', '8246', '8248', '8248', '8248', '8248', '8248', '8248',
               '8248', '8248', '8248', '8248', '8248', '8248', '8248', '8248', '8248',
               '8248', '8248', '8248', '8248', '8248', '8248', '8248', '8248', '8248',
               '8248', '8248', '8248', '8248', '8248', '8248', '8248', '8248', '8248',
               '8248', '8248', '8248', '8248', '8248', '8248', '8250', '8250', '8250',
               '8250', '8250', '8250', '8250', '8250', '8250', '8250', '8250', '8250',
               '8250', '8250', '8250', '8250', '8250', '8250', '8250', '8250', '8250',
               '8250', '8250', '8250', '8250', '8250', '8250', '8250', '8250', '8250',
               '8250', '8250', '8250', '8250', '8250', '8250', '8250', '8250', '8250',
               '8260', '8260', '8260', '8260', '8260', '8260', '8260', '8260', '8260',
               '8260', '8260', '8260', '8260', '8260', '8260', '8260', '8260', '8260',
               '8260', '8260', '8260', '8260', '8260', '8260', '8260', '8260', '8260',
               '8260', '8260', '8260', '8260', '8260', '8260', '8260', '8260', '8260',
               '8260', '8260', '8260', '8260', '8260', '8260', '8260', '8260', '8260',
               '8260', '8260', '8260', '8260', '8260', '8260', '8270', '8270', '8270',
               '8360', '8360', '8360', '8360', '8360', '8360', '8360', '8360', '8360',
               '8360', '8360', '8360', '8361', '8361', '8361', '8361', '8361', '8361',
               '8361', '8361', '8361', '8361', '8361', '8361', '8361', '8362', '8362',
               '8362', '8362', '8362', '8362', '8362', '8362', '8362', '8362', '8362',
               '8404', '8404', '8404', '8407', '8407', '8407', '8408', '8408', '8408',
               '8408', '8408', '8408', '8408', '8408', '8408', '8408', '8408', '8408',
               '8408', '8408', '8408', '8408', '8408', '8408', '8408', '8408', '8408',
               '8409', '8409', '8409', '8409', '8409', '8409', '8409', '8409', '8409',
               '8438', '8438', '8438', '8438', '8438', '8438', '8438', '8438', '8438',
               '8438', '8438', '8438', '8438', '8438', '8438', '8438', '8438', '8438',
               '8438', '8440', '8440', '8440', '8442', '8442', '8442', '8442', '8442',
               '8442', '8442', '8442', '8442', '8442', '8448', '8448', '8448', '8448',
               '8448', '8448', '8448', '8448', '8448', '8448', '8448', '8448', '8448',
               '8448', '8448', '8448', '8448', '8448', '8449', '8449', '8449', '8449',
               '8449', '8449', '8470', '8470', '8470', '8471', '8471', '8472', '8479',
               '8479', '8488', '8488', '8488', '8488', '8488', '8488', '8488', '8488',
               '8820', '8820', '8820', '8820', '8820', '8820', '8820', '8820', '8820',
               '8820', '8820', '8820', '8830', '8830', '8830', '8830', '8830', '8830',
               '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830',
               '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830',
               '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830',
               '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830',
               '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830',
               '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830',
               '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830',
               '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830',
               '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830',
               '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830',
               '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8830', '8881',
               '8881', '8881', '8881', '8881', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057', '9057',
               '9057', '9221', '9221', '9221', '9592', '9592', '9592', '9592', '9592',
               '9592', '9592', '9592', '9592', '9592', '9592', '9592', '9592', '9592',
               '9592', '9592', '9592', '9592', '9592', '9592', '9592', '9592', '9592',
               '9592', '9592', '9592', '9592', '9592', '9592', '9592', '9592', '9592',
               '9592', '9592', '9592', '9592', '9592', '9592', '9592', '9592', '9592',
               '9592', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593', '9593',
               '9593', '9594', '9594', '9594', '9594', '9595', '9595', '9595', '9595',
               '9595', '9596', '9596', '9596', '9596', '9596', '9596', '9596', '9596',
               '9596', '9596', '9596', '9596', '9596', '9596', '9596', '9596', '9596',
               '9596', '9596', '9596', '9596', '9596', '9596', '9596', '9596', '9596',
               '9596', '9596', '9596', '9596', '9596', '9596', '9596', '9596', '9596',
               '9596', '9596', '9596', '9596', '9596', '9596', '9596', '9596', '9596',
               '9596', '9596', '9596', '9596', '9597', '9597', '9597', '9597', '9597',
               '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597',
               '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597',
               '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597',
               '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597',
               '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597',
               '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597',
               '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597',
               '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9597',
               '9597', '9597', '9597', '9597', '9597', '9597', '9597', '9598', '9599',
               '9599', '9599', '9952', '9952', '9999', '9999', '9999', '9999', '9999',
               '20280', '20280', '20280', '20280', '20280', '20280', '20280', '20280',
               '20280', '20280', '20280', '20280', '20280', '20280', '20280', '20280',
               '20300', '24990', '24990', '24990', '25000', '25000', '25080', '25080',
               '25080', '25080', '25080', '25080', '25080', '25080', '25080', '27401',
               '27401', '27401', '27401', '27401', '27401', '27401', '27401', '27401',
               '27401', '27401', '27401', '27401', '27401', '27401', '27401', '27401',
               '27401', '27401', '27401', '27401', '27401', '27401', '27401', '27401',
               '27401', '27401', '27401', '27401', '27401', '27401', '27401', '27401',
               '27401', '27401', '27401', '27401', '27401', '27401', '27401', '27401',
               '27401', '27401', '27401', '27401', '27401', '27401', '27401', '27411',
               '27800', '27800', '27800', '27800', '27801', '29621', '29622', '29623',
               '29624', '29630', '29630', '29631', '29632', '29633', '29640', '29640',
               '29640', '29680', '29682', '29689', '30000', '30001', '30002', '30009',
               '30009', '30151', '30151', '30392', '30400', '30400', '30400', '30400',
               '30400', '30400', '30400', '30400', '30402', '30462', '30924', '30928',
               '30981', '30981', '30981', '32720', '33821', '34610', '34690', '36100',
               '36100', '36100', '36100', '36107', '36107', '36107', '36107', '36616',
               '36616', '36616', '36616', '37200', '37200', '37200', '37200', '37200',
               '37200', '38610', '38610', '38610', '38610', '38611', '38611', '38611',
               '38611', '40291', '41011', '41011', '41011', '41072', '41092', '41519',
               '42731', '42731', '42731', '42820', '42979', '42979', '42979', '42979',
               '42979', '42979', '43491', '43491', '43491', '43491', '43491', '43491',
               '43491', '43491', '43491', '43491', '43491', '43491', '43491', '43491',
               '43491', '44422', '44422', '45340', '45340', '45340', '45340', '46400',
               '47400', '48812', '49120', '49310', '49310', '49310', '49310', '49312',
               '49312', '49312', '49312', '49390', '49390', '51881', '51881', '51881',
               '51881', '51881', '51881', '51889', '52100', '53081', '55010', '55012',
               '55090', '55091', '55092', '55221', '55321', '55329', '55329', '56089',
               '56089', '56210', '56210', '56211', '56211', '56211', '56211', '56949',
               '56949', '56949', '57400', '57400', '57410', '57410', '57420', '57420',
               '57510', '57511', '60889', '60889', '60889', '60889', '60889', '60889',
               '60889', '60889', '61172', '61801', '61801', '63492', '64403', '64403',
               '64681', '64681', '64681', '64681', '64681', '64681', '64681', '64681',
               '64681', '64681', '64681', '64681', '64681', '64681', '64681', '64681',
               '64681', '64681', '64681', '64681', '64681', '64681', '64681', '64681',
               '64681', '64681', '64681', '64681', '64681', '64681', '64681', '64681',
               '64681', '64681', '64681', '64681']
    default_cond = 'Derive_2'
    return np.select(conditions, choices, default=default_cond)


def icd10to9_2(PRI_ICD_CD, ICD10to9_1):
    conditions = [ICD10to9_1 != 'Derive_2', PRI_ICD_CD == 'O29111',
                  PRI_ICD_CD == 'O29093', PRI_ICD_CD == 'O29092', PRI_ICD_CD == 'O29091',
                  PRI_ICD_CD == 'O29023', PRI_ICD_CD == 'O29022', PRI_ICD_CD == 'O29021',
                  PRI_ICD_CD == 'O29013', PRI_ICD_CD == 'O29012', PRI_ICD_CD == 'O29011',
                  PRI_ICD_CD == 'O2693', PRI_ICD_CD == 'O2686', PRI_ICD_CD == 'O2672',
                  PRI_ICD_CD == 'O26713', PRI_ICD_CD == 'O26712', PRI_ICD_CD == 'O26711',
                  PRI_ICD_CD == 'O2633', PRI_ICD_CD == 'O2632', PRI_ICD_CD == 'O2631',
                  PRI_ICD_CD == 'O26813', PRI_ICD_CD == 'O26812', PRI_ICD_CD == 'O26811',
                  PRI_ICD_CD == 'O2643', PRI_ICD_CD == 'O2642', PRI_ICD_CD == 'O2641',
                  PRI_ICD_CD == 'O2613', PRI_ICD_CD == 'O2612', PRI_ICD_CD == 'O2611',
                  PRI_ICD_CD == 'O2690', PRI_ICD_CD == 'O9989', PRI_ICD_CD == 'O99810',
                  PRI_ICD_CD == 'O24419', PRI_ICD_CD == 'O30003', PRI_ICD_CD == 'O30002',
                  PRI_ICD_CD == 'O30001', PRI_ICD_CD == 'O3421', PRI_ICD_CD == 'O82',
                  PRI_ICD_CD == 'O26893', PRI_ICD_CD == 'O26892', PRI_ICD_CD == 'O26891',
                  PRI_ICD_CD == 'L732', PRI_ICD_CD == 'M150', PRI_ICD_CD == 'M19019',
                  PRI_ICD_CD == 'M19012', PRI_ICD_CD == 'M19011', PRI_ICD_CD == 'M19049',
                  PRI_ICD_CD == 'M19042', PRI_ICD_CD == 'M19041', PRI_ICD_CD == 'M1812',
                  PRI_ICD_CD == 'M1811', PRI_ICD_CD == 'M1810', PRI_ICD_CD == 'M180',
                  PRI_ICD_CD == 'M1612', PRI_ICD_CD == 'M1611', PRI_ICD_CD == 'M1610',
                  PRI_ICD_CD == 'M160', PRI_ICD_CD == 'M1712', PRI_ICD_CD == 'M1711',
                  PRI_ICD_CD == 'M1710', PRI_ICD_CD == 'M170', PRI_ICD_CD == 'M19079',
                  PRI_ICD_CD == 'M19072', PRI_ICD_CD == 'M19071', PRI_ICD_CD == 'M1990',
                  PRI_ICD_CD == 'M159', PRI_ICD_CD == 'M169', PRI_ICD_CD == 'M179',
                  PRI_ICD_CD == 'M23302', PRI_ICD_CD == 'M23301', PRI_ICD_CD == 'M23300',
                  PRI_ICD_CD == 'M23269', PRI_ICD_CD == 'M23262', PRI_ICD_CD == 'M23261',
                  PRI_ICD_CD == 'M23202', PRI_ICD_CD == 'M23201', PRI_ICD_CD == 'M23200',
                  PRI_ICD_CD == 'M238X9', PRI_ICD_CD == 'M238X1', PRI_ICD_CD == 'M23679',
                  PRI_ICD_CD == 'M23672', PRI_ICD_CD == 'M23671', PRI_ICD_CD == 'M23649',
                  PRI_ICD_CD == 'M23642', PRI_ICD_CD == 'M23641', PRI_ICD_CD == 'M23639',
                  PRI_ICD_CD == 'M23632', PRI_ICD_CD == 'M23631', PRI_ICD_CD == 'M23629',
                  PRI_ICD_CD == 'M23622', PRI_ICD_CD == 'M23621', PRI_ICD_CD == 'M23619',
                  PRI_ICD_CD == 'M23612', PRI_ICD_CD == 'M23611', PRI_ICD_CD == 'M23609',
                  PRI_ICD_CD == 'M23602', PRI_ICD_CD == 'M23601', PRI_ICD_CD == 'M228X9',
                  PRI_ICD_CD == 'M228X2', PRI_ICD_CD == 'M228X1', PRI_ICD_CD == 'M223X9',
                  PRI_ICD_CD == 'M223X2', PRI_ICD_CD == 'M223X1', PRI_ICD_CD == 'M222X9',
                  PRI_ICD_CD == 'M222X2', PRI_ICD_CD == 'M222X1', PRI_ICD_CD == 'M25319',
                  PRI_ICD_CD == 'M25312', PRI_ICD_CD == 'M25311', PRI_ICD_CD == 'M25219',
                  PRI_ICD_CD == 'M25212', PRI_ICD_CD == 'M25211', PRI_ICD_CD == 'M24819',
                  PRI_ICD_CD == 'M24812', PRI_ICD_CD == 'M24811', PRI_ICD_CD == 'M25339',
                  PRI_ICD_CD == 'M25332', PRI_ICD_CD == 'M25331', PRI_ICD_CD == 'M25239',
                  PRI_ICD_CD == 'M25232', PRI_ICD_CD == 'M25231', PRI_ICD_CD == 'M24839',
                  PRI_ICD_CD == 'M24832', PRI_ICD_CD == 'M24831', PRI_ICD_CD == 'M25376',
                  PRI_ICD_CD == 'M25375', PRI_ICD_CD == 'M25374', PRI_ICD_CD == 'M25373',
                  PRI_ICD_CD == 'M25372', PRI_ICD_CD == 'M25371', PRI_ICD_CD == 'M25279',
                  PRI_ICD_CD == 'M25272', PRI_ICD_CD == 'M25271', PRI_ICD_CD == 'M24876',
                  PRI_ICD_CD == 'M24875', PRI_ICD_CD == 'M24874', PRI_ICD_CD == 'M24873',
                  PRI_ICD_CD == 'M24872', PRI_ICD_CD == 'M24871', PRI_ICD_CD == 'M25519',
                  PRI_ICD_CD == 'M25512', PRI_ICD_CD == 'M25511', PRI_ICD_CD == 'M79622',
                  PRI_ICD_CD == 'M25529', PRI_ICD_CD == 'M25522', PRI_ICD_CD == 'M25521',
                  PRI_ICD_CD == 'M79632', PRI_ICD_CD == 'M25539', PRI_ICD_CD == 'M25532',
                  PRI_ICD_CD == 'M25531', PRI_ICD_CD == 'M79646', PRI_ICD_CD == 'M79643',
                  PRI_ICD_CD == 'M25559', PRI_ICD_CD == 'M25552', PRI_ICD_CD == 'M25551',
                  PRI_ICD_CD == 'M25569', PRI_ICD_CD == 'M25562', PRI_ICD_CD == 'M25561',
                  PRI_ICD_CD == 'M25579', PRI_ICD_CD == 'M25572', PRI_ICD_CD == 'M25571',
                  PRI_ICD_CD == 'M25859', PRI_ICD_CD == 'M25852', PRI_ICD_CD == 'M25851',
                  PRI_ICD_CD == 'M25159', PRI_ICD_CD == 'M5127', PRI_ICD_CD == 'M5126',
                  PRI_ICD_CD == 'M5137', PRI_ICD_CD == 'M5136', PRI_ICD_CD == 'M5003',
                  PRI_ICD_CD == 'M5002', PRI_ICD_CD == 'M5001', PRI_ICD_CD == 'M5000',
                  PRI_ICD_CD == 'M5107', PRI_ICD_CD == 'M5106', PRI_ICD_CD == 'M519',
                  PRI_ICD_CD == 'M4649', PRI_ICD_CD == 'M4648', PRI_ICD_CD == 'M4640',
                  PRI_ICD_CD == 'M5093', PRI_ICD_CD == 'M5092', PRI_ICD_CD == 'M5091',
                  PRI_ICD_CD == 'M5090', PRI_ICD_CD == 'M5083', PRI_ICD_CD == 'M5082',
                  PRI_ICD_CD == 'M5081', PRI_ICD_CD == 'M5080', PRI_ICD_CD == 'M4644',
                  PRI_ICD_CD == 'M4643', PRI_ICD_CD == 'M4642', PRI_ICD_CD == 'M4641',
                  PRI_ICD_CD == 'M5187', PRI_ICD_CD == 'M5186', PRI_ICD_CD == 'M4647',
                  PRI_ICD_CD == 'M4646', PRI_ICD_CD == 'M4800', PRI_ICD_CD == 'M9973',
                  PRI_ICD_CD == 'M9963', PRI_ICD_CD == 'M9953', PRI_ICD_CD == 'M9943',
                  PRI_ICD_CD == 'M9933', PRI_ICD_CD == 'M9923', PRI_ICD_CD == 'M4807',
                  PRI_ICD_CD == 'M4806', PRI_ICD_CD == 'M7552', PRI_ICD_CD == 'M7551',
                  PRI_ICD_CD == 'M7550', PRI_ICD_CD == 'M75102', PRI_ICD_CD == 'M75101',
                  PRI_ICD_CD == 'M75100', PRI_ICD_CD == 'M66819', PRI_ICD_CD == 'M66812',
                  PRI_ICD_CD == 'M66811', PRI_ICD_CD == 'M66219', PRI_ICD_CD == 'M66212',
                  PRI_ICD_CD == 'M66211', PRI_ICD_CD == 'M7522', PRI_ICD_CD == 'M7521',
                  PRI_ICD_CD == 'M7520', PRI_ICD_CD == 'M75110', PRI_ICD_CD == 'M7580',
                  PRI_ICD_CD == 'M75112', PRI_ICD_CD == 'M75111', PRI_ICD_CD == 'M7702',
                  PRI_ICD_CD == 'M7701', PRI_ICD_CD == 'M7700', PRI_ICD_CD == 'M7712',
                  PRI_ICD_CD == 'M7711', PRI_ICD_CD == 'M7710', PRI_ICD_CD == 'M7742',
                  PRI_ICD_CD == 'M7741', PRI_ICD_CD == 'M7740', PRI_ICD_CD == 'M76899',
                  PRI_ICD_CD == 'M25776', PRI_ICD_CD == 'M25775', PRI_ICD_CD == 'M25774',
                  PRI_ICD_CD == 'M25773', PRI_ICD_CD == 'M25772', PRI_ICD_CD == 'M25771',
                  PRI_ICD_CD == 'M7662', PRI_ICD_CD == 'M7661', PRI_ICD_CD == 'M7660',
                  PRI_ICD_CD == 'M76829', PRI_ICD_CD == 'M76822', PRI_ICD_CD == 'M76821',
                  PRI_ICD_CD == 'M76819', PRI_ICD_CD == 'M76812', PRI_ICD_CD == 'M76811',
                  PRI_ICD_CD == 'M7732', PRI_ICD_CD == 'M7731', PRI_ICD_CD == 'M7730',
                  PRI_ICD_CD == 'M779', PRI_ICD_CD == 'M2570', PRI_ICD_CD == 'M65359',
                  PRI_ICD_CD == 'M65352', PRI_ICD_CD == 'M65351', PRI_ICD_CD == 'M65349',
                  PRI_ICD_CD == 'M65342', PRI_ICD_CD == 'M65341', PRI_ICD_CD == 'M65339',
                  PRI_ICD_CD == 'M65332', PRI_ICD_CD == 'M65331', PRI_ICD_CD == 'M65329',
                  PRI_ICD_CD == 'M65322', PRI_ICD_CD == 'M65321', PRI_ICD_CD == 'M65319',
                  PRI_ICD_CD == 'M65312', PRI_ICD_CD == 'M65311', PRI_ICD_CD == 'M6530',
                  PRI_ICD_CD == 'M654', PRI_ICD_CD == 'M65849', PRI_ICD_CD == 'M65842',
                  PRI_ICD_CD == 'M65841', PRI_ICD_CD == 'M65839', PRI_ICD_CD == 'M65832',
                  PRI_ICD_CD == 'M65831', PRI_ICD_CD == 'M65879', PRI_ICD_CD == 'M65872',
                  PRI_ICD_CD == 'M65871', PRI_ICD_CD == 'M6749', PRI_ICD_CD == 'M6748',
                  PRI_ICD_CD == 'M67479', PRI_ICD_CD == 'M67472', PRI_ICD_CD == 'M67471',
                  PRI_ICD_CD == 'M67469', PRI_ICD_CD == 'M67462', PRI_ICD_CD == 'M67461',
                  PRI_ICD_CD == 'M67459', PRI_ICD_CD == 'M67452', PRI_ICD_CD == 'M67451',
                  PRI_ICD_CD == 'M67449', PRI_ICD_CD == 'M67442', PRI_ICD_CD == 'M67441',
                  PRI_ICD_CD == 'M67439', PRI_ICD_CD == 'M67432', PRI_ICD_CD == 'M67431',
                  PRI_ICD_CD == 'M67429', PRI_ICD_CD == 'M67422', PRI_ICD_CD == 'M67421',
                  PRI_ICD_CD == 'M67419', PRI_ICD_CD == 'M67411', PRI_ICD_CD == 'M6740',
                  PRI_ICD_CD == 'M75122', PRI_ICD_CD == 'M75121', PRI_ICD_CD == 'M75120',
                  PRI_ICD_CD == 'M66839', PRI_ICD_CD == 'M66832', PRI_ICD_CD == 'M66831',
                  PRI_ICD_CD == 'M66829', PRI_ICD_CD == 'M66822', PRI_ICD_CD == 'M66821',
                  PRI_ICD_CD == 'M66329', PRI_ICD_CD == 'M66322', PRI_ICD_CD == 'M66321',
                  PRI_ICD_CD == 'M66319', PRI_ICD_CD == 'M66312', PRI_ICD_CD == 'M66311',
                  PRI_ICD_CD == 'M6630', PRI_ICD_CD == 'M66229', PRI_ICD_CD == 'M66222',
                  PRI_ICD_CD == 'M66221', PRI_ICD_CD == 'M66259', PRI_ICD_CD == 'M66252',
                  PRI_ICD_CD == 'M66251', PRI_ICD_CD == 'M66869', PRI_ICD_CD == 'M66862',
                  PRI_ICD_CD == 'M66861', PRI_ICD_CD == 'M66369', PRI_ICD_CD == 'M66362',
                  PRI_ICD_CD == 'M66361', PRI_ICD_CD == 'M7149', PRI_ICD_CD == 'M7148',
                  PRI_ICD_CD == 'M71479', PRI_ICD_CD == 'M71472', PRI_ICD_CD == 'M71471',
                  PRI_ICD_CD == 'M71469', PRI_ICD_CD == 'M71462', PRI_ICD_CD == 'M71461',
                  PRI_ICD_CD == 'M71459', PRI_ICD_CD == 'M71452', PRI_ICD_CD == 'M71451',
                  PRI_ICD_CD == 'M71449', PRI_ICD_CD == 'M71442', PRI_ICD_CD == 'M71441',
                  PRI_ICD_CD == 'M71439', PRI_ICD_CD == 'M71432', PRI_ICD_CD == 'M71431',
                  PRI_ICD_CD == 'M71429', PRI_ICD_CD == 'M71422', PRI_ICD_CD == 'M71421',
                  PRI_ICD_CD == 'M7140', PRI_ICD_CD == 'M6529', PRI_ICD_CD == 'M6528',
                  PRI_ICD_CD == 'M65279', PRI_ICD_CD == 'M65272', PRI_ICD_CD == 'M65271',
                  PRI_ICD_CD == 'M65269', PRI_ICD_CD == 'M65262', PRI_ICD_CD == 'M65261',
                  PRI_ICD_CD == 'M65259', PRI_ICD_CD == 'M65252', PRI_ICD_CD == 'M65251',
                  PRI_ICD_CD == 'M65249', PRI_ICD_CD == 'M65242', PRI_ICD_CD == 'M65241',
                  PRI_ICD_CD == 'M65239', PRI_ICD_CD == 'M65232', PRI_ICD_CD == 'M65231',
                  PRI_ICD_CD == 'M65229', PRI_ICD_CD == 'M65222', PRI_ICD_CD == 'M65221',
                  PRI_ICD_CD == 'M6520', PRI_ICD_CD == 'M722', PRI_ICD_CD == 'M62838',
                  PRI_ICD_CD == 'M62831', PRI_ICD_CD == 'M6249', PRI_ICD_CD == 'M6248',
                  PRI_ICD_CD == 'M62479', PRI_ICD_CD == 'M62472', PRI_ICD_CD == 'M62471',
                  PRI_ICD_CD == 'M62469', PRI_ICD_CD == 'M62462', PRI_ICD_CD == 'M62461',
                  PRI_ICD_CD == 'M62459', PRI_ICD_CD == 'M62452', PRI_ICD_CD == 'M62451',
                  PRI_ICD_CD == 'M62449', PRI_ICD_CD == 'M62442', PRI_ICD_CD == 'M62441',
                  PRI_ICD_CD == 'M62439', PRI_ICD_CD == 'M62432', PRI_ICD_CD == 'M62431',
                  PRI_ICD_CD == 'M62429', PRI_ICD_CD == 'M62422', PRI_ICD_CD == 'M62421',
                  PRI_ICD_CD == 'M62419', PRI_ICD_CD == 'M62412', PRI_ICD_CD == 'M62411',
                  PRI_ICD_CD == 'M6240', PRI_ICD_CD == 'M86279', PRI_ICD_CD == 'M86272',
                  PRI_ICD_CD == 'M86271', PRI_ICD_CD == 'M86179', PRI_ICD_CD == 'M86172',
                  PRI_ICD_CD == 'M86171', PRI_ICD_CD == 'M86079', PRI_ICD_CD == 'M86072',
                  PRI_ICD_CD == 'M86071', PRI_ICD_CD == 'S92919K', PRI_ICD_CD == 'S92912K',
                  PRI_ICD_CD == 'S92911K', PRI_ICD_CD == 'S92909K', PRI_ICD_CD == 'S92902K',
                  PRI_ICD_CD == 'S92901K', PRI_ICD_CD == 'S92599K', PRI_ICD_CD == 'S92592K',
                  PRI_ICD_CD == 'S92591K', PRI_ICD_CD == 'S92536K', PRI_ICD_CD == 'S92535K',
                  PRI_ICD_CD == 'S92534K', PRI_ICD_CD == 'S92533K', PRI_ICD_CD == 'S92532K',
                  PRI_ICD_CD == 'S92531K', PRI_ICD_CD == 'S92526K', PRI_ICD_CD == 'S92525K',
                  PRI_ICD_CD == 'S92524K', PRI_ICD_CD == 'S92523K', PRI_ICD_CD == 'S92522K',
                  PRI_ICD_CD == 'S92521K', PRI_ICD_CD == 'S92516K', PRI_ICD_CD == 'S92515K',
                  PRI_ICD_CD == 'S92514K', PRI_ICD_CD == 'S92513K', PRI_ICD_CD == 'S92512K',
                  PRI_ICD_CD == 'S92511K', PRI_ICD_CD == 'S92506K', PRI_ICD_CD == 'S92505K',
                  PRI_ICD_CD == 'S92504K', PRI_ICD_CD == 'S92503K', PRI_ICD_CD == 'S92502K',
                  PRI_ICD_CD == 'S92501K', PRI_ICD_CD == 'S92499K', PRI_ICD_CD == 'S92492K',
                  PRI_ICD_CD == 'S92491K', PRI_ICD_CD == 'S92426K', PRI_ICD_CD == 'S92425K',
                  PRI_ICD_CD == 'S92424K', PRI_ICD_CD == 'S92423K', PRI_ICD_CD == 'S92422K',
                  PRI_ICD_CD == 'S92421K', PRI_ICD_CD == 'S92416K', PRI_ICD_CD == 'S92415K',
                  PRI_ICD_CD == 'S92414K', PRI_ICD_CD == 'S92413K', PRI_ICD_CD == 'S92412K',
                  PRI_ICD_CD == 'S92411K', PRI_ICD_CD == 'S92406K', PRI_ICD_CD == 'S92405K',
                  PRI_ICD_CD == 'S92404K', PRI_ICD_CD == 'S92403K', PRI_ICD_CD == 'S92402K',
                  PRI_ICD_CD == 'S92401K', PRI_ICD_CD == 'S92356K', PRI_ICD_CD == 'S92355K',
                  PRI_ICD_CD == 'S92354K', PRI_ICD_CD == 'S92353K', PRI_ICD_CD == 'S92352K',
                  PRI_ICD_CD == 'S92351K', PRI_ICD_CD == 'S92346K', PRI_ICD_CD == 'S92345K',
                  PRI_ICD_CD == 'S92344K', PRI_ICD_CD == 'S92343K', PRI_ICD_CD == 'S92342K',
                  PRI_ICD_CD == 'S92341K', PRI_ICD_CD == 'S92336K', PRI_ICD_CD == 'S92335K',
                  PRI_ICD_CD == 'S92334K', PRI_ICD_CD == 'S92333K', PRI_ICD_CD == 'S92332K',
                  PRI_ICD_CD == 'S92331K', PRI_ICD_CD == 'S92326K', PRI_ICD_CD == 'S92325K',
                  PRI_ICD_CD == 'S92324K', PRI_ICD_CD == 'S92323K', PRI_ICD_CD == 'S92322K',
                  PRI_ICD_CD == 'S92321K', PRI_ICD_CD == 'S92316K', PRI_ICD_CD == 'S92315K',
                  PRI_ICD_CD == 'S92314K', PRI_ICD_CD == 'S92313K', PRI_ICD_CD == 'S92312K',
                  PRI_ICD_CD == 'S92311K', PRI_ICD_CD == 'S92309K', PRI_ICD_CD == 'S92302K',
                  PRI_ICD_CD == 'S92301K', PRI_ICD_CD == 'S92256K', PRI_ICD_CD == 'S92255K',
                  PRI_ICD_CD == 'S92254K', PRI_ICD_CD == 'S92253K', PRI_ICD_CD == 'S92252K',
                  PRI_ICD_CD == 'S92251K', PRI_ICD_CD == 'S92246K', PRI_ICD_CD == 'S92245K',
                  PRI_ICD_CD == 'S92244K', PRI_ICD_CD == 'S92243K', PRI_ICD_CD == 'S92242K',
                  PRI_ICD_CD == 'S92241K', PRI_ICD_CD == 'S92236K', PRI_ICD_CD == 'S92235K',
                  PRI_ICD_CD == 'S92234K', PRI_ICD_CD == 'S92233K', PRI_ICD_CD == 'S92232K',
                  PRI_ICD_CD == 'S92231K', PRI_ICD_CD == 'S92226K', PRI_ICD_CD == 'S92225K',
                  PRI_ICD_CD == 'S92224K', PRI_ICD_CD == 'S92223K', PRI_ICD_CD == 'S92222K',
                  PRI_ICD_CD == 'S92221K', PRI_ICD_CD == 'S92216K', PRI_ICD_CD == 'S92215K',
                  PRI_ICD_CD == 'S92214K', PRI_ICD_CD == 'S92213K', PRI_ICD_CD == 'S92212K',
                  PRI_ICD_CD == 'S92211K', PRI_ICD_CD == 'S92209K', PRI_ICD_CD == 'S92202K',
                  PRI_ICD_CD == 'S92201K', PRI_ICD_CD == 'S92199K', PRI_ICD_CD == 'S92192K',
                  PRI_ICD_CD == 'S92191K', PRI_ICD_CD == 'S92156K', PRI_ICD_CD == 'S92155K',
                  PRI_ICD_CD == 'S92154K', PRI_ICD_CD == 'S92153K', PRI_ICD_CD == 'S92152K',
                  PRI_ICD_CD == 'S92151K', PRI_ICD_CD == 'S92146K', PRI_ICD_CD == 'S92145K',
                  PRI_ICD_CD == 'S92144K', PRI_ICD_CD == 'S92143K', PRI_ICD_CD == 'S92142K',
                  PRI_ICD_CD == 'S92141K', PRI_ICD_CD == 'S92136K', PRI_ICD_CD == 'S92135K',
                  PRI_ICD_CD == 'S92134K', PRI_ICD_CD == 'S92133K', PRI_ICD_CD == 'S92132K',
                  PRI_ICD_CD == 'S92131K', PRI_ICD_CD == 'S92126K', PRI_ICD_CD == 'S92125K',
                  PRI_ICD_CD == 'S92124K', PRI_ICD_CD == 'S92123K', PRI_ICD_CD == 'S92122K',
                  PRI_ICD_CD == 'S92121K', PRI_ICD_CD == 'S92116K', PRI_ICD_CD == 'S92115K',
                  PRI_ICD_CD == 'S92114K', PRI_ICD_CD == 'S92113K', PRI_ICD_CD == 'S92112K',
                  PRI_ICD_CD == 'S92111K', PRI_ICD_CD == 'S92109K', PRI_ICD_CD == 'S92102K',
                  PRI_ICD_CD == 'S92101K', PRI_ICD_CD == 'S92066K', PRI_ICD_CD == 'S92065K',
                  PRI_ICD_CD == 'S92064K', PRI_ICD_CD == 'S92063K', PRI_ICD_CD == 'S92062K',
                  PRI_ICD_CD == 'S92061K', PRI_ICD_CD == 'S92056K', PRI_ICD_CD == 'S92055K',
                  PRI_ICD_CD == 'S92054K', PRI_ICD_CD == 'S92053K', PRI_ICD_CD == 'S92052K',
                  PRI_ICD_CD == 'S92051K', PRI_ICD_CD == 'S92046K', PRI_ICD_CD == 'S92045K',
                  PRI_ICD_CD == 'S92044K', PRI_ICD_CD == 'S92043K', PRI_ICD_CD == 'S92042K',
                  PRI_ICD_CD == 'S92041K', PRI_ICD_CD == 'S92036K', PRI_ICD_CD == 'S92035K',
                  PRI_ICD_CD == 'S92034K', PRI_ICD_CD == 'S92033K', PRI_ICD_CD == 'S92032K',
                  PRI_ICD_CD == 'S92031K', PRI_ICD_CD == 'S92026K', PRI_ICD_CD == 'S92025K',
                  PRI_ICD_CD == 'S92024K', PRI_ICD_CD == 'S92023K', PRI_ICD_CD == 'S92022K',
                  PRI_ICD_CD == 'S92021K', PRI_ICD_CD == 'S92016K', PRI_ICD_CD == 'S92015K',
                  PRI_ICD_CD == 'S92014K', PRI_ICD_CD == 'S92013K', PRI_ICD_CD == 'S92012K',
                  PRI_ICD_CD == 'S92011K', PRI_ICD_CD == 'S92009K', PRI_ICD_CD == 'S92002K',
                  PRI_ICD_CD == 'S92001K', PRI_ICD_CD == 'S89399K', PRI_ICD_CD == 'S89392K',
                  PRI_ICD_CD == 'S89391K', PRI_ICD_CD == 'S89329K', PRI_ICD_CD == 'S89322K',
                  PRI_ICD_CD == 'S89321K', PRI_ICD_CD == 'S89319K', PRI_ICD_CD == 'S89312K',
                  PRI_ICD_CD == 'S89311K', PRI_ICD_CD == 'S89309K', PRI_ICD_CD == 'S89302K',
                  PRI_ICD_CD == 'S89301K', PRI_ICD_CD == 'S89299K', PRI_ICD_CD == 'S89292K',
                  PRI_ICD_CD == 'S89291K', PRI_ICD_CD == 'S89229K', PRI_ICD_CD == 'S89222K',
                  PRI_ICD_CD == 'S89221K', PRI_ICD_CD == 'S89219K', PRI_ICD_CD == 'S89212K',
                  PRI_ICD_CD == 'S89211K', PRI_ICD_CD == 'S89209K', PRI_ICD_CD == 'S89202K',
                  PRI_ICD_CD == 'S89201K', PRI_ICD_CD == 'S89199K', PRI_ICD_CD == 'S89192K',
                  PRI_ICD_CD == 'S89191K', PRI_ICD_CD == 'S89149K', PRI_ICD_CD == 'S89142K',
                  PRI_ICD_CD == 'S89141K', PRI_ICD_CD == 'S89139K', PRI_ICD_CD == 'S89132K',
                  PRI_ICD_CD == 'S89131K', PRI_ICD_CD == 'S89129K', PRI_ICD_CD == 'S89122K',
                  PRI_ICD_CD == 'S89121K', PRI_ICD_CD == 'S89119K', PRI_ICD_CD == 'S89112K',
                  PRI_ICD_CD == 'S89111K', PRI_ICD_CD == 'S89109K', PRI_ICD_CD == 'S89102K',
                  PRI_ICD_CD == 'S89101K', PRI_ICD_CD == 'S89099K', PRI_ICD_CD == 'S89092K',
                  PRI_ICD_CD == 'S89091K', PRI_ICD_CD == 'S89049K', PRI_ICD_CD == 'S89042K',
                  PRI_ICD_CD == 'S89041K', PRI_ICD_CD == 'S89039K', PRI_ICD_CD == 'S89032K',
                  PRI_ICD_CD == 'S89031K', PRI_ICD_CD == 'S89029K', PRI_ICD_CD == 'S89022K',
                  PRI_ICD_CD == 'S89021K', PRI_ICD_CD == 'S89019K', PRI_ICD_CD == 'S89012K',
                  PRI_ICD_CD == 'S89011K', PRI_ICD_CD == 'S89009K', PRI_ICD_CD == 'S89002K',
                  PRI_ICD_CD == 'S89001K', PRI_ICD_CD == 'S8292XN', PRI_ICD_CD == 'S8292XM',
                  PRI_ICD_CD == 'S8292XK', PRI_ICD_CD == 'S8291XN', PRI_ICD_CD == 'S8291XM',
                  PRI_ICD_CD == 'S8291XK', PRI_ICD_CD == 'S8290XN', PRI_ICD_CD == 'S8290XM',
                  PRI_ICD_CD == 'S8290XK', PRI_ICD_CD == 'S82899N', PRI_ICD_CD == 'S82899M',
                  PRI_ICD_CD == 'S82899K', PRI_ICD_CD == 'S82892N', PRI_ICD_CD == 'S82892M',
                  PRI_ICD_CD == 'S82892K', PRI_ICD_CD == 'S82891N', PRI_ICD_CD == 'S82891M',
                  PRI_ICD_CD == 'S82891K', PRI_ICD_CD == 'S82876N', PRI_ICD_CD == 'S82876M',
                  PRI_ICD_CD == 'S82876K', PRI_ICD_CD == 'S82875N', PRI_ICD_CD == 'S82875M',
                  PRI_ICD_CD == 'S82875K', PRI_ICD_CD == 'S82874N', PRI_ICD_CD == 'S82874M',
                  PRI_ICD_CD == 'S82874K', PRI_ICD_CD == 'S82873N', PRI_ICD_CD == 'S82873M',
                  PRI_ICD_CD == 'S82873K', PRI_ICD_CD == 'S82872N', PRI_ICD_CD == 'S82872M',
                  PRI_ICD_CD == 'S82872K', PRI_ICD_CD == 'S82871N', PRI_ICD_CD == 'S82871M',
                  PRI_ICD_CD == 'S82871K', PRI_ICD_CD == 'S82866N', PRI_ICD_CD == 'S82866M',
                  PRI_ICD_CD == 'S82866K', PRI_ICD_CD == 'S82865R', PRI_ICD_CD == 'S82865Q',
                  PRI_ICD_CD == 'S82865P', PRI_ICD_CD == 'S82865N', PRI_ICD_CD == 'S82865M',
                  PRI_ICD_CD == 'S82865K', PRI_ICD_CD == 'S82864N', PRI_ICD_CD == 'S82864M',
                  PRI_ICD_CD == 'S82864K', PRI_ICD_CD == 'S82863N', PRI_ICD_CD == 'S82863M',
                  PRI_ICD_CD == 'S82863K', PRI_ICD_CD == 'S82862N', PRI_ICD_CD == 'S82862M',
                  PRI_ICD_CD == 'S82862K', PRI_ICD_CD == 'S82861N', PRI_ICD_CD == 'S82861M',
                  PRI_ICD_CD == 'S82861K', PRI_ICD_CD == 'S82856N', PRI_ICD_CD == 'S82856M',
                  PRI_ICD_CD == 'S82856K', PRI_ICD_CD == 'S82855N', PRI_ICD_CD == 'S82855M',
                  PRI_ICD_CD == 'S82855K', PRI_ICD_CD == 'S82854N', PRI_ICD_CD == 'S82854M',
                  PRI_ICD_CD == 'S82854K', PRI_ICD_CD == 'S82853N', PRI_ICD_CD == 'S82853M',
                  PRI_ICD_CD == 'S82853K', PRI_ICD_CD == 'S82852N', PRI_ICD_CD == 'S82852M',
                  PRI_ICD_CD == 'S82852K', PRI_ICD_CD == 'S82851N', PRI_ICD_CD == 'S82851M',
                  PRI_ICD_CD == 'S82851K', PRI_ICD_CD == 'S82846N', PRI_ICD_CD == 'S82846M',
                  PRI_ICD_CD == 'S82846K', PRI_ICD_CD == 'S82845N', PRI_ICD_CD == 'S82845M',
                  PRI_ICD_CD == 'S82845K', PRI_ICD_CD == 'S82844N', PRI_ICD_CD == 'S82844M',
                  PRI_ICD_CD == 'S82844K', PRI_ICD_CD == 'S82843N', PRI_ICD_CD == 'S82843M',
                  PRI_ICD_CD == 'S82843K', PRI_ICD_CD == 'S82842N', PRI_ICD_CD == 'S82842M',
                  PRI_ICD_CD == 'S82842K', PRI_ICD_CD == 'S82841N', PRI_ICD_CD == 'S82841M',
                  PRI_ICD_CD == 'S82841K', PRI_ICD_CD == 'S82839N', PRI_ICD_CD == 'S82839M',
                  PRI_ICD_CD == 'S82839K', PRI_ICD_CD == 'S82832N', PRI_ICD_CD == 'S82832M',
                  PRI_ICD_CD == 'S82832K', PRI_ICD_CD == 'S82831N', PRI_ICD_CD == 'S82831M',
                  PRI_ICD_CD == 'S82831K', PRI_ICD_CD == 'S82829K', PRI_ICD_CD == 'S82822K',
                  PRI_ICD_CD == 'S82821K', PRI_ICD_CD == 'S82819K', PRI_ICD_CD == 'S82812K',
                  PRI_ICD_CD == 'S82811K', PRI_ICD_CD == 'S8266XN', PRI_ICD_CD == 'S8266XM',
                  PRI_ICD_CD == 'S8266XK', PRI_ICD_CD == 'S8265XN', PRI_ICD_CD == 'S8265XM',
                  PRI_ICD_CD == 'S8265XK', PRI_ICD_CD == 'S8264XN', PRI_ICD_CD == 'S8264XM',
                  PRI_ICD_CD == 'S8264XK', PRI_ICD_CD == 'S8263XN', PRI_ICD_CD == 'S8263XM',
                  PRI_ICD_CD == 'S8263XK', PRI_ICD_CD == 'S8262XN', PRI_ICD_CD == 'S8262XM',
                  PRI_ICD_CD == 'S8262XK', PRI_ICD_CD == 'S8261XN', PRI_ICD_CD == 'S8261XM',
                  PRI_ICD_CD == 'S8261XK', PRI_ICD_CD == 'S8256XN', PRI_ICD_CD == 'S8256XM',
                  PRI_ICD_CD == 'S8256XK', PRI_ICD_CD == 'S8255XN', PRI_ICD_CD == 'S8255XM',
                  PRI_ICD_CD == 'S8255XK', PRI_ICD_CD == 'S8254XN', PRI_ICD_CD == 'S8254XM',
                  PRI_ICD_CD == 'S8254XK', PRI_ICD_CD == 'S8253XN', PRI_ICD_CD == 'S8253XM',
                  PRI_ICD_CD == 'S8253XK', PRI_ICD_CD == 'S8252XN', PRI_ICD_CD == 'S8252XM',
                  PRI_ICD_CD == 'S8252XK', PRI_ICD_CD == 'S8251XN', PRI_ICD_CD == 'S8251XM',
                  PRI_ICD_CD == 'S8251XK', PRI_ICD_CD == 'S82499N', PRI_ICD_CD == 'S82499M',
                  PRI_ICD_CD == 'S82499K', PRI_ICD_CD == 'S82492N', PRI_ICD_CD == 'S82492M',
                  PRI_ICD_CD == 'S82492K', PRI_ICD_CD == 'S82491N', PRI_ICD_CD == 'S82491M',
                  PRI_ICD_CD == 'S82491K', PRI_ICD_CD == 'S82466N', PRI_ICD_CD == 'S82466M',
                  PRI_ICD_CD == 'S82466K', PRI_ICD_CD == 'S82465N', PRI_ICD_CD == 'S82465M',
                  PRI_ICD_CD == 'S82465K', PRI_ICD_CD == 'S82464N', PRI_ICD_CD == 'S82464M',
                  PRI_ICD_CD == 'S82464K', PRI_ICD_CD == 'S82463N', PRI_ICD_CD == 'S82463M',
                  PRI_ICD_CD == 'S82463K', PRI_ICD_CD == 'S82462N', PRI_ICD_CD == 'S82462M',
                  PRI_ICD_CD == 'S82462K', PRI_ICD_CD == 'S82461N', PRI_ICD_CD == 'S82461M',
                  PRI_ICD_CD == 'S82461K', PRI_ICD_CD == 'S82456N', PRI_ICD_CD == 'S82456M',
                  PRI_ICD_CD == 'S82456K', PRI_ICD_CD == 'S82455N', PRI_ICD_CD == 'S82455M',
                  PRI_ICD_CD == 'S82455K', PRI_ICD_CD == 'S82454N', PRI_ICD_CD == 'S82454M',
                  PRI_ICD_CD == 'S82454K', PRI_ICD_CD == 'S82453N', PRI_ICD_CD == 'S82453M',
                  PRI_ICD_CD == 'S82453K', PRI_ICD_CD == 'S82452N', PRI_ICD_CD == 'S82452M',
                  PRI_ICD_CD == 'S82452K', PRI_ICD_CD == 'S82451N', PRI_ICD_CD == 'S82451M',
                  PRI_ICD_CD == 'S82451K', PRI_ICD_CD == 'S82446N', PRI_ICD_CD == 'S82446M',
                  PRI_ICD_CD == 'S82446K', PRI_ICD_CD == 'S82445N', PRI_ICD_CD == 'S82445M',
                  PRI_ICD_CD == 'S82445K', PRI_ICD_CD == 'S82444N', PRI_ICD_CD == 'S82444M',
                  PRI_ICD_CD == 'S82444K', PRI_ICD_CD == 'S82443N', PRI_ICD_CD == 'S82443M',
                  PRI_ICD_CD == 'S82443K', PRI_ICD_CD == 'S82442N', PRI_ICD_CD == 'S82442M',
                  PRI_ICD_CD == 'S82442K', PRI_ICD_CD == 'S82441N', PRI_ICD_CD == 'S82441M',
                  PRI_ICD_CD == 'S82441K', PRI_ICD_CD == 'S82436N', PRI_ICD_CD == 'S82436M',
                  PRI_ICD_CD == 'S82436K', PRI_ICD_CD == 'S82435N', PRI_ICD_CD == 'S82435M',
                  PRI_ICD_CD == 'S82435K', PRI_ICD_CD == 'S82434N', PRI_ICD_CD == 'S82434M',
                  PRI_ICD_CD == 'S82434K', PRI_ICD_CD == 'S82433N', PRI_ICD_CD == 'S82433M',
                  PRI_ICD_CD == 'S82433K', PRI_ICD_CD == 'S82432N', PRI_ICD_CD == 'S82432M',
                  PRI_ICD_CD == 'S82432K', PRI_ICD_CD == 'S82431N', PRI_ICD_CD == 'S82431M',
                  PRI_ICD_CD == 'S82431K', PRI_ICD_CD == 'S82426N', PRI_ICD_CD == 'S82426M',
                  PRI_ICD_CD == 'S82426K', PRI_ICD_CD == 'S82425N', PRI_ICD_CD == 'S82425M',
                  PRI_ICD_CD == 'S82425K', PRI_ICD_CD == 'S82424N', PRI_ICD_CD == 'S82424M',
                  PRI_ICD_CD == 'S82424K', PRI_ICD_CD == 'S82423N', PRI_ICD_CD == 'S82423M',
                  PRI_ICD_CD == 'S82423K', PRI_ICD_CD == 'S82422N', PRI_ICD_CD == 'S82422M',
                  PRI_ICD_CD == 'S82422K', PRI_ICD_CD == 'S82421N', PRI_ICD_CD == 'S82421M',
                  PRI_ICD_CD == 'S82421K', PRI_ICD_CD == 'S82409N', PRI_ICD_CD == 'S82409M',
                  PRI_ICD_CD == 'S82409K', PRI_ICD_CD == 'S82402N', PRI_ICD_CD == 'S82402M',
                  PRI_ICD_CD == 'S82402K', PRI_ICD_CD == 'S82401N', PRI_ICD_CD == 'S82401M',
                  PRI_ICD_CD == 'S82401K', PRI_ICD_CD == 'S82399N', PRI_ICD_CD == 'S82399M',
                  PRI_ICD_CD == 'S82399K', PRI_ICD_CD == 'S82392N', PRI_ICD_CD == 'S82392M',
                  PRI_ICD_CD == 'S82392K', PRI_ICD_CD == 'S82391N', PRI_ICD_CD == 'S82391M',
                  PRI_ICD_CD == 'S82391K', PRI_ICD_CD == 'S82319K', PRI_ICD_CD == 'S82312K',
                  PRI_ICD_CD == 'S82311K', PRI_ICD_CD == 'S82309N', PRI_ICD_CD == 'S82309M',
                  PRI_ICD_CD == 'S82309K', PRI_ICD_CD == 'S82302N', PRI_ICD_CD == 'S82302M',
                  PRI_ICD_CD == 'S82302K', PRI_ICD_CD == 'S82301N', PRI_ICD_CD == 'S82301M',
                  PRI_ICD_CD == 'S82301K', PRI_ICD_CD == 'S82299N', PRI_ICD_CD == 'S82299M',
                  PRI_ICD_CD == 'S82299K', PRI_ICD_CD == 'S82292N', PRI_ICD_CD == 'S82292M',
                  PRI_ICD_CD == 'S82292K', PRI_ICD_CD == 'S82291N', PRI_ICD_CD == 'S82291M',
                  PRI_ICD_CD == 'S82291K', PRI_ICD_CD == 'S82266N', PRI_ICD_CD == 'S82266M',
                  PRI_ICD_CD == 'S82266K', PRI_ICD_CD == 'S82265N', PRI_ICD_CD == 'S82265M',
                  PRI_ICD_CD == 'S82265K', PRI_ICD_CD == 'S82264N', PRI_ICD_CD == 'S82264M',
                  PRI_ICD_CD == 'S82264K', PRI_ICD_CD == 'S82263N', PRI_ICD_CD == 'S82263M',
                  PRI_ICD_CD == 'S82263K', PRI_ICD_CD == 'S82262N', PRI_ICD_CD == 'S82262M',
                  PRI_ICD_CD == 'S82262K', PRI_ICD_CD == 'S82261N', PRI_ICD_CD == 'S82261M',
                  PRI_ICD_CD == 'S82261K', PRI_ICD_CD == 'S82256N', PRI_ICD_CD == 'S82256M',
                  PRI_ICD_CD == 'S82256K', PRI_ICD_CD == 'S82255N', PRI_ICD_CD == 'S82255M',
                  PRI_ICD_CD == 'S82255K', PRI_ICD_CD == 'S82254N', PRI_ICD_CD == 'S82254M',
                  PRI_ICD_CD == 'S82254K', PRI_ICD_CD == 'S82253N', PRI_ICD_CD == 'S82253M',
                  PRI_ICD_CD == 'S82253K', PRI_ICD_CD == 'S82252N', PRI_ICD_CD == 'S82252M',
                  PRI_ICD_CD == 'S82252K', PRI_ICD_CD == 'S82251N', PRI_ICD_CD == 'S82251M',
                  PRI_ICD_CD == 'S82251K', PRI_ICD_CD == 'S82246N', PRI_ICD_CD == 'S82246M',
                  PRI_ICD_CD == 'S82246K', PRI_ICD_CD == 'S82245N', PRI_ICD_CD == 'S82245M',
                  PRI_ICD_CD == 'S82245K', PRI_ICD_CD == 'S82244N', PRI_ICD_CD == 'S82244M',
                  PRI_ICD_CD == 'S82244K', PRI_ICD_CD == 'S82243N', PRI_ICD_CD == 'S82243M',
                  PRI_ICD_CD == 'S82243K', PRI_ICD_CD == 'S82242N', PRI_ICD_CD == 'S82242M',
                  PRI_ICD_CD == 'S82242K', PRI_ICD_CD == 'S82241N', PRI_ICD_CD == 'S82241M',
                  PRI_ICD_CD == 'S82241K', PRI_ICD_CD == 'S82236N', PRI_ICD_CD == 'S82236M',
                  PRI_ICD_CD == 'S82236K', PRI_ICD_CD == 'S82235N', PRI_ICD_CD == 'S82235M',
                  PRI_ICD_CD == 'S82235K', PRI_ICD_CD == 'S82234N', PRI_ICD_CD == 'S82234M',
                  PRI_ICD_CD == 'S82234K', PRI_ICD_CD == 'S82233N', PRI_ICD_CD == 'S82233M',
                  PRI_ICD_CD == 'S82233K', PRI_ICD_CD == 'S82232N', PRI_ICD_CD == 'S82232M',
                  PRI_ICD_CD == 'S82232K', PRI_ICD_CD == 'S82231N', PRI_ICD_CD == 'S82231M',
                  PRI_ICD_CD == 'S82231K', PRI_ICD_CD == 'S82226N', PRI_ICD_CD == 'S82226M',
                  PRI_ICD_CD == 'S82226K', PRI_ICD_CD == 'S82225N', PRI_ICD_CD == 'S82225M',
                  PRI_ICD_CD == 'S82225K', PRI_ICD_CD == 'S82224N', PRI_ICD_CD == 'S82224M',
                  PRI_ICD_CD == 'S82224K', PRI_ICD_CD == 'S82223N', PRI_ICD_CD == 'S82223M',
                  PRI_ICD_CD == 'S82223K', PRI_ICD_CD == 'S82222N', PRI_ICD_CD == 'S82222M',
                  PRI_ICD_CD == 'S82222K', PRI_ICD_CD == 'S82221N', PRI_ICD_CD == 'S82221M',
                  PRI_ICD_CD == 'S82221K', PRI_ICD_CD == 'S82209N', PRI_ICD_CD == 'S82209M',
                  PRI_ICD_CD == 'S82209K', PRI_ICD_CD == 'S82202N', PRI_ICD_CD == 'S82202M',
                  PRI_ICD_CD == 'S82202K', PRI_ICD_CD == 'S82201N', PRI_ICD_CD == 'S82201M',
                  PRI_ICD_CD == 'S82201K', PRI_ICD_CD == 'S82199N', PRI_ICD_CD == 'S82199M',
                  PRI_ICD_CD == 'S82199K', PRI_ICD_CD == 'S82192N', PRI_ICD_CD == 'S82192M',
                  PRI_ICD_CD == 'S82192K', PRI_ICD_CD == 'S82191N', PRI_ICD_CD == 'S82191M',
                  PRI_ICD_CD == 'S82191K', PRI_ICD_CD == 'S82169K', PRI_ICD_CD == 'S82162K',
                  PRI_ICD_CD == 'S82161K', PRI_ICD_CD == 'S82156N', PRI_ICD_CD == 'S82156M',
                  PRI_ICD_CD == 'S82156K', PRI_ICD_CD == 'S82155N', PRI_ICD_CD == 'S82155M',
                  PRI_ICD_CD == 'S82155K', PRI_ICD_CD == 'S82154N', PRI_ICD_CD == 'S82154M',
                  PRI_ICD_CD == 'S82154K', PRI_ICD_CD == 'S82153N', PRI_ICD_CD == 'S82153M',
                  PRI_ICD_CD == 'S82153K', PRI_ICD_CD == 'S82152N', PRI_ICD_CD == 'S82152M',
                  PRI_ICD_CD == 'S82152K', PRI_ICD_CD == 'S82151N', PRI_ICD_CD == 'S82151M',
                  PRI_ICD_CD == 'S82151K', PRI_ICD_CD == 'S82146N', PRI_ICD_CD == 'S82146M',
                  PRI_ICD_CD == 'S82146K', PRI_ICD_CD == 'S82145N', PRI_ICD_CD == 'S82145M',
                  PRI_ICD_CD == 'S82145K', PRI_ICD_CD == 'S82144N', PRI_ICD_CD == 'S82144M',
                  PRI_ICD_CD == 'S82144K', PRI_ICD_CD == 'S82143N', PRI_ICD_CD == 'S82143M',
                  PRI_ICD_CD == 'S82143K', PRI_ICD_CD == 'S82142N', PRI_ICD_CD == 'S82142M',
                  PRI_ICD_CD == 'S82142K', PRI_ICD_CD == 'S82141N', PRI_ICD_CD == 'S82141M',
                  PRI_ICD_CD == 'S82141K', PRI_ICD_CD == 'S82136N', PRI_ICD_CD == 'S82136M',
                  PRI_ICD_CD == 'S82136K', PRI_ICD_CD == 'S82135N', PRI_ICD_CD == 'S82135M',
                  PRI_ICD_CD == 'S82135K', PRI_ICD_CD == 'S82134N', PRI_ICD_CD == 'S82134M',
                  PRI_ICD_CD == 'S82134K', PRI_ICD_CD == 'S82133N', PRI_ICD_CD == 'S82133M',
                  PRI_ICD_CD == 'S82133K', PRI_ICD_CD == 'S82132N', PRI_ICD_CD == 'S82132M',
                  PRI_ICD_CD == 'S82132K', PRI_ICD_CD == 'S82131N', PRI_ICD_CD == 'S82131M',
                  PRI_ICD_CD == 'S82131K', PRI_ICD_CD == 'S82126N', PRI_ICD_CD == 'S82126M',
                  PRI_ICD_CD == 'S82126K', PRI_ICD_CD == 'S82125N', PRI_ICD_CD == 'S82125M',
                  PRI_ICD_CD == 'S82125K', PRI_ICD_CD == 'S82124N', PRI_ICD_CD == 'S82124M',
                  PRI_ICD_CD == 'S82124K', PRI_ICD_CD == 'S82123N', PRI_ICD_CD == 'S82123M',
                  PRI_ICD_CD == 'S82123K', PRI_ICD_CD == 'S82122N', PRI_ICD_CD == 'S82122M',
                  PRI_ICD_CD == 'S82122K', PRI_ICD_CD == 'S82121N', PRI_ICD_CD == 'S82121M',
                  PRI_ICD_CD == 'S82121K', PRI_ICD_CD == 'S82116N', PRI_ICD_CD == 'S82116M',
                  PRI_ICD_CD == 'S82116K', PRI_ICD_CD == 'S82115N', PRI_ICD_CD == 'S82115M',
                  PRI_ICD_CD == 'S82115K', PRI_ICD_CD == 'S82114N', PRI_ICD_CD == 'S82114M',
                  PRI_ICD_CD == 'S82114K', PRI_ICD_CD == 'S82113N', PRI_ICD_CD == 'S82113M',
                  PRI_ICD_CD == 'S82113K', PRI_ICD_CD == 'S82112N', PRI_ICD_CD == 'S82112M',
                  PRI_ICD_CD == 'S82112K', PRI_ICD_CD == 'S82111N', PRI_ICD_CD == 'S82111M',
                  PRI_ICD_CD == 'S82111K', PRI_ICD_CD == 'S82109N', PRI_ICD_CD == 'S82109M',
                  PRI_ICD_CD == 'S82109K', PRI_ICD_CD == 'S82102N', PRI_ICD_CD == 'S82102M',
                  PRI_ICD_CD == 'S82102K', PRI_ICD_CD == 'S82101N', PRI_ICD_CD == 'S82101M',
                  PRI_ICD_CD == 'S82101K', PRI_ICD_CD == 'S82099N', PRI_ICD_CD == 'S82099M',
                  PRI_ICD_CD == 'S82099K', PRI_ICD_CD == 'S82092N', PRI_ICD_CD == 'S82092M',
                  PRI_ICD_CD == 'S82092K', PRI_ICD_CD == 'S82091N', PRI_ICD_CD == 'S82091M',
                  PRI_ICD_CD == 'S82091K', PRI_ICD_CD == 'S82046N', PRI_ICD_CD == 'S82046M',
                  PRI_ICD_CD == 'S82046K', PRI_ICD_CD == 'S82045N', PRI_ICD_CD == 'S82045M',
                  PRI_ICD_CD == 'S82045K', PRI_ICD_CD == 'S82044N', PRI_ICD_CD == 'S82044M',
                  PRI_ICD_CD == 'S82044K', PRI_ICD_CD == 'S82043N', PRI_ICD_CD == 'S82043M',
                  PRI_ICD_CD == 'S82043K', PRI_ICD_CD == 'S82042N', PRI_ICD_CD == 'S82042M',
                  PRI_ICD_CD == 'S82042K', PRI_ICD_CD == 'S82041N', PRI_ICD_CD == 'S82041M',
                  PRI_ICD_CD == 'S82041K', PRI_ICD_CD == 'S82036N', PRI_ICD_CD == 'S82036M',
                  PRI_ICD_CD == 'S82036K', PRI_ICD_CD == 'S82035N', PRI_ICD_CD == 'S82035M',
                  PRI_ICD_CD == 'S82035K', PRI_ICD_CD == 'S82034N', PRI_ICD_CD == 'S82034M',
                  PRI_ICD_CD == 'S82034K', PRI_ICD_CD == 'S82033N', PRI_ICD_CD == 'S82033M',
                  PRI_ICD_CD == 'S82033K', PRI_ICD_CD == 'S82032N', PRI_ICD_CD == 'S82032M',
                  PRI_ICD_CD == 'S82032K', PRI_ICD_CD == 'S82031N', PRI_ICD_CD == 'S82031M',
                  PRI_ICD_CD == 'S82031K', PRI_ICD_CD == 'S82026N', PRI_ICD_CD == 'S82026M',
                  PRI_ICD_CD == 'S82026K', PRI_ICD_CD == 'S82025N', PRI_ICD_CD == 'S82025M',
                  PRI_ICD_CD == 'S82025K', PRI_ICD_CD == 'S82024N', PRI_ICD_CD == 'S82024M',
                  PRI_ICD_CD == 'S82024K', PRI_ICD_CD == 'S82023N', PRI_ICD_CD == 'S82023M',
                  PRI_ICD_CD == 'S82023K', PRI_ICD_CD == 'S82022N', PRI_ICD_CD == 'S82022M',
                  PRI_ICD_CD == 'S82022K', PRI_ICD_CD == 'S82021N', PRI_ICD_CD == 'S82021M',
                  PRI_ICD_CD == 'S82021K', PRI_ICD_CD == 'S82016N', PRI_ICD_CD == 'S82016M',
                  PRI_ICD_CD == 'S82016K', PRI_ICD_CD == 'S82015N', PRI_ICD_CD == 'S82015M',
                  PRI_ICD_CD == 'S82015K', PRI_ICD_CD == 'S82014N', PRI_ICD_CD == 'S82014M',
                  PRI_ICD_CD == 'S82014K', PRI_ICD_CD == 'S82013N', PRI_ICD_CD == 'S82013M',
                  PRI_ICD_CD == 'S82013K', PRI_ICD_CD == 'S82012N', PRI_ICD_CD == 'S82012M',
                  PRI_ICD_CD == 'S82012K', PRI_ICD_CD == 'S82011N', PRI_ICD_CD == 'S82011M',
                  PRI_ICD_CD == 'S82011K', PRI_ICD_CD == 'S82009N', PRI_ICD_CD == 'S82009M',
                  PRI_ICD_CD == 'S82009K', PRI_ICD_CD == 'S82002N', PRI_ICD_CD == 'S82002M',
                  PRI_ICD_CD == 'S82002K', PRI_ICD_CD == 'S82001N', PRI_ICD_CD == 'S82001M',
                  PRI_ICD_CD == 'S82001K', PRI_ICD_CD == 'S79199K', PRI_ICD_CD == 'S79192K',
                  PRI_ICD_CD == 'S79191K', PRI_ICD_CD == 'S79149K', PRI_ICD_CD == 'S79142K',
                  PRI_ICD_CD == 'S79141K', PRI_ICD_CD == 'S79139K', PRI_ICD_CD == 'S79132K',
                  PRI_ICD_CD == 'S79131K', PRI_ICD_CD == 'S79129K', PRI_ICD_CD == 'S79122K',
                  PRI_ICD_CD == 'S79121K', PRI_ICD_CD == 'S79119K', PRI_ICD_CD == 'S79112K',
                  PRI_ICD_CD == 'S79111K', PRI_ICD_CD == 'S79109K', PRI_ICD_CD == 'S79102K',
                  PRI_ICD_CD == 'S79101K', PRI_ICD_CD == 'S79099K', PRI_ICD_CD == 'S79092K',
                  PRI_ICD_CD == 'S79091K', PRI_ICD_CD == 'S79019K', PRI_ICD_CD == 'S79012K',
                  PRI_ICD_CD == 'S79011K', PRI_ICD_CD == 'S79009K', PRI_ICD_CD == 'S79002K',
                  PRI_ICD_CD == 'S79001K', PRI_ICD_CD == 'S7292XN', PRI_ICD_CD == 'S7292XM',
                  PRI_ICD_CD == 'S7292XK', PRI_ICD_CD == 'S7291XN', PRI_ICD_CD == 'S7291XM',
                  PRI_ICD_CD == 'S7291XK', PRI_ICD_CD == 'S7290XN', PRI_ICD_CD == 'S7290XM',
                  PRI_ICD_CD == 'S7290XK', PRI_ICD_CD == 'S728X9N', PRI_ICD_CD == 'S728X9M',
                  PRI_ICD_CD == 'S728X9K', PRI_ICD_CD == 'S728X2N', PRI_ICD_CD == 'S728X2M',
                  PRI_ICD_CD == 'S728X2K', PRI_ICD_CD == 'S728X1N', PRI_ICD_CD == 'S728X1M',
                  PRI_ICD_CD == 'S728X1K', PRI_ICD_CD == 'S72499N', PRI_ICD_CD == 'S72499M',
                  PRI_ICD_CD == 'S72499K', PRI_ICD_CD == 'S72492N', PRI_ICD_CD == 'S72492M',
                  PRI_ICD_CD == 'S72492K', PRI_ICD_CD == 'S72491N', PRI_ICD_CD == 'S72491M',
                  PRI_ICD_CD == 'S72491K', PRI_ICD_CD == 'S72479K', PRI_ICD_CD == 'S72472K',
                  PRI_ICD_CD == 'S72471K', PRI_ICD_CD == 'S72466N', PRI_ICD_CD == 'S72466M',
                  PRI_ICD_CD == 'S72466K', PRI_ICD_CD == 'S72465N', PRI_ICD_CD == 'S72465M',
                  PRI_ICD_CD == 'S72465K', PRI_ICD_CD == 'S72464N', PRI_ICD_CD == 'S72464M',
                  PRI_ICD_CD == 'S72464K', PRI_ICD_CD == 'S72463N', PRI_ICD_CD == 'S72463M',
                  PRI_ICD_CD == 'S72463K', PRI_ICD_CD == 'S72462N', PRI_ICD_CD == 'S72462M',
                  PRI_ICD_CD == 'S72462K', PRI_ICD_CD == 'S72461N', PRI_ICD_CD == 'S72461M',
                  PRI_ICD_CD == 'S72461K', PRI_ICD_CD == 'S72456N', PRI_ICD_CD == 'S72456M',
                  PRI_ICD_CD == 'S72456K', PRI_ICD_CD == 'S72455N', PRI_ICD_CD == 'S72455M',
                  PRI_ICD_CD == 'S72455K', PRI_ICD_CD == 'S72454N', PRI_ICD_CD == 'S72454M',
                  PRI_ICD_CD == 'S72454K', PRI_ICD_CD == 'S72453N', PRI_ICD_CD == 'S72453M',
                  PRI_ICD_CD == 'S72453K', PRI_ICD_CD == 'S72452N', PRI_ICD_CD == 'S72452M',
                  PRI_ICD_CD == 'S72452K', PRI_ICD_CD == 'S72451N', PRI_ICD_CD == 'S72451M',
                  PRI_ICD_CD == 'S72451K', PRI_ICD_CD == 'S72446N', PRI_ICD_CD == 'S72446M',
                  PRI_ICD_CD == 'S72446K', PRI_ICD_CD == 'S72445N', PRI_ICD_CD == 'S72445M',
                  PRI_ICD_CD == 'S72445K', PRI_ICD_CD == 'S72444N', PRI_ICD_CD == 'S72444M',
                  PRI_ICD_CD == 'S72444K', PRI_ICD_CD == 'S72443N', PRI_ICD_CD == 'S72443M',
                  PRI_ICD_CD == 'S72443K', PRI_ICD_CD == 'S72442N', PRI_ICD_CD == 'S72442M',
                  PRI_ICD_CD == 'S72442K', PRI_ICD_CD == 'S72441N', PRI_ICD_CD == 'S72441M',
                  PRI_ICD_CD == 'S72441K', PRI_ICD_CD == 'S72436N', PRI_ICD_CD == 'S72436M',
                  PRI_ICD_CD == 'S72436K', PRI_ICD_CD == 'S72435N', PRI_ICD_CD == 'S72435M',
                  PRI_ICD_CD == 'S72435K', PRI_ICD_CD == 'S72434N', PRI_ICD_CD == 'S72434M',
                  PRI_ICD_CD == 'S72434K', PRI_ICD_CD == 'S72433N', PRI_ICD_CD == 'S72433M',
                  PRI_ICD_CD == 'S72433K', PRI_ICD_CD == 'S72432N', PRI_ICD_CD == 'S72432M',
                  PRI_ICD_CD == 'S72432K', PRI_ICD_CD == 'S72431N', PRI_ICD_CD == 'S72431M',
                  PRI_ICD_CD == 'S72431K', PRI_ICD_CD == 'S72426N', PRI_ICD_CD == 'S72426M',
                  PRI_ICD_CD == 'S72426K', PRI_ICD_CD == 'S72425N', PRI_ICD_CD == 'S72425M',
                  PRI_ICD_CD == 'S72425K', PRI_ICD_CD == 'S72424N', PRI_ICD_CD == 'S72424M',
                  PRI_ICD_CD == 'S72424K', PRI_ICD_CD == 'S72423N', PRI_ICD_CD == 'S72423M',
                  PRI_ICD_CD == 'S72423K', PRI_ICD_CD == 'S72422N', PRI_ICD_CD == 'S72422M',
                  PRI_ICD_CD == 'S72422K', PRI_ICD_CD == 'S72421N', PRI_ICD_CD == 'S72421M',
                  PRI_ICD_CD == 'S72421K', PRI_ICD_CD == 'S72416N', PRI_ICD_CD == 'S72416M',
                  PRI_ICD_CD == 'S72416K', PRI_ICD_CD == 'S72415N', PRI_ICD_CD == 'S72415M',
                  PRI_ICD_CD == 'S72415K', PRI_ICD_CD == 'S72414N', PRI_ICD_CD == 'S72414M',
                  PRI_ICD_CD == 'S72414K', PRI_ICD_CD == 'S72413N', PRI_ICD_CD == 'S72413M',
                  PRI_ICD_CD == 'S72413K', PRI_ICD_CD == 'S72412N', PRI_ICD_CD == 'S72412M',
                  PRI_ICD_CD == 'S72412K', PRI_ICD_CD == 'S72411N', PRI_ICD_CD == 'S72411M',
                  PRI_ICD_CD == 'S72411K', PRI_ICD_CD == 'S72409N', PRI_ICD_CD == 'S72409M',
                  PRI_ICD_CD == 'S72409K', PRI_ICD_CD == 'S72402N', PRI_ICD_CD == 'S72402M',
                  PRI_ICD_CD == 'S72402K', PRI_ICD_CD == 'S72401N', PRI_ICD_CD == 'S72401M',
                  PRI_ICD_CD == 'S72401K', PRI_ICD_CD == 'S72399N', PRI_ICD_CD == 'S72399M',
                  PRI_ICD_CD == 'S72399K', PRI_ICD_CD == 'S72392N', PRI_ICD_CD == 'S72392M',
                  PRI_ICD_CD == 'S72392K', PRI_ICD_CD == 'S72391N', PRI_ICD_CD == 'S72391M',
                  PRI_ICD_CD == 'S72391K', PRI_ICD_CD == 'S72366N', PRI_ICD_CD == 'S72366M',
                  PRI_ICD_CD == 'S72366K', PRI_ICD_CD == 'S72365N', PRI_ICD_CD == 'S72365M',
                  PRI_ICD_CD == 'S72365K', PRI_ICD_CD == 'S72364N', PRI_ICD_CD == 'S72364M',
                  PRI_ICD_CD == 'S72364K', PRI_ICD_CD == 'S72363N', PRI_ICD_CD == 'S72363M',
                  PRI_ICD_CD == 'S72363K', PRI_ICD_CD == 'S72362N', PRI_ICD_CD == 'S72362M',
                  PRI_ICD_CD == 'S72362K', PRI_ICD_CD == 'S72361N', PRI_ICD_CD == 'S72361M',
                  PRI_ICD_CD == 'S72361K', PRI_ICD_CD == 'S72356N', PRI_ICD_CD == 'S72356M',
                  PRI_ICD_CD == 'S72356K', PRI_ICD_CD == 'S72355N', PRI_ICD_CD == 'S72355M',
                  PRI_ICD_CD == 'S72355K', PRI_ICD_CD == 'S72354N', PRI_ICD_CD == 'S72354M',
                  PRI_ICD_CD == 'S72354K', PRI_ICD_CD == 'S72353N', PRI_ICD_CD == 'S72353M',
                  PRI_ICD_CD == 'S72353K', PRI_ICD_CD == 'S72352N', PRI_ICD_CD == 'S72352M',
                  PRI_ICD_CD == 'S72352K', PRI_ICD_CD == 'S72351N', PRI_ICD_CD == 'S72351M',
                  PRI_ICD_CD == 'S72351K', PRI_ICD_CD == 'S72346N', PRI_ICD_CD == 'S72346M',
                  PRI_ICD_CD == 'S72346K', PRI_ICD_CD == 'S72345N', PRI_ICD_CD == 'S72345M',
                  PRI_ICD_CD == 'S72345K', PRI_ICD_CD == 'S72344N', PRI_ICD_CD == 'S72344M',
                  PRI_ICD_CD == 'S72344K', PRI_ICD_CD == 'S72343N', PRI_ICD_CD == 'S72343M',
                  PRI_ICD_CD == 'S72343K', PRI_ICD_CD == 'S72342N', PRI_ICD_CD == 'S72342M',
                  PRI_ICD_CD == 'S72342K', PRI_ICD_CD == 'S72341N', PRI_ICD_CD == 'S72341M',
                  PRI_ICD_CD == 'S72341K', PRI_ICD_CD == 'S72336N', PRI_ICD_CD == 'S72336M',
                  PRI_ICD_CD == 'S72336K', PRI_ICD_CD == 'S72335N', PRI_ICD_CD == 'S72335M',
                  PRI_ICD_CD == 'S72335K', PRI_ICD_CD == 'S72334N', PRI_ICD_CD == 'S72334M',
                  PRI_ICD_CD == 'S72334K', PRI_ICD_CD == 'S72333N', PRI_ICD_CD == 'S72333M',
                  PRI_ICD_CD == 'S72333K', PRI_ICD_CD == 'S72332N', PRI_ICD_CD == 'S72332M',
                  PRI_ICD_CD == 'S72332K', PRI_ICD_CD == 'S72331N', PRI_ICD_CD == 'S72331M',
                  PRI_ICD_CD == 'S72331K', PRI_ICD_CD == 'S72326N', PRI_ICD_CD == 'S72326M',
                  PRI_ICD_CD == 'S72326K', PRI_ICD_CD == 'S72325N', PRI_ICD_CD == 'S72325M',
                  PRI_ICD_CD == 'S72325K', PRI_ICD_CD == 'S72324N', PRI_ICD_CD == 'S72324M',
                  PRI_ICD_CD == 'S72324K', PRI_ICD_CD == 'S72323N', PRI_ICD_CD == 'S72323M',
                  PRI_ICD_CD == 'S72323K', PRI_ICD_CD == 'S72322N', PRI_ICD_CD == 'S72322M',
                  PRI_ICD_CD == 'S72322K', PRI_ICD_CD == 'S72321N', PRI_ICD_CD == 'S72321M',
                  PRI_ICD_CD == 'S72321K', PRI_ICD_CD == 'S72309N', PRI_ICD_CD == 'S72309M',
                  PRI_ICD_CD == 'S72309K', PRI_ICD_CD == 'S72302N', PRI_ICD_CD == 'S72302M',
                  PRI_ICD_CD == 'S72302K', PRI_ICD_CD == 'S72301N', PRI_ICD_CD == 'S72301M',
                  PRI_ICD_CD == 'S72301K', PRI_ICD_CD == 'S7226XN', PRI_ICD_CD == 'S7226XM',
                  PRI_ICD_CD == 'S7226XK', PRI_ICD_CD == 'S7225XN', PRI_ICD_CD == 'S7225XM',
                  PRI_ICD_CD == 'S7225XK', PRI_ICD_CD == 'S7224XN', PRI_ICD_CD == 'S7224XM',
                  PRI_ICD_CD == 'S7224XK', PRI_ICD_CD == 'S7223XN', PRI_ICD_CD == 'S7223XM',
                  PRI_ICD_CD == 'S7223XK', PRI_ICD_CD == 'S7222XN', PRI_ICD_CD == 'S7222XM',
                  PRI_ICD_CD == 'S7222XK', PRI_ICD_CD == 'S7221XN', PRI_ICD_CD == 'S7221XM',
                  PRI_ICD_CD == 'S7221XK', PRI_ICD_CD == 'S72146N', PRI_ICD_CD == 'S72146M',
                  PRI_ICD_CD == 'S72146K', PRI_ICD_CD == 'S72145N', PRI_ICD_CD == 'S72145M',
                  PRI_ICD_CD == 'S72145K', PRI_ICD_CD == 'S72144N', PRI_ICD_CD == 'S72144M',
                  PRI_ICD_CD == 'S72144K', PRI_ICD_CD == 'S72143N', PRI_ICD_CD == 'S72143M',
                  PRI_ICD_CD == 'S72143K', PRI_ICD_CD == 'S72142N', PRI_ICD_CD == 'S72142M',
                  PRI_ICD_CD == 'S72142K', PRI_ICD_CD == 'S72141N', PRI_ICD_CD == 'S72141M',
                  PRI_ICD_CD == 'S72141K', PRI_ICD_CD == 'S72136N', PRI_ICD_CD == 'S72136M',
                  PRI_ICD_CD == 'S72136K', PRI_ICD_CD == 'S72135N', PRI_ICD_CD == 'S72135M',
                  PRI_ICD_CD == 'S72135K', PRI_ICD_CD == 'S72134N', PRI_ICD_CD == 'S72134M',
                  PRI_ICD_CD == 'S72134K', PRI_ICD_CD == 'S72133N', PRI_ICD_CD == 'S72133M',
                  PRI_ICD_CD == 'S72133K', PRI_ICD_CD == 'S72132N', PRI_ICD_CD == 'S72132M',
                  PRI_ICD_CD == 'S72132K', PRI_ICD_CD == 'S72131N', PRI_ICD_CD == 'S72131M',
                  PRI_ICD_CD == 'S72131K', PRI_ICD_CD == 'S72126N', PRI_ICD_CD == 'S72126M',
                  PRI_ICD_CD == 'S72126K', PRI_ICD_CD == 'S72125N', PRI_ICD_CD == 'S72125M',
                  PRI_ICD_CD == 'S72125K', PRI_ICD_CD == 'S72124N', PRI_ICD_CD == 'S72124M',
                  PRI_ICD_CD == 'S72124K', PRI_ICD_CD == 'S72123N', PRI_ICD_CD == 'S72123M',
                  PRI_ICD_CD == 'S72123K', PRI_ICD_CD == 'S72122N', PRI_ICD_CD == 'S72122M',
                  PRI_ICD_CD == 'S72122K', PRI_ICD_CD == 'S72121N', PRI_ICD_CD == 'S72121M',
                  PRI_ICD_CD == 'S72121K', PRI_ICD_CD == 'S72116N', PRI_ICD_CD == 'S72116M',
                  PRI_ICD_CD == 'S72116K', PRI_ICD_CD == 'S72115N', PRI_ICD_CD == 'S72115M',
                  PRI_ICD_CD == 'S72115K', PRI_ICD_CD == 'S72114N', PRI_ICD_CD == 'S72114M',
                  PRI_ICD_CD == 'S72114K', PRI_ICD_CD == 'S72113N', PRI_ICD_CD == 'S72113M',
                  PRI_ICD_CD == 'S72113K', PRI_ICD_CD == 'S72112N', PRI_ICD_CD == 'S72112M',
                  PRI_ICD_CD == 'S72112K', PRI_ICD_CD == 'S72111N', PRI_ICD_CD == 'S72111M',
                  PRI_ICD_CD == 'S72111K', PRI_ICD_CD == 'S72109N', PRI_ICD_CD == 'S72109M',
                  PRI_ICD_CD == 'S72109K', PRI_ICD_CD == 'S72102N', PRI_ICD_CD == 'S72102M',
                  PRI_ICD_CD == 'S72102K', PRI_ICD_CD == 'S72101N', PRI_ICD_CD == 'S72101M',
                  PRI_ICD_CD == 'S72101K', PRI_ICD_CD == 'S72099N', PRI_ICD_CD == 'S72099M',
                  PRI_ICD_CD == 'S72099K', PRI_ICD_CD == 'S72092N', PRI_ICD_CD == 'S72092M',
                  PRI_ICD_CD == 'S72092K', PRI_ICD_CD == 'S72091N', PRI_ICD_CD == 'S72091M',
                  PRI_ICD_CD == 'S72091K', PRI_ICD_CD == 'S72066N', PRI_ICD_CD == 'S72066M',
                  PRI_ICD_CD == 'S72066K', PRI_ICD_CD == 'S72065N', PRI_ICD_CD == 'S72065M',
                  PRI_ICD_CD == 'S72065K', PRI_ICD_CD == 'S72064N', PRI_ICD_CD == 'S72064M',
                  PRI_ICD_CD == 'S72064K', PRI_ICD_CD == 'S72063N', PRI_ICD_CD == 'S72063M',
                  PRI_ICD_CD == 'S72063K', PRI_ICD_CD == 'S72062N', PRI_ICD_CD == 'S72062M',
                  PRI_ICD_CD == 'S72062K', PRI_ICD_CD == 'S72061N', PRI_ICD_CD == 'S72061M',
                  PRI_ICD_CD == 'S72061K', PRI_ICD_CD == 'S72059N', PRI_ICD_CD == 'S72059M',
                  PRI_ICD_CD == 'S72059K', PRI_ICD_CD == 'S72052N', PRI_ICD_CD == 'S72052M',
                  PRI_ICD_CD == 'S72052K', PRI_ICD_CD == 'S72051N', PRI_ICD_CD == 'S72051M',
                  PRI_ICD_CD == 'S72051K', PRI_ICD_CD == 'S72046N', PRI_ICD_CD == 'S72046M',
                  PRI_ICD_CD == 'S72046K', PRI_ICD_CD == 'S72045N', PRI_ICD_CD == 'S72045M',
                  PRI_ICD_CD == 'S72045K', PRI_ICD_CD == 'S72044N', PRI_ICD_CD == 'S72044M',
                  PRI_ICD_CD == 'S72044K', PRI_ICD_CD == 'S72043N', PRI_ICD_CD == 'S72043M',
                  PRI_ICD_CD == 'S72043K', PRI_ICD_CD == 'S72042M', PRI_ICD_CD == 'S72042K',
                  PRI_ICD_CD == 'S72041N', PRI_ICD_CD == 'S72041M', PRI_ICD_CD == 'S72036N',
                  PRI_ICD_CD == 'S72036M', PRI_ICD_CD == 'S72036K', PRI_ICD_CD == 'S72035N',
                  PRI_ICD_CD == 'S72035M', PRI_ICD_CD == 'S72035K', PRI_ICD_CD == 'S72034N',
                  PRI_ICD_CD == 'S72034M', PRI_ICD_CD == 'S72034K', PRI_ICD_CD == 'S72033N',
                  PRI_ICD_CD == 'S72033M', PRI_ICD_CD == 'S72033K', PRI_ICD_CD == 'S72032N',
                  PRI_ICD_CD == 'S72032M', PRI_ICD_CD == 'S72032K', PRI_ICD_CD == 'S72031N',
                  PRI_ICD_CD == 'S72031M', PRI_ICD_CD == 'S72031K', PRI_ICD_CD == 'S72026N',
                  PRI_ICD_CD == 'S72026M', PRI_ICD_CD == 'S72026K', PRI_ICD_CD == 'S72025N',
                  PRI_ICD_CD == 'S72025M', PRI_ICD_CD == 'S72025K', PRI_ICD_CD == 'S72024N',
                  PRI_ICD_CD == 'S72024M', PRI_ICD_CD == 'S72024K', PRI_ICD_CD == 'S72023N',
                  PRI_ICD_CD == 'S72023M', PRI_ICD_CD == 'S72023K', PRI_ICD_CD == 'S72022N',
                  PRI_ICD_CD == 'S72022M', PRI_ICD_CD == 'S72022K', PRI_ICD_CD == 'S72021N',
                  PRI_ICD_CD == 'S72021M', PRI_ICD_CD == 'S72021K', PRI_ICD_CD == 'S72019N',
                  PRI_ICD_CD == 'S72019M', PRI_ICD_CD == 'S72019K', PRI_ICD_CD == 'S72012N',
                  PRI_ICD_CD == 'S72012M', PRI_ICD_CD == 'S72012K', PRI_ICD_CD == 'S72011N',
                  PRI_ICD_CD == 'S72011M', PRI_ICD_CD == 'S72011K', PRI_ICD_CD == 'S72009N',
                  PRI_ICD_CD == 'S72009M', PRI_ICD_CD == 'S72009K', PRI_ICD_CD == 'S72002N',
                  PRI_ICD_CD == 'S72002M', PRI_ICD_CD == 'S72002K', PRI_ICD_CD == 'S72001N',
                  PRI_ICD_CD == 'S72001M', PRI_ICD_CD == 'S72001K', PRI_ICD_CD == 'S6292XK',
                  PRI_ICD_CD == 'S6291XK', PRI_ICD_CD == 'S6290XK', PRI_ICD_CD == 'S62669K',
                  PRI_ICD_CD == 'S62668K', PRI_ICD_CD == 'S62667K', PRI_ICD_CD == 'S62666K',
                  PRI_ICD_CD == 'S62665K', PRI_ICD_CD == 'S62664K', PRI_ICD_CD == 'S62663K',
                  PRI_ICD_CD == 'S62662K', PRI_ICD_CD == 'S62661K', PRI_ICD_CD == 'S62660K',
                  PRI_ICD_CD == 'S62659K', PRI_ICD_CD == 'S62658K', PRI_ICD_CD == 'S62657K',
                  PRI_ICD_CD == 'S62656K', PRI_ICD_CD == 'S62655K', PRI_ICD_CD == 'S62654K',
                  PRI_ICD_CD == 'S62653K', PRI_ICD_CD == 'S62652K', PRI_ICD_CD == 'S62651K',
                  PRI_ICD_CD == 'S62650K', PRI_ICD_CD == 'S62649K', PRI_ICD_CD == 'S62648K',
                  PRI_ICD_CD == 'S62647K', PRI_ICD_CD == 'S62646K', PRI_ICD_CD == 'S62645K',
                  PRI_ICD_CD == 'S62644K', PRI_ICD_CD == 'S62643K', PRI_ICD_CD == 'S62642K',
                  PRI_ICD_CD == 'S62641K', PRI_ICD_CD == 'S62640K', PRI_ICD_CD == 'S62639K',
                  PRI_ICD_CD == 'S62638K', PRI_ICD_CD == 'S62637K', PRI_ICD_CD == 'S62636K',
                  PRI_ICD_CD == 'S62635K', PRI_ICD_CD == 'S62634K', PRI_ICD_CD == 'S62633K',
                  PRI_ICD_CD == 'S62632K', PRI_ICD_CD == 'S62631K', PRI_ICD_CD == 'S62630K',
                  PRI_ICD_CD == 'S62629K', PRI_ICD_CD == 'S62628K', PRI_ICD_CD == 'S62627K',
                  PRI_ICD_CD == 'S62626K', PRI_ICD_CD == 'S62625K', PRI_ICD_CD == 'S62624K',
                  PRI_ICD_CD == 'S62623K', PRI_ICD_CD == 'S62622K', PRI_ICD_CD == 'S62621K',
                  PRI_ICD_CD == 'S62620K', PRI_ICD_CD == 'S62619K', PRI_ICD_CD == 'S62618K',
                  PRI_ICD_CD == 'S62617K', PRI_ICD_CD == 'S62616K', PRI_ICD_CD == 'S62615K',
                  PRI_ICD_CD == 'S62614K', PRI_ICD_CD == 'S62613K', PRI_ICD_CD == 'S62612K',
                  PRI_ICD_CD == 'S62611K', PRI_ICD_CD == 'S62610K', PRI_ICD_CD == 'S62609K',
                  PRI_ICD_CD == 'S62608K', PRI_ICD_CD == 'S62607K', PRI_ICD_CD == 'S62606K',
                  PRI_ICD_CD == 'S62605K', PRI_ICD_CD == 'S62604K', PRI_ICD_CD == 'S62603K',
                  PRI_ICD_CD == 'S62602K', PRI_ICD_CD == 'S62601K', PRI_ICD_CD == 'S62600K',
                  PRI_ICD_CD == 'S62526K', PRI_ICD_CD == 'S62525K', PRI_ICD_CD == 'S62524K',
                  PRI_ICD_CD == 'S62523K', PRI_ICD_CD == 'S62522K', PRI_ICD_CD == 'S62521K',
                  PRI_ICD_CD == 'S62516K', PRI_ICD_CD == 'S62515K', PRI_ICD_CD == 'S62514K',
                  PRI_ICD_CD == 'S62513K', PRI_ICD_CD == 'S62512K', PRI_ICD_CD == 'S62511K',
                  PRI_ICD_CD == 'S62509K', PRI_ICD_CD == 'S62502K', PRI_ICD_CD == 'S62501K',
                  PRI_ICD_CD == 'S62399K', PRI_ICD_CD == 'S62398K', PRI_ICD_CD == 'S62397K',
                  PRI_ICD_CD == 'S62396K', PRI_ICD_CD == 'S62395K', PRI_ICD_CD == 'S62394K',
                  PRI_ICD_CD == 'S62393K', PRI_ICD_CD == 'S62392K', PRI_ICD_CD == 'S62391K',
                  PRI_ICD_CD == 'S62390K', PRI_ICD_CD == 'S62369K', PRI_ICD_CD == 'S62368K',
                  PRI_ICD_CD == 'S62367K', PRI_ICD_CD == 'S62366K', PRI_ICD_CD == 'S62365K',
                  PRI_ICD_CD == 'S62364K', PRI_ICD_CD == 'S62363K', PRI_ICD_CD == 'S62362K',
                  PRI_ICD_CD == 'S62361K', PRI_ICD_CD == 'S62360K', PRI_ICD_CD == 'S62359K',
                  PRI_ICD_CD == 'S62358K', PRI_ICD_CD == 'S62357K', PRI_ICD_CD == 'S62356K',
                  PRI_ICD_CD == 'S62355K', PRI_ICD_CD == 'S62354K', PRI_ICD_CD == 'S62353K',
                  PRI_ICD_CD == 'S62352K', PRI_ICD_CD == 'S62351K', PRI_ICD_CD == 'S62350K',
                  PRI_ICD_CD == 'S62349K', PRI_ICD_CD == 'S62348K', PRI_ICD_CD == 'S62347K',
                  PRI_ICD_CD == 'S62346K', PRI_ICD_CD == 'S62345K', PRI_ICD_CD == 'S62344K',
                  PRI_ICD_CD == 'S62343K', PRI_ICD_CD == 'S62342K', PRI_ICD_CD == 'S62341K',
                  PRI_ICD_CD == 'S62340K', PRI_ICD_CD == 'S62339K', PRI_ICD_CD == 'S62338K',
                  PRI_ICD_CD == 'S62337K', PRI_ICD_CD == 'S62336K', PRI_ICD_CD == 'S62335K',
                  PRI_ICD_CD == 'S62334K', PRI_ICD_CD == 'S62333K', PRI_ICD_CD == 'S62332K',
                  PRI_ICD_CD == 'S62331K', PRI_ICD_CD == 'S62330K', PRI_ICD_CD == 'S62329K',
                  PRI_ICD_CD == 'S62328K', PRI_ICD_CD == 'S62327K', PRI_ICD_CD == 'S62326K',
                  PRI_ICD_CD == 'S62325K', PRI_ICD_CD == 'S62324K', PRI_ICD_CD == 'S62323K',
                  PRI_ICD_CD == 'S62322K', PRI_ICD_CD == 'S62321K', PRI_ICD_CD == 'S62320K',
                  PRI_ICD_CD == 'S62319K', PRI_ICD_CD == 'S62318K', PRI_ICD_CD == 'S62317K',
                  PRI_ICD_CD == 'S62316K', PRI_ICD_CD == 'S62315K', PRI_ICD_CD == 'S62314K',
                  PRI_ICD_CD == 'S62313K', PRI_ICD_CD == 'S62312K', PRI_ICD_CD == 'S62311K',
                  PRI_ICD_CD == 'S62310K', PRI_ICD_CD == 'S62309K', PRI_ICD_CD == 'S62308K',
                  PRI_ICD_CD == 'S62307K', PRI_ICD_CD == 'S62306K', PRI_ICD_CD == 'S62305K',
                  PRI_ICD_CD == 'S62304K', PRI_ICD_CD == 'S62303K', PRI_ICD_CD == 'S62302K',
                  PRI_ICD_CD == 'S62301K', PRI_ICD_CD == 'S62300K', PRI_ICD_CD == 'S62299K',
                  PRI_ICD_CD == 'S62292K', PRI_ICD_CD == 'S62291K', PRI_ICD_CD == 'S62256K',
                  PRI_ICD_CD == 'S62255K', PRI_ICD_CD == 'S62254K', PRI_ICD_CD == 'S62253K',
                  PRI_ICD_CD == 'S62252K', PRI_ICD_CD == 'S62251K', PRI_ICD_CD == 'S62246K',
                  PRI_ICD_CD == 'S62245K', PRI_ICD_CD == 'S62244K', PRI_ICD_CD == 'S62243K',
                  PRI_ICD_CD == 'S62242K', PRI_ICD_CD == 'S62241K', PRI_ICD_CD == 'S62236K',
                  PRI_ICD_CD == 'S62235K', PRI_ICD_CD == 'S62234K', PRI_ICD_CD == 'S62233P',
                  PRI_ICD_CD == 'S62233K', PRI_ICD_CD == 'S62232K', PRI_ICD_CD == 'S62231K',
                  PRI_ICD_CD == 'S62226K', PRI_ICD_CD == 'S62225K', PRI_ICD_CD == 'S62224K',
                  PRI_ICD_CD == 'S62223K', PRI_ICD_CD == 'S62222K', PRI_ICD_CD == 'S62221K',
                  PRI_ICD_CD == 'S62213K', PRI_ICD_CD == 'S62212K', PRI_ICD_CD == 'S62211K',
                  PRI_ICD_CD == 'S62209K', PRI_ICD_CD == 'S62202K', PRI_ICD_CD == 'S62201K',
                  PRI_ICD_CD == 'S62186K', PRI_ICD_CD == 'S62185K', PRI_ICD_CD == 'S62184K',
                  PRI_ICD_CD == 'S62183K', PRI_ICD_CD == 'S62182K', PRI_ICD_CD == 'S62181K',
                  PRI_ICD_CD == 'S62176K', PRI_ICD_CD == 'S62175K', PRI_ICD_CD == 'S62174K',
                  PRI_ICD_CD == 'S62173K', PRI_ICD_CD == 'S62172K', PRI_ICD_CD == 'S62171K',
                  PRI_ICD_CD == 'S62166K', PRI_ICD_CD == 'S62165K', PRI_ICD_CD == 'S62164K',
                  PRI_ICD_CD == 'S62163K', PRI_ICD_CD == 'S62162K', PRI_ICD_CD == 'S62161K',
                  PRI_ICD_CD == 'S62156K', PRI_ICD_CD == 'S62155K', PRI_ICD_CD == 'S62154K',
                  PRI_ICD_CD == 'S62153K', PRI_ICD_CD == 'S62152K', PRI_ICD_CD == 'S62151K',
                  PRI_ICD_CD == 'S62146K', PRI_ICD_CD == 'S62145K', PRI_ICD_CD == 'S62144K',
                  PRI_ICD_CD == 'S62143K', PRI_ICD_CD == 'S62142K', PRI_ICD_CD == 'S62141K',
                  PRI_ICD_CD == 'S62136K', PRI_ICD_CD == 'S62135K', PRI_ICD_CD == 'S62134K',
                  PRI_ICD_CD == 'S62133K', PRI_ICD_CD == 'S62132K', PRI_ICD_CD == 'S62131K',
                  PRI_ICD_CD == 'S62126K', PRI_ICD_CD == 'S62125K', PRI_ICD_CD == 'S62124K',
                  PRI_ICD_CD == 'S62123K', PRI_ICD_CD == 'S62122K', PRI_ICD_CD == 'S62121K',
                  PRI_ICD_CD == 'S62116K', PRI_ICD_CD == 'S62115K', PRI_ICD_CD == 'S62114K',
                  PRI_ICD_CD == 'S62113K', PRI_ICD_CD == 'S62112K', PRI_ICD_CD == 'S62111K',
                  PRI_ICD_CD == 'S62109K', PRI_ICD_CD == 'S62102K', PRI_ICD_CD == 'S62101K',
                  PRI_ICD_CD == 'S62036K', PRI_ICD_CD == 'S62035K', PRI_ICD_CD == 'S62034K',
                  PRI_ICD_CD == 'S62033K', PRI_ICD_CD == 'S62032K', PRI_ICD_CD == 'S62031K',
                  PRI_ICD_CD == 'S62026K', PRI_ICD_CD == 'S62025K', PRI_ICD_CD == 'S62024K',
                  PRI_ICD_CD == 'S62023K', PRI_ICD_CD == 'S62022K', PRI_ICD_CD == 'S62021K',
                  PRI_ICD_CD == 'S62016K', PRI_ICD_CD == 'S62015K', PRI_ICD_CD == 'S62014K',
                  PRI_ICD_CD == 'S62013K', PRI_ICD_CD == 'S62012K', PRI_ICD_CD == 'S62011K',
                  PRI_ICD_CD == 'S62009K', PRI_ICD_CD == 'S62002K', PRI_ICD_CD == 'S62001K',
                  PRI_ICD_CD == 'S59299K', PRI_ICD_CD == 'S59292K', PRI_ICD_CD == 'S59291K',
                  PRI_ICD_CD == 'S59249K', PRI_ICD_CD == 'S59242K', PRI_ICD_CD == 'S59241K',
                  PRI_ICD_CD == 'S59239K', PRI_ICD_CD == 'S59232K', PRI_ICD_CD == 'S59231K',
                  PRI_ICD_CD == 'S59229K', PRI_ICD_CD == 'S59222K', PRI_ICD_CD == 'S59221K',
                  PRI_ICD_CD == 'S59219K', PRI_ICD_CD == 'S59212K', PRI_ICD_CD == 'S59211K',
                  PRI_ICD_CD == 'S59209K', PRI_ICD_CD == 'S59202K', PRI_ICD_CD == 'S59201K',
                  PRI_ICD_CD == 'S59199K', PRI_ICD_CD == 'S59192K', PRI_ICD_CD == 'S59191K',
                  PRI_ICD_CD == 'S59149K', PRI_ICD_CD == 'S59142K', PRI_ICD_CD == 'S59141K',
                  PRI_ICD_CD == 'S59139K', PRI_ICD_CD == 'S59132K', PRI_ICD_CD == 'S59131K',
                  PRI_ICD_CD == 'S59129K', PRI_ICD_CD == 'S59122K', PRI_ICD_CD == 'S59121K',
                  PRI_ICD_CD == 'S59119K', PRI_ICD_CD == 'S59112K', PRI_ICD_CD == 'S59111K',
                  PRI_ICD_CD == 'S59109K', PRI_ICD_CD == 'S59102K', PRI_ICD_CD == 'S59101K',
                  PRI_ICD_CD == 'S59099K', PRI_ICD_CD == 'S59092K', PRI_ICD_CD == 'S59091K',
                  PRI_ICD_CD == 'S59049K', PRI_ICD_CD == 'S59042K', PRI_ICD_CD == 'S59041K',
                  PRI_ICD_CD == 'S59039K', PRI_ICD_CD == 'S59032K', PRI_ICD_CD == 'S59031K',
                  PRI_ICD_CD == 'S59029K', PRI_ICD_CD == 'S59022K', PRI_ICD_CD == 'S59021K',
                  PRI_ICD_CD == 'S59019K', PRI_ICD_CD == 'S59012K', PRI_ICD_CD == 'S59011K',
                  PRI_ICD_CD == 'S59009K', PRI_ICD_CD == 'S59002K', PRI_ICD_CD == 'S59001K',
                  PRI_ICD_CD == 'S5292XN', PRI_ICD_CD == 'S5292XM', PRI_ICD_CD == 'S5292XK',
                  PRI_ICD_CD == 'S5291XN', PRI_ICD_CD == 'S5291XM', PRI_ICD_CD == 'S5291XK',
                  PRI_ICD_CD == 'S5290XN', PRI_ICD_CD == 'S5290XM', PRI_ICD_CD == 'S5290XK',
                  PRI_ICD_CD == 'S52699N', PRI_ICD_CD == 'S52699M', PRI_ICD_CD == 'S52699K',
                  PRI_ICD_CD == 'S52692N', PRI_ICD_CD == 'S52692M', PRI_ICD_CD == 'S52692K',
                  PRI_ICD_CD == 'S52691N', PRI_ICD_CD == 'S52691M', PRI_ICD_CD == 'S52691K',
                  PRI_ICD_CD == 'S52629K', PRI_ICD_CD == 'S52622K', PRI_ICD_CD == 'S52621K',
                  PRI_ICD_CD == 'S52616N', PRI_ICD_CD == 'S52616M', PRI_ICD_CD == 'S52616K',
                  PRI_ICD_CD == 'S52615N', PRI_ICD_CD == 'S52615M', PRI_ICD_CD == 'S52615K',
                  PRI_ICD_CD == 'S52614N', PRI_ICD_CD == 'S52614M', PRI_ICD_CD == 'S52614K',
                  PRI_ICD_CD == 'S52613N', PRI_ICD_CD == 'S52613M', PRI_ICD_CD == 'S52613K',
                  PRI_ICD_CD == 'S52612N', PRI_ICD_CD == 'S52612M', PRI_ICD_CD == 'S52612K',
                  PRI_ICD_CD == 'S52611N', PRI_ICD_CD == 'S52611M', PRI_ICD_CD == 'S52611K',
                  PRI_ICD_CD == 'S52609N', PRI_ICD_CD == 'S52609M', PRI_ICD_CD == 'S52609K',
                  PRI_ICD_CD == 'S52602N', PRI_ICD_CD == 'S52602M', PRI_ICD_CD == 'S52602K',
                  PRI_ICD_CD == 'S52601N', PRI_ICD_CD == 'S52601M', PRI_ICD_CD == 'S52601K',
                  PRI_ICD_CD == 'S52599N', PRI_ICD_CD == 'S52599M', PRI_ICD_CD == 'S52599K',
                  PRI_ICD_CD == 'S52592N', PRI_ICD_CD == 'S52592M', PRI_ICD_CD == 'S52592K',
                  PRI_ICD_CD == 'S52591N', PRI_ICD_CD == 'S52591M', PRI_ICD_CD == 'S52591K',
                  PRI_ICD_CD == 'S52579N', PRI_ICD_CD == 'S52579M', PRI_ICD_CD == 'S52579K',
                  PRI_ICD_CD == 'S52572N', PRI_ICD_CD == 'S52572M', PRI_ICD_CD == 'S52572K',
                  PRI_ICD_CD == 'S52571N', PRI_ICD_CD == 'S52571M', PRI_ICD_CD == 'S52571K',
                  PRI_ICD_CD == 'S52569N', PRI_ICD_CD == 'S52569M', PRI_ICD_CD == 'S52569K',
                  PRI_ICD_CD == 'S52562N', PRI_ICD_CD == 'S52562M', PRI_ICD_CD == 'S52562K',
                  PRI_ICD_CD == 'S52561N', PRI_ICD_CD == 'S52561M', PRI_ICD_CD == 'S52561K',
                  PRI_ICD_CD == 'S52559N', PRI_ICD_CD == 'S52559M', PRI_ICD_CD == 'S52559K',
                  PRI_ICD_CD == 'S52552N', PRI_ICD_CD == 'S52552M', PRI_ICD_CD == 'S52552K',
                  PRI_ICD_CD == 'S52551N', PRI_ICD_CD == 'S52551M', PRI_ICD_CD == 'S52551K',
                  PRI_ICD_CD == 'S52549N', PRI_ICD_CD == 'S52549M', PRI_ICD_CD == 'S52549K',
                  PRI_ICD_CD == 'S52542N', PRI_ICD_CD == 'S52542M', PRI_ICD_CD == 'S52542K',
                  PRI_ICD_CD == 'S52541N', PRI_ICD_CD == 'S52541M', PRI_ICD_CD == 'S52541K',
                  PRI_ICD_CD == 'S52539N', PRI_ICD_CD == 'S52539M', PRI_ICD_CD == 'S52539K',
                  PRI_ICD_CD == 'S52532N', PRI_ICD_CD == 'S52532M', PRI_ICD_CD == 'S52532K',
                  PRI_ICD_CD == 'S52531N', PRI_ICD_CD == 'S52531M', PRI_ICD_CD == 'S52531K',
                  PRI_ICD_CD == 'S52529K', PRI_ICD_CD == 'S52522K', PRI_ICD_CD == 'S52521K',
                  PRI_ICD_CD == 'S52516N', PRI_ICD_CD == 'S52516M', PRI_ICD_CD == 'S52516K',
                  PRI_ICD_CD == 'S52515N', PRI_ICD_CD == 'S52515M', PRI_ICD_CD == 'S52515K',
                  PRI_ICD_CD == 'S52514N', PRI_ICD_CD == 'S52514M', PRI_ICD_CD == 'S52514K',
                  PRI_ICD_CD == 'S52513N', PRI_ICD_CD == 'S52513M', PRI_ICD_CD == 'S52513K',
                  PRI_ICD_CD == 'S52512N', PRI_ICD_CD == 'S52512M', PRI_ICD_CD == 'S52512K',
                  PRI_ICD_CD == 'S52511N', PRI_ICD_CD == 'S52511M', PRI_ICD_CD == 'S52511K',
                  PRI_ICD_CD == 'S52509N', PRI_ICD_CD == 'S52509M', PRI_ICD_CD == 'S52509K',
                  PRI_ICD_CD == 'S52502N', PRI_ICD_CD == 'S52502M', PRI_ICD_CD == 'S52502K',
                  PRI_ICD_CD == 'S52501N', PRI_ICD_CD == 'S52501M', PRI_ICD_CD == 'S52501K',
                  PRI_ICD_CD == 'S52399N', PRI_ICD_CD == 'S52399M', PRI_ICD_CD == 'S52399K',
                  PRI_ICD_CD == 'S52392N', PRI_ICD_CD == 'S52392M', PRI_ICD_CD == 'S52392K',
                  PRI_ICD_CD == 'S52391N', PRI_ICD_CD == 'S52391M', PRI_ICD_CD == 'S52391K',
                  PRI_ICD_CD == 'S52389N', PRI_ICD_CD == 'S52389M', PRI_ICD_CD == 'S52389K',
                  PRI_ICD_CD == 'S52382N', PRI_ICD_CD == 'S52382M', PRI_ICD_CD == 'S52382K',
                  PRI_ICD_CD == 'S52381N', PRI_ICD_CD == 'S52381M', PRI_ICD_CD == 'S52381K',
                  PRI_ICD_CD == 'S52379N', PRI_ICD_CD == 'S52379M', PRI_ICD_CD == 'S52379K',
                  PRI_ICD_CD == 'S52372N', PRI_ICD_CD == 'S52372M', PRI_ICD_CD == 'S52372K',
                  PRI_ICD_CD == 'S52371N', PRI_ICD_CD == 'S52371M', PRI_ICD_CD == 'S52371K',
                  PRI_ICD_CD == 'S52366N', PRI_ICD_CD == 'S52366M', PRI_ICD_CD == 'S52366K',
                  PRI_ICD_CD == 'S52365N', PRI_ICD_CD == 'S52365M', PRI_ICD_CD == 'S52365K',
                  PRI_ICD_CD == 'S52364N', PRI_ICD_CD == 'S52364M', PRI_ICD_CD == 'S52364K',
                  PRI_ICD_CD == 'S52363N', PRI_ICD_CD == 'S52363M', PRI_ICD_CD == 'S52363K',
                  PRI_ICD_CD == 'S52362N', PRI_ICD_CD == 'S52362M', PRI_ICD_CD == 'S52362K',
                  PRI_ICD_CD == 'S52361N', PRI_ICD_CD == 'S52361M', PRI_ICD_CD == 'S52361K',
                  PRI_ICD_CD == 'S52356N', PRI_ICD_CD == 'S52356M', PRI_ICD_CD == 'S52356K',
                  PRI_ICD_CD == 'S52355N', PRI_ICD_CD == 'S52355M', PRI_ICD_CD == 'S52355K',
                  PRI_ICD_CD == 'S52354N', PRI_ICD_CD == 'S52354M', PRI_ICD_CD == 'S52354K',
                  PRI_ICD_CD == 'S52353N', PRI_ICD_CD == 'S52353M', PRI_ICD_CD == 'S52353K',
                  PRI_ICD_CD == 'S52352N', PRI_ICD_CD == 'S52352M', PRI_ICD_CD == 'S52352K',
                  PRI_ICD_CD == 'S52351N', PRI_ICD_CD == 'S52351M', PRI_ICD_CD == 'S52351K',
                  PRI_ICD_CD == 'S52346N', PRI_ICD_CD == 'S52346M', PRI_ICD_CD == 'S52346K',
                  PRI_ICD_CD == 'S52345N', PRI_ICD_CD == 'S52345M', PRI_ICD_CD == 'S52345K',
                  PRI_ICD_CD == 'S52344N', PRI_ICD_CD == 'S52344M', PRI_ICD_CD == 'S52344K',
                  PRI_ICD_CD == 'S52343N', PRI_ICD_CD == 'S52343M', PRI_ICD_CD == 'S52343K',
                  PRI_ICD_CD == 'S52342N', PRI_ICD_CD == 'S52342M', PRI_ICD_CD == 'S52342K',
                  PRI_ICD_CD == 'S52341N', PRI_ICD_CD == 'S52341M', PRI_ICD_CD == 'S52341K',
                  PRI_ICD_CD == 'S52336N', PRI_ICD_CD == 'S52336M', PRI_ICD_CD == 'S52336K',
                  PRI_ICD_CD == 'S52335N', PRI_ICD_CD == 'S52335M', PRI_ICD_CD == 'S52335K',
                  PRI_ICD_CD == 'S52334N', PRI_ICD_CD == 'S52334M', PRI_ICD_CD == 'S52334K',
                  PRI_ICD_CD == 'S52333N', PRI_ICD_CD == 'S52333M', PRI_ICD_CD == 'S52333K',
                  PRI_ICD_CD == 'S52332N', PRI_ICD_CD == 'S52332M', PRI_ICD_CD == 'S52332K',
                  PRI_ICD_CD == 'S52331N', PRI_ICD_CD == 'S52331M', PRI_ICD_CD == 'S52331K',
                  PRI_ICD_CD == 'S52326N', PRI_ICD_CD == 'S52326M', PRI_ICD_CD == 'S52326K',
                  PRI_ICD_CD == 'S52325N', PRI_ICD_CD == 'S52325M', PRI_ICD_CD == 'S52325K',
                  PRI_ICD_CD == 'S52324N', PRI_ICD_CD == 'S52324M', PRI_ICD_CD == 'S52324K',
                  PRI_ICD_CD == 'S52323N', PRI_ICD_CD == 'S52323M', PRI_ICD_CD == 'S52323K',
                  PRI_ICD_CD == 'S52322N', PRI_ICD_CD == 'S52322M', PRI_ICD_CD == 'S52322K',
                  PRI_ICD_CD == 'S52321N', PRI_ICD_CD == 'S52321M', PRI_ICD_CD == 'S52321K',
                  PRI_ICD_CD == 'S52319K', PRI_ICD_CD == 'S52312K', PRI_ICD_CD == 'S52311K',
                  PRI_ICD_CD == 'S52309N', PRI_ICD_CD == 'S52309M', PRI_ICD_CD == 'S52309K',
                  PRI_ICD_CD == 'S52302N', PRI_ICD_CD == 'S52302M', PRI_ICD_CD == 'S52302K',
                  PRI_ICD_CD == 'S52301N', PRI_ICD_CD == 'S52301M', PRI_ICD_CD == 'S52301K',
                  PRI_ICD_CD == 'S52299N', PRI_ICD_CD == 'S52299M', PRI_ICD_CD == 'S52299K',
                  PRI_ICD_CD == 'S52292N', PRI_ICD_CD == 'S52292M', PRI_ICD_CD == 'S52292K',
                  PRI_ICD_CD == 'S52291N', PRI_ICD_CD == 'S52291M', PRI_ICD_CD == 'S52291K',
                  PRI_ICD_CD == 'S52283N', PRI_ICD_CD == 'S52283M', PRI_ICD_CD == 'S52283K',
                  PRI_ICD_CD == 'S52282N', PRI_ICD_CD == 'S52282M', PRI_ICD_CD == 'S52282K',
                  PRI_ICD_CD == 'S52281N', PRI_ICD_CD == 'S52281M', PRI_ICD_CD == 'S52281K',
                  PRI_ICD_CD == 'S52279N', PRI_ICD_CD == 'S52279M', PRI_ICD_CD == 'S52279K',
                  PRI_ICD_CD == 'S52272N', PRI_ICD_CD == 'S52272M', PRI_ICD_CD == 'S52272K',
                  PRI_ICD_CD == 'S52271N', PRI_ICD_CD == 'S52271M', PRI_ICD_CD == 'S52271K',
                  PRI_ICD_CD == 'S52266N', PRI_ICD_CD == 'S52266M', PRI_ICD_CD == 'S52266K',
                  PRI_ICD_CD == 'S52265N', PRI_ICD_CD == 'S52265M', PRI_ICD_CD == 'S52265K',
                  PRI_ICD_CD == 'S52264N', PRI_ICD_CD == 'S52264M', PRI_ICD_CD == 'S52264K',
                  PRI_ICD_CD == 'S52263N', PRI_ICD_CD == 'S52263M', PRI_ICD_CD == 'S52263K',
                  PRI_ICD_CD == 'S52262N', PRI_ICD_CD == 'S52262M', PRI_ICD_CD == 'S52262K',
                  PRI_ICD_CD == 'S52261N', PRI_ICD_CD == 'S52261M', PRI_ICD_CD == 'S52261K',
                  PRI_ICD_CD == 'S52256N', PRI_ICD_CD == 'S52256M', PRI_ICD_CD == 'S52256K',
                  PRI_ICD_CD == 'S52255N', PRI_ICD_CD == 'S52255M', PRI_ICD_CD == 'S52255K',
                  PRI_ICD_CD == 'S52254N', PRI_ICD_CD == 'S52254M', PRI_ICD_CD == 'S52254K',
                  PRI_ICD_CD == 'S52253N', PRI_ICD_CD == 'S52253M', PRI_ICD_CD == 'S52253K',
                  PRI_ICD_CD == 'S52252N', PRI_ICD_CD == 'S52252M', PRI_ICD_CD == 'S52252K',
                  PRI_ICD_CD == 'S52251N', PRI_ICD_CD == 'S52251M', PRI_ICD_CD == 'S52251K',
                  PRI_ICD_CD == 'S52246N', PRI_ICD_CD == 'S52246M', PRI_ICD_CD == 'S52246K',
                  PRI_ICD_CD == 'S52245N', PRI_ICD_CD == 'S52245M', PRI_ICD_CD == 'S52245K',
                  PRI_ICD_CD == 'S52244N', PRI_ICD_CD == 'S52244M', PRI_ICD_CD == 'S52244K',
                  PRI_ICD_CD == 'S52243N', PRI_ICD_CD == 'S52243M', PRI_ICD_CD == 'S52243K',
                  PRI_ICD_CD == 'S52242N', PRI_ICD_CD == 'S52242M', PRI_ICD_CD == 'S52242K',
                  PRI_ICD_CD == 'S52241N', PRI_ICD_CD == 'S52241M', PRI_ICD_CD == 'S52241K',
                  PRI_ICD_CD == 'S52236N', PRI_ICD_CD == 'S52236M', PRI_ICD_CD == 'S52236K',
                  PRI_ICD_CD == 'S52235N', PRI_ICD_CD == 'S52235M', PRI_ICD_CD == 'S52235K',
                  PRI_ICD_CD == 'S52234N', PRI_ICD_CD == 'S52234M', PRI_ICD_CD == 'S52234K',
                  PRI_ICD_CD == 'S52233N', PRI_ICD_CD == 'S52233M', PRI_ICD_CD == 'S52233K',
                  PRI_ICD_CD == 'S52232N', PRI_ICD_CD == 'S52232M', PRI_ICD_CD == 'S52232K',
                  PRI_ICD_CD == 'S52231N', PRI_ICD_CD == 'S52231M', PRI_ICD_CD == 'S52231K',
                  PRI_ICD_CD == 'S52226N', PRI_ICD_CD == 'S52226M', PRI_ICD_CD == 'S52226K',
                  PRI_ICD_CD == 'S52225N', PRI_ICD_CD == 'S52225M', PRI_ICD_CD == 'S52225K',
                  PRI_ICD_CD == 'S52224N', PRI_ICD_CD == 'S52224M', PRI_ICD_CD == 'S52224K',
                  PRI_ICD_CD == 'S52223N', PRI_ICD_CD == 'S52223M', PRI_ICD_CD == 'S52223K',
                  PRI_ICD_CD == 'S52222N', PRI_ICD_CD == 'S52222M', PRI_ICD_CD == 'S52222K',
                  PRI_ICD_CD == 'S52221N', PRI_ICD_CD == 'S52221M', PRI_ICD_CD == 'S52221K',
                  PRI_ICD_CD == 'S52219K', PRI_ICD_CD == 'S52212K', PRI_ICD_CD == 'S52211K',
                  PRI_ICD_CD == 'S52209N', PRI_ICD_CD == 'S52209M', PRI_ICD_CD == 'S52209K',
                  PRI_ICD_CD == 'S52202N', PRI_ICD_CD == 'S52202M', PRI_ICD_CD == 'S52202K',
                  PRI_ICD_CD == 'S52201N', PRI_ICD_CD == 'S52201M', PRI_ICD_CD == 'S52201K',
                  PRI_ICD_CD == 'S52189N', PRI_ICD_CD == 'S52189M', PRI_ICD_CD == 'S52189K',
                  PRI_ICD_CD == 'S52182N', PRI_ICD_CD == 'S52182M', PRI_ICD_CD == 'S52182K',
                  PRI_ICD_CD == 'S52181N', PRI_ICD_CD == 'S52181M', PRI_ICD_CD == 'S52181K',
                  PRI_ICD_CD == 'S52136N', PRI_ICD_CD == 'S52136M', PRI_ICD_CD == 'S52136K',
                  PRI_ICD_CD == 'S52135N', PRI_ICD_CD == 'S52135M', PRI_ICD_CD == 'S52135K',
                  PRI_ICD_CD == 'S52134N', PRI_ICD_CD == 'S52134M', PRI_ICD_CD == 'S52134K',
                  PRI_ICD_CD == 'S52133N', PRI_ICD_CD == 'S52133M', PRI_ICD_CD == 'S52133K',
                  PRI_ICD_CD == 'S52132N', PRI_ICD_CD == 'S52132M', PRI_ICD_CD == 'S52132K',
                  PRI_ICD_CD == 'S52131N', PRI_ICD_CD == 'S52131M', PRI_ICD_CD == 'S52131K',
                  PRI_ICD_CD == 'S52126N', PRI_ICD_CD == 'S52126M', PRI_ICD_CD == 'S52126K',
                  PRI_ICD_CD == 'S52125N', PRI_ICD_CD == 'S52125M', PRI_ICD_CD == 'S52125K',
                  PRI_ICD_CD == 'S52124N', PRI_ICD_CD == 'S52124M', PRI_ICD_CD == 'S52124K',
                  PRI_ICD_CD == 'S52123N', PRI_ICD_CD == 'S52123M', PRI_ICD_CD == 'S52123K',
                  PRI_ICD_CD == 'S52122N', PRI_ICD_CD == 'S52122M', PRI_ICD_CD == 'S52122K',
                  PRI_ICD_CD == 'S52121N', PRI_ICD_CD == 'S52121M', PRI_ICD_CD == 'S52121K',
                  PRI_ICD_CD == 'S52119K', PRI_ICD_CD == 'S52112K', PRI_ICD_CD == 'S52111K',
                  PRI_ICD_CD == 'S52109N', PRI_ICD_CD == 'S52109M', PRI_ICD_CD == 'S52109K',
                  PRI_ICD_CD == 'S52102N', PRI_ICD_CD == 'S52102M', PRI_ICD_CD == 'S52102K',
                  PRI_ICD_CD == 'S52101N', PRI_ICD_CD == 'S52101M', PRI_ICD_CD == 'S52101K',
                  PRI_ICD_CD == 'S52099N', PRI_ICD_CD == 'S52099M', PRI_ICD_CD == 'S52099K',
                  PRI_ICD_CD == 'S52092N', PRI_ICD_CD == 'S52092M', PRI_ICD_CD == 'S52092K',
                  PRI_ICD_CD == 'S52091N', PRI_ICD_CD == 'S52091M', PRI_ICD_CD == 'S52091K',
                  PRI_ICD_CD == 'S52046N', PRI_ICD_CD == 'S52046M', PRI_ICD_CD == 'S52046K',
                  PRI_ICD_CD == 'S52045N', PRI_ICD_CD == 'S52045M', PRI_ICD_CD == 'S52045K',
                  PRI_ICD_CD == 'S52044N', PRI_ICD_CD == 'S52044M', PRI_ICD_CD == 'S52044K',
                  PRI_ICD_CD == 'S52043N', PRI_ICD_CD == 'S52043M', PRI_ICD_CD == 'S52043K',
                  PRI_ICD_CD == 'S52042N', PRI_ICD_CD == 'S52042M', PRI_ICD_CD == 'S52042K',
                  PRI_ICD_CD == 'S52041N', PRI_ICD_CD == 'S52041M', PRI_ICD_CD == 'S52041K',
                  PRI_ICD_CD == 'S52036N', PRI_ICD_CD == 'S52036M', PRI_ICD_CD == 'S52036K',
                  PRI_ICD_CD == 'S52035N', PRI_ICD_CD == 'S52035M', PRI_ICD_CD == 'S52035K',
                  PRI_ICD_CD == 'S52034N', PRI_ICD_CD == 'S52034M', PRI_ICD_CD == 'S52034K',
                  PRI_ICD_CD == 'S52033N', PRI_ICD_CD == 'S52033M', PRI_ICD_CD == 'S52033K',
                  PRI_ICD_CD == 'S52032N', PRI_ICD_CD == 'S52032M', PRI_ICD_CD == 'S52032K',
                  PRI_ICD_CD == 'S52031N', PRI_ICD_CD == 'S52031M', PRI_ICD_CD == 'S52031K',
                  PRI_ICD_CD == 'S52026N', PRI_ICD_CD == 'S52026M', PRI_ICD_CD == 'S52026K',
                  PRI_ICD_CD == 'S52025N', PRI_ICD_CD == 'S52025M', PRI_ICD_CD == 'S52025K',
                  PRI_ICD_CD == 'S52024N', PRI_ICD_CD == 'S52024M', PRI_ICD_CD == 'S52024K',
                  PRI_ICD_CD == 'S52023N', PRI_ICD_CD == 'S52023M', PRI_ICD_CD == 'S52023K',
                  PRI_ICD_CD == 'S52022N', PRI_ICD_CD == 'S52022M', PRI_ICD_CD == 'S52022K',
                  PRI_ICD_CD == 'S52021N']
    choices = [ICD10to9_1, '64681', '64681', '64681', '64681', '64681',
               '64681', '64681', '64681', '64681', '64681', '64681', '64681', '64681',
               '64681', '64681', '64681', '64681', '64681', '64681', '64683', '64683',
               '64683', '64683', '64683', '64683', '64683', '64683', '64683', '64690',
               '64693', '64883', '64883', '65103', '65103', '65103', '65423', '66971',
               '67903', '67903', '67903', '70583', '71509', '71511', '71511', '71511',
               '71514', '71514', '71514', '71514', '71514', '71514', '71514', '71515',
               '71515', '71515', '71515', '71516', '71516', '71516', '71516', '71517',
               '71517', '71517', '71590', '71590', '71595', '71596', '71740', '71740',
               '71740', '71740', '71740', '71740', '71740', '71740', '71740', '71789',
               '71789', '71789', '71789', '71789', '71789', '71789', '71789', '71789',
               '71789', '71789', '71789', '71789', '71789', '71789', '71789', '71789',
               '71789', '71789', '71789', '71789', '71789', '71789', '71789', '71789',
               '71789', '71789', '71789', '71789', '71881', '71881', '71881', '71881',
               '71881', '71881', '71881', '71881', '71881', '71883', '71883', '71883',
               '71883', '71883', '71883', '71883', '71883', '71883', '71887', '71887',
               '71887', '71887', '71887', '71887', '71887', '71887', '71887', '71887',
               '71887', '71887', '71887', '71887', '71887', '71941', '71941', '71941',
               '71942', '71942', '71942', '71942', '71943', '71943', '71943', '71943',
               '71944', '71944', '71945', '71945', '71945', '71946', '71946', '71946',
               '71947', '71947', '71947', '71985', '71985', '71985', '71985', '72210',
               '72210', '72252', '72252', '72271', '72271', '72271', '72271', '72273',
               '72273', '72290', '72290', '72290', '72290', '72291', '72291', '72291',
               '72291', '72291', '72291', '72291', '72291', '72291', '72291', '72291',
               '72291', '72293', '72293', '72293', '72293', '72400', '72402', '72402',
               '72402', '72402', '72402', '72402', '72402', '72403', '72610', '72610',
               '72610', '72610', '72610', '72610', '72610', '72610', '72610', '72610',
               '72610', '72610', '72612', '72612', '72612', '72613', '72619', '72619',
               '72619', '72631', '72631', '72631', '72632', '72632', '72632', '72670',
               '72670', '72670', '72670', '72670', '72670', '72670', '72670', '72670',
               '72670', '72671', '72671', '72671', '72672', '72672', '72672', '72672',
               '72672', '72672', '72673', '72673', '72673', '72690', '72691', '72703',
               '72703', '72703', '72703', '72703', '72703', '72703', '72703', '72703',
               '72703', '72703', '72703', '72703', '72703', '72703', '72703', '72704',
               '72705', '72705', '72705', '72705', '72705', '72705', '72706', '72706',
               '72706', '72742', '72742', '72742', '72742', '72742', '72742', '72742',
               '72742', '72742', '72742', '72742', '72742', '72742', '72742', '72742',
               '72742', '72742', '72742', '72742', '72742', '72742', '72742', '72743',
               '72761', '72761', '72761', '72762', '72762', '72762', '72762', '72762',
               '72762', '72762', '72762', '72762', '72762', '72762', '72762', '72762',
               '72762', '72762', '72762', '72765', '72765', '72765', '72767', '72767',
               '72767', '72767', '72767', '72767', '72782', '72782', '72782', '72782',
               '72782', '72782', '72782', '72782', '72782', '72782', '72782', '72782',
               '72782', '72782', '72782', '72782', '72782', '72782', '72782', '72782',
               '72782', '72782', '72782', '72782', '72782', '72782', '72782', '72782',
               '72782', '72782', '72782', '72782', '72782', '72782', '72782', '72782',
               '72782', '72782', '72782', '72782', '72782', '72782', '72871', '72885',
               '72885', '72885', '72885', '72885', '72885', '72885', '72885', '72885',
               '72885', '72885', '72885', '72885', '72885', '72885', '72885', '72885',
               '72885', '72885', '72885', '72885', '72885', '72885', '72885', '72885',
               '72885', '73007', '73007', '73007', '73007', '73007', '73007', '73007',
               '73007', '73007', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382']
    default_cond = 'Derive_3'
    return np.select(conditions, choices, default=default_cond)


def icd10to9_3(ICD10to9_2, PRI_ICD_CD):
    conditions = [ICD10to9_2 != 'Derive_3', PRI_ICD_CD == 'S52021M',
                  PRI_ICD_CD == 'S52021K', PRI_ICD_CD == 'S52019K', PRI_ICD_CD == 'S52012K',
                  PRI_ICD_CD == 'S52011K', PRI_ICD_CD == 'S52009N', PRI_ICD_CD == 'S52009M',
                  PRI_ICD_CD == 'S52009K', PRI_ICD_CD == 'S52002N', PRI_ICD_CD == 'S52002M',
                  PRI_ICD_CD == 'S52002K', PRI_ICD_CD == 'S52001P', PRI_ICD_CD == 'S52001N',
                  PRI_ICD_CD == 'S52001M', PRI_ICD_CD == 'S52001K', PRI_ICD_CD == 'S49199K',
                  PRI_ICD_CD == 'S49192K', PRI_ICD_CD == 'S49191K', PRI_ICD_CD == 'S49149K',
                  PRI_ICD_CD == 'S49142K', PRI_ICD_CD == 'S49141K', PRI_ICD_CD == 'S49139K',
                  PRI_ICD_CD == 'S49132K', PRI_ICD_CD == 'S49131K', PRI_ICD_CD == 'S49129K',
                  PRI_ICD_CD == 'S49122K', PRI_ICD_CD == 'S49121K', PRI_ICD_CD == 'S49119K',
                  PRI_ICD_CD == 'S49112K', PRI_ICD_CD == 'S49111K', PRI_ICD_CD == 'S49109K',
                  PRI_ICD_CD == 'S49102K', PRI_ICD_CD == 'S49101K', PRI_ICD_CD == 'S49099K',
                  PRI_ICD_CD == 'S49092K', PRI_ICD_CD == 'S49091K', PRI_ICD_CD == 'S49049K',
                  PRI_ICD_CD == 'S49042K', PRI_ICD_CD == 'S49041K', PRI_ICD_CD == 'S49039K',
                  PRI_ICD_CD == 'S49032K', PRI_ICD_CD == 'S49031K', PRI_ICD_CD == 'S49029K',
                  PRI_ICD_CD == 'S49022K', PRI_ICD_CD == 'S49021K', PRI_ICD_CD == 'S49019K',
                  PRI_ICD_CD == 'S49012K', PRI_ICD_CD == 'S49011K', PRI_ICD_CD == 'S49009K',
                  PRI_ICD_CD == 'S49002K', PRI_ICD_CD == 'S49001K', PRI_ICD_CD == 'S4292XK',
                  PRI_ICD_CD == 'S4291XK', PRI_ICD_CD == 'S4290XK', PRI_ICD_CD == 'S42496K',
                  PRI_ICD_CD == 'S42495K', PRI_ICD_CD == 'S42494K', PRI_ICD_CD == 'S42493K',
                  PRI_ICD_CD == 'S42492K', PRI_ICD_CD == 'S42491K', PRI_ICD_CD == 'S42489K',
                  PRI_ICD_CD == 'S42482K', PRI_ICD_CD == 'S42481K', PRI_ICD_CD == 'S42476K',
                  PRI_ICD_CD == 'S42475K', PRI_ICD_CD == 'S42474K', PRI_ICD_CD == 'S42473K',
                  PRI_ICD_CD == 'S42472K', PRI_ICD_CD == 'S42471K', PRI_ICD_CD == 'S42466K',
                  PRI_ICD_CD == 'S42465K', PRI_ICD_CD == 'S42464K', PRI_ICD_CD == 'S42463K',
                  PRI_ICD_CD == 'S42462K', PRI_ICD_CD == 'S42461K', PRI_ICD_CD == 'S42456K',
                  PRI_ICD_CD == 'S42455K', PRI_ICD_CD == 'S42454K', PRI_ICD_CD == 'S42453K',
                  PRI_ICD_CD == 'S42452K', PRI_ICD_CD == 'S42451K', PRI_ICD_CD == 'S42449K',
                  PRI_ICD_CD == 'S42448K', PRI_ICD_CD == 'S42447K', PRI_ICD_CD == 'S42446K',
                  PRI_ICD_CD == 'S42445K', PRI_ICD_CD == 'S42444K', PRI_ICD_CD == 'S42443K',
                  PRI_ICD_CD == 'S42442K', PRI_ICD_CD == 'S42441K', PRI_ICD_CD == 'S42436K',
                  PRI_ICD_CD == 'S42435K', PRI_ICD_CD == 'S42434K', PRI_ICD_CD == 'S42433K',
                  PRI_ICD_CD == 'S42432K', PRI_ICD_CD == 'S42431K', PRI_ICD_CD == 'S42426K',
                  PRI_ICD_CD == 'S42425K', PRI_ICD_CD == 'S42424K', PRI_ICD_CD == 'S42423K',
                  PRI_ICD_CD == 'S42422K', PRI_ICD_CD == 'S42421K', PRI_ICD_CD == 'S42416K',
                  PRI_ICD_CD == 'S42415K', PRI_ICD_CD == 'S42414K', PRI_ICD_CD == 'S42413K',
                  PRI_ICD_CD == 'S42412K', PRI_ICD_CD == 'S42411K', PRI_ICD_CD == 'S42409K',
                  PRI_ICD_CD == 'S42402K', PRI_ICD_CD == 'S42401K', PRI_ICD_CD == 'S42399K',
                  PRI_ICD_CD == 'S42392K', PRI_ICD_CD == 'S42391K', PRI_ICD_CD == 'S42366K',
                  PRI_ICD_CD == 'S42365K', PRI_ICD_CD == 'S42364K', PRI_ICD_CD == 'S42363K',
                  PRI_ICD_CD == 'S42362K', PRI_ICD_CD == 'S42361K', PRI_ICD_CD == 'S42356K',
                  PRI_ICD_CD == 'S42355K', PRI_ICD_CD == 'S42354K', PRI_ICD_CD == 'S42353K',
                  PRI_ICD_CD == 'S42352K', PRI_ICD_CD == 'S42351K', PRI_ICD_CD == 'S42346K',
                  PRI_ICD_CD == 'S42345K', PRI_ICD_CD == 'S42344K', PRI_ICD_CD == 'S42343K',
                  PRI_ICD_CD == 'S42342K', PRI_ICD_CD == 'S42341K', PRI_ICD_CD == 'S42336K',
                  PRI_ICD_CD == 'S42335K', PRI_ICD_CD == 'S42334K', PRI_ICD_CD == 'S42333K',
                  PRI_ICD_CD == 'S42332K', PRI_ICD_CD == 'S42331K', PRI_ICD_CD == 'S42326K',
                  PRI_ICD_CD == 'S42325K', PRI_ICD_CD == 'S42324K', PRI_ICD_CD == 'S42323K',
                  PRI_ICD_CD == 'S42322K', PRI_ICD_CD == 'S42321K', PRI_ICD_CD == 'S42319K',
                  PRI_ICD_CD == 'S42312K', PRI_ICD_CD == 'S42311K', PRI_ICD_CD == 'S42309K',
                  PRI_ICD_CD == 'S42302K', PRI_ICD_CD == 'S42301K', PRI_ICD_CD == 'S42296K',
                  PRI_ICD_CD == 'S42295K', PRI_ICD_CD == 'S42294K', PRI_ICD_CD == 'S42293K',
                  PRI_ICD_CD == 'S42292K', PRI_ICD_CD == 'S42291K', PRI_ICD_CD == 'S42279K',
                  PRI_ICD_CD == 'S42272K', PRI_ICD_CD == 'S42271K', PRI_ICD_CD == 'S42266K',
                  PRI_ICD_CD == 'S42265K', PRI_ICD_CD == 'S42264K', PRI_ICD_CD == 'S42263K',
                  PRI_ICD_CD == 'S42262K', PRI_ICD_CD == 'S42261K', PRI_ICD_CD == 'S42256K',
                  PRI_ICD_CD == 'S42255K', PRI_ICD_CD == 'S42254K', PRI_ICD_CD == 'S42253K',
                  PRI_ICD_CD == 'S42252K', PRI_ICD_CD == 'S42251K', PRI_ICD_CD == 'S42249K',
                  PRI_ICD_CD == 'S42242K', PRI_ICD_CD == 'S42241K', PRI_ICD_CD == 'S42239K',
                  PRI_ICD_CD == 'S42232K', PRI_ICD_CD == 'S42231K', PRI_ICD_CD == 'S42226K',
                  PRI_ICD_CD == 'S42225K', PRI_ICD_CD == 'S42224K', PRI_ICD_CD == 'S42223K',
                  PRI_ICD_CD == 'S42222K', PRI_ICD_CD == 'S42221K', PRI_ICD_CD == 'S42216K',
                  PRI_ICD_CD == 'S42215K', PRI_ICD_CD == 'S42214K', PRI_ICD_CD == 'S42213K',
                  PRI_ICD_CD == 'S42212K', PRI_ICD_CD == 'S42211K', PRI_ICD_CD == 'S42209K',
                  PRI_ICD_CD == 'S42202K', PRI_ICD_CD == 'S42201K', PRI_ICD_CD == 'S42199K',
                  PRI_ICD_CD == 'S42192K', PRI_ICD_CD == 'S42191K', PRI_ICD_CD == 'S42156K',
                  PRI_ICD_CD == 'S42155K', PRI_ICD_CD == 'S42154K', PRI_ICD_CD == 'S42153K',
                  PRI_ICD_CD == 'S42152K', PRI_ICD_CD == 'S42151K', PRI_ICD_CD == 'S42146K',
                  PRI_ICD_CD == 'S42145K', PRI_ICD_CD == 'S42144K', PRI_ICD_CD == 'S42143K',
                  PRI_ICD_CD == 'S42142K', PRI_ICD_CD == 'S42141K', PRI_ICD_CD == 'S42136K',
                  PRI_ICD_CD == 'S42135K', PRI_ICD_CD == 'S42134K', PRI_ICD_CD == 'S42133K',
                  PRI_ICD_CD == 'S42132K', PRI_ICD_CD == 'S42131K', PRI_ICD_CD == 'S42126K',
                  PRI_ICD_CD == 'S42125K', PRI_ICD_CD == 'S42124K', PRI_ICD_CD == 'S42123K',
                  PRI_ICD_CD == 'S42122K', PRI_ICD_CD == 'S42121K', PRI_ICD_CD == 'S42116K',
                  PRI_ICD_CD == 'S42115K', PRI_ICD_CD == 'S42114K', PRI_ICD_CD == 'S42113K',
                  PRI_ICD_CD == 'S42112K', PRI_ICD_CD == 'S42111K', PRI_ICD_CD == 'S42109K',
                  PRI_ICD_CD == 'S42102K', PRI_ICD_CD == 'S42101K', PRI_ICD_CD == 'S42036K',
                  PRI_ICD_CD == 'S42035K', PRI_ICD_CD == 'S42034K', PRI_ICD_CD == 'S42033K',
                  PRI_ICD_CD == 'S42032K', PRI_ICD_CD == 'S42031K', PRI_ICD_CD == 'S42026K',
                  PRI_ICD_CD == 'S42025K', PRI_ICD_CD == 'S42024K', PRI_ICD_CD == 'S42023K',
                  PRI_ICD_CD == 'S42022K', PRI_ICD_CD == 'S42021K', PRI_ICD_CD == 'S42019K',
                  PRI_ICD_CD == 'S42018K', PRI_ICD_CD == 'S42017K', PRI_ICD_CD == 'S42016K',
                  PRI_ICD_CD == 'S42015K', PRI_ICD_CD == 'S42014K', PRI_ICD_CD == 'S42013K',
                  PRI_ICD_CD == 'S42012K', PRI_ICD_CD == 'S42011K', PRI_ICD_CD == 'S42009K',
                  PRI_ICD_CD == 'S42002K', PRI_ICD_CD == 'S42001K', PRI_ICD_CD == 'S329XXK',
                  PRI_ICD_CD == 'S3289XK', PRI_ICD_CD == 'S3282XK', PRI_ICD_CD == 'S32811K',
                  PRI_ICD_CD == 'S32810K', PRI_ICD_CD == 'S32699K', PRI_ICD_CD == 'S32692K',
                  PRI_ICD_CD == 'S32691K', PRI_ICD_CD == 'S32616K', PRI_ICD_CD == 'S32615K',
                  PRI_ICD_CD == 'S32614K', PRI_ICD_CD == 'S32613K', PRI_ICD_CD == 'S32612K',
                  PRI_ICD_CD == 'S32611K', PRI_ICD_CD == 'S32609K', PRI_ICD_CD == 'S32602K',
                  PRI_ICD_CD == 'S32601K', PRI_ICD_CD == 'S32599K', PRI_ICD_CD == 'S32592K',
                  PRI_ICD_CD == 'S32591K', PRI_ICD_CD == 'S32519K', PRI_ICD_CD == 'S32512K',
                  PRI_ICD_CD == 'S32511K', PRI_ICD_CD == 'S32509K', PRI_ICD_CD == 'S32502K',
                  PRI_ICD_CD == 'S32501K', PRI_ICD_CD == 'S32499K', PRI_ICD_CD == 'S32492K',
                  PRI_ICD_CD == 'S32491K', PRI_ICD_CD == 'S32486K', PRI_ICD_CD == 'S32485K',
                  PRI_ICD_CD == 'S32484K', PRI_ICD_CD == 'S32483K', PRI_ICD_CD == 'S32482K',
                  PRI_ICD_CD == 'S32481K', PRI_ICD_CD == 'S32476K', PRI_ICD_CD == 'S32475K',
                  PRI_ICD_CD == 'S32474K', PRI_ICD_CD == 'S32473K', PRI_ICD_CD == 'S32472K',
                  PRI_ICD_CD == 'S32471K', PRI_ICD_CD == 'S32466K', PRI_ICD_CD == 'S32465K',
                  PRI_ICD_CD == 'S32464K', PRI_ICD_CD == 'S32463K', PRI_ICD_CD == 'S32462K',
                  PRI_ICD_CD == 'S32461K', PRI_ICD_CD == 'S32456K', PRI_ICD_CD == 'S32455K',
                  PRI_ICD_CD == 'S32454K', PRI_ICD_CD == 'S32453K', PRI_ICD_CD == 'S32452K',
                  PRI_ICD_CD == 'S32451K', PRI_ICD_CD == 'S32446K', PRI_ICD_CD == 'S32445K',
                  PRI_ICD_CD == 'S32444K', PRI_ICD_CD == 'S32443K', PRI_ICD_CD == 'S32442K',
                  PRI_ICD_CD == 'S32441K', PRI_ICD_CD == 'S32436K', PRI_ICD_CD == 'S32435K',
                  PRI_ICD_CD == 'S32434K', PRI_ICD_CD == 'S32433K', PRI_ICD_CD == 'S32432K',
                  PRI_ICD_CD == 'S32431K', PRI_ICD_CD == 'S32426K', PRI_ICD_CD == 'S32425K',
                  PRI_ICD_CD == 'S32424K', PRI_ICD_CD == 'S32423K', PRI_ICD_CD == 'S32422K',
                  PRI_ICD_CD == 'S32421K', PRI_ICD_CD == 'S32416K', PRI_ICD_CD == 'S32415K',
                  PRI_ICD_CD == 'S32414K', PRI_ICD_CD == 'S32413K', PRI_ICD_CD == 'S32412K',
                  PRI_ICD_CD == 'S32411K', PRI_ICD_CD == 'S32409K', PRI_ICD_CD == 'S32402K',
                  PRI_ICD_CD == 'S32401K', PRI_ICD_CD == 'S32399K', PRI_ICD_CD == 'S32392K',
                  PRI_ICD_CD == 'S32391K', PRI_ICD_CD == 'S32316K', PRI_ICD_CD == 'S32315K',
                  PRI_ICD_CD == 'S32314K', PRI_ICD_CD == 'S32313K', PRI_ICD_CD == 'S32312K',
                  PRI_ICD_CD == 'S32311K', PRI_ICD_CD == 'S32309K', PRI_ICD_CD == 'S32302K',
                  PRI_ICD_CD == 'S32301K', PRI_ICD_CD == 'S322XXK', PRI_ICD_CD == 'S3219XK',
                  PRI_ICD_CD == 'S3217XK', PRI_ICD_CD == 'S3216XK', PRI_ICD_CD == 'S3215XK',
                  PRI_ICD_CD == 'S3214XK', PRI_ICD_CD == 'S32139K', PRI_ICD_CD == 'S32132K',
                  PRI_ICD_CD == 'S32131K', PRI_ICD_CD == 'S32130K', PRI_ICD_CD == 'S32129K',
                  PRI_ICD_CD == 'S32122K', PRI_ICD_CD == 'S32121K', PRI_ICD_CD == 'S32120K',
                  PRI_ICD_CD == 'S32119K', PRI_ICD_CD == 'S32112K', PRI_ICD_CD == 'S32111K',
                  PRI_ICD_CD == 'S32110K', PRI_ICD_CD == 'S3210XK', PRI_ICD_CD == 'S32059K',
                  PRI_ICD_CD == 'S32058K', PRI_ICD_CD == 'S32052K', PRI_ICD_CD == 'S32051K',
                  PRI_ICD_CD == 'S32050K', PRI_ICD_CD == 'S32049K', PRI_ICD_CD == 'S32048K',
                  PRI_ICD_CD == 'S32042K', PRI_ICD_CD == 'S32041K', PRI_ICD_CD == 'S32040K',
                  PRI_ICD_CD == 'S32039K', PRI_ICD_CD == 'S32038K', PRI_ICD_CD == 'S32032K',
                  PRI_ICD_CD == 'S32031K', PRI_ICD_CD == 'S32030K', PRI_ICD_CD == 'S32029K',
                  PRI_ICD_CD == 'S32028K', PRI_ICD_CD == 'S32022K', PRI_ICD_CD == 'S32021K',
                  PRI_ICD_CD == 'S32020K', PRI_ICD_CD == 'S32019K', PRI_ICD_CD == 'S32018K',
                  PRI_ICD_CD == 'S32012K', PRI_ICD_CD == 'S32011K', PRI_ICD_CD == 'S32010K',
                  PRI_ICD_CD == 'S32009K', PRI_ICD_CD == 'S32008K', PRI_ICD_CD == 'S32002K',
                  PRI_ICD_CD == 'S32001K', PRI_ICD_CD == 'S32000K', PRI_ICD_CD == 'S229XXK',
                  PRI_ICD_CD == 'S225XXK', PRI_ICD_CD == 'S2249XK', PRI_ICD_CD == 'S2243XK',
                  PRI_ICD_CD == 'S2242XK', PRI_ICD_CD == 'S2241XK', PRI_ICD_CD == 'S2239XK',
                  PRI_ICD_CD == 'S2232XK', PRI_ICD_CD == 'S2231XK', PRI_ICD_CD == 'S2224XK',
                  PRI_ICD_CD == 'S2223XK', PRI_ICD_CD == 'S2222XK', PRI_ICD_CD == 'S2221XK',
                  PRI_ICD_CD == 'S2220XK', PRI_ICD_CD == 'S22089K', PRI_ICD_CD == 'S22088K',
                  PRI_ICD_CD == 'S22082K', PRI_ICD_CD == 'S22081K', PRI_ICD_CD == 'S22080K',
                  PRI_ICD_CD == 'S22079K', PRI_ICD_CD == 'S22078K', PRI_ICD_CD == 'S22072K',
                  PRI_ICD_CD == 'S22071K', PRI_ICD_CD == 'S22070K', PRI_ICD_CD == 'S22069K',
                  PRI_ICD_CD == 'S22068K', PRI_ICD_CD == 'S22062K', PRI_ICD_CD == 'S22061K',
                  PRI_ICD_CD == 'S22060K', PRI_ICD_CD == 'S22059K', PRI_ICD_CD == 'S22058K',
                  PRI_ICD_CD == 'S22052K', PRI_ICD_CD == 'S22051K', PRI_ICD_CD == 'S22050K',
                  PRI_ICD_CD == 'S22049K', PRI_ICD_CD == 'S22048K', PRI_ICD_CD == 'S22042K',
                  PRI_ICD_CD == 'S22041K', PRI_ICD_CD == 'S22040K', PRI_ICD_CD == 'S22039K',
                  PRI_ICD_CD == 'S22038K', PRI_ICD_CD == 'S22032K', PRI_ICD_CD == 'S22031K',
                  PRI_ICD_CD == 'S22030K', PRI_ICD_CD == 'S22029K', PRI_ICD_CD == 'S22028K',
                  PRI_ICD_CD == 'S22022K', PRI_ICD_CD == 'S22021K', PRI_ICD_CD == 'S22020K',
                  PRI_ICD_CD == 'S22019K', PRI_ICD_CD == 'S22018K', PRI_ICD_CD == 'S22012K',
                  PRI_ICD_CD == 'S22011K', PRI_ICD_CD == 'S22010K', PRI_ICD_CD == 'S22009K',
                  PRI_ICD_CD == 'S22008K', PRI_ICD_CD == 'S22002K', PRI_ICD_CD == 'S22001K',
                  PRI_ICD_CD == 'S22000K', PRI_ICD_CD == 'S12691K', PRI_ICD_CD == 'S12690K',
                  PRI_ICD_CD == 'S12651K', PRI_ICD_CD == 'S12650K', PRI_ICD_CD == 'S1264XK',
                  PRI_ICD_CD == 'S12631K', PRI_ICD_CD == 'S12630K', PRI_ICD_CD == 'S12601K',
                  PRI_ICD_CD == 'S12600K', PRI_ICD_CD == 'S12591K', PRI_ICD_CD == 'S12590K',
                  PRI_ICD_CD == 'S12551K', PRI_ICD_CD == 'S12550K', PRI_ICD_CD == 'S1254XK',
                  PRI_ICD_CD == 'S12531K', PRI_ICD_CD == 'S12530K', PRI_ICD_CD == 'S12501K',
                  PRI_ICD_CD == 'S12500K', PRI_ICD_CD == 'S12491K', PRI_ICD_CD == 'S12490K',
                  PRI_ICD_CD == 'S12451K', PRI_ICD_CD == 'S12450K', PRI_ICD_CD == 'S1244XK',
                  PRI_ICD_CD == 'S12431K', PRI_ICD_CD == 'S12430K', PRI_ICD_CD == 'S12401K',
                  PRI_ICD_CD == 'S12400K', PRI_ICD_CD == 'S12391K', PRI_ICD_CD == 'S12390K',
                  PRI_ICD_CD == 'S12351K', PRI_ICD_CD == 'S12350K', PRI_ICD_CD == 'S1234XK',
                  PRI_ICD_CD == 'S12331K', PRI_ICD_CD == 'S12330K', PRI_ICD_CD == 'S12301K',
                  PRI_ICD_CD == 'S12300K', PRI_ICD_CD == 'S12291K', PRI_ICD_CD == 'S12290K',
                  PRI_ICD_CD == 'S12251K', PRI_ICD_CD == 'S12250K', PRI_ICD_CD == 'S1224XK',
                  PRI_ICD_CD == 'S12231K', PRI_ICD_CD == 'S12230K', PRI_ICD_CD == 'S12201K',
                  PRI_ICD_CD == 'S12200K', PRI_ICD_CD == 'S12191K', PRI_ICD_CD == 'S12190K',
                  PRI_ICD_CD == 'S12151K', PRI_ICD_CD == 'S12150K', PRI_ICD_CD == 'S1214XK',
                  PRI_ICD_CD == 'S12131K', PRI_ICD_CD == 'S12130K', PRI_ICD_CD == 'S12121K',
                  PRI_ICD_CD == 'S12120K', PRI_ICD_CD == 'S12112K', PRI_ICD_CD == 'S12111K',
                  PRI_ICD_CD == 'S12110K', PRI_ICD_CD == 'S12101K', PRI_ICD_CD == 'S12100K',
                  PRI_ICD_CD == 'S12091K', PRI_ICD_CD == 'S12090K', PRI_ICD_CD == 'S12041K',
                  PRI_ICD_CD == 'S12040K', PRI_ICD_CD == 'S12031K', PRI_ICD_CD == 'S12030K',
                  PRI_ICD_CD == 'S1202XK', PRI_ICD_CD == 'S1201XK', PRI_ICD_CD == 'S12001K',
                  PRI_ICD_CD == 'S12000K', PRI_ICD_CD == 'S0292XK', PRI_ICD_CD == 'S0291XK',
                  PRI_ICD_CD == 'S028XXK', PRI_ICD_CD == 'S0269XK', PRI_ICD_CD == 'S0267XK',
                  PRI_ICD_CD == 'S0266XK', PRI_ICD_CD == 'S0265XK', PRI_ICD_CD == 'S0264XK',
                  PRI_ICD_CD == 'S0263XK', PRI_ICD_CD == 'S0262XK', PRI_ICD_CD == 'S0261XK',
                  PRI_ICD_CD == 'S02609K', PRI_ICD_CD == 'S02600K', PRI_ICD_CD == 'S025XXK',
                  PRI_ICD_CD == 'S0242XK', PRI_ICD_CD == 'S02413K', PRI_ICD_CD == 'S02412K',
                  PRI_ICD_CD == 'S02411K', PRI_ICD_CD == 'S02402K', PRI_ICD_CD == 'S02401K',
                  PRI_ICD_CD == 'S02400K', PRI_ICD_CD == 'S023XXK', PRI_ICD_CD == 'S022XXK',
                  PRI_ICD_CD == 'S0219XK', PRI_ICD_CD == 'S02119K', PRI_ICD_CD == 'S02118K',
                  PRI_ICD_CD == 'S02113K', PRI_ICD_CD == 'S02112K', PRI_ICD_CD == 'S02111K',
                  PRI_ICD_CD == 'S02110K', PRI_ICD_CD == 'S0210XK', PRI_ICD_CD == 'S020XXK',
                  PRI_ICD_CD == 'M8468XK', PRI_ICD_CD == 'M84676K', PRI_ICD_CD == 'M84675K',
                  PRI_ICD_CD == 'M84674K', PRI_ICD_CD == 'M84673K', PRI_ICD_CD == 'M84672K',
                  PRI_ICD_CD == 'M84671K', PRI_ICD_CD == 'M84669K', PRI_ICD_CD == 'M84664K',
                  PRI_ICD_CD == 'M84663K', PRI_ICD_CD == 'M84662K', PRI_ICD_CD == 'M84661K',
                  PRI_ICD_CD == 'M84659K', PRI_ICD_CD == 'M84653K', PRI_ICD_CD == 'M84652K',
                  PRI_ICD_CD == 'M84651K', PRI_ICD_CD == 'M84650K', PRI_ICD_CD == 'M84649K',
                  PRI_ICD_CD == 'M84642K', PRI_ICD_CD == 'M84641K', PRI_ICD_CD == 'M84639K',
                  PRI_ICD_CD == 'M84634K', PRI_ICD_CD == 'M84633K', PRI_ICD_CD == 'M84632K',
                  PRI_ICD_CD == 'M84631K', PRI_ICD_CD == 'M84629K', PRI_ICD_CD == 'M84622K',
                  PRI_ICD_CD == 'M84621K', PRI_ICD_CD == 'M84619K', PRI_ICD_CD == 'M84612K',
                  PRI_ICD_CD == 'M84611K', PRI_ICD_CD == 'M8460XK', PRI_ICD_CD == 'M8458XK',
                  PRI_ICD_CD == 'M84576K', PRI_ICD_CD == 'M84575K', PRI_ICD_CD == 'M84574K',
                  PRI_ICD_CD == 'M84573K', PRI_ICD_CD == 'M84572K', PRI_ICD_CD == 'M84571K',
                  PRI_ICD_CD == 'M84569K', PRI_ICD_CD == 'M84564K', PRI_ICD_CD == 'M84563K',
                  PRI_ICD_CD == 'M84562K', PRI_ICD_CD == 'M84561K', PRI_ICD_CD == 'M84559K',
                  PRI_ICD_CD == 'M84553K', PRI_ICD_CD == 'M84552K', PRI_ICD_CD == 'M84551K',
                  PRI_ICD_CD == 'M84550K', PRI_ICD_CD == 'M84549K', PRI_ICD_CD == 'M84542K',
                  PRI_ICD_CD == 'M84541K', PRI_ICD_CD == 'M84539K', PRI_ICD_CD == 'M84534K',
                  PRI_ICD_CD == 'M84533K', PRI_ICD_CD == 'M84532K', PRI_ICD_CD == 'M84531K',
                  PRI_ICD_CD == 'M84529K', PRI_ICD_CD == 'M84522K', PRI_ICD_CD == 'M84521K',
                  PRI_ICD_CD == 'M84519K', PRI_ICD_CD == 'M84512K', PRI_ICD_CD == 'M84511K',
                  PRI_ICD_CD == 'M8450XK', PRI_ICD_CD == 'M8448XK', PRI_ICD_CD == 'M84479K',
                  PRI_ICD_CD == 'M84478K', PRI_ICD_CD == 'M84477K', PRI_ICD_CD == 'M84476K',
                  PRI_ICD_CD == 'M84475K', PRI_ICD_CD == 'M84474K', PRI_ICD_CD == 'M84473K',
                  PRI_ICD_CD == 'M84472K', PRI_ICD_CD == 'M84471K', PRI_ICD_CD == 'M84469K',
                  PRI_ICD_CD == 'M84464K', PRI_ICD_CD == 'M84463K', PRI_ICD_CD == 'M84462K',
                  PRI_ICD_CD == 'M84461K', PRI_ICD_CD == 'M84459K', PRI_ICD_CD == 'M84454K',
                  PRI_ICD_CD == 'M84453K', PRI_ICD_CD == 'M84452K', PRI_ICD_CD == 'M84451K',
                  PRI_ICD_CD == 'M84446K', PRI_ICD_CD == 'M84445K', PRI_ICD_CD == 'M84444K',
                  PRI_ICD_CD == 'M84443K', PRI_ICD_CD == 'M84442K', PRI_ICD_CD == 'M84441K',
                  PRI_ICD_CD == 'M84439K', PRI_ICD_CD == 'M84434K', PRI_ICD_CD == 'M84433K',
                  PRI_ICD_CD == 'M84432K', PRI_ICD_CD == 'M84431K', PRI_ICD_CD == 'M84429K',
                  PRI_ICD_CD == 'M84422K', PRI_ICD_CD == 'M84421K', PRI_ICD_CD == 'M84419K',
                  PRI_ICD_CD == 'M84412K', PRI_ICD_CD == 'M84411K', PRI_ICD_CD == 'M8440XK',
                  PRI_ICD_CD == 'M8438XK', PRI_ICD_CD == 'M84379K', PRI_ICD_CD == 'M84378K',
                  PRI_ICD_CD == 'M84377K', PRI_ICD_CD == 'M84376K', PRI_ICD_CD == 'M84375K',
                  PRI_ICD_CD == 'M84374K', PRI_ICD_CD == 'M84373K', PRI_ICD_CD == 'M84372K',
                  PRI_ICD_CD == 'M84371K', PRI_ICD_CD == 'M84369K', PRI_ICD_CD == 'M84364K',
                  PRI_ICD_CD == 'M84363K', PRI_ICD_CD == 'M84362K', PRI_ICD_CD == 'M84361K',
                  PRI_ICD_CD == 'M84359K', PRI_ICD_CD == 'M84353K', PRI_ICD_CD == 'M84352K',
                  PRI_ICD_CD == 'M84351K', PRI_ICD_CD == 'M84350K', PRI_ICD_CD == 'M84346K',
                  PRI_ICD_CD == 'M84345K', PRI_ICD_CD == 'M84344K', PRI_ICD_CD == 'M84343K',
                  PRI_ICD_CD == 'M84342K', PRI_ICD_CD == 'M84341K', PRI_ICD_CD == 'M84339K',
                  PRI_ICD_CD == 'M84333K', PRI_ICD_CD == 'M84332K', PRI_ICD_CD == 'M84331K',
                  PRI_ICD_CD == 'M84329K', PRI_ICD_CD == 'M84322K', PRI_ICD_CD == 'M84321K',
                  PRI_ICD_CD == 'M84319K', PRI_ICD_CD == 'M84312K', PRI_ICD_CD == 'M84311K',
                  PRI_ICD_CD == 'M8430XK', PRI_ICD_CD == 'M8088XK', PRI_ICD_CD == 'M80879K',
                  PRI_ICD_CD == 'M80872K', PRI_ICD_CD == 'M80871K', PRI_ICD_CD == 'M80869K',
                  PRI_ICD_CD == 'M80862K', PRI_ICD_CD == 'M80861K', PRI_ICD_CD == 'M80859K',
                  PRI_ICD_CD == 'M80852K', PRI_ICD_CD == 'M80851K', PRI_ICD_CD == 'M80849K',
                  PRI_ICD_CD == 'M80842K', PRI_ICD_CD == 'M80841K', PRI_ICD_CD == 'M80839K',
                  PRI_ICD_CD == 'M80832K', PRI_ICD_CD == 'M80831K', PRI_ICD_CD == 'M80829K',
                  PRI_ICD_CD == 'M80822K', PRI_ICD_CD == 'M80821K', PRI_ICD_CD == 'M80819K',
                  PRI_ICD_CD == 'M80812K', PRI_ICD_CD == 'M80811K', PRI_ICD_CD == 'M8080XK',
                  PRI_ICD_CD == 'M8008XK', PRI_ICD_CD == 'M80079K', PRI_ICD_CD == 'M80072K',
                  PRI_ICD_CD == 'M80071K', PRI_ICD_CD == 'M80069K', PRI_ICD_CD == 'M80062K',
                  PRI_ICD_CD == 'M80061K', PRI_ICD_CD == 'M80059K', PRI_ICD_CD == 'M80052K',
                  PRI_ICD_CD == 'M80051K', PRI_ICD_CD == 'M80049K', PRI_ICD_CD == 'M80042K',
                  PRI_ICD_CD == 'M80041K', PRI_ICD_CD == 'M80039K', PRI_ICD_CD == 'M80032P',
                  PRI_ICD_CD == 'M80032K', PRI_ICD_CD == 'M80031K', PRI_ICD_CD == 'M80029K',
                  PRI_ICD_CD == 'M80022K', PRI_ICD_CD == 'M80021K', PRI_ICD_CD == 'M80019K',
                  PRI_ICD_CD == 'M80012K', PRI_ICD_CD == 'M80011K', PRI_ICD_CD == 'M8000XK',
                  PRI_ICD_CD == 'M948X9', PRI_ICD_CD == 'M948X8', PRI_ICD_CD == 'M948X7',
                  PRI_ICD_CD == 'M948X6', PRI_ICD_CD == 'M948X5', PRI_ICD_CD == 'M948X4',
                  PRI_ICD_CD == 'M948X3', PRI_ICD_CD == 'M948X2', PRI_ICD_CD == 'M948X1',
                  PRI_ICD_CD == 'M948X0', PRI_ICD_CD == 'M94359', PRI_ICD_CD == 'M94352',
                  PRI_ICD_CD == 'M94351', PRI_ICD_CD == 'M941', PRI_ICD_CD == 'M898X9',
                  PRI_ICD_CD == 'M898X8', PRI_ICD_CD == 'M898X7', PRI_ICD_CD == 'M898X6',
                  PRI_ICD_CD == 'M898X5', PRI_ICD_CD == 'M898X4', PRI_ICD_CD == 'M898X3',
                  PRI_ICD_CD == 'M898X2', PRI_ICD_CD == 'M898X1', PRI_ICD_CD == 'M898X0',
                  PRI_ICD_CD == 'M8959', PRI_ICD_CD == 'M8958', PRI_ICD_CD == 'M89579',
                  PRI_ICD_CD == 'M89572', PRI_ICD_CD == 'M89571', PRI_ICD_CD == 'M89569',
                  PRI_ICD_CD == 'M89562', PRI_ICD_CD == 'M89561', PRI_ICD_CD == 'M89559',
                  PRI_ICD_CD == 'M89552', PRI_ICD_CD == 'M89551', PRI_ICD_CD == 'M89549',
                  PRI_ICD_CD == 'M89542', PRI_ICD_CD == 'M89541', PRI_ICD_CD == 'M89539',
                  PRI_ICD_CD == 'M89532', PRI_ICD_CD == 'M89531', PRI_ICD_CD == 'M89529',
                  PRI_ICD_CD == 'M89522', PRI_ICD_CD == 'M89521', PRI_ICD_CD == 'M89519',
                  PRI_ICD_CD == 'M89512', PRI_ICD_CD == 'M89511', PRI_ICD_CD == 'M8950',
                  PRI_ICD_CD == 'M8939', PRI_ICD_CD == 'M8938', PRI_ICD_CD == 'M89379',
                  PRI_ICD_CD == 'M89372', PRI_ICD_CD == 'M89371', PRI_ICD_CD == 'M89369',
                  PRI_ICD_CD == 'M89364', PRI_ICD_CD == 'M89363', PRI_ICD_CD == 'M89362',
                  PRI_ICD_CD == 'M89361', PRI_ICD_CD == 'M89359', PRI_ICD_CD == 'M89352',
                  PRI_ICD_CD == 'M89351', PRI_ICD_CD == 'M89349', PRI_ICD_CD == 'M89342',
                  PRI_ICD_CD == 'M89341', PRI_ICD_CD == 'M89339', PRI_ICD_CD == 'M89334',
                  PRI_ICD_CD == 'M89333', PRI_ICD_CD == 'M89332', PRI_ICD_CD == 'M89331',
                  PRI_ICD_CD == 'M89329', PRI_ICD_CD == 'M89322', PRI_ICD_CD == 'M89321',
                  PRI_ICD_CD == 'M89319', PRI_ICD_CD == 'M89312', PRI_ICD_CD == 'M89311',
                  PRI_ICD_CD == 'M8930', PRI_ICD_CD == 'M8929', PRI_ICD_CD == 'M8928',
                  PRI_ICD_CD == 'M89279', PRI_ICD_CD == 'M89272', PRI_ICD_CD == 'M89271',
                  PRI_ICD_CD == 'M89269', PRI_ICD_CD == 'M89264', PRI_ICD_CD == 'M89263',
                  PRI_ICD_CD == 'M89262', PRI_ICD_CD == 'M89261', PRI_ICD_CD == 'M89259',
                  PRI_ICD_CD == 'M89252', PRI_ICD_CD == 'M89251', PRI_ICD_CD == 'M89249',
                  PRI_ICD_CD == 'M89242', PRI_ICD_CD == 'M89241', PRI_ICD_CD == 'M89239',
                  PRI_ICD_CD == 'M89234', PRI_ICD_CD == 'M89233', PRI_ICD_CD == 'M89232',
                  PRI_ICD_CD == 'M89231', PRI_ICD_CD == 'M89229', PRI_ICD_CD == 'M89222',
                  PRI_ICD_CD == 'M89221', PRI_ICD_CD == 'M89219', PRI_ICD_CD == 'M89212',
                  PRI_ICD_CD == 'M89211', PRI_ICD_CD == 'M8920', PRI_ICD_CD == 'M8589',
                  PRI_ICD_CD == 'M8588', PRI_ICD_CD == 'M85879', PRI_ICD_CD == 'M85872',
                  PRI_ICD_CD == 'M85871', PRI_ICD_CD == 'M85869', PRI_ICD_CD == 'M85862',
                  PRI_ICD_CD == 'M85861', PRI_ICD_CD == 'M85859', PRI_ICD_CD == 'M85852',
                  PRI_ICD_CD == 'M85851', PRI_ICD_CD == 'M85849', PRI_ICD_CD == 'M85842',
                  PRI_ICD_CD == 'M85841', PRI_ICD_CD == 'M85839', PRI_ICD_CD == 'M85832',
                  PRI_ICD_CD == 'M85831', PRI_ICD_CD == 'M85829', PRI_ICD_CD == 'M85822',
                  PRI_ICD_CD == 'M85821', PRI_ICD_CD == 'M85819', PRI_ICD_CD == 'M85812',
                  PRI_ICD_CD == 'M85811', PRI_ICD_CD == 'M8580', PRI_ICD_CD == 'M8519',
                  PRI_ICD_CD == 'M8518', PRI_ICD_CD == 'M85179', PRI_ICD_CD == 'M85172',
                  PRI_ICD_CD == 'M85171', PRI_ICD_CD == 'M85169', PRI_ICD_CD == 'M85162',
                  PRI_ICD_CD == 'M85161', PRI_ICD_CD == 'M85159', PRI_ICD_CD == 'M85152',
                  PRI_ICD_CD == 'M85151', PRI_ICD_CD == 'M85149', PRI_ICD_CD == 'M85142',
                  PRI_ICD_CD == 'M85141', PRI_ICD_CD == 'M85139', PRI_ICD_CD == 'M85132',
                  PRI_ICD_CD == 'M85131', PRI_ICD_CD == 'M85129', PRI_ICD_CD == 'M85122',
                  PRI_ICD_CD == 'M85121', PRI_ICD_CD == 'M85119', PRI_ICD_CD == 'M85112',
                  PRI_ICD_CD == 'M85111', PRI_ICD_CD == 'M8510', PRI_ICD_CD == 'M849',
                  PRI_ICD_CD == 'M8488', PRI_ICD_CD == 'M84879', PRI_ICD_CD == 'M84872',
                  PRI_ICD_CD == 'M84871', PRI_ICD_CD == 'M84869', PRI_ICD_CD == 'M84864',
                  PRI_ICD_CD == 'M84863', PRI_ICD_CD == 'M84862', PRI_ICD_CD == 'M84861',
                  PRI_ICD_CD == 'M84859', PRI_ICD_CD == 'M84852', PRI_ICD_CD == 'M84851',
                  PRI_ICD_CD == 'M84849', PRI_ICD_CD == 'M84842', PRI_ICD_CD == 'M84841',
                  PRI_ICD_CD == 'M84839', PRI_ICD_CD == 'M84834', PRI_ICD_CD == 'M84833',
                  PRI_ICD_CD == 'M84832', PRI_ICD_CD == 'M84831', PRI_ICD_CD == 'M84829',
                  PRI_ICD_CD == 'M84822', PRI_ICD_CD == 'M84821', PRI_ICD_CD == 'M84819',
                  PRI_ICD_CD == 'M84812', PRI_ICD_CD == 'M84811', PRI_ICD_CD == 'M8480',
                  PRI_ICD_CD == 'M21949', PRI_ICD_CD == 'M21942', PRI_ICD_CD == 'M21941',
                  PRI_ICD_CD == 'M21939', PRI_ICD_CD == 'M21932', PRI_ICD_CD == 'M21931',
                  PRI_ICD_CD == 'M216X9', PRI_ICD_CD == 'M216X2', PRI_ICD_CD == 'M216X1',
                  PRI_ICD_CD == 'M21379', PRI_ICD_CD == 'M21372', PRI_ICD_CD == 'M21371',
                  PRI_ICD_CD == 'M21079', PRI_ICD_CD == 'M21072', PRI_ICD_CD == 'M21071',
                  PRI_ICD_CD == 'M21969', PRI_ICD_CD == 'M21962', PRI_ICD_CD == 'M21961',
                  PRI_ICD_CD == 'M21929', PRI_ICD_CD == 'M21922', PRI_ICD_CD == 'M21921',
                  PRI_ICD_CD == 'M21829', PRI_ICD_CD == 'M21822', PRI_ICD_CD == 'M21821',
                  PRI_ICD_CD == 'M2180', PRI_ICD_CD == 'M21739', PRI_ICD_CD == 'M21734',
                  PRI_ICD_CD == 'M21733', PRI_ICD_CD == 'M21732', PRI_ICD_CD == 'M21731',
                  PRI_ICD_CD == 'M21729', PRI_ICD_CD == 'M21722', PRI_ICD_CD == 'M21721',
                  PRI_ICD_CD == 'M2170', PRI_ICD_CD == 'M21279', PRI_ICD_CD == 'M21272',
                  PRI_ICD_CD == 'M21271', PRI_ICD_CD == 'M21269', PRI_ICD_CD == 'M21262',
                  PRI_ICD_CD == 'M21261', PRI_ICD_CD == 'M21259', PRI_ICD_CD == 'M21252',
                  PRI_ICD_CD == 'M21251', PRI_ICD_CD == 'M21249', PRI_ICD_CD == 'M21242',
                  PRI_ICD_CD == 'M21241', PRI_ICD_CD == 'M21239', PRI_ICD_CD == 'M21232',
                  PRI_ICD_CD == 'M21231', PRI_ICD_CD == 'M21229', PRI_ICD_CD == 'M21222',
                  PRI_ICD_CD == 'M21221', PRI_ICD_CD == 'M21219', PRI_ICD_CD == 'M21212',
                  PRI_ICD_CD == 'M21211', PRI_ICD_CD == 'M2120', PRI_ICD_CD == 'Q652',
                  PRI_ICD_CD == 'Q6500', PRI_ICD_CD == 'Q6689', PRI_ICD_CD == 'Q7649',
                  PRI_ICD_CD == 'Q76419', PRI_ICD_CD == 'Q76415', PRI_ICD_CD == 'Q76414',
                  PRI_ICD_CD == 'Q76413', PRI_ICD_CD == 'Q76412', PRI_ICD_CD == 'Q76411',
                  PRI_ICD_CD == 'R079', PRI_ICD_CD == 'R109', PRI_ICD_CD == 'R100',
                  PRI_ICD_CD == 'S2239XA', PRI_ICD_CD == 'S2232XA', PRI_ICD_CD == 'S2231XA',
                  PRI_ICD_CD == 'S2243XA', PRI_ICD_CD == 'S2242XA', PRI_ICD_CD == 'S2241XA',
                  PRI_ICD_CD == 'S2249XA', PRI_ICD_CD == 'S42009A', PRI_ICD_CD == 'S42002A',
                  PRI_ICD_CD == 'S42001A', PRI_ICD_CD == 'S42209A', PRI_ICD_CD == 'S42202A',
                  PRI_ICD_CD == 'S42201A', PRI_ICD_CD == 'S4292XA', PRI_ICD_CD == 'S4291XA',
                  PRI_ICD_CD == 'S4290XA', PRI_ICD_CD == 'S42309A', PRI_ICD_CD == 'S42302A',
                  PRI_ICD_CD == 'S42301A', PRI_ICD_CD == 'S52126A', PRI_ICD_CD == 'S52125A',
                  PRI_ICD_CD == 'S52124A', PRI_ICD_CD == 'S52123A', PRI_ICD_CD == 'S52122A',
                  PRI_ICD_CD == 'S52121A', PRI_ICD_CD == 'S52299A', PRI_ICD_CD == 'S52292A',
                  PRI_ICD_CD == 'S52291A', PRI_ICD_CD == 'S52283A', PRI_ICD_CD == 'S52282A',
                  PRI_ICD_CD == 'S52281A', PRI_ICD_CD == 'S52266A', PRI_ICD_CD == 'S52265A',
                  PRI_ICD_CD == 'S52264A', PRI_ICD_CD == 'S52263A', PRI_ICD_CD == 'S52262A',
                  PRI_ICD_CD == 'S52261A', PRI_ICD_CD == 'S52256A', PRI_ICD_CD == 'S52255A',
                  PRI_ICD_CD == 'S52254A', PRI_ICD_CD == 'S52253A', PRI_ICD_CD == 'S52252A',
                  PRI_ICD_CD == 'S52251A', PRI_ICD_CD == 'S52246A', PRI_ICD_CD == 'S52245A',
                  PRI_ICD_CD == 'S52244A', PRI_ICD_CD == 'S52243A', PRI_ICD_CD == 'S52242A',
                  PRI_ICD_CD == 'S52241A', PRI_ICD_CD == 'S52236A', PRI_ICD_CD == 'S52235A',
                  PRI_ICD_CD == 'S52234A', PRI_ICD_CD == 'S52233A', PRI_ICD_CD == 'S52232A',
                  PRI_ICD_CD == 'S52231A', PRI_ICD_CD == 'S52226A', PRI_ICD_CD == 'S52225A',
                  PRI_ICD_CD == 'S52224A', PRI_ICD_CD == 'S52223A', PRI_ICD_CD == 'S52222A',
                  PRI_ICD_CD == 'S52221A', PRI_ICD_CD == 'S52219A', PRI_ICD_CD == 'S52212A',
                  PRI_ICD_CD == 'S52211A', PRI_ICD_CD == 'S52209A', PRI_ICD_CD == 'S52202A',
                  PRI_ICD_CD == 'S52201A', PRI_ICD_CD == 'S59299A', PRI_ICD_CD == 'S59292A',
                  PRI_ICD_CD == 'S59291A', PRI_ICD_CD == 'S59249A', PRI_ICD_CD == 'S59242A',
                  PRI_ICD_CD == 'S59241A', PRI_ICD_CD == 'S59239A', PRI_ICD_CD == 'S59232A',
                  PRI_ICD_CD == 'S59231A', PRI_ICD_CD == 'S59229A', PRI_ICD_CD == 'S59222A',
                  PRI_ICD_CD == 'S59221A', PRI_ICD_CD == 'S59219A', PRI_ICD_CD == 'S59212A',
                  PRI_ICD_CD == 'S59211A', PRI_ICD_CD == 'S59209A', PRI_ICD_CD == 'S59202A',
                  PRI_ICD_CD == 'S59201A', PRI_ICD_CD == 'S52599A', PRI_ICD_CD == 'S52592A',
                  PRI_ICD_CD == 'S52591A', PRI_ICD_CD == 'S52579A', PRI_ICD_CD == 'S52572A',
                  PRI_ICD_CD == 'S52571A', PRI_ICD_CD == 'S52569A', PRI_ICD_CD == 'S52562A',
                  PRI_ICD_CD == 'S52561A', PRI_ICD_CD == 'S52559A', PRI_ICD_CD == 'S52552A',
                  PRI_ICD_CD == 'S52551A', PRI_ICD_CD == 'S52549A', PRI_ICD_CD == 'S52542A',
                  PRI_ICD_CD == 'S52541A', PRI_ICD_CD == 'S52516A', PRI_ICD_CD == 'S52515A',
                  PRI_ICD_CD == 'S52514A', PRI_ICD_CD == 'S52513A', PRI_ICD_CD == 'S52512A',
                  PRI_ICD_CD == 'S52511A', PRI_ICD_CD == 'S52509A', PRI_ICD_CD == 'S52502A',
                  PRI_ICD_CD == 'S52501A', PRI_ICD_CD == 'S5292XA', PRI_ICD_CD == 'S5291XA',
                  PRI_ICD_CD == 'S5290XA', PRI_ICD_CD == 'S62109A', PRI_ICD_CD == 'S62102A',
                  PRI_ICD_CD == 'S62101A', PRI_ICD_CD == 'S62036A', PRI_ICD_CD == 'S62035A',
                  PRI_ICD_CD == 'S62034A', PRI_ICD_CD == 'S62033A', PRI_ICD_CD == 'S62032A',
                  PRI_ICD_CD == 'S62031A', PRI_ICD_CD == 'S62026A', PRI_ICD_CD == 'S62025A',
                  PRI_ICD_CD == 'S62024A', PRI_ICD_CD == 'S62023A', PRI_ICD_CD == 'S62022A',
                  PRI_ICD_CD == 'S62021A', PRI_ICD_CD == 'S62016A', PRI_ICD_CD == 'S62015A',
                  PRI_ICD_CD == 'S62014A', PRI_ICD_CD == 'S62013A', PRI_ICD_CD == 'S62012A',
                  PRI_ICD_CD == 'S62011A', PRI_ICD_CD == 'S62009A', PRI_ICD_CD == 'S62002A',
                  PRI_ICD_CD == 'S62001A', PRI_ICD_CD == 'S62309A', PRI_ICD_CD == 'S62609A',
                  PRI_ICD_CD == 'S62608A', PRI_ICD_CD == 'S62607A', PRI_ICD_CD == 'S62606A',
                  PRI_ICD_CD == 'S62605A', PRI_ICD_CD == 'S62604A', PRI_ICD_CD == 'S62603A',
                  PRI_ICD_CD == 'S62602A', PRI_ICD_CD == 'S62601A', PRI_ICD_CD == 'S62600A',
                  PRI_ICD_CD == 'S62509A', PRI_ICD_CD == 'S62502A', PRI_ICD_CD == 'S62501A',
                  PRI_ICD_CD == 'S89099A', PRI_ICD_CD == 'S89092A', PRI_ICD_CD == 'S89091A',
                  PRI_ICD_CD == 'S89049A', PRI_ICD_CD == 'S89042A', PRI_ICD_CD == 'S89041A',
                  PRI_ICD_CD == 'S89039A', PRI_ICD_CD == 'S89032A', PRI_ICD_CD == 'S89031A',
                  PRI_ICD_CD == 'S89029A', PRI_ICD_CD == 'S89022A', PRI_ICD_CD == 'S89021A',
                  PRI_ICD_CD == 'S89019A', PRI_ICD_CD == 'S89012A', PRI_ICD_CD == 'S89011A',
                  PRI_ICD_CD == 'S89009A', PRI_ICD_CD == 'S89002A', PRI_ICD_CD == 'S82199A',
                  PRI_ICD_CD == 'S82192A', PRI_ICD_CD == 'S82191A', PRI_ICD_CD == 'S82156A',
                  PRI_ICD_CD == 'S82155A', PRI_ICD_CD == 'S82154A', PRI_ICD_CD == 'S82153A',
                  PRI_ICD_CD == 'S82152A', PRI_ICD_CD == 'S82151A', PRI_ICD_CD == 'S82146A',
                  PRI_ICD_CD == 'S82145A', PRI_ICD_CD == 'S82144A', PRI_ICD_CD == 'S82143A',
                  PRI_ICD_CD == 'S82142A', PRI_ICD_CD == 'S82141A', PRI_ICD_CD == 'S82136A',
                  PRI_ICD_CD == 'S82135A', PRI_ICD_CD == 'S82134A', PRI_ICD_CD == 'S82133A',
                  PRI_ICD_CD == 'S82132A', PRI_ICD_CD == 'S82131A', PRI_ICD_CD == 'S82126A',
                  PRI_ICD_CD == 'S82125A', PRI_ICD_CD == 'S82124A', PRI_ICD_CD == 'S82123A',
                  PRI_ICD_CD == 'S82122A', PRI_ICD_CD == 'S82121A', PRI_ICD_CD == 'S82116A',
                  PRI_ICD_CD == 'S82115A', PRI_ICD_CD == 'S82114A', PRI_ICD_CD == 'S82113A',
                  PRI_ICD_CD == 'S82112A', PRI_ICD_CD == 'S82111A', PRI_ICD_CD == 'S82109A',
                  PRI_ICD_CD == 'S82102A', PRI_ICD_CD == 'S82101A', PRI_ICD_CD == 'S82202A',
                  PRI_ICD_CD == 'S82402A', PRI_ICD_CD == 'S82401A', PRI_ICD_CD == 'S92909A',
                  PRI_ICD_CD == 'S92902A', PRI_ICD_CD == 'S92901A', PRI_ICD_CD == 'S92356A',
                  PRI_ICD_CD == 'S92355A', PRI_ICD_CD == 'S92354A', PRI_ICD_CD == 'S92353A',
                  PRI_ICD_CD == 'S92352A', PRI_ICD_CD == 'S92351G', PRI_ICD_CD == 'S92351A',
                  PRI_ICD_CD == 'S92346A', PRI_ICD_CD == 'S92345A', PRI_ICD_CD == 'S92344A',
                  PRI_ICD_CD == 'S92343A', PRI_ICD_CD == 'S92342A', PRI_ICD_CD == 'S92341A',
                  PRI_ICD_CD == 'S92336A', PRI_ICD_CD == 'S92335A', PRI_ICD_CD == 'S92334A',
                  PRI_ICD_CD == 'S92333A', PRI_ICD_CD == 'S92332A', PRI_ICD_CD == 'S92331A',
                  PRI_ICD_CD == 'S92326A', PRI_ICD_CD == 'S92325A', PRI_ICD_CD == 'S92324A',
                  PRI_ICD_CD == 'S92323A', PRI_ICD_CD == 'S92322A', PRI_ICD_CD == 'S92321A',
                  PRI_ICD_CD == 'S92316A', PRI_ICD_CD == 'S92315A', PRI_ICD_CD == 'S92314A',
                  PRI_ICD_CD == 'S92313A', PRI_ICD_CD == 'S92312A', PRI_ICD_CD == 'S92311A',
                  PRI_ICD_CD == 'S92302A', PRI_ICD_CD == 'S92301A', PRI_ICD_CD == 'S92309A',
                  PRI_ICD_CD == 'S92209A', PRI_ICD_CD == 'S92202A', PRI_ICD_CD == 'S92201A',
                  PRI_ICD_CD == 'S43006A', PRI_ICD_CD == 'S43005A', PRI_ICD_CD == 'S43004A',
                  PRI_ICD_CD == 'S43003A', PRI_ICD_CD == 'S43002A', PRI_ICD_CD == 'S43001A',
                  PRI_ICD_CD == 'S43159A', PRI_ICD_CD == 'S43152A', PRI_ICD_CD == 'S43151A',
                  PRI_ICD_CD == 'S43149A', PRI_ICD_CD == 'S43142A', PRI_ICD_CD == 'S43141A',
                  PRI_ICD_CD == 'S43139A', PRI_ICD_CD == 'S43132A', PRI_ICD_CD == 'S43131A',
                  PRI_ICD_CD == 'S43129A', PRI_ICD_CD == 'S43122A', PRI_ICD_CD == 'S43121A',
                  PRI_ICD_CD == 'S43119A', PRI_ICD_CD == 'S43112A', PRI_ICD_CD == 'S43111A',
                  PRI_ICD_CD == 'S43109A', PRI_ICD_CD == 'S43102A', PRI_ICD_CD == 'S43101A',
                  PRI_ICD_CD == 'S66912A', PRI_ICD_CD == 'S66911A', PRI_ICD_CD == 'S63509A',
                  PRI_ICD_CD == 'S63502A', PRI_ICD_CD == 'S63501A', PRI_ICD_CD == 'S66919A',
                  PRI_ICD_CD == 'S6392XA', PRI_ICD_CD == 'S6391XA', PRI_ICD_CD == 'S6390XA',
                  PRI_ICD_CD == 'S96919A', PRI_ICD_CD == 'S93409A', PRI_ICD_CD == 'S93402A',
                  PRI_ICD_CD == 'S93401A', PRI_ICD_CD == 'S96912A', PRI_ICD_CD == 'S96911A',
                  PRI_ICD_CD == 'S96819A', PRI_ICD_CD == 'S96812A', PRI_ICD_CD == 'S96811A',
                  PRI_ICD_CD == 'S96219A', PRI_ICD_CD == 'S96212A', PRI_ICD_CD == 'S96211A',
                  PRI_ICD_CD == 'S96119A', PRI_ICD_CD == 'S96112A', PRI_ICD_CD == 'S96111A',
                  PRI_ICD_CD == 'S96019A', PRI_ICD_CD == 'S96012A', PRI_ICD_CD == 'S93499A',
                  PRI_ICD_CD == 'S93492A', PRI_ICD_CD == 'S93491A', PRI_ICD_CD == 'S86019A',
                  PRI_ICD_CD == 'S86012A', PRI_ICD_CD == 'S86011A', PRI_ICD_CD == 'S93609A',
                  PRI_ICD_CD == 'S93602A', PRI_ICD_CD == 'S93601A', PRI_ICD_CD == 'S060X0A',
                  PRI_ICD_CD == 'S8002XA', PRI_ICD_CD == 'S8001XA', PRI_ICD_CD == 'S8000XA',
                  PRI_ICD_CD == 'S0990XA', PRI_ICD_CD == 'S098XXA', PRI_ICD_CD == 'S0919XA',
                  PRI_ICD_CD == 'S0911XA', PRI_ICD_CD == 'S0910XA', PRI_ICD_CD == 'S199XXA',
                  PRI_ICD_CD == 'S1989XA', PRI_ICD_CD == 'S1985XA', PRI_ICD_CD == 'S1984XA',
                  PRI_ICD_CD == 'S1983XA', PRI_ICD_CD == 'S1982XA', PRI_ICD_CD == 'S1981XA',
                  PRI_ICD_CD == 'S1980XA', PRI_ICD_CD == 'S169XXA', PRI_ICD_CD == 'S168XXA',
                  PRI_ICD_CD == 'S0993XA', PRI_ICD_CD == 'S0992XA', PRI_ICD_CD == 'S3993XA',
                  PRI_ICD_CD == 'S3992XA', PRI_ICD_CD == 'S3983XA', PRI_ICD_CD == 'S3982XA',
                  PRI_ICD_CD == 'S39093A', PRI_ICD_CD == 'S39092A', PRI_ICD_CD == 'S39003A',
                  PRI_ICD_CD == 'S39002A']
    choices = [ICD10to9_2, '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73382', '73382',
               '73382', '73382', '73382', '73382', '73382', '73382', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73399', '73399', '73399', '73399', '73399', '73399',
               '73399', '73399', '73600', '73600', '73600', '73600', '73600', '73600',
               '73679', '73679', '73679', '73679', '73679', '73679', '73679', '73679',
               '73679', '73689', '73689', '73689', '73689', '73689', '73689', '73689',
               '73689', '73689', '73689', '73689', '73689', '73689', '73689', '73689',
               '73689', '73689', '73689', '73689', '73689', '73689', '73689', '73689',
               '73689', '73689', '73689', '73689', '73689', '73689', '73689', '73689',
               '73689', '73689', '73689', '73689', '73689', '73689', '73689', '73689',
               '73689', '73689', '75430', '75430', '75567', '75619', '75619', '75619',
               '75619', '75619', '75619', '75619', '78650', '78900', '78900', '80701',
               '80701', '80701', '80704', '80704', '80704', '80709', '81000', '81000',
               '81000', '81200', '81200', '81200', '81220', '81220', '81220', '81220',
               '81220', '81220', '81305', '81305', '81305', '81305', '81305', '81305',
               '81322', '81322', '81322', '81322', '81322', '81322', '81322', '81322',
               '81322', '81322', '81322', '81322', '81322', '81322', '81322', '81322',
               '81322', '81322', '81322', '81322', '81322', '81322', '81322', '81322',
               '81322', '81322', '81322', '81322', '81322', '81322', '81322', '81322',
               '81322', '81322', '81322', '81322', '81322', '81322', '81322', '81322',
               '81322', '81322', '81342', '81342', '81342', '81342', '81342', '81342',
               '81342', '81342', '81342', '81342', '81342', '81342', '81342', '81342',
               '81342', '81342', '81342', '81342', '81342', '81342', '81342', '81342',
               '81342', '81342', '81342', '81342', '81342', '81342', '81342', '81342',
               '81342', '81342', '81342', '81342', '81342', '81342', '81342', '81342',
               '81342', '81342', '81342', '81342', '81380', '81380', '81380', '81400',
               '81400', '81400', '81401', '81401', '81401', '81401', '81401', '81401',
               '81401', '81401', '81401', '81401', '81401', '81401', '81401', '81401',
               '81401', '81401', '81401', '81401', '81401', '81401', '81401', '81500',
               '81600', '81600', '81600', '81600', '81600', '81600', '81600', '81600',
               '81600', '81600', '81600', '81600', '81600', '82300', '82300', '82300',
               '82300', '82300', '82300', '82300', '82300', '82300', '82300', '82300',
               '82300', '82300', '82300', '82300', '82300', '82300', '82300', '82300',
               '82300', '82300', '82300', '82300', '82300', '82300', '82300', '82300',
               '82300', '82300', '82300', '82300', '82300', '82300', '82300', '82300',
               '82300', '82300', '82300', '82300', '82300', '82300', '82300', '82300',
               '82300', '82300', '82300', '82300', '82300', '82300', '82300', '82300',
               '82300', '82300', '82380', '82381', '82381', '82520', '82520', '82520',
               '82525', '82525', '82525', '82525', '82525', '82525', '82525', '82525',
               '82525', '82525', '82525', '82525', '82525', '82525', '82525', '82525',
               '82525', '82525', '82525', '82525', '82525', '82525', '82525', '82525',
               '82525', '82525', '82525', '82525', '82525', '82525', '82525', '82525',
               '82525', '82529', '82529', '82529', '82529', '83100', '83100', '83100',
               '83100', '83100', '83100', '83104', '83104', '83104', '83104', '83104',
               '83104', '83104', '83104', '83104', '83104', '83104', '83104', '83104',
               '83104', '83104', '83104', '83104', '83104', '84200', '84200', '84200',
               '84200', '84200', '84210', '84210', '84210', '84210', '84500', '84500',
               '84500', '84500', '84509', '84509', '84509', '84509', '84509', '84509',
               '84509', '84509', '84509', '84509', '84509', '84509', '84509', '84509',
               '84509', '84509', '84509', '84509', '84509', '84510', '84510', '84510',
               '85409', '92411', '92411', '92411', '95901', '95901', '95901', '95901',
               '95901', '95909', '95909', '95909', '95909', '95909', '95909', '95909',
               '95909', '95909', '95909', '95909', '95909', '95919', '95919', '95919',
               '95919', '95919', '95919', '95919', '95919']
    default_cond = ''
    return np.select(conditions, choices, default=default_cond)


def primary_icd9_code(row):
    if row['ICD9'] == '':
        return row['PRI_ICD_CD']
    else:
        return row['ICD9']


def prmry_icd9_cd_5digit(row):
    if len(row) == 3:
        return str(row) + '00'
    elif len(row) == 4:
        return str(row) + '0'
    else:
        return row


def icd9_to_mdc(row):
    if ((row >= 'B20') & (row <= 'B24')) or ((row >= '042') & (row <= '044')):
        return 'AIDS & ARC'
    elif ((row >= 'A00') & (row <= 'B99')) or ((row >= '001') & (row <= '139')):
        return 'INFECTIOUS DISEASES'
    elif ((row >= 'C00') & (row <= 'D49')) or ((row >= '140') & (row <= '239')):
        return 'NEOPLASMS'
    elif ((row >= 'D50') & (row <= 'D89')) or ((row >= '279') & (row <= '289')):
        return 'BLOOD & BLOOD FORMING ORGANS'
    elif ((row >= 'E00') & (row <= 'E99')) or ((row >= '240') & (row <= '278')):
        return 'ENDOCRINE SYSTEM'
    elif ((row in ['F01', 'F02', 'F03', 'F04', 'F05', 'F06', 'F20', 'F21', 'F22', 'F23', 'F24', 'F25', 'F28', 'F29', 'F30', 'F31', 'F32', 'F33', 'F34', 'F39', 'F53', 'F84'])) or ((row >= '290') & (row <= '299')):
        return 'PSYCHOSES'
    elif ((row >= 'F01') & (row <= 'F99')) or ((row >= '300') & (row <= '319')):
        return 'NON-PSYCHOTIC MENTAL DISORDERS'
    elif ((row >= 'G00') & (row <= 'G99')) or ((row >= '320') & (row <= '359')):
        return 'NERVOUS SYSTEM'
    elif ((row >= 'H00') & (row <= 'H59')) or ((row >= '360') & (row <= '379')):
        return 'EYE DISORDERS'
    elif ((row >= 'H60') & (row <= 'H95')) or ((row >= '380') & (row <= '389')):
        return 'EAR DISORDERS'
    elif ((row >= 'I00') & (row <= 'I99')) or ((row >= '390') & (row <= '459')):
        return 'CIRCULATORY SYSTEM'
    elif ((row >= 'J00') & (row <= 'J99')) or ((row >= '460') & (row <= '519')):
        return 'RESPIRATORY SYSTEM'
    elif ((row >= 'K00') & (row <= 'K95')) or ((row >= '520') & (row <= '579')):
        return 'DIGESTIVE  SYSTEM'
    elif ((row >= 'L00') & (row <= 'L99')) or ((row >= '680') & (row <= '709')):
        return 'SKIN DISORDERS'
    elif ((row >= 'M00') & (row <= 'M96')) or ((row >= '710') & (row <= '739')):
        return 'MUSCULOSKELETAL SYSTEM'
    elif ((row >= 'N00') & (row <= 'N99')) or ((row >= '580') & (row <= '629')):
        return 'GENITOURINARY SYSTEM'
    elif ((row == '650')) or ((row in ['V22', 'V24', 'V27', 'Z33', 'Z34', 'Z39', 'Z3A', 'O80'])):
        return 'NORMAL PREGNANCY & DELIVERY'
    elif ((row >= 'O00') & (row <= 'O99')) or ((row >= '630') & (row <= '679')):
        return 'COMPLICATIONS OF PREGNANCY'
    elif ((row >= 'P00') & (row <= 'P96')) or ((row >= '760') & (row <= '779')):
        return 'PERINATAL COMPLICATIONS'
    elif ((row >= 'Q00') & (row <= 'Q99')) or ((row >= '740') & (row <= '759')):
        return 'CONGENITAL ANOMALIES'
    elif ((row == '000') or (row == '') or (row == 'Z75')):
        return 'UNKNOWN'
    elif ((row >= 'R00') & (row <= 'R99')) or ((row >= '780') & (row <= '799')) or ((row >= 'Z00') & (row <= 'Z99')):
        return 'ILL DEFINED CONDITIONS'
    else:
        return'INJURY & POISONING'


def icd9(row):
    if row.isdigit() is True:
        return row
    else:
        return ''


def icd123(MDC, V2, V3, ICD9, RTW_P):
    conditions = [(MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7809') & (RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '55090') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '9599') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '486') & (
        RTW_P == 1) & (V2 == 1) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4299') & (
            RTW_P == 1) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '487') & (
            RTW_P == 1) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5539') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '5920') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7245') & (
            RTW_P == 1) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '490') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '540') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '999') & (
            RTW_P == 1) & (V2 == 0) & (V3 == 0),
        (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '539') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '486') & (
            RTW_P == 1) & (V2 == 0) & (V3 == 0),
        (MDC == 'NERVOUS SYSTEM') & (ICD9 == '3540') & (
            RTW_P == 1) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '780') & (
            RTW_P == 1) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5531') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6262') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5409') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '2189') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4870') & (
            RTW_P == 1) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '57420') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '780') & (
            RTW_P == 1) & (V2 == 1) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '490') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '463') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'NORMAL PREGNANCY & DELIVERY') & (
            ICD9 == '650') & (RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '487') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7242') & (
            RTW_P == 1) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '780') & (
            RTW_P == 1) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30151') & (RTW_P == 1) & (V2 == 0) & (V3 == 0),
        (MDC == 'NORMAL PREGNANCY & DELIVERY') & (
            ICD9 == '650') & (RTW_P == 1) & (V2 == 0) & (V3 == 0),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '648') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '27801') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '66971') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'UNKNOWN') & (ICD9 == '74') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '575') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5759') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '6697') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '486') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'NERVOUS SYSTEM') & (ICD9 == '3540') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '27801') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4660') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6202') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'NORMAL PREGNANCY & DELIVERY') & (
            ICD9 == '650') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '470') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '470') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '56211') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4659') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4870') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7809') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '64681') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '6697') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '66971') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '486') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5750') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '27411') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8360') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30151') & (RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '64693') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '6510') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9597') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '644') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '1749') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4749') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '64690') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4299') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4660') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7179') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '487') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5210') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '642') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '29682') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '540') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '29689') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5409') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '67903') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NORMAL PREGNANCY & DELIVERY') & (
            ICD9 == '650') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '463') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '64403') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '487') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9599') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '999') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7295') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '780') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '574') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5206') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '29682') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '646') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '470') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '2181') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '461') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '575') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '29622') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4878') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '821') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6271') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '780') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71590') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4019') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '621') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '57510') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30151') & (RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8240') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '29622') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'PSYCHOSES') & (ICD9 == '29680') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30928') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71516') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '541') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '57400') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3089') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4739') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8244') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8250') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '29621') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71515') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71985') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4240') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4618') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '57420') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6262') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30000') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '311') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6218') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '311') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'PSYCHOSES') & (ICD9 == '29623') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '634') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '646') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'PSYCHOSES') & (ICD9 == '29630') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6299') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72210') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '29689') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3009') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '490') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '2962') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6262') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'PSYCHOSES') & (ICD9 == '29680') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '455') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8242') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '29633') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '81342') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4660') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5759') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71596') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71536') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5439') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '82300') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'COMPLICATIONS OF PREGNANCY') & (
            ICD9 == '6469') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71511') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '57410') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5758') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8270') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3089') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '724') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8248') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4659') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9598') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '185') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '84500') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72400') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3090') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71515') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '999') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'PSYCHOSES') & (ICD9 == '29630') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8220') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '824') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30981') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NEOPLASMS') & (ICD9 == '218') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '29640') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6268') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '29682') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30000') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72403') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NEOPLASMS') & (ICD9 == '2189') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '29633') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7211') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71595') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9599') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72210') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30462') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '82520') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7363') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6259') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '2962') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '308') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '311') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5750') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '543') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6268') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NEOPLASMS') & (ICD9 == '2189') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7230') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71509') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '82520') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7173') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '461') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '715') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30981') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8208') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71516') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '810') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71596') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '73382') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30001') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72403') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3090') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '311') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7384') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30000') & (RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7177') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'PSYCHOSES') & (ICD9 == '29621') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '824') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '5920') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8248') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3009') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6202') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4871') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71887') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4241') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '490') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '4558') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '308') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '29632') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6269') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6218') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4870') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7177') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71511') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4660') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72610') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '81400') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30002') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '812') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '82525') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'PSYCHOSES') & (ICD9 == '29620') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3000') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '81200') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72762') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6259') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NEOPLASMS') & (ICD9 == '2180') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7262') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7179') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '29632') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72610') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7176') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6269') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7244') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7230') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30002') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72761') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6170') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72613') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71740') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71881') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7384') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '246') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '81000') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30392') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '575') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '470') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72271') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72761') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71789') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71945') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '621') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'CONGENITAL ANOMALIES') & (ICD9 == '75430') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '41092') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '29620') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4659') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30928') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '81401') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '340') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7234') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '818') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72402') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'EYE DISORDERS') & (ICD9 == '3669') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7224') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3039') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8054') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5539') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7179') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72619') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '550') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7998') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '82525') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8404') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5400') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30001') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'EYE DISORDERS') & (ICD9 == '366') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '617') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '53') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4140') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30392') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3089') & (RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '815') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4280') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30390') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6202') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7175') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5533') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4289') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71881') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30000') & (RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'PSYCHOSES') & (ICD9 == '29623') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '81500') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '410') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '486') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4292') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3049') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9596') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5531') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7261') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '480') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72402') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72291') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72619') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7366') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71887') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '55320') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7210') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7210') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8408') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8362') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71991') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7363') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4140') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '717') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '73679') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '27801') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72210') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7220') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7382') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '311') & (RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8404') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6200') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '42979') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72767') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7262') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '46400') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '55091') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7999') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3089') & (RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7220') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '81600') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7231') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7260') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71947') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4241') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7242') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7245') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71991') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8442') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4373') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4292') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7261') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8449') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71946') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7234') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '719') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72671') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '55092') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3049') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72252') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '61172') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4378') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7211') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '311') & (RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8442') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4299') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6179') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '55090') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '304') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7242') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71945') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '2469') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3000') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4299') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '539') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5521') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4379') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5759') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '55221') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '717') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '55010') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '27411') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71946') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4275') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72252') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6299') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '410') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9592') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '84509') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '73679') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7224') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7366') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72293') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '111') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8360') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8260') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8438') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4439') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '73600') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72293') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NEOPLASMS') & (ICD9 == '1990') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72632') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '586') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72673') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '80709') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4739') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NEOPLASMS') & (ICD9 == '2180') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '566') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72210') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '49120') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '27801') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '27800') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9597') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5531') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '75') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71514') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8070') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8408') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7140') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71941') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6256') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '723') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '55321') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72671') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4280') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7245') & (
            RTW_P == 0) & (V2 == 1) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '73670') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '5990') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8361') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7140') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8448') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8449') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NERVOUS SYSTEM') & (ICD9 == '4359') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7244') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9593') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30390') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7241') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71941') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '5920') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '722') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7999') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '55329') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '73689') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '493') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7292') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '722') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8360') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71996') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'SKIN DISORDERS') & (ICD9 == '7071') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4151') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '95919') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9592') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'EYE DISORDERS') & (ICD9 == '379') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7271') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8361') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '85409') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5651') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3004') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '789') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7213') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4254') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5539') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3039') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '43491') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7222') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7295') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7244') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9597') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6111') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '840') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8362') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7200') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7241') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72673') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7222') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5523') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '85409') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '55012') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8409') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71947') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '959') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '486') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72871') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '493') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4359') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7352') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '460') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '602') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6111') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '90') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '436') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '42731') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '5939') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '43491') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'SKIN DISORDERS') & (ICD9 == '7062') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '51889') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5559') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8409') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4359') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '724') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'CONGENITAL ANOMALIES') & (ICD9 == '75567') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7295') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NERVOUS SYSTEM') & (ICD9 == '3510') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '1991') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4151') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '816') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '239') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5529') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30151') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7354') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7292') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7352') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72670') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72871') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '1890') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4340') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30002') & (RTW_P == 0) & (V2 == 1) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '480') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '274') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CONGENITAL ANOMALIES') & (ICD9 == '75567') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7170') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '2396') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5559') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7271') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'SKIN DISORDERS') & (ICD9 == '6829') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7100') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NERVOUS SYSTEM') & (ICD9 == '340') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '5969') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4379') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '42731') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6029') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '84500') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '1539') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9999') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7100') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7354') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '1744') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '724') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7350') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '49120') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NERVOUS SYSTEM') & (ICD9 == '3540') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '436') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '84500') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9599') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7809') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9590') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'SKIN DISORDERS') & (ICD9 == '6822') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71883') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71964') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '2330') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7231') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7243') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8509') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NERVOUS SYSTEM') & (ICD9 == '3542') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'EYE DISORDERS') & (ICD9 == '36107') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7291') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72703') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8488') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '569') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'BLOOD & BLOOD FORMING ORGANS') & (
            ICD9 == '2808') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9595') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5609') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '1991') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'SKIN DISORDERS') & (ICD9 == '6826') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '611') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7803') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'EYE DISORDERS') & (ICD9 == '3619') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '95919') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '585') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NEOPLASMS') & (ICD9 == '1740') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7803') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8820') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7243') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '30151') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9594') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5699') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '431') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8470') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '20280') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '496') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                     '3102') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '5939') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7242') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NEOPLASMS') & (ICD9 == '1749') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '1749') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '24990') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7231') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8509') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7890') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '537') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9591') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '1369') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '1830') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'SKIN DISORDERS') & (ICD9 == '6826') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '780') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8830') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '1541') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '78650') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '153') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7840') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '25000') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7242') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '999') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '56211') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '1629') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7291') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72703') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '56210') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7245') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7350') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '78650') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '496') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NERVOUS SYSTEM') & (ICD9 == '3540') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7245') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NERVOUS SYSTEM') & (ICD9 == '346') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8472') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8470') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9591') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '185') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '56211') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '24990') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7802') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '1368') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9599') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '174') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8472') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NEOPLASMS') & (ICD9 == '1919') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '585') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5770') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5609') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7809') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '78900') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NEOPLASMS') & (ICD9 == '1820') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '193') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5770') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '1809') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4019') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '1729') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '78900') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4019') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7890') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7802') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '1629') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NEOPLASMS') & (ICD9 == '179') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '185') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7865') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NEOPLASMS') & (ICD9 == '1509') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '2509') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '2509') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5379') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NERVOUS SYSTEM') & (ICD9 == '34690') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9590') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NERVOUS SYSTEM') & (ICD9 == '346') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '27411') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7804') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '780') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'SKIN DISORDERS') & (ICD9 == '6829') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8450') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '401') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NEOPLASMS') & (ICD9 == '1579') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NERVOUS SYSTEM') & (ICD9 == '340') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NERVOUS SYSTEM') & (ICD9 == '34610') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'NERVOUS SYSTEM') & (ICD9 == '34610') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7865') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7804') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'EAR DISORDERS') & (ICD9 == '3861') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7840') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'NERVOUS SYSTEM') & (ICD9 == '34690') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '999') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'INJURY & POISONING') & (ICD9 == '9999') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 1),
        (MDC == 'EAR DISORDERS') & (ICD9 == '38611') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'INJURY & POISONING') & (ICD9 == '8479') & (
            RTW_P == 0) & (V2 == 0) & (V3 == 0),
        (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '401') & (RTW_P == 0) & (V2 == 0) & (V3 == 1)]
    choices = ['5', '6', '7', '9', '10', '11', '17', '22', '25', '38', '39',
               '40', '41', '44', '45', '46', '48', '49', '51', '55', '56', '58', '62', '66',
               '68', '70', '72', '73', '77', '91', '95', '98', '108', '110', '112', '113',
               '114', '115', '117', '119', '120', '124', '125', '127', '129', '132', '134',
               '138', '140', '144', '148', '153', '160', '161', '162', '163', '164', '166',
               '178', '179', '180', '189', '195', '204', '205', '207', '208', '209', '210',
               '212', '213', '217', '218', '220', '224', '229', '230', '232', '233', '235',
               '236', '238', '241', '242', '243', '245', '246', '253', '254', '258', '259',
               '260', '261', '263', '269', '270', '272', '273', '276', '279', '280', '283',
               '284', '286', '287', '290', '291', '292', '293', '295', '296', '299', '300',
               '303', '304', '305', '308', '309', '311', '312', '313', '315', '318', '322',
               '323', '324', '325', '331', '332', '334', '335', '337', '342', '344', '346',
               '347', '348', '349', '350', '353', '354', '355', '356', '357', '359', '360',
               '362', '363', '364', '365', '366', '367', '369', '370', '371', '373', '374',
               '375', '377', '380', '381', '383', '385', '386', '387', '388', '389', '391',
               '392', '393', '394', '396', '397', '399', '401', '402', '403', '404', '405',
               '406', '407', '408', '409', '411', '413', '414', '416', '417', '418', '421',
               '422', '423', '424', '431', '432', '434', '435', '439', '441', '442', '443',
               '446', '448', '449', '450', '451', '452', '453', '454', '456', '457', '458',
               '459', '460', '461', '462', '463', '464', '465', '467', '468', '470', '471',
               '472', '473', '474', '475', '477', '479', '480', '481', '482', '483', '485',
               '486', '487', '488', '489', '491', '493', '494', '496', '497', '499', '500',
               '501', '502', '503', '504', '505', '506', '509', '510', '511', '513', '514',
               '515', '516', '517', '518', '519', '520', '522', '525', '527', '528', '530',
               '531', '532', '533', '534', '535', '536', '538', '539', '540', '543', '544',
               '545', '546', '547', '548', '550', '552', '554', '555', '558', '559', '560',
               '561', '563', '564', '565', '566', '567', '568', '569', '570', '572', '573',
               '574', '575', '578', '579', '580', '585', '587', '588', '591', '592', '593',
               '595', '596', '600', '601', '603', '605', '607', '609', '610', '611', '612',
               '613', '614', '616', '617', '619', '620', '621', '623', '624', '625', '626',
               '628', '629', '630', '631', '633', '634', '635', '636', '637', '638', '639',
               '640', '641', '642', '644', '646', '647', '648', '649', '650', '651', '654',
               '656', '657', '658', '659', '660', '661', '664', '665', '666', '667', '668',
               '669', '670', '674', '675', '677', '679', '682', '684', '685', '686', '687',
               '689', '691', '695', '696', '699', '700', '701', '702', '703', '704', '705',
               '707', '708', '709', '711', '712', '713', '714', '715', '716', '718', '719',
               '720', '721', '722', '725', '732', '733', '734', '735', '736', '738', '739',
               '740', '741', '743', '744', '745', '748', '749', '752', '754', '755', '758',
               '759', '760', '763', '764', '765', '766', '769', '770', '771', '772', '774',
               '775', '776', '778', '779', '780', '782', '787', '789', '791', '795', '797',
               '798', '800', '802', '803', '804', '805', '806', '807', '808', '812', '813',
               '818', '819', '820', '822', '823', '827', '828', '831', '833', '834', '835',
               '836', '839', '841', '842', '843', '844', '845', '847', '848', '849', '854',
               '855', '857', '858', '859', '861', '862', '864', '866', '868', '870', '871',
               '872', '873', '875', '877', '878', '880', '883', '884', '886', '889', '890',
               '891', '892', '894', '895', '896', '900', '901', '902', '903', '906', '907',
               '908', '909', '911', '912', '913', '914', '915', '916', '917', '918', '920',
               '922', '923', '924', '925', '926', '928', '931', '932', '935', '937', '939',
               '940', '941', '942', '944', '945', '946', '949', '950', '951', '952', '957',
               '959', '960', '962', '964', '965', '968', '970', '971', '974', '975', '976',
               '977', '979', '983', '984', '985', '986', '987', '988', '989', '991', '996',
               '1001', '1002', '1003', '1005', '1009', '1015', '1016', '1017', '1018',
               '1020', '1022', '1023', '1025', '1027', '1028', '1029', '1030', '1032',
               '1034', '1036', '1037', '1038', '1039', '1040', '1042', '1043', '1046',
               '1050', '1051', '1054', '1056', '1057', '1058', '1061', '1062', '1063',
               '1064', '1067', '1069', '1070', '1071', '1072', '1073', '1076', '1078',
               '1079', '1084', '1085', '1086', '1089', '1096', '1098', '1101', '1102',
               '1104', '1105', '1109', '1110', '1111', '1113', '1117', '1118', '1121',
               '1123', '1124', '1125', '1126', '1130', '1131', '1132', '1134', '1136',
               '1138', '1146', '1147', '1149', '1150', '1151', '1155', '1156', '1158',
               '1163', '1164', '1165', '1167', '1169', '1170', '1172', '1174', '1175',
               '1176', '1181', '1182', '1183', '1185', '1187', '1189', '1190', '1192',
               '1193', '1194', '1197', '1200', '1201', '1202', '1204', '1205', '1206',
               '1208', '1214']
    default_cond = 'Derive_2'
    return np.select(conditions, choices, default=default_cond)


def icd12(MDC, ICD123, V2, V3, ICD9, RTW_P):
    conditions = [ICD123 != 'Derive_2',
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '57410') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'COMPLICATIONS OF PREGNANCY') & (
                      ICD9 == '64883') & (RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '490') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7242') & (
                      RTW_P == 1) & (V2 == 1) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4739') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4660') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == ''),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '30151') & (RTW_P == 1) & (V2 == 1) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4618') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72703') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '30000') & (RTW_P == 1) & (V2 == 0) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4610') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '6829') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4659') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6299') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6111') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5206') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72871') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'COMPLICATIONS OF PREGNANCY') & (
                      ICD9 == '65423') & (RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '42731') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '9999') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'COMPLICATIONS OF PREGNANCY') & (
                      ICD9 == '6488') & (RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71946') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '466') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71516') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '78650') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '6826') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8246') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6253') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '799') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '340') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4640') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '82381') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5751') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '82380') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'COMPLICATIONS OF PREGNANCY') & (
                      ICD9 == '65103') & (RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71941') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '401') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72765') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4610') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '300') & (RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '81380') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '81220') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'PSYCHOSES') & (ICD9 == '29624') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '41011') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '81305') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '465') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71517') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '808') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '81322') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'COMPLICATIONS OF PREGNANCY') & (
                      ICD9 == '64683') & (RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '30402') & (RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7804') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '2780') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '83100') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72672') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '348') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7243') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '83104') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6266') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '73007') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '42820') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'PSYCHOSES') & (ICD9 == '2963') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'PSYCHOSES') & (ICD9 == '29621') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8470') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '82529') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'PSYCHOSES') & (ICD9 == '311') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '813') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '5921') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8472') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'EYE DISORDERS') & (ICD9 == '36100') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8407') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '553') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'CONGENITAL ANOMALIES') & (ICD9 == '75619') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7240') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '44422') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '30924') & (RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '823') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7236') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'PSYCHOSES') & (ICD9 == '2962') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '80701') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '596') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7359') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '41519') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7806') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4781') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'PSYCHOSES') & (ICD9 == '29633') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '41072') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '826') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4111') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'NEOPLASMS') & (ICD9 == '1741') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '831') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72273') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '73399') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '9591') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '5849') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '30400') & (RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '6850') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'PSYCHOSES') & (ICD9 == '29623') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '5180') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7249') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72690') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '53081') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '25080') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '60889') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '33821') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '49390') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7172') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '6827') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7226') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72631') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '84200') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '95909') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '389') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7893') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'NEOPLASMS') & (ICD9 == '20300') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8440') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5650') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '430') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '518') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6180') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72691') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '428') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7263') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7870') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4270') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72290') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4800') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72705') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '84510') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '84210') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7248') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '735') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '8881') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7264') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5589') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '850') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '95901') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '845') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '3556') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '5856') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5693') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '51881') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '3453') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '250') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72742') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '714') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '453') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72885') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5739') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72612') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '6869') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '556') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '49310') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4349') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71943') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '411') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'NEOPLASMS') & (ICD9 == '1550') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '438') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5641') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5789') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '3320') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'NEOPLASMS') & (ICD9 == '162') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7860') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71944') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7393') & (RTW_P == 0) & (V2 == 0) & (V3 == '')]
    choices = [ICD123, '8', '12', '28', '35', '53', '67', '69', '76', '80',
               '81', '87', '97', '100', '102', '149', '157', '173', '177', '181', '193',
               '194', '215', '221', '228', '231', '256', '264', '274', '277', '297', '301',
               '314', '321', '326', '329', '336', '351', '376', '382', '390', '395', '400',
               '410', '412', '415', '440', '444', '447', '455', '478', '484', '507', '508',
               '529', '541', '549', '553', '577', '583', '584', '589', '590', '594', '597',
               '599', '602', '604', '606', '608', '618', '632', '643', '645', '652', '655',
               '662', '663', '671', '673', '676', '678', '680', '681', '683', '692', '694',
               '697', '723', '727', '728', '730', '731', '737', '750', '753', '757', '768',
               '781', '783', '785', '786', '788', '794', '814', '817', '821', '824', '825',
               '826', '829', '837', '838', '846', '852', '853', '856', '860', '869', '879',
               '885', '888', '893', '899', '905', '910', '930', '953', '956', '958', '963',
               '966', '967', '972', '1000', '1012', '1019', '1021', '1024', '1026', '1031',
               '1033', '1045', '1047', '1060', '1065', '1068', '1082', '1088', '1100',
               '1107', '1114', '1120', '1122', '1128', '1133', '1139', '1140', '1157',
               '1166', '1168', '1184', '1188', '1195', '1196', '1207']
    default_cond = 'Derive_3'
    return np.select(conditions, choices, default=default_cond)


def icd1(ICD12, MDC, V2, V3, ICD9, RTW_P):
    conditions = [ICD12 != 'Derive_3',
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5750') & (
                      RTW_P == 1) & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '27411') & (
                      RTW_P == 1) & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '486') & (
                      RTW_P == 1) & (V2 == '') & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4019') & (
                      RTW_P == 1) & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72210') & (
                      RTW_P == 1) & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '5920') & (
                      RTW_P == 1) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8360') & (
                      RTW_P == 1) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '56211') & (
                      RTW_P == 1) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '569') & (
                      RTW_P == 1) & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4740') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8472') & (
                      RTW_P == 1) & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '474') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '27801') & (
                      RTW_P == 1) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5770') & (
                      RTW_P == 1) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5758') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4749') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '462') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6170') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'COMPLICATIONS OF PREGNANCY') & (ICD9 == '63492') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'EYE DISORDERS') & (ICD9 == '366') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '4558') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'NEOPLASMS') & (ICD9 == '2181') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '55092') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'EYE DISORDERS') & (ICD9 == '36616') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '52100') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '57400') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4871') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '57420') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '550') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5521') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '30009') & (RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '566') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5259') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6179') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8270') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6271') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71535') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5750') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4870') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '46400') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '611') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'COMPLICATIONS OF PREGNANCY') & (ICD9 == '6469') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '454') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '6851') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '7908') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'PSYCHOSES') & (ICD9 == '29631') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '55321') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '75') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'NEOPLASMS') & (ICD9 == '2141') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'EAR DISORDERS') & (ICD9 == '3829') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '53') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'EYE DISORDERS') & (ICD9 == '379') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7862') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '82300') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'NEOPLASMS') & (ICD9 == '193') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '460') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '569') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6256') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '90') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72271') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '70583') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6110') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '682') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '419') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '3004') & (RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '55090') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '61801') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72743') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '56949') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5699') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '9221') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '9057') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'BLOOD & BLOOD FORMING ORGANS') & (
                      ICD9 == '2859') & (RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '959') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7213') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '537') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72704') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '3501') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '6822') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'EAR DISORDERS') & (ICD9 == '38611') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7260') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8500') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72782') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5715') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '42979') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '3510') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7170') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '9593') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8070') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71740') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '45340') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '840') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5550') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'BLOOD & BLOOD FORMING ORGANS') & (
                      ICD9 == '2826') & (RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '92411') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7175') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8260') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'NEOPLASMS') & (ICD9 == '174') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'NEOPLASMS') & (ICD9 == '2352') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72767') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4011') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '9988') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8471') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72632') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7823') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4539') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '4359') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4289') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'NEOPLASMS') & (ICD9 == '1889') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'NEOPLASMS') & (ICD9 == '1539') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8448') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '84509') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8479') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'EAR DISORDERS') & (ICD9 == '38610') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'EAR DISORDERS') & (ICD9 == '3861') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8488') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7820') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '3102') & (RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'EAR DISORDERS') & (ICD9 == '3862') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7805') & (
                      RTW_P == 0) & (V2 == '') & (V3 == ''),
                  (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '25000') & (RTW_P == 0) & (V2 == '') & (V3 == '')]
    choices = [ICD12, '3', '13', '21', '24', '34', '54', '59', '78', '84',
               '93', '105', '136', '141', '150', '183', '185', '223', '244', '248', '282',
               '288', '289', '294', '298', '306', '307', '317', '327', '352', '368', '378',
               '420', '425', '426', '427', '429', '430', '436', '438', '445', '466', '469',
               '476', '495', '498', '521', '537', '542', '562', '582', '586', '615', '627',
               '653', '672', '688', '690', '693', '698', '706', '717', '726', '756', '793',
               '809', '810', '850', '851', '863', '867', '882', '887', '898', '921', '929',
               '934', '947', '954', '955', '990', '993', '994', '995', '998', '1004', '1006',
               '1010', '1014', '1044', '1055', '1059', '1066', '1075', '1077', '1080',
               '1081', '1083', '1087', '1093', '1094', '1095', '1097', '1112', '1115',
               '1141', '1144', '1148', '1152', '1153', '1160', '1162', '1177', '1178',
               '1179', '1199', '1203', '1209', '1210', '1211', '1212', '1213']
    default_cond = 'Derive_4'
    return np.select(conditions, choices, default=default_cond)


def icd(MDC, V2, V3, ICD1, ICD9, RTW_P):
    conditions = [ICD1 != 'Derive_4',
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6202') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '78900') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '575') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '47400') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7350') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6218') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '541') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'COMPLICATIONS OF PREGNANCY') & (ICD9 == '633') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5759') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'NEOPLASMS') & (ICD9 == '2189') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5210') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '480') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5609') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '6259') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5589') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5531') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'CONGENITAL ANOMALIES') & (ICD9 == '75567') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'COMPLICATIONS OF PREGNANCY') & (ICD9 == '646') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '5921') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8449') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7231') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '487') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7809') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72610') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4140') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '9597') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '9592') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7179') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4659') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8442') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '461') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7295') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '717') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '410') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '455') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '463') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '3540') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4619') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4878') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7244') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '340') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'COMPLICATIONS OF PREGNANCY') & (ICD9 == '634') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4299') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '246') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '48812') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5651') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7366') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '57511') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '57510') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5209') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72252') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5409') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '274') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5400') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'EYE DISORDERS') & (ICD9 == '37200') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '61172') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '724') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '7062') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '540') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '7998') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '2469') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '539') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '95919') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4808') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '626') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '4618') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7220') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5379') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '5533') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '5990') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '56210') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '592') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '346') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'EAR DISORDERS') & (ICD9 == '388') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '789') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '6825') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8242') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '1368') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '27401') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '2749') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72670') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '558') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71590') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'PSYCHOSES') & (ICD9 == '29632') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72400') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '8450') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '80704') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '49312') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '30392') & (RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71514') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '3090') & (RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'PSYCHOSES') & (ICD9 == '29682') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '81342') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '30981') & (RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '414') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '80700') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '30002') & (RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4449') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '32720') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '30001') & (RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '71942') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '9952') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '3009') & (RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '586') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '3542') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '56089') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '3384') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '73689') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '584') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '72706') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '40291') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '7382') & (
                      RTW_P == '') & (V2 == '') & (V3 == ''),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '4254') & (RTW_P == '') & (V2 == '') & (V3 == '')]
    choices = [ICD1, '1', '2', '16', '19', '52', '57', '79', '82', '94',
               '128', '135', '137', '142', '143', '145', '147', '151', '152', '154', '156',
               '165', '167', '168', '169', '170', '171', '172', '176', '187', '191', '200',
               '202', '203', '211', '214', '216', '219', '226', '234', '239', '240', '252',
               '255', '257', '265', '266', '267', '268', '271', '275', '281', '310', '316',
               '319', '320', '328', '330', '338', '339', '340', '343', '361', '384', '398',
               '428', '433', '490', '492', '512', '523', '551', '571', '576', '581', '598',
               '729', '747', '762', '767', '784', '792', '811', '815', '865', '874', '881',
               '897', '919', '936', '938', '948', '969', '978', '980', '981', '997', '999',
               '1007', '1008', '1013', '1035', '1052', '1090', '1091', '1092', '1108',
               '1116', '1137', '1142', '1143', '1161', '1180', '1198']
    default_cond = 'Derive_5'
    return np.select(conditions, choices, default=default_cond)


def mdc123(MDC, V2, V3, ICD9, ICD, RTW_P):
    conditions = [ICD != 'Derive_5',
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 1),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '') & (RTW_P == 1) & (V2 == 0) & (V3 == 1),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 1) & (V3 == 0),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 1) & (V3 == 1),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 1),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 1),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 1) & (V3 == 0),
                  (MDC == 'PSYCHOSES') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 1) & (V3 == 0),
                  (MDC == 'EYE DISORDERS') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 1),
                  (MDC == 'COMPLICATIONS OF PREGNANCY') & (
                      ICD9 == '') & (RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 1) & (V3 == 1),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '') & (RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 1) & (V3 == 0),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 1) & (V3 == 1),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 1) & (V3 == 1),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 1) & (V3 == 0),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 1) & (V3 == 0),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 1) & (V3 == 0),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 1),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 1),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 1) & (V3 == 0),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'EYE DISORDERS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 1),
                  (MDC == 'EYE DISORDERS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 1),
                  (MDC == 'NEOPLASMS') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 1) & (V3 == 0),
                  (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 1),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 1),
                  (MDC == 'EAR DISORDERS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'COMPLICATIONS OF PREGNANCY') & (
                      ICD9 == '') & (RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'NEOPLASMS') & (ICD9 == '') & (
                      RTW_P == 1) & (V2 == 0) & (V3 == 0),
                  (MDC == 'NEOPLASMS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 1),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 1),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 1),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'NEOPLASMS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 1),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 1),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 1),
                  (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 1),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 1),
                  (MDC == 'COMPLICATIONS OF PREGNANCY') & (
                      ICD9 == '') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 1),
                  (MDC == 'COMPLICATIONS OF PREGNANCY') & (
                      ICD9 == '') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'PSYCHOSES') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'PSYCHOSES') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 1),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'PSYCHOSES') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 1),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'INJURY & POISONING') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'PSYCHOSES') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'CONGENITAL ANOMALIES') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'MUSCULOSKELETAL SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '') & (RTW_P == 0) & (V2 == 1) & (V3 == 1),
                  (MDC == 'GENITOURINARY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'CONGENITAL ANOMALIES') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'CIRCULATORY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'EAR DISORDERS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'NON-PSYCHOTIC MENTAL DISORDERS') & (ICD9 ==
                                                               '') & (RTW_P == 0) & (V2 == 1) & (V3 == 0),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'SKIN DISORDERS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'NERVOUS SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'EYE DISORDERS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'ENDOCRINE SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'BLOOD & BLOOD FORMING ORGANS') & (
                      ICD9 == '') & (RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'INFECTIOUS DISEASES') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'EAR DISORDERS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'DIGESTIVE  SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'NEOPLASMS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'NEOPLASMS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'EYE DISORDERS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'BLOOD & BLOOD FORMING ORGANS') & (
                      ICD9 == '') & (RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'RESPIRATORY SYSTEM') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 1),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '') & (
                      RTW_P == 0) & (V2 == 0) & (V3 == 0),
                  (MDC == 'ILL DEFINED CONDITIONS') & (ICD9 == '') & (RTW_P == 0) & (V2 == 0) & (V3 == 1)]
    choices = [ICD, '4', '14', '15', '20', '23', '26', '27', '29', '31', '36',
               '37', '42', '43', '47', '50', '64', '65', '71', '75', '85', '86', '88', '90',
               '92', '96', '99', '101', '103', '104', '106', '109', '111', '116', '118',
               '121', '122', '123', '130', '131', '133', '139', '146', '155', '158', '159',
               '174', '182', '184', '188', '192', '196', '198', '199', '201', '206', '222',
               '227', '237', '249', '251', '262', '285', '302', '333', '341', '372', '419',
               '526', '556', '557', '710', '724', '742', '751', '761', '773', '777', '790',
               '799', '801', '832', '840', '876', '904', '927', '933', '943', '961', '973',
               '992', '1011', '1041', '1048', '1049', '1053', '1074', '1103', '1106', '1119',
               '1127', '1129', '1135', '1145', '1154', '1159', '1173', '1191']
    default_cond = 'Derive_6'
    return np.select(conditions, choices, default=default_cond)


def mdc12(row):
    if row['MDC123'] != 'Derive_6':
        return row['MDC123']
    elif (row['MDC'] == 'INFECTIOUS DISEASES') & (row['ICD9'] == '') & (row['RTW_P'] == 1) & (row['V2'] == 1) & (row['V3'] == ''):
        return '18'
    elif (row['MDC'] == 'NON-PSYCHOTIC MENTAL DISORDERS') & (row['ICD9'] == '') & (row['RTW_P'] == 1) & (row['V2'] == 1) & (row['V3'] == ''):
        return '61'
    elif (row['MDC'] == 'EYE DISORDERS') & (row['ICD9'] == '') & (row['RTW_P'] == 1) & (row['V2'] == 1) & (row['V3'] == ''):
        return '83'
    elif (row['MDC'] == 'CONGENITAL ANOMALIES') & (row['ICD9'] == '') & (row['RTW_P'] == 0) & (row['V2'] == 1) & (row['V3'] == ''):
        return '186'
    elif (row['MDC'] == 'BLOOD & BLOOD FORMING ORGANS') & (row['ICD9'] == '') & (row['RTW_P'] == 0) & (row['V2'] == 1) & (row['V3'] == ''):
        return '225'
    elif (row['MDC'] == 'AIDS & ARC') & (row['ICD9'] == '') & (row['RTW_P'] == 0) & (row['V2'] == 0) & (row['V3'] == ''):
        return '830'
    else:
        return 'Derive_7'


def mdc1(row):
    if row['MDC12'] != 'Derive_7':
        return row['MDC12']
    elif (row['MDC'] == 'BLOOD & BLOOD FORMING ORGANS') & (row['ICD9'] == '') & (row['RTW_P'] == 1) & (row['V2'] == '') & (row['V3'] == ''):
        return '30'
    elif (row['MDC'] == 'ENDOCRINE SYSTEM') & (row['ICD9'] == '') & (row['RTW_P'] == 1) & (row['V2'] == '') & (row['V3'] == ''):
        return '32'
    elif (row['MDC'] == 'EAR DISORDERS') & (row['ICD9'] == '') & (row['RTW_P'] == 1) & (row['V2'] == '') & (row['V3'] == ''):
        return '33'
    elif (row['MDC'] == 'PSYCHOSES') & (row['ICD9'] == '') & (row['RTW_P'] == 1) & (row['V2'] == '') & (row['V3'] == ''):
        return '60'
    elif (row['MDC'] == 'SKIN DISORDERS') & (row['ICD9'] == '') & (row['RTW_P'] == 1) & (row['V2'] == '') & (row['V3'] == ''):
        return '89'
    elif (row['MDC'] == 'NERVOUS SYSTEM') & (row['ICD9'] == '') & (row['RTW_P'] == 1) & (row['V2'] == '') & (row['V3'] == ''):
        return '175'
    else:
        return 'Derive_8'


def mdc_final(row):
    if row['MDC1'] != 'Derive_8':
        return row['MDC1']
    elif (row['MDC'] == 'COMPLICATIONS OF PREGNANCY') & (row['ICD9'] == '') & (row['RTW_P'] == '') & (row['V2'] == '') & (row['V3'] == ''):
        return '190'
    elif (row['MDC'] == 'UNKNOWN') & (row['ICD9'] == '') & (row['RTW_P'] == '') & (row['V2'] == '') & (row['V3'] == ''):
        return '437'
    else:
        return '250'


def pred_lcp(row):
    if row in ['684', '563', '419', '1064', '454', '452', '1208', '1207', '494', '450', '984', '556', '1202', '1201', '781', '780', '555', '667', '777', '980', '449', '809', '694', '446', '399', '220', '624', '485', '757', '484', '217', '483', '480', '834', '540', '390', '1178', '385', '394', '1175', '832', '531', '1172', '662', '413', '969', '528', '526', '1098', '434', '917', '602', '724', '411', '410', '594', '521', '961', '468', '590', '587', '823', '467', '660', '675', '865', '514', '409', '393', '405', '388', '575', '574', '948', '673', '391', '1073', '761', '502', '459', '567', '564', '635', '380', '378', '367', '350', '347', '344', '337', '335', '331', '323', '322', '315', '313', '303', '295', '290', '287', '286', '261', '246']:
        return 'Complex RTW'
    elif row in ['1189', '1184', '1156']:
        return 'Ext Dis Limited RTW'
    elif row in ['1182', '1180', '1179', '833', '1176', '1173', '1171', '1170', '1168', '968', '1166', '691', '743', '690', '1162', '964', '741', '1159', '827', '618', '688', '738', '1151', '822', '1149', '955', '821', '953', '687', '736', '818', '735', '1141', '947', '686', '1137', '615', '944', '943', '814', '1132', '1131', '1130', '813', '940', '1127', '1126', '1214', '811', '810', '1122', '936', '1120', '935', '934', '933', '1115', '683', '682', '1112', '729', '928', '1109', '1108', '927', '926', '627', '638', '726', '626', '921', '920', '919', '918', '1095', '1093', '800', '678', '1090', '677', '797', '1087', '608', '795', '1083', '793', '1081', '1080', '907', '1078', '674', '905', '717', '789', '1071', '1070', '788', '672', '898', '1065', '152', '714', '784', '670', '634', '633', '1053', '1052', '1051', '631', '886', '885', '1046', '664', '773', '1043', '882', '881', '619', '770', '877', '704', '875', '768', '1033', '873', '872', '767', '766', '644', '868', '867', '864', '863', '862', '763', '860', '1018', '762', '858', '1014', '1013', '1012', '1011', '659', '855', '1008', '759', '1006', '1005', '700', '852', '1002', '851', '850', '999', '997', '756', '699', '994', '698', '992', '643', '990', '642', '843', '606', '605', '598', '597', '593', '591', '586', '583', '582', '581', '580', '576', '571', '570', '568', '562', '560', '559', '558', '557', '554', '553', '551', '548', '547', '544', '542', '538', '537', '533', '530', '524', '523', '522', '516', '515', '512', '511', '508', '507', '504', '500', '499', '498', '495', '492', '490', '489', '488', '478', '476', '475', '472', '471', '470', '469', '466', '465', '464', '461', '460', '457', '445', '440', '438', '437', '436', '433', '431', '429', '428', '426', '425', '420', '418', '417', '416', '414', '408', '404', '403', '398', '397', '392', '389', '384', '383', '382', '1213', '379', '1212', '375', '374', '373', '372', '371', '369', '368', '987', '365', '364', '362', '361', '359', '355', '354', '352', '351', '1210', '348', '695', '346', '345', '985', '343', '342', '341', '340', '339', '338', '1205', '336', '1203', '334', '333', '332', '983', '330', '329', '328', '327', '325', '324', '1199', '1198', '321', '320', '319', '318', '317', '316', '982', '750', '312', '311', '310', '309', '307', '306', '1194', '302', '301', '298', '297', '296', '840', '294', '293', '292', '748', '289', '288', '693', '692', '285', '283', '282', '281', '280', '279', '277', '276', '275', '274', '272', '271', '270', '268', '267', '266', '265', '263', '262', '1187', '260', '259', '258', '257', '256', '255', '254', '253', '252', '251', '250', '249', '248', '247', '745', '245', '244', '243', '242', '241', '240', '239', '238', '237', '236', '235', '234', '233', '232', '231', '230', '229', '228', '227', '226', '225', '224', '223', '222', '221', '973', '219', '218', '1183', '216', '215', '214', '213', '212', '211', '210', '209', '208', '207', '206', '205', '204', '203', '202', '201', '200', '199', '198', '197', '196', '195', '194', '193', '192', '191', '190', '189', '188', '187', '186', '185', '184', '183', '182', '181', '180', '179', '178', '177', '176', '175', '174', '173', '172', '171', '170', '169', '168', '167', '166', '165', '164', '163', '162', '161', '160', '159', '158', '157', '156', '155', '154', '153', '151', '150', '149', '148', '147', '146', '145', '144', '143', '142', '141', '140', '139', '138', '137', '136', '135', '134', '133', '132', '131', '130', '129', '128', '127', '126', '125', '124', '123', '122', '121', '120', '119', '118', '117', '116', '115', '114', '113', '112', '111', '110', '109', '108', '107', '106', '105', '104', '103', '102', '101', '100', '99', '98', '97', '96', '95', '94', '93', '92', '91', '90', '89', '88', '87', '86', '85', '84', '83', '82', '81', '80', '79', '78', '77', '76', '75', '74', '73', '72', '71', '70', '69', '68', '67', '66', '65', '64', '63', '62', '61', '60', '59', '58', '57', '56', '55', '54', '53', '52', '51', '50', '49', '48', '47', '46', '45', '44', '43', '42', '41', '40', '39', '38', '37', '36', '35', '34', '33', '32', '31', '30', '29', '28', '27', '26', '25', '24', '23', '22', '21', '20', '19', '18', '17', '16', '15', '14', '13', '12', '11', '10', '9', '8', '7', '6', '5', '4', '3', '2', '1']:
        return 'High Potential RTW'
    elif row in ['1107', '1106', '497', '496', '1105', '1104', '493', '1103', '491', '1102', '1101', '1100', '487', '486', '1099', '1097', '1096', '482', '481', '1094', '479', '1092', '477', '1091', '1089', '474', '473', '1088', '1086', '1085', '1084', '1082', '1079', '1077', '1076', '1075', '463', '462', '1074', '1072', '1069', '458', '1068', '456', '455', '1067', '453', '1066', '451', '1062', '1061', '448', '447', '1060', '1059', '444', '443', '442', '441', '1058', '439', '1057', '1056', '1055', '435', '1054', '1050', '432', '1049', '430', '1048', '1047', '427', '1045', '1044', '424', '423', '422', '421', '1042', '1041', '1040', '1039', '1038', '415', '1037', '1036', '412', '1035', '1034', '1032', '1031', '407', '406', '1030', '1029', '1028', '402', '401', '400', '1027', '1026', '1025', '396', '395', '1024', '1023', '1022', '1021', '1020', '1019', '1017', '387', '386', '1016', '1015', '1010', '1009', '381', '1007', '1004', '1003', '377', '376', '1001', '1000', '998', '996', '995', '370', '993', '991', '989', '366', '988', '986', '363', '981', '979', '360', '978', '358', '357', '356', '977', '976', '353', '975', '974', '972', '349', '971', '970', '967', '966', '965', '963', '962', '960', '959', '958', '957', '956', '954', '952', '951', '950', '949', '946', '945', '942', '941', '939', '326', '938', '937', '932', '931', '930', '929', '925', '924', '923', '922', '916', '314', '915', '914', '913', '912', '911', '308', '910', '909', '305', '304', '908', '906', '904', '300', '299', '903', '902', '901', '900', '899', '897', '896', '291', '895', '894', '893', '892', '891', '890', '284', '889', '888', '887', '884', '883', '278', '880', '879', '878', '876', '273', '874', '871', '870', '269', '869', '866', '861', '859', '264', '857', '856', '854', '853', '849', '848', '847', '846', '845', '844', '842', '841', '839', '838', '837', '836', '835', '831', '830', '829', '828', '826', '825', '824', '820', '819', '817', '816', '815', '812', '808', '807', '806', '805', '804', '803', '802', '801', '799', '798', '796', '794', '792', '791', '790', '787', '786', '785', '783', '782', '779', '778', '776', '775', '774', '772', '771', '769', '765', '764', '760', '758', '755', '754', '753', '752', '751', '749', '747', '746', '744', '742', '740', '739', '737', '734', '733', '732', '731', '730', '728', '727', '725', '723', '722', '721', '720', '719', '718', '716', '715', '713', '712', '711', '710', '709', '708', '707', '706', '705', '703', '702', '701', '697', '696', '689', '685', '681', '680', '679', '676', '607', '671', '669', '668', '666', '665', '663', '661', '658', '657', '656', '655', '654', '653', '652', '651', '650', '649', '648', '647', '646', '645', '641', '640', '639', '637', '636', '632', '630', '629', '628', '625', '623', '622', '621', '620', '617', '616', '614', '613', '612', '611', '610', '609', '1063', '1211', '1209', '604', '603', '1206', '601', '600', '599', '1204', '1200', '596', '595', '1197', '1196', '592', '1195', '1193', '589', '588', '1192', '1191', '585', '584', '1190', '1188', '1186', '1185', '579', '578', '577', '1181', '1177', '1174', '573', '572', '1169', '1167', '569', '1165', '1164', '566', '565', '1163', '1161', '1160', '561', '1158', '1157', '1155', '1154', '1153', '1152', '1150', '1148', '552', '1147', '550', '549', '1146', '1145', '546', '545', '1144', '543', '1143', '541', '1142', '539', '1140', '1139', '536', '535', '534', '1138', '532', '1136', '1135', '529', '1134', '527', '1133', '525', '1129', '1128', '1125', '1124', '520', '519', '518', '517', '1123', '1121', '1119', '513', '1118', '1117', '510', '509', '1116', '1114', '506', '505', '1113', '503', '1111', '501', '1110']:
        return 'Variable RTW'
    else:
        return ''


def pred_lcp_1(row):
    if (row['Primary_ICD9_Code'] == '') or (row['Primary_ICD_Major_Diagnosis_Category_Description'] == '') or (row['Microsegments'] == '250'):
        return ''
    else:
        return row['Pred_LCP']


def lcp_predicted(row):
    if row == 'High Potential RTW':
        return 1
    elif row == 'Ext Dis Limited RTW':
        return 2
    elif row == 'Variable RTW':
        return 3
    elif row == 'Complex RTW':
        return 4
    elif row == '':
        return 5


def ed_flag(row):
    if row in ['1156', '1184', '1189', '1188', '1165', '1072', '1123', '1140', '1029', '996', '1054', '722', '1163', '1153', '1160', '1015', '878', '1027', '1063', '1124', '1138', '1129', '949', '1038', '1128', '916', '937', '901', '1031', '998', '1135', '1061', '831', '942', '869', '884', '374', '853']:
        return 'Flag'
    else:
        return ''
