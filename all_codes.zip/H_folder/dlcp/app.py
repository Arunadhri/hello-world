# -*- coding: utf-8 -*-
"""
Created on Mon May 26 22:12:50 2019

@author: Shreyas Burra
"""

import sys,os
from flask import  Flask, request, json, jsonify, Blueprint, abort, make_response

import pandas as pd
from std_dlcp_600_scoring import *


#import utils and ds_fucntions
cwd = os.path.dirname(os.path.abspath(__file__))
print(cwd)
req = os.path.dirname(cwd)
print(req)
req_dir = os.path.join(os.path.dirname(req), "utils")
print(req_dir)      
sys.path.insert(0, req_dir)
ds_dir = os.path.join(os.path.dirname(cwd), "utils")
print(ds_dir)
sys.path.insert(1, ds_dir)
from config import Config
    
try:
    from dlcp_model import DlcpModel
except ImportError:
    raise ImportError("Loading pfm_model has failed")
                                  
import json
import time


app = Flask(__name__)

def create_app(config_path):
    
    start_time = time.time()
    global log
    global config
    global prediction_engine
    #global model_coeff_dict
    #global submodel_mapping_dict

    #config params
    app_path = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.abspath(os.path.join(app_path, '..'))
    env = os.environ.get("ENV")
    config = Config(env, config_path)
    log = config.get_consolelogger()
    log.info("create app method has started")

    try:
        prediction_engine = DlcpModel(config_path)
    except ImportError:
        raise error("Failed to load PfmModel")

    log.warning("--- %s seconds ---" % (time.time() - start_time))
    log.info("Create app method is now complete")
    return app


def get_app():
    
    app_path = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.abspath(os.path.join(app_path, '..'))
    env = os.environ.get("ENV")
    config = Config(env, config_path)
    log = config.get_consolelogger()
    log.info("get_app method is now complete")

    #Create the app
    return(create_app(config_path))


app = get_app()

#healthcheck for pfm model
@app.route('/api/dlcp600/health',methods=["GET"])
def get():
    responses = jsonify(health="Server Up")
    responses.status_code = 200
    return (responses)

#predict model
@app.route('/api/dlcp600/predict',methods=["POST"])
def predict():
    global prediction_engine

    start_time = time.time()
    log.info("predict method has started");

    #Getting the JSON
    input_json = request.get_json()
    log.warning("Request: %s", input_json);

    # Call functions
    main, treatment, icd_cd = data_import(main_data=input_json["main"], treatment_data=input_json["treatment"], icd_cd_data=input_json["icd_cd"])
    data_validation_df = data_preparation(main, treatment, icd_cd)
    final_df = prediction_engine.get_final_df(data_validation_df)
    responses = jsonify(predictions=final_df.to_json(orient="records"))
    log.info("Response to the request generated")
    log.warning(("The predict method is completed in --- %s seconds ---" % (time.time() - start_time)))
    responses.status_code = 200
    return (responses)

   
@app.errorhandler(400)
def not_found(error):
    """
    Gives error message when any bad requests are made.
    Args:
        error (string):
    Returns:
        Error message.
    """
    print(error)
    return make_response(jsonify({'error': 'Bad request'}), 400)


@app.errorhandler(404)
def not_found(error):
    """
    Gives error message when any invalid url are requested.
    Args:
        error (string): 
    Returns:
        Error message.
    """
    print(error)
    return make_response(jsonify({'error': 'Not found'}), 404)


@app.errorhandler(500)
def not_found(error):
    """
    Gives error message when any bad requests are made.
    Args:
        error (string):
    Returns:
        Error message.
    """
    print(error)
    return make_response(jsonify({'error': 'Internal Server Error'}), 500)

if __name__ == "__main__":
    env = os.environ.get("ENV")
    app_path = os.path.dirname(os.path.abspath(__file__))
    #Create the app
    app = create_app(config_path)
    #run_server(app)
    app.run()