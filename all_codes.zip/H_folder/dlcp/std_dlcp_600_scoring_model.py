#############################################################################
# ---------------------------------------------------------------------------
#                            Program Information
# ---------------------------------------------------------------------------
# Author                 : Prakash Ranjan
# Creation Date          : 29APR2019
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#                             Script Information
# ---------------------------------------------------------------------------
# Script Name            : std_dlcp_600_scoring.py
# Bitbucket Project/Repo : DnAAnalytics-US-Group / US-GRP-MO-STD-DLCP
# Brief Description      : Script for automating the likely claims process  for
#                          std claims
# Data Used              : ad_main, ad_treatment, ad_icd_cd
# Input Files            : N/A
# Output Files           : N/A
# Notes / Assumptions    : Imports helper functions from std_dlcp_600_functions.py
# ---------------------------------------------------------------------------
#                            Environment Information
# ---------------------------------------------------------------------------
# Python Version         : 3.6.3
# Anaconda Version       : 5.0.1
# Spark Version          : N/A
# Operating System       : Red Hat Enterprise Linux 7.4
# ---------------------------------------------------------------------------
#############################################################################
#
# Packages and Modules
#
#############################################################################
import pandas as pd
import numpy as np
import os
import time
import sys
sys.path.append('./python')

try:
    from config import Config
except ImportError:
    raise ImportError('Failed to import Config class.')

# Fetch Config Parameters
try:
    env = os.environ.get('ENV')
    app_path = os.getcwd()
    config = Config(env, app_path)
    log = config.get_logger()
except Exception:
    raise Exception('Failed to initiate config and log file.')

# Get values stored in the config file.
try:
    outputdir = config.getConfigValueFor('outputdir')
    inputdir = config.getConfigValueFor('inputdir')
    main_data_file_name = config.getConfigValueFor('main_data_file_name')
    treatment_data_file_name = config.getConfigValueFor('treatment_data_file_name')
    icd_cd_data_file_name = config.getConfigValueFor('icd_cd_data_file_name')
    export_file_name = config.getConfigValueFor('export_file_name')
except Exception as e:
    log.error('Failed to read the input and export data path')
    raise e

try:
    from std_dlcp_600_functions import (co_morbidity, rtw_in_the_past, icd10to9_1, icd10to9_2, icd10to9_3,
                                        primary_icd9_code, prmry_icd9_cd_5digit, icd9_to_mdc, icd9, icd123, icd12,
                                        icd1, icd, mdc123, mdc12, mdc1, mdc_final, pred_lcp, pred_lcp_1, lcp_predicted,
                                        ed_flag)
except Exception as e:
    log.exception('Failed to import std_dlcp_600_functions')
    raise e

#############################################################################
#
# Data Import
#
#############################################################################


def data_import(inputdir, main_data_file_name, treatment_data_file_name, icd_cd_data_file_name, log=log):
    log.info('Data import method is starting')
    # Get data from flat files
    ad_main_dtype = {'TRANS_ID': str,
                     'CLM_NUM_CD': str,
                     'CLM_RECD_DT': str,
                     'CVR_CD': str}
    ad_treatment_dtype = {'CLM_NUM_CD': str,
                          'TREAT_DT': str,
                          'ICD_DX_2_CD': str}
    ad_icd_cd_dtype = {'CLM_NUM_CD': str,
                       'PRI_ICD_CD': str,
                       'SEC_ICD_CD': str,
                       'ICD_CD_VER': str,
                       'MJR_DX_CTGY_DSCR': str}
    try:
        input_file1 = os.path.join(inputdir, main_data_file_name)
        main = pd.read_csv(input_file1,
                           sep='\t',
                           parse_dates=['DABL_DT', 'RTRN_TO_WRK_DT'],
                           dtype=ad_main_dtype)
    except Exception as e:
        log.exception('Failed to load the main data')
        raise e
    try:
        input_file2 = os.path.join(inputdir, treatment_data_file_name)
        treatment = pd.read_csv(input_file2,
                                sep='\t',
                                parse_dates=['PROG_DT'],
                                dtype=ad_treatment_dtype)
    except Exception as e:
        log.exception('Failed to load the treatment data')
        raise e
    try:
        input_file3 = os.path.join(inputdir, icd_cd_data_file_name)
        icd_cd = pd.read_csv(input_file3,
                             sep='\t',
                             dtype=ad_icd_cd_dtype)
    except Exception as e:
        log.exception('Failed to load the icd_cd data')
        raise e
    log.info('Data import method is now complete')
    return main, treatment, icd_cd

#############################################################################
#
# Data Preparation
#
#############################################################################


def data_validation(row):
    if row['ICD_CD_VER'] == '':
        return 'Provided field value is an incorrect data type. ICD_CD_VER is expecting a NUMERIC value to be provided.'
    elif (row['CLM_NUM_CD'].strip() == ''):
        return 'Required value not provided for CLM_NUM_CD.  A valid value for this field is required in order to calculate a score.'
    elif (row['TRANS_ID'].strip() == ''):
        return 'Required value not provided for TRANS_ID.  A valid value for this field is required in order to calculate a score.'
    elif (row['PRI_ICD_CD'].strip() == ''):
        return 'Required value not provided for PRI_ICD_CD.  A valid value for this field is required in order to calculate a score.'
    else:
        return ''


def data_preparation(ad_main, ad_treatment, ad_icd_cd, log=log):
    log.info('Data preperation method is starting')
    ad_main['RequestReceivedTS'] = pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
    df = ad_main.merge(ad_treatment, on='CLM_NUM_CD')
    df1 = df.merge(ad_icd_cd, on='CLM_NUM_CD')
    df1.loc[:, df1.dtypes == object] = df1.loc[:, df1.dtypes == object].fillna('')
    df1['DATA_VALIDATION'] = df1.apply(data_validation, axis=1)
    log.info('Data preperation is now complete')
    return df1

#############################################################################
#
# Validation Flag Creation
#
#############################################################################


def set_field_on_data_errors(df):
    df['ResultReasonDesc1'] = df['DATA_VALIDATION']
    df['ResultReasonDesc2'] = ''
    df['ResultReasonDesc3'] = ''
    df['ResultReasonDesc4'] = ''
    df['ResultReasonDesc5'] = ''
    df['LCPPredicted'] = '5'
    df['EDFlag'] = ''
    df['RTWinthepast'] = ''
    df['PrognosisDateLessThan30'] = ''
    df['EDSuspicousLevel'] = ''
    df['Co_morbidity'] = 0
    df['ClusterType'] = ''
    df['Microsegments'] = ''
    return df


def feature_validation_fail_process(df, log=log):
    log.info('feature_validation_fail_process method is starting')
    df = set_field_on_data_errors(df)
    df = df.rename(columns={'CLM_NUM_CD': 'Claim_Number_Code',
                            'RTWinthepast': 'RTW',
                            'PrognosisDateLessThan30': 'Prognosis',
                            'LCPPredicted': 'LCP_Predicted',
                            'EDFlag': 'ED_Flag'})
    df = df[['Claim_Number_Code',
             'TRANS_ID',
             'RequestReceivedTS',
             'ResultReasonDesc1',
             'ResultReasonDesc2',
             'ResultReasonDesc3',
             'ResultReasonDesc4',
             'ResultReasonDesc5',
             'LCP_Predicted',
             'ED_Flag',
             'RTW',
             'Prognosis',
             'EDSuspicousLevel',
             'Co_morbidity',
             'ClusterType',
             'Microsegments']]
    log.info('Feature_validation_fail_process method is now complete')
    return df


def feature_validation_pass_process(df, log=log):
    log.info('feature_validation_pass_process method is starting')
    df = df.rename(columns={'CLM_NUM_CD': 'Claim_Number_Code',
                            'CLM_RECD_DT': 'Claim_Received_Date',
                            'CVR_CD': 'Coverage_Code',
                            'DABL_DT': 'Disability_Date',
                            'RTRN_TO_WRK_DT': 'Return_To_Work_Date',
                            'PROG_DT': 'Prognosis_Date',
                            'MJR_DX_CTGY_DSCR': 'Primary_ICD_Major_Diagnosis_Category_Description'})
    df['Co_morbidity'] = df['SEC_ICD_CD'].apply(co_morbidity)
    df['RTW_in_the_past'] = df['Return_To_Work_Date'].apply(rtw_in_the_past)
    df['Prognosis<30'] = np.where((df['Prognosis_Date'] - df['Disability_Date']) / np.timedelta64(1, 'D') <= 30, 1, 0,)
    df['ICD10to9_1'] = icd10to9_1(df['PRI_ICD_CD'].values)
    df['ICD10to9_2'] = icd10to9_2(df['PRI_ICD_CD'].values, df['ICD10to9_1'].values)
    df['ICD10to9_3'] = icd10to9_3(df['ICD10to9_2'].values, df['PRI_ICD_CD'].values)
    df = df.rename(columns={'ICD10to9_3': 'ICD9'})
    df = df.drop(['ICD10to9_1', 'ICD10to9_2'], axis=1)
    df['Primary_ICD9_Code'] = df.apply(primary_icd9_code, axis=1)
    df['PRMRY_ICD9_CD_5DIGIT'] = df['Primary_ICD9_Code'].apply(prmry_icd9_cd_5digit)
    df['PRMRY_ICD9_CD_3DIGIT'] = df['PRMRY_ICD9_CD_5DIGIT'].str[:3]
    df['ICD9_TO_MDC'] = df['PRMRY_ICD9_CD_3DIGIT'].apply(icd9_to_mdc)
    df = df.drop('Primary_ICD_Major_Diagnosis_Category_Description', axis=1)
    df = df.rename(columns={'ICD9_TO_MDC': 'Primary_ICD_Major_Diagnosis_Category_Description'})
    df = df.drop(['PRMRY_ICD9_CD_5DIGIT', 'PRMRY_ICD9_CD_3DIGIT'], axis=1)
    df['V2'] = df['Prognosis<30']
    df['V3'] = df['Co_morbidity']
    df = df.drop(['ICD9'], axis=1)
    df = df.rename(columns={'RTW_in_the_past': 'RTW_P',
                            'Primary_ICD_Major_Diagnosis_Category_Description': 'MDC',
                            'Primary_ICD9_Code': 'ICD9'})
    df = df[['Claim_Number_Code',
             'TRANS_ID',
             'RequestReceivedTS',
             'Co_morbidity',
             'RTW_P',
             'Prognosis<30',
             'ICD9',
             'MDC',
             'V2',
             'V3']]
    df1 = df.copy(deep=True)
    df['ICD9'] = df['ICD9'].apply(icd9)
    df['ICD123'] = icd123(df['MDC'].values, df['V2'].values, df['V3'].values, df['ICD9'].values, df['RTW_P'].values)
    df['V3'] = ''
    df['ICD12'] = icd12(df['MDC'].values, df['ICD123'].values, df['V2'].values, df['V3'].values, df['ICD9'].values, df['RTW_P'].values)
    df['V2'] = ''
    df['ICD1'] = icd1(df['ICD12'].values, df['MDC'].values, df['V2'].values, df['V3'].values, df['ICD9'].values, df['RTW_P'].values)
    df['RTW_P'] = ''
    df['ICD'] = icd(df['MDC'].values, df['V2'].values, df['V3'].values, df['ICD1'].values, df['ICD9'].values, df['RTW_P'].values)
    df = df.drop(['ICD9', 'MDC', 'V2', 'V3', 'RTW_P'], axis=1)
    df2 = df1[['Claim_Number_Code', 'RTW_P', 'ICD9', 'MDC', 'V2', 'V3']]
    df3 = pd.merge(df2, df, on='Claim_Number_Code', how='left')
    df3['ICD9'] = ''
    df3['MDC123'] = mdc123(df3['MDC'].values, df3['V2'].values, df3['V3'].values, df3['ICD9'].values, df3['ICD'].values, df3['RTW_P'].values)
    df3['V3'] = ''
    df3['MDC12'] = df3.apply(mdc12, axis=1)
    df3['V2'] = ''
    df3['MDC1'] = df3.apply(mdc1, axis=1)
    df3['RTW_P'] = ''
    df3['MDC_FINAL'] = df3.apply(mdc_final, axis=1)
    df3 = df3[['Claim_Number_Code', 'MDC_FINAL']]
    df4 = pd.merge(df1, df3, on='Claim_Number_Code', how='left')
    df4 = df4.rename(columns={'RTW_P': 'RTW_in_the_past',
                              'ICD9': 'Primary_ICD9_Code',
                              'MDC': 'Primary_ICD_Major_Diagnosis_Category_Description',
                              'MDC_FINAL': 'Microsegments'})
    df4['Pred_LCP'] = df4['Microsegments'].apply(pred_lcp)
    df4['Pred_LCP'] = df4.apply(pred_lcp_1, axis=1)
    df4 = df4.drop(['V2', 'V3'], axis=1)
    df4['LCP_Predicted'] = df4['Pred_LCP'].apply(lcp_predicted)
    df4['ED_Flag'] = df4['Microsegments'].apply(ed_flag)
    df4['RTW'] = np.where(df4['RTW_in_the_past'] == 1, 1, 0)
    df4['Prognosis'] = np.where(df4['Prognosis<30'] == 1, 1, 0)
    df4['co_morbid'] = np.where(df4['Co_morbidity'] == 1, 1, 0)
    df4['Primary_ICD9_Code'] = df4['Primary_ICD9_Code'].replace(np.nan, '')
    df4['Primary_ICD_Major_Diagnosis_Category_Description'] = df4['Primary_ICD_Major_Diagnosis_Category_Description'].replace(np.nan, '')
    df4['ResultReasonDesc1'] = 'ICD=' + df4['Primary_ICD9_Code']
    df4['ResultReasonDesc2'] = 'MDC=' + df4['Primary_ICD_Major_Diagnosis_Category_Description']
    df4['ResultReasonDesc3'] = df4['RTW']
    df4['ResultReasonDesc4'] = df4['Prognosis']
    df4['ResultReasonDesc5'] = df4['co_morbid']
    df4['ClusterType'] = ''
    df4['EDSuspicousLevel'] = ''
    log.info('feature_validation_pass_process method is now complete')
    return df4


def validation_pass_fail_data_creation(df, log=log):
    log.info('validation_pass_fail_data_creation function is starting')
    validation_fail_df = df[df['DATA_VALIDATION'] != ''].copy()
    validation_pass_df = df[df['DATA_VALIDATION'] == ''].copy()
    validation_fail_flag = 0
    validation_pass_flag = 0
    if len(validation_fail_df) > 0:
        validation_fail_df = feature_validation_fail_process(validation_fail_df, log)
        validation_fail_flag = 1
    if len(validation_pass_df) > 0:
        validation_pass_df = feature_validation_pass_process(validation_pass_df, log)
        validation_pass_flag = 1
    if validation_fail_flag == 1 and validation_pass_flag == 1:
        com_cols = set(validation_pass_df.columns).intersection(set(validation_fail_df.columns))
        final_df = validation_pass_df[list(com_cols)].append(validation_fail_df[list(com_cols)])
    elif validation_pass_flag == 1:
        final_df = validation_pass_df
        final_df = final_df.drop(['Pred_LCP',
                                  'Primary_ICD_Major_Diagnosis_Category_Description',
                                  'Primary_ICD9_Code',
                                  'RTW_in_the_past',
                                  'Prognosis<30',
                                  'co_morbid'], axis=1)
    else:
        final_df = validation_fail_df
    log.info('validation_pass_fail_data_creation is now complete')
    return final_df

#############################################################################
#
# Data Processing
#
#############################################################################


def data_processing(df, log=log):
    log.info('data processing method is starting')
    df1 = validation_pass_fail_data_creation(df, log)
    df1['RequestReturnedTS'] = pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
    df1 = df1.rename(columns={'Claim_Number_Code': 'ClaimNumberCode',
                              'TRANS_ID': 'TransId',
                              'LCP_Predicted': 'LCPPredicted',
                              'ED_Flag': 'EDFlag',
                              'RTW': 'RTWinthepast',
                              'Prognosis': 'PrognosisDateLessThan30',
                              'Microsegments': 'Microsegment'})
    df1 = df1[['TransId', 'ClaimNumberCode', 'EDFlag', 'RTWinthepast', 'ClusterType', 'EDSuspicousLevel', 'Microsegment', 'Co_morbidity', 'PrognosisDateLessThan30', 'LCPPredicted', 'ResultReasonDesc1', 'ResultReasonDesc2', 'ResultReasonDesc3', 'ResultReasonDesc4', 'ResultReasonDesc5', 'RequestReceivedTS', 'RequestReturnedTS']]
    df1 = df1.sort_values(['TransId'], ascending=[True])
    log.info('data processing method is now complete')
    return df1

#############################################################################
#
# Save Results
#
#############################################################################


def export_results(final_df, outputdir, export_file_name, log=log):
    log.info('Export data method is starting')
    output_path = os.path.join(outputdir, export_file_name)
    # Write out to the location
    log.debug('Exporting the results to file: ' + output_path)
    try:
        final_df.to_csv(output_path, index=False, sep='\t')
    except Exception as e:
        log.exception('Failed to export result data.')
        raise e
    log.info('Export results method is now complete')
    return None


if __name__ == '__main__':
    start_time = time.time()
    # start likely claims decision process
    log.info('likely claims decision process is starting')
    # Import data from flat files
    ad_main, ad_treatment, ad_icd_cd = data_import(inputdir, main_data_file_name, treatment_data_file_name, icd_cd_data_file_name, log)
    # Data Preparation
    try:
        data_validation_df = data_preparation(ad_main, ad_treatment, ad_icd_cd, log)
    except Exception as e:
        log.exception('Failed to validate the data.')
        raise e
    # Feature engineering
    try:
        final_df = data_processing(data_validation_df, log)
    except Exception as e:
        log.exception('Failed to post process the data.')
        raise e
    # export data onto predefined location
    export_results(final_df, outputdir, export_file_name, log)
    log.info('likely claims decision process is now complete')
    log.warning('The likely claims decision process is completed in: [ %s ] Seconds ---' % (time.time() - start_time))
