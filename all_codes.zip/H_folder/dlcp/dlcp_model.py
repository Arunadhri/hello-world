import sys,os
import _pickle as pickle
sys.path.append(os.path.abspath(os.path.join('..', 'config')))
from config import Config
from std_dlcp_600_scoring import *


#class pfmModel:
#A risk inspection prediction engine
class DlcpModel:

    def get_final_df(self, data_validation_df):
    	final_df = data_processing(data_validation_df)
    	return final_df
 
    def __init__(self, config_path):
    #Init the prediction engine given a configuration path
        env = os.environ.get("ENV")
        self.config = Config(env ,config_path)
        self.log = self.config.get_consolelogger()