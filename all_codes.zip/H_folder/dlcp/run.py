# -*- coding: utf-8 -*-
"""
Created on Tue Feb 26 22:11:46 2019

@author: Suresh Kamath
"""

import os
from app import get_app
def run_server(app):
   #app.run(host='0.0.0.0', port=5000, debug=True)
   app.run(host='0.0.0.0', port=5000)
if __name__ == "__main__":
    # Configuration Settings
    env = os.environ.get("ENV")
    app_path = os.path.dirname(os.path.abspath(__file__))
    #os.chdir("..")
    config_path = os.path.abspath(os.path.join(app_path, '..'))
    app = get_app()
    # start the application server
    #run_server(app)
    app.run(host='0.0.0.0', port=5000)