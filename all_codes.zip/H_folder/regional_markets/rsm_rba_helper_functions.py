######### met_config_share_functions #########
# df = pd.read_excel(finance_assumptions_path)
# finance_assumptions_path = Finance_Assumptions.xlsx
# run locals().update(d) after running this function to use variables
def load_met_finance_assumption(df):
    d = {}
    for p in df['Product'].unique():
        mem_to_emp = df[df['Product'] == p]['PartPct'] * df[df['Product'] == p]['Dep_ratio']
        d[p.lower() + '_Members_to_emp'] = mem_to_emp
        pmpm_fi = df[df['Product'] == p]['PMPM']
        d['pmpm_fi_' + p.lower()] = pmpm_fi
    return d


######### met_data_cleaning_tw_functions #########
# function to reconcile broker name between MetLife database and f5500 filing 
def met_broker_standardization(dt=dt, map=brokerMappingFile):
    map_brokers = map_brokers.drop_duplicates()

    if 'LKUP_BRKR_ID' in dt.columns:
        dt['BRKR_FIRM_ID'] = dt['LKUP_BRKR_ID']
    if 'LKUP_BRKR_FIRM_NM' in dt.columns:
        dt['BRKR_FIRM_NM'] = dt['LKUP_BRKR_FIRM_NM']

    dt = dt.merge(map_brokers[['BrokerProper', 'BRKR_FIRM_ID']],
                  on='BRKR_FIRM_ID', how='left')
    dt = dt.rename(columns={'BrokerProper': 'BROKER_NAME_GRIP'})
    dt['BROKER_NAME_GRIP'] = np.where((dt['BROKER_NAME_GRIP'].isnull()) or (dt['BROKER_NAME_GRIP'] == ''),
             dt['BRKR_FIRM_NM'], dt['BROKER_NAME_GRIP'])

    dt.replace({'BROKER_NAME_GRIP': {'Northwestern Mutual': 'Northwestern'}}, inplace=True)
    return dt


# get profitability and persistency metrics
def profitabilty_calc(dt, last_Year_in_int, Small_100_200, market_type,
                      inscope_products=met_inscope_products,
                      inscope_state=met_inscope_state,
                      sizecut=size_cut, suffix=suffix, metvar=metvar):
    dt = dt[dt['REC_YR'].isin(range(last_Year_in_int - 3, last_Year_in_int))]
    dt['CVR_GRP_SCOR_CARD_CD'] = dt['CVR_GRP_SCOR_CARD_CD'].apply(lambda x: x.toupper())
    dt = met_broker_standardization(dt)
    dt['BRKR_FIRM_ZIP_CD'] = dt['BRKR_FIRM_ZIP_CD'].apply(lambda x: x[:5])
    dt = met_add_market(dt, zipvar=['BRKR_FIRM_ZIP_CD'], Statevar='BRKR_FIRM_ST_CD', brokervar='BROKER_NAME_GRIP')
    dt['SalesOffice'].fillna('', inplace=True)
    dt = dt[(dt['CVR_GRP_SCOR_CARD_CD'].isin(inscope_products))]

    from_string = ['100-199', '200-499', '500-999', '1000-4999',
                   '5000-9999', '10000-14999', '15000-19999',
                   '20000-24999', '25000-49999', '50000_Plus']
    to_string = ['100-500', '100-500', '500-1000', '1000-5000',
                 '5000-15000', '5000-15000', '15000-25000',
                 '15000-25000', '25000+', '25000+']
    if Small_100_200:
        to_string = ['100-200', '200-500', '500-1000',
                     '1000-5000', '5000-15000', '5000-15000',
                     '15000-25000', '15000-25000', '25000+', '25000+']
    
    dt = dt.replace({'SUBSEGMENT2': {i: j for i, j in zip(from_string, to_string)}})
    dt['SUBSEGMENT'] = dt.loc[:, 'SUBSEGMENT2']

    if market_type == 'Regional Market':
        dt = dt[dt['RPT_SIZE_TXT'] == '100-5000']
    if market_type == 'National Account':
        dt = dt[dt['RPT_SIZE_TXT'] != '100-5000']
    # aggregate by state, sales office, size segment, Product, broker
    ag = dt.groupby(metvar)['TOT_PREM_AND_FEE_AMT', 'P_TAX_ERN_AMT'].sum().reset_index()
    ag.to_pickle('./pickles/Profit_Calculation' + suffix + '.pkl')


def persistency_calc(dt, last_Year_in_int, Small_100_200, market_type,
                     inscope_products=met_inscope_products,
                     inscope_state=met_inscope_state,
                     sizecut=size_cut, suffix=suffix, metvar=metvar):
    dt = dt[dt['REC_YR'].isin(range(last_Year_in_int - 3, last_Year_in_int))]
    dt['CVR_GRP_SCOR_CARD_CD'] = dt['CVR_GRP_SCOR_CARD_CD'].apply(lambda x: x.toupper())
    dt = met_broker_standardization(dt)
    dt['BRKR_FIRM_ZIP_CD'] = dt['BRKR_FIRM_ZIP_CD'].apply(lambda x: x[:5])
    dt = met_add_market(dt, zipvar=['BRKR_FIRM_ZIP_CD'], Statevar='BRKR_FIRM_ST_CD', brokervar='BROKER_NAME_GRIP')
    dt['SalesOffice'].fillna('', inplace=True)
    dt = dt[(dt['CVR_GRP_SCOR_CARD_CD'].isin(inscope_products))]

    from_string = ['100-199', '200-499', '500-999', '1000-4999',
                   '5000-9999', '10000-14999', '15000-19999',
                   '20000-24999', '25000-49999', '50000_Plus']
    to_string = ['100-500', '100-500', '500-1000', '1000-5000',
                 '5000-15000', '5000-15000', '15000-25000',
                 '15000-25000', '25000+', '25000+']
    if Small_100_200:
        to_string = ['100-200', '200-500', '500-1000',
                     '1000-5000', '5000-15000', '5000-15000',
                     '15000-25000', '15000-25000', '25000+', '25000+']
    
    dt = dt.replace({'SUBSEGMENT2': {i: j for i, j in zip(from_string, to_string)}})
    dt['SUBSEGMENT'] = dt.loc[:, 'SUBSEGMENT2']

    if market_type == 'Regional Market':
        dt = dt[dt['RPT_SIZE_TXT'] == '100-5000']
    if market_type == 'National Account':
        dt = dt[dt['RPT_SIZE_TXT'] != '100-5000']
    # aggregate by state, sales office, size segment, Product, broker
    ag = dt.groupby(metvar)['PRST_PREM_BASE_AMT', 'PRST_TRM_PREM_AMT'].sum().reset_index()
    ag.to_pickle('./pickles/Persistency_Calculation' + suffix + '.pkl')


def import_sales_data(data_current_Year_0, data_current_Year_1,
                      data_current_Year_2, data_current_Year_3,
                      data_current_Year_4, met_mapping):
    all_files = pd.DataFrame()
    for i in [data_current_Year_0, data_current_Year_1,
                data_current_Year_2, data_current_Year_3,
                data_current_Year_4]:
        sub = pd.read_excel(i)
        sub['ETL_CYC_DT'] = pd.to_datetime(sub['ETL_CYC_DT'], format='%m/%d/%Y')
        sub['cycleYear'] = sub['ETL_CYC_DT'].dt.year
        sub = sub[sub['cycleYear'] == sub['EFF_YR']]
        sub[['ELGBL_LIF_CNT','QT_PCT','CVR_CNT','PREMIUM']] = pd.to_numeric(sub[['ELGBL_LIF_CNT','QT_PCT','CVR_CNT','PREMIUM']])
        all_files = all_files.append(sub)

    all_files = all_files[(all_files['CUST_NM'] != '(null)') & ~(all_files['CUST_NM'].isna())]
    all_files = all_files.merge(met_mapping[['BRKR_FIRM_ID','BRKR_FIRM_PRNT_NM','BRKR_FIRM_ZIP_CD']],
                                left_on='LKUP_BRKR_ID', right_on='BRKR_FIRM_ID', how='left')
    all_files['BRKR_FIRM_PRNT_NM'] = np.where(all_files['BRKR_FIRM_PRNT_NM'].isna(),
                                              all_files['LKUP_BRKR_FIRM_NM'],
                                              all_files['BRKR_FIRM_PRNT_NM'])
    all_files['BRKR_FIRM_ZIP_CD'] = np.where(all_files['BRKR_FIRM_ZIP_CD'].isna(),
                                             '', all_files['BRKR_FIRM_ZIP_CD'])
    all_files['BRKR_FIRM_ZIP_CD'] = all_files['BRKR_FIRM_ZIP_CD'].apply(lambda x: x[:5])
    all_files.to_pickle('./pickles/AllSalesQuote.pkl')


def clean_sales_quote_data(dt):
    #dt = pd.read_pickle('./pickles/AllSalesQuote.pkl')
    dt = met_broker_standardization(dt)
    dt = dt.sort_values('CUST_NM')
    dt['CUST_NM'] = dt['CUST_NM'].apply(lambda x: x.toupper())

    quotes = dt[dt['COMP_CD'] == 'Quoted']
    sales = dt[dt['COMP_CD'] == 'Sales$']

    customer = sales[sales['CUST_NUM'] != '(null)'].groupby(['CUST_NUM', 'CUST_NM'])['COMP_CD'].count().reset_index(name='Freq')
    customer['NAMECT'] = customer.groupby(['CUST_NM'])['CUST_NM'].transform('size')
    customer['NAMELEN'] = customer['CUST_NM'].apply(lambda x: len(x))
    badCUST_NUM = list(customer[customer['NAMECT'] > 12]['CUST_NUM'].unique())
    badCUST_NUM += ['5347643','0163845','5343412','5347558','9999814','0000000', '0000224']
    customer = customer[~customer['CUST_NUM'].isin(badCUST_NUM)]
    customer = customer.sort_values(['CUST_NUM', 'Freq', 'NAMELEN'], ascending=[True, False,True])
    customer_unique = customer[['CUST_NUM','CUST_NM']].drop_duplicates(subset='CUST_NUM')
    customer_unique.rename(columns={'CUST_NM': 'CUST_NM_STD'}, inplace=True)
    customer = customer.merge(customer_unique, how='inner', on='CUST_NUM')
    customer = customer[['CUST_NUM','CUST_NM','CUST_NM_STD']].drop_duplicates()
    sales = sales.merge(customer, on=['CUST_NUM','CUST_NM'], how='left')
    prospect = quotes[quotes['PRSP_NUM'] != '(null)'].groupby(['CUST_NM','PRSP_NUM'])['CUST_NM'].count().reset_index(name='Freq')
    prospect['NAMECT'] = prospect.groupby(['PRSP_NUM'])['CUST_NM'].transform('size')
    prospect['NAMELEN'] = prospect['CUST_NM'].apply(lambda x: len(x))
    badPRSP_NUM = list(prospect[prospect['NAMECT'] > 8]['PRSP_NUM'].unique())
    badPRSP_NUM += ['na','n/a','N/A','Unknown','P1000000','P1122334','0']
    prospect = prospect[~prospect['PRSP_NUM'].isin(badPRSP_NUM)]
    prospect = prospect.sort_values(['PRSP_NUM', 'Freq', 'NAMELEN'], ascending=[True, False,True])
    prospect_unique = prospect[['PRSP_NUM','CUST_NM']].drop_duplicates(subset='PRSP_NUM')
    prospect_unique.rename(columns={'CUST_NM': 'CUST_NM_STD'})
    prospect = prospect.merge(prospect_unique, how='inner', on='PRSP_NUM')
    prospect = prospect[['PRSP_NUM','CUST_NM','CUST_NM_STD']].drop_duplicates()
    quotes = quotes.merge(prospect, on=['PRSP_NUM','CUST_NM'], how='left')
    dt = sales.append(quotes)
    dt['CUST_NM_STD'] = np.where(dt['CUST_NM_STD'].isnull(), dt['CUST_NM'], dt['CUST_NM_STD'])
    dt.to_pickle('./pickles/AllSalesQuote_clean.pkl')


def Closing_ratio_calc(dt, last_Year_in_int, Small_100_200,
                       market_type, zip_st_mapping,
                       inscope_products=met_inscope_products,
                       inscope_state=met_inscope_state,
                       sizecut=size_cut,
                       suffix=suffix,
                       metvar=metvar):
    dt = dt[(dt['CVR_GRP_SCOR_CARD_CD'].isin(inscope_products))
            & (dt['EFF_YR'].isin(range(last_Year_in_int - 3, last_Year_in_int)))]
    from_string = ['A_LT_10', 'B_10-24', 'C_25-49', 'D_50-99',
                   'E_100-199', 'F_200-499', 'G_500-999', 'H_1000-4999',
                   'I_5000-9999', 'J_10000-14999', 'K_15000-19999',
                   'L_20000-24999', 'M_25000-49999', 'N_50000_PLUS',
                   'OTHER', 'GLOBAL']
    to_string = ['1-100', '1-100', '1-100', '1-100', '100-500',
                 '100-500', '500-1000', '1000-5000', '5000-15000',
                 '5000-15000', '15000-25000', '15000-25000', '25000+',
                 '25000+', 'OTHER', 'GLOBAL']
    if Small_100_200:
        to_string = ['1-100', '1-100', '1-100', '1-100', '100-200',
                     '100-200', '500-1000', '1000-5000', '5000-15000',
                     '5000-15000', '15000-25000', '15000-25000', '25000+',
                     '25000+', 'OTHER', 'GLOBAL']

    dt = dt.replace({'SEG_3_DFN_TXT': {i: j for i, j in zip(from_string, to_string)}})
    dt['SUBSEGMENT'] = dt.loc[:, 'SEG_3_DFN_TXT']

    if market_type == 'Regional Market':
        dt = dt[dt['MKT_CD_WITH_SORT_TXT'] == 'B_100-5000']
    if market_type == 'National Account':
        dt = dt[dt['MKT_CD_WITH_SORT_TXT'] != 'C_5000_PLUS']
    dt = dt.merge(zip_st_mapping, how='left', left_on='BRKR_FIRM_ZIP_CD', right_on='Zip')
    dt['ST'] = dt['ST'].fillna('')
    dt['FL'] = np.where((dt['BRKR_FIRM_ST_CD'] != dt['ST']) & (dt['BRKR_FIRM_ST_CD'] != '')
                        & (dt['ST'] != ''), 1, 0)
    dt['BRKR_FIRM_ST_CD'] = np.where(dt['FL'] == 1, dt['ST'], dt['BRKR_FIRM_ST_CD'])
    dt = dt.drop(['ST', 'FL'], axis=1)
    dt = met_add_market(dt, zipvar=['BRKR_FIRM_ZIP_CD'], Statevar='BRKR_FIRM_ST_CD', brokervar='BROKER_NAME_GRIP')
    dt[['SalesOffice', 'Region']] = dt[['SalesOffice', 'Region']].fillna('')

    quotes = dt[dt['COMP_CD'] == 'Quoted']
    sales = dt[dt['COMP_CD'] == 'Sales$']
    ag_s = sales.groupby(metvar)['PREMIUM', 'CVR_CNT'].sum().reset_index().rename(columns={'PREMIUM': 'AvgSales',
                                                                                           'CVR_CNT': 'AvgSoldCvg'})
    ag_s['AvgSales'] = ag_s['AvgSales']/3
    ag_s['AvgSoldCvg'] = ag_s['AvgSoldCvg']/3
    ag_quotes = quotes.groupby(metvar)['QT_PCT'].sum().reset_index(name='AvgQuotes')
    ag_quotes['QT_PCT'] = ag_quotes['QT_PCT']/3
    ag = ag_s.merge(ag_quotes, how='outer', on=metvar)
    ag[['AvgSales', 'AvgSoldCvg', 'AvgQuotes']].fillna(0, inplace=True)
    ag.to_pickle('./pickles/Sales_Calculation' + suffix + '.pkl')


def met_combine(suffix, profit_path, persistency_path, salesquote_path,
                metvar,
                inscope_products=met_inscope_products):
    profit = pd.read_pickle(profit_path + suffix + '.pkl')
    persistency = pd.read_pickle(persistency_path + suffix + '.pkl')
    salesquote = pd.read_pickle(salesquote_path + suffix + '.pkl')
    all_ = profit.merge(persistency, by=metvar, how='outer')
    all_ = all_.merge(salesquote, by=metvar, how='outer')
    all_ = all_.rename({'CVR_GRP_SCOR_CARD_CD': {'DENTAL': 'Dental',
                                                 'HL': 'Legal',
                                                 'TERM LIFE': 'Life',
                                                 'VISION': 'Vision'}})
    all_ = all_.rename(columns={'BROKER_NAME_GRIP': 'Broker'})
    all_.to_pickle('./pickles/Met_Metrics' + suffix + '.pkl')
    all_.to_excel('./outputs/Met_Metrics' + suffix + '.xlsx')

######### met_add_fields_to_PIT_share_functions #########
def met_add_field(dt, zip_st_mapping, met_finance_asmp,
                  market_type, RM=True,
                  size_cut=size_cut,
                  allprods=['Medical', 'Dental', 'Life', 'LTD', 'STD', 'Vision', 'CI', 'Accident', 'Hospital', 'Legal'],
                  mod='met_add_field'):
    
    dt = dt.merge(zip_st_mapping, left_on='Broker_Zip', right_on='Zip', how='left')
    dt['ST'] = dt['ST'].fillna('')
    dt['FL'] = np.where((dt['Broker_State'] != dt['ST']) & (dt['Broker_State'] != '') & (dt['ST'] != ''), 1, 0)
    dt['Broker_State'] = np.where(dt['FL'] == 1, dt['ST'], dt['Broker_State'])
    dt = dt.drop(['ST', 'FL'], axis=1)
    dt = dt.merge(zip_st_mapping, left_on='BrokerCrossProductZIP', right_on='Zip', how='left')
    dt['ST'] = dt['ST'].fillna('')
    dt['FL'] = np.where((dt['BrokerCrossProductSTATE'] != dt['ST']) & (dt['BrokerCrossProductSTATE'] != '') & (dt['ST'] != ''), 1, 0)
    dt['BrokerCrossProductSTATE'] = np.where(dt['FL'] == 1, dt['ST'], dt['BrokerCrossProductSTATE'])
    dt = dt.drop(['ST'], axis=1)

    dt['STATE_EIN'] = dt['STATE_EIN'].astype(str) + dt['EIN'].astype(str)
    dt = dt.sort_values(['STATE_EIN', 'Year', 'Product', 'Members', 'Carrier'], ascending=[True, True, True, False, True])
    dt['CarrierIND'] = customer.groupby(['STATE_EIN','Year','Product'])['Carrier'].cumcount(1).add(1)
    map_ = dt[dt['Product'] == 'Medical'][['STATE_EIN', 'Carrier', 'CarrierIND', 'Year', 'PN', 'Members']]
    map_['CT'] = dt.groupby(['STATE_EIN','CarrierIND','Year'])['Members'].count()
    for i in range(1, 3):
        sub = map_[map_['CarrierIND'] == i]
        sub = sub.drop('CarrierIND', axis=1)
        carVar = 'Medical_Car' + str(i)
        sub = sub.rename(columns={'Carrier': carVar})
        dt = dt.merge(sub[['STATE_EIN', 'Year', carVar]], on=['STATE_EIN', 'Year'], how='left')
        dt[carVar] = dt[carVar].fillna('')
    dt = dt[dt['Product'] != 'Medical']


    dt = dt.merge(met_finance_asmp[['Product', 'PMPM', 'RenewFreq']], on='Product', how='inner')
    dt['EstProd_Prem_Carrier'] = 12 * dt['Members'] * dt['PMPM'] / 1000
    dt = add_size_band(dt=dt, size_cut=size_cut)
    if market_type == 'Regional Market':
        dt = dt[dt['Size_Band'] != '5000+']
    if market_type == 'National Account':
        dt = dt[dt['Size_Band'] != '100-5000']
    
    dt = met_add_market(dt, zipvar='Broker_Zip', outputvar='SalesOffice', Statevar='Broker_State',
                        outputvarRegion='Region', brokervar='Broker')
    dt[['SalesOffice', 'Region']] = dt[['SalesOffice', 'Region']].fillna('')
    dt = met_add_market(dt, zipvar='BrokerCrossProductZIP', outputvar='SalesOfficePrimary',
                        outputvarRegion='RegionPrimary', Statevar='BrokerCrossProductSTATE', brokervar='BrokerCrossProduct')
    dt[['SalesOfficePrimary', 'RegionPrimary']] = dt[['SalesOfficePrimary', 'RegionPrimary']].fillna('')
    na = dt.loc[:, dt.isnull().any()].columns.values
    if len(na) > 0:
        print(na, 'columns contain NULL values for mod:', mod)
        raise Exception('Data contains NAs')
    byvars = ['Year','STATE_EIN','PN','Carrier','product','Funding']
    dt['CT'] = dt.groupby(byvars)['Members'].count()
    if dt[dt['CT'] > 1]['CT'].sum() > 0:
        print('not unique at ', byvars)
        raise Exception('Values not unique')
    return dt


######### BundlingAnalysis_share_functions #########
def BundlingTrend(dt=group_Product_carrier_ally, BaseProduct='Medical',
                  mod='Bundling_trend_by_Year', size_cut=[500, 1000, 5000],
                  byvars='Year', OVERALL=True, car='Overall'):

    mod = mod + ' for ' + BaseProduct
    if market_type == 'Regional Market':
        dt = dt[dt['EIN_FTE'] <= 5000]
    if market_type == 'National Account':
        dt = dt[dt['EIN_FTE'] > 5000]

    dt['STATE_EIN'] = dt['State_HQ'] + dt['EIN']
    dt = add_size_band(dt=dt, size_cut=size_cut)
    dt = met_add_market(dt, zipvar='BrokerCrossProductZIP', outputvar='SalesOfficePrimary',
                        outputvarRegion='RegionPrimary', Statevar='BrokerCrossProductSTATE',
                        brokervar='BrokerCrossProduct')
    dt[['SalesOfficePrimary', 'RegionPrimary']] = dt[['SalesOfficePrimary', 'RegionPrimary']].fillna('')
    coreprod = ["Medical", "Life", "LTD", "STD","Vision","Dental"]
    coreGB = ["Life", "LTD", "STD","Vision","Dental"]
    coreVB = [ "CI", "Accident", "Hospital", "Legal"]

    def groupby1(x):
      d = {}
      d["OfferMedical"] = 1 if (x['Product'] == 'Medical').any() else 0
      d["OfferLife"] = 1 if (x['Product'] == 'Life').any() else 0
      d["OfferVision"] = 1 if (x['Product'] == 'Vision').any() else 0
      d["OfferLTD"] = 1 if (x['Product'] == 'LTD').any() else 0
      d["OfferSTD"] = 1 if (x['Product'] == 'STD').any() else 0
      d["OfferDental"] = 1 if (x['Product'] == 'Dental').any() else 0
      d["OfferCI"] = 1 if (x['Product'] == 'CI').any() else 0
      d["OfferAccident"] = 1 if (x['Product'] == 'Accident').any() else 0
      d["OfferHospital"] = 1 if (x['Product'] == 'Hospital').any() else 0
      d["OfferLegal"] = 1 if (x['Product'] == 'Legal').any() else 0
      return pd.Series(d, index=["OfferMedical", "OfferLife", "OfferVision", "OfferLTD",
                                 "OfferSTD", "OfferDental", "OfferCI", "OfferAccident", "OfferHospital", "OfferLegal"])
    map_ = dt.groupby(["State_HQ","STATE_EIN", byvars, 'Size_Band']).apply(groupby1).reset_index()

    def groupby1(x):
      d = {}
      d["Medical"] = 1 if (x['Product'] == 'Medical').any() else 0
      d["Life"] = 1 if (x['Product'] == 'Life').any() else 0
      d["Vision"] = 1 if (x['Product'] == 'Vision').any() else 0
      d["LTD"] = 1 if (x['Product'] == 'LTD').any() else 0
      d["STD"] = 1 if (x['Product'] == 'STD').any() else 0
      d["Dental"] = 1 if (x['Product'] == 'Dental').any() else 0
      d["CI"] = 1 if (x['Product'] == 'CI').any() else 0
      d["Accident"] = 1 if (x['Product'] == 'Accident').any() else 0
      d["Hospital"] = 1 if (x['Product'] == 'Hospital').any() else 0
      d["Legal"] = 1 if (x['Product'] == 'Legal').any() else 0
      return pd.Series(d, index=["Medical", "Life", "Vision", "LTD", "STD", "Dental", "CI", "Accident", "Hospital", "Legal"])
    prodXgroup = dt.groupby(["State_HQ","STATE_EIN", 'Carrier', byvars, 'Size_Band']).apply(groupby1).reset_index()
    dt = map_.merge(prodXgroup, on=["State_HQ","STATE_EIN", byvars, 'Size_Band'])
    df = dt.copy()
    na = dt.loc[:, dt.isnull().any()].columns.values
    if len(na) > 0:
        print(na, 'columns contain NULL values')
        raise Exception('Data contains NAs')
    df = df[(df["OfferMedical" == 1]) & ~(df['Carrier'].isin(["", "Not Provided"]))]
    df = df[df["Carrier"] in ["", "Not Provided"]]
    prods = [i for i in (coreprod + coreVB) if i != BaseProduct]
    bcbs_names = ['BCBS', 'Blue Shield', 'Blue Cross', 'Blueshield', 'Bluecross']
    df['Carrier'] = np.where(df['Carrier'].str.contains('|'.join(bcbs_names)), 'BCBS', df['Carrier'])
    if OVERALL:
        bundles = bundlingTrendOverall(dt=df, BaseProduct=BaseProduct, prods=prods, 
                                       byvars=byvars)
    else:
        for i in range(1, len(prods) + 1):
            v = prods[i]


######### top_broker_carrier_per_state_functions #########
def create_top_brok_car_by_state(Product, USE_BROKER_STATE, BROKER_OR_CARRIER,
                                 size_lim, y2=end_yr, dt=group_Product_carrier_ally):
    y1 = y2 - 2
    op_file_name = 'Top_' + BROKER_OR_CARRIER + '_regional_' + Product + '.pkl'
    dt = dt[(dt['Year'] >= y1) & (dt['Year'] <= y2)]
    dt = dt[dt['Product'] == Product]
    dt['DROP'] = np.where(((dt['Members'] > size_lim) | (dt['EIN_FTE'] > size_lim)), 1, 0)
    dt = dt[dt['DROP'] == 0]
    if BROKER_OR_CARRIER == 'Broker':
        dt = dt[dt['Broker'] != '']
        byvars = ["State", "Broker"]
    if BROKER_OR_CARRIER == 'Carrier':
        dt = dt[~dt['Carrier'].isin(['', '0', 0, 'Not Provided'])]
        byvars = ["State", "Carrier"]
    if USE_BROKER_STATE:
        dt['State'] = dt['Broker_State']
    else:
        dt['State'] = dt['State_HQ']

    ag = dt.groupby(byvars).agg({'Members': [('Groups', 'count'), ('Members', 'sum')]}).reset_index()
    ag.columns = [i[0] if i[1] == '' else i[1] for i in ag.columns]
    ag['KEY'] = roung(ag['Groups'] + (ag['Members'] / 200))
    ag = ag.sort_values(['ag', 'State', 'KEY'], ascending=[True, True, False])
    ag['Rank'] = ag.groupby('KEY')['State'].cumcount() + 1
    ag = ag.drop(['KEY'], axis=1)
    ag.to_pickle('./pickles/' + op_file_name)


def top_brok_car_by_state(ag, Product, BROKER_OR_CARRIER,
                          broker_num=1, carrier_num=1):
    ag = ag[ag['Groups'] > 10]
    if BROKER_OR_CARRIER == 'Broker':
        x = ag[ag['Rank'] <= broker_num][['State', 'Broker']]
        return x
    if BROKER_OR_CARRIER == 'Carrier':
        x = ag[ag['Rank'] <= carrier_num][['State', 'Carrier']]
        return x


def EditBrokerCarrier(df, ag, broker, state_var, imputed_term, client,
                      LONGITUDINAL=False, BROKERFLOW=False, EDIT_BROKER=False,
                      EDIT_CARRIER=False, brokervar='Broker1',
                      Carriervar='Carrier', lob='', CoreORALL='Core',
                      client='Metlife', carrier_num=10, broker_num=50):
    if 'State' not in df.columns:
        df['State'] = df['state_var']
        noState = True
    else:
        noState = False

    if EDIT_BROKER:
        if LONGITUDINAL:
            brokers = top_brok_car_by_state(ag, broker_num=broker_num, Product=lob, BROKER_OR_CARRIER="Broker")
            broker['KEEPBROKER'] = 1
            df = df.merge(broker, how='left', left_on=['Broker1_Base', 'State'], right_on=['Broker', 'State'])
            df['KEEPBROKER'] = df['KEEPBROKER'].fillna(0)
            df['Broker1_Post'] = np.where((df['KEEPBROKER'] == 1) | (df['Broker1_Post'] == ''), df['Broker1_Post'], 'Other')
            df = df.drop('KEEPBROKER', axis=1)

        if BROKERFLOW:
            broker_allprod = pd.DataFrame()
            for Product in ["Dental", "Life", "LTD", "STD", "Vision"]:
                brokers = top_brok_car_by_state(broker_num=broker_num, Product=Product, BROKER_OR_CARRIER="Broker")
                broker_allprod = broker_allprod.append(brokers)
            broker_allprod = broker_allprod.drop_duplciates()
            broker_allprod['KEEPBROKER'] = 1

            df = df.merge(broker_allprod, how='left', left_on=['Broker_Base', 'State'], right_on=['Broker', 'State'])
            df['KEEPBROKER'] = df['KEEPBROKER'].fillna(0)
            df['Broker_Base'] = np.where((df['KEEPBROKER'] == 1) | (df['Broker_Base'] == ''), df['Broker_Base'], 'Other')
            df = df.merge(broker_allprod, how='left', left_on=['Broker_Post', 'State'], right_on=['Broker', 'State'])
            df['KEEPBROKER'] = df['KEEPBROKER'].fillna(0)
            df['Broker_Post'] = np.where((df['KEEPBROKER'] == 1) | (df['Broker_Post'] == ''), df['Broker_Post'], 'Other')
            df = df.drop('KEEPBROKER', axis=1)

        if not LONGITUDINAL and not BROKERFLOW:
            df['VAR'] = df['brokervar']
            broker_allprod = pd.DataFrame()
            for Product in ["Dental", "Life", "LTD", "STD", "Vision"]:
                brokers = top_brok_car_by_state(broker_num=broker_num, Product=Product, BROKER_OR_CARRIER="Broker")
                broker_allprod = broker_allprod.append(brokers)
            broker_allprod = broker_allprod.drop_duplciates()
            broker_allprod['KEEPBROKER'] = 1
            df = df.merge(broker_allprod, how='left', left_on=['VAR', 'State'], right_on=['Broker', 'State'])
            df['KEEPBROKER'] = df['KEEPBROKER'].fillna(0)
            df['VAR'] = np.where((df['KEEPBROKER'] == 1) | (df['VAR'] == ''), df['VAR'], 'Other')
            df[brokervar + '_Init'] = df['brokervar']
            df['brokervar'] = df['VAR']
            df = df.drop(['VAR', 'KEEPBROKER'], axis=1)

    if EDIT_CARRIER:
        if LONGITUDINAL:
            carriers = top_brok_car_by_state(carrier_num=carrier_num, Product=lob, BROKER_OR_CARRIER="Carrier")
            carriers['KEEPCARRIER'] = 1
            df = df.merge(carriers, how='left', left_on=['Carrier_Base', 'State'], right_on=['Carrier', 'State'])
            df['KEEPCARRIER'] = df['KEEPCARRIER'].fillna(0)
            df['KEEPCARRIER'] = np.where((df['Carrier_Base'].isin([imputed_term, client])), 1, df['KEEPCARRIER'])
            df['Carrier_Base'] = np.where(df['KEEPCARRIER'] == 0, 'Other', df['Carrier_Base'])
            df = df.drop('KEEPCARRIER', axis=1)
            df = df.merge(carriers, how='left', left_on=['Carrier_Post', 'State'], right_on=['Carrier', 'State'])
            df['KEEPCARRIER'] = df['KEEPCARRIER'].fillna(0)
            df['KEEPCARRIER'] = np.where((df['Carrier_Post'].isin([imputed_term, client])), 1, df['KEEPCARRIER'])
            df['Carrier_Post'] = np.where(df['KEEPCARRIER'] == 0, 'Other', df['Carrier_Post'])
            df = df.drop('KEEPCARRIER', axis=1)
        else:
            df['VAR'] = df['Carriervar']
            carriers_allprod = pd.DataFrame()
            if CoreORALL == 'Core':
                plist = ["Dental", "Life", "LTD", "STD", "Vision"]
            else:
                plist = ["Dental", "Life", "LTD", "STD", "Vision", "CI", "Accident", "Hospital", "Legal"]
            for Product in plist:
                carriers = top_brok_car_by_state(carrier_num=carrier_num, Product=lob, BROKER_OR_CARRIER="Carrier")
                carriers_allprod = carriers_allprod.append(carriers)
            carriers_allprod = carriers_allprod.drop_duplciates()
            carriers_allprod['KEEPCARRIER'] = 1
            df = df.merge(carriers_allprod, how='left', left_on=['VAR', 'State'], right_on=['Carrier', 'State'])
            df['KEEPCARRIER'] = df['KEEPCARRIER'].fillna(0)
            df['KEEPCARRIER'] = np.where((df['Carrier'].isin([imputed_term, client])), 1, df['KEEPCARRIER'])
            df['VAR'] = np.where(df['KEEPCARRIER'] == 0, 'Other', df['VAR'])
            df['Carrier_Init'] = df['Carriervar']
            df['Carriervar'] = df['VAR']
            df = df.drop(['VAR', 'KEEPCARRIER'], axis=1)

    if noState:
        df = df.drop('STATE', axis=1)
    return df


######### Carrier_Penetration_share_functions #########
def State_Carrier_aggregation(carrier_num, dt=groupdt, byvars=["Year", "State", "Product"],
                              CoreProducts=["Dental", "Life", "LTD", "STD", "Vision"],
                              Statevar="Broker_State", Years=list(range(2014, 2018)),
                              broker_num=50, CoreORALL="Core", EDIT_BROKER=True, keepall=False):

    # the use of corebyvars is for customizing regional view, and before we aggregate at the end, we need the most granular level
    if 'Size_Band' in byvars:
        corebyvar = ["Region", "Broker_State", "SalesOffice", "Broker", "Product","Year","Size_Band"]
    else:
        corebyvar = ["Region", "Broker_State", "SalesOffice", "Broker", "Product","Year"]
    # in broker deep dive, we need broker field, but in migration view, we don't want it and we can differentiate it by byvars
    if 'Broker' not in byvars:
        corebyvar = [i for i in corebyvar if i != 'Broker']
    dt = dt[dt['Year'].isin(Years)]
    if CoreORALL == 'Core':
      dt = dt[dt['Product'].isin(CoreProducts)]
    if 'Broker' in byvars:
        dt = EditBrokerCarrier(dt=dt, LONGITUDINAL=False, EDIT_BROKER=EDIT_BROKER, carrier_num=broker_num,
                               state_var=Statevar, brokervar="Broker")

    def groupby_ein_product(x):
        d = {}
        d['EstProd_Prem_Carrier'] = x['EstProd_Prem_Carrier'].sum()
        d['Members'] = x['Members'].sum()
        d['EIN_FTE'] = x['EIN_FTE'].sum()
        d['DummyASOUnder1KPrem'] = x[(x['Carrier'] == 'Not Provided')
                                     & (x['Funding'] == 'SI')
                                     & (x['EIN_FTE'] < 1000)]['EstProd_Prem_Carrier'].sum()
        d['DummyASOUnder1KMembers'] = x[(x['Carrier'] == 'Not Provided')
                                        & (x['Funding'] == 'SI')
                                        & (x['EIN_FTE'] < 1000)]['Members'].sum()
        d['DummyASOUnder1KFTE'] = x[(x['Carrier'] == 'Not Provided')
                                    & (x['Funding'] == 'SI')
                                    & (x['EIN_FTE'] < 1000)]['EIN_FTE'].sum()
        d['DummyASOUnder1KGroup'] = len(x[(x['Carrier'] == 'Not Provided')
                                          & (x['Funding'] == 'SI')
                                          & (x['EIN_FTE'] < 1000)])
        return pd.Series(d, index=['EstProd_Prem_Carrier', 'Members', 'EIN_FTE',
                                   'DummyASOUnder1KPrem', 'DummyASOUnder1KMembers',
                                   'DummyASOUnder1KFTE', 'DummyASOUnder1KGroup'])
    EIN_Product = dt.groupby([corebyvar, "Carrier", "STATE_EIN"]).apply(groupby_ein_product).reset_index()

    def groupby_pin_product(x):
        d = {}
        d['BasePremEquivalent'] = x['EstProd_Prem_Carrier'].sum()
        d['BaseMemberser'] = x['Members'].sum()
        d['BaseSIMemberser'] = x['SIMembers'].sum()
        d['BaseFTE'] = x['EIN_FTE'].sum()
        d['BaseGroups'] = x['STATE_EIN'].count()
        d['DummyASOUnder1KPrem'] = x['DummyASOUnder1KPrem'].sum()
        d['DummyASOUnder1KMembers'] = x['DummyASOUnder1KMembers'].sum()
        d['DummyASOUnder1KFTE'] = x['DummyASOUnder1KFTE'].sum()
        d['DummyASOUnder1KGroup'] = x['DummyASOUnder1KGroup'].sum()
        return pd.Series(d, index=['BasePremEquivalent', 'BaseMemberser',
                                   'BaseSIMemberser', 'BaseFTE', 'BaseGroups',
                                   'DummyASOUnder1KPrem', 'DummyASOUnder1KMembers',
                                   'DummyASOUnder1KFTE', 'DummyASOUnder1KGroup'])
    PIT_Product = EIN_Product.groupby(corebyvar + ['Carrier']).apply(groupby_pin_product).reset_index()

    # adjust for Market share due to dummy account by state/Product for premium and groups
    # get state total
    PIT_Product['StateTotPremEst'] = PIT_Product.groupby(corebyvar)['BasePremEquivalent'].transform('sum')
    PIT_Product['StateTotMemberserEst'] = PIT_Product.groupby(corebyvar)['BaseMemberser'].transform('sum')
    PIT_Product['StateTotSIMemberserEst'] = PIT_Product.groupby(corebyvar)['BaseSIMemberser'].transform('sum')
    PIT_Product['StateTotGroupsEst'] = PIT_Product.groupby(corebyvar)['BaseGroups'].transform('sum')
    PIT_Product['StateTotFTEEst'] = PIT_Product.groupby(corebyvar)['BaseFTE'].transform('sum')

    # use reported filing to estimate penetration
    PIT_Product['StateTotPremReported'] = PIT_Product[PIT_Product['Carrier'] != 'Not Provided'].groupby(corebyvar)['BasePremEquivalent'].transform('sum')
    PIT_Product['StateTotGroupsReported'] = PIT_Product[PIT_Product['Carrier'] != 'Not Provided'].groupby(corebyvar)['BaseGroups'].transform('sum')
    PIT_Product['StateTotMembersReported'] = PIT_Product[PIT_Product['Carrier'] != 'Not Provided'].groupby(corebyvar)['BaseMemberser'].transform('sum')
    PIT_Product['StateTotFTEReported'] = PIT_Product[PIT_Product['Carrier'] != 'Not Provided'].groupby(corebyvar)['BaseFTE'].transform('sum')
    PIT_Product['StateTotSIMembersReported'] = PIT_Product[PIT_Product['Carrier'] != 'Not Provided'].groupby(corebyvar)['BaseSIMemberser'].transform('sum')
    PIT_Product[['StateTotPremReported', 'StateTotGroupsReported', 'StateTotMembersReported',
                 'StateTotFTEReported', 'StateTotSIMembersReported']] = PIT_Product[['StateTotPremReported',
                                                                                     'StateTotGroupsReported',
                                                                                     'StateTotMembersReported',
                                                                                     'StateTotFTEReported',
                                                                                     'StateTotSIMembersReported']].fillna(0)
    PIT_Product['CarrierPenetration_prem_raw'] = PIT_Product[PIT_Product['Carrier'] != 'Not Provided']['BasePremEquivalent']\
                                                 PIT_Product[PIT_Product['Carrier'] != 'Not Provided']['StateTotPremReported']
    PIT_Product['CarrierPenetration_grps_raw'] = PIT_Product[PIT_Product['Carrier'] != 'Not Provided']['BaseGroups']\
                                                 PIT_Product[PIT_Product['Carrier'] != 'Not Provided']['StateTotGroupsReported']
    PIT_Product[['CarrierPenetration_prem_raw', 'CarrierPenetration_grps_raw']] = PIT_Product[['CarrierPenetration_prem_raw', 'CarrierPenetration_grps_raw']].fillna(0)
    # get dummy account under 1K
    PIT_Product['StateDummyASOUnder1KPrem'] = PIT_Product.groupby(corebyvar)['DummyASOUnder1KPrem'].transform('sum')
    PIT_Product['StateDummyASOUnder1KMembers'] = PIT_Product.groupby(corebyvar)['DummyASOUnder1KMembers'].transform('sum')
    PIT_Product['StateDummyASOUnder1KFTE'] = PIT_Product.groupby(corebyvar)['DummyASOUnder1KFTE'].transform('sum')
    PIT_Product['StateDummyASOUnder1KGroup'] = PIT_Product.groupby(corebyvar)['DummyASOUnder1KGroup'].transform('sum')

    PIT_Product['TotalNonMetSharePrem'] = PIT_Product[PIT_Product['Carrier'] != 'Metlife']\
    .groupby(corebyvar)['CarrierPenetration_prem_raw']\
    .transform('sum')
    PIT_Product['TotalNonMetShareGrps'] = PIT_Product[PIT_Product['Carrier'] != 'Metlife']\
    .groupby(corebyvar)['CarrierPenetration_grps_raw']\
    .transform('sum')
    PIT_Product[['TotalNonMetSharePrem', 'TotalNonMetShareGrps']] = PIT_Product[['TotalNonMetSharePrem', 'TotalNonMetShareGrps']].fillna(0)
    #MetLife do not offer ASO under 1K 
    #adjust prem
    temp_df = PIT_Product[~PIT_Product['Carrier'].isin(['Metlife', "Not Provided"])]
    PIT_Product['BasePremDummyASOUnder1KPrem'] = temp_df['CarrierPenetration_prem_raw']\
                                                 / temp_df['TotalNonMetSharePrem']\
                                                 * temp_df['StateDummyASOUnder1KPrem']
    PIT_Product['BasePremDummyASOUnder1KPrem'] = PIT_Product['BasePremDummyASOUnder1KPrem'].fillna(0)
    PIT_Product['BasePremDummyOther'] = PIT_Product['CarrierPenetration_prem_raw'] * (PIT_Product['StateTotPremEst']\
                                                                                      - PIT_Product['StateTotPremReported']\
                                                                                      - PIT_Product['StateDummyASOUnder1KPrem'])
    temp_df = PIT_Product[~PIT_Product['Carrier'] == 'Not Provided']
    PIT_Product['BasePremEst'] = temp_df['BasePremEquivalent']
    PIT_Product['BasePremEst'] = PIT_Product['BasePremEst'].fillna(0)
    PIT_Product['BasePremEst'] = PIT_Product['BasePremEst'] + PIT_Product['BasePremDummyASOUnder1KPrem'] + PIT_Product['BasePremDummyOther']
    #adjust groups
    temp_df = PIT_Product[~PIT_Product['Carrier'].isin(['Metlife', "Not Provided"])]
    PIT_Product['BaseGroupDummyASOUnder1K'] = temp_df['CarrierPenetration_grps_raw']\
                                                 / temp_df['TotalNonMetShareGrps']\
                                                 * temp_df['StateDummyASOUnder1KGroup']
    PIT_Product['BaseGroupDummyASOUnder1K'] = PIT_Product['BaseGroupDummyASOUnder1K'].fillna(0)
    PIT_Product['BaseGroupDummyOther'] = PIT_Product['CarrierPenetration_grps_raw'] * (PIT_Product['StateTotGroupsEst']\
                                                                                      - PIT_Product['StateTotGroupsReported']\
                                                                                      - PIT_Product['StateDummyASOUnder1KGroup'])
    temp_df = PIT_Product[~PIT_Product['Carrier'] == 'Not Provided']
    PIT_Product['BaseGroupEst'] = temp_df['BaseGroups']
    PIT_Product['BaseGroupEst'] = PIT_Product['BaseGroupEst'].fillna(0)
    PIT_Product['BaseGroupEst'] = PIT_Product['BaseGroupEst'] + PIT_Product['BaseGroupDummyASOUnder1K'] + PIT_Product['BaseGroupDummyOther']
    #adjust Memberser
    temp_df = PIT_Product[~PIT_Product['Carrier'].isin(['Metlife', "Not Provided"])]
    PIT_Product['BaseMembersDummyASOUnder1K'] = temp_df['CarrierPenetration_prem_raw']\
                                                 / temp_df['TotalNonMetSharePrem']\
                                                 * temp_df['StateDummyASOUnder1KMembers']
    PIT_Product['BaseMembersDummyASOUnder1K'] = PIT_Product['BaseMembersDummyASOUnder1K'].fillna(0)
    PIT_Product['BaseMembersDummyOther'] = PIT_Product['CarrierPenetration_prem_raw'] * (PIT_Product['StateTotMemberserEst']\
                                                                                      - PIT_Product['StateTotMembersReported']\
                                                                                      - PIT_Product['StateDummyASOUnder1KMembers'])
    temp_df = PIT_Product[~PIT_Product['Carrier'] == 'Not Provided']
    PIT_Product['BaseMembersEst'] = temp_df['BaseMemberser']
    PIT_Product['BaseMembersEst'] = PIT_Product['BaseMembersEst'].fillna(0)
    PIT_Product['BaseMembersEst'] = PIT_Product['BaseMembersEst']\
                                    + PIT_Product['BaseMembersDummyASOUnder1K']\
                                    + PIT_Product['BaseMembersDummyOther']
  
    #adjust FTE covered
    temp_df = PIT_Product[~PIT_Product['Carrier'].isin(['Metlife', "Not Provided"])]
    PIT_Product['BaseFTEDummyASOUnder1K'] = temp_df['CarrierPenetration_prem_raw']\
                                                 / temp_df['TotalNonMetSharePrem']\
                                                 * temp_df['StateDummyASOUnder1KFTE']
    PIT_Product['BaseFTEDummyASOUnder1K'] = PIT_Product['BaseFTEDummyASOUnder1K'].fillna(0)
    PIT_Product['BaseFTEDummyOther'] = PIT_Product['CarrierPenetration_prem_raw'] * (PIT_Product['StateTotFTEEst']\
                                                                                      - PIT_Product['StateTotFTEReported']\
                                                                                      - PIT_Product['StateDummyASOUnder1KFTE'])
    temp_df = PIT_Product[~PIT_Product['Carrier'] == 'Not Provided']
    PIT_Product['BaseFTEEst'] = temp_df['BaseFTE']
    PIT_Product['BaseFTEEst'] = PIT_Product['BaseFTEEst'].fillna(0)
    PIT_Product['BaseFTEEst'] = PIT_Product['BaseFTEEst']\
                                    + PIT_Product['BaseFTEDummyASOUnder1K']\
                                    + PIT_Product['BaseFTEDummyOther']

    # recalculate penetration
    PIT_Product = PIT_Product[PIT_Product['Carrier'] != 'Not Provided']
    PIT_Product = PIT_Product.groupby(byvars + ['Carrier'])['BasePremEst', 'BaseGroupEst'].sum().reset_index()
    temp_list = [i for i in byvars if i != 'Carrier']
    PIT_Product['StateTotPremEst'] = PIT_Product.groupby(temp_list)['BasePremEst'].transform('sum')
    PIT_Product['StateTotGroupsEst'] = PIT_Product.groupby(temp_list)['BaseGroupEst'].transform('sum')
    PIT_Product['CarrierPenetration_prem'] = PIT_Product['BasePremEst'] / PIT_Product['StateTotPremEst']
    PIT_Product['CarrierPenetration_grps'] = PIT_Product['BaseGroupEst'] / PIT_Product['StateTotGroupsEst']
  
    # export State x Carrier x Year BaseGroups/Premium and Penetration
    keepvars = byvars + ["Carrier", "BasePremEst", 'BaseGroupEst',
                         "CarrierPenetration_prem", "CarrierPenetration_grps",
                         "StateTotPremEst","StateTotGroupsEst"]
    if keepall:
        keepvars = list(set(keepvars + list(PIT_Product.columns)))
    PIT_Product = PIT_Product[keepvars]  
    return(PIT_Product)
